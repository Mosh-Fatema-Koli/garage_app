import 'package:flutter/material.dart';

class RowWidget2 extends StatelessWidget {
  const RowWidget2(
      {Key? key,
      required this.title,
      required this.value,
      required this.tfSize,
      required this.vfSize,
      required this.ttxtcolor})
      : super(key: key);
  final String title;
  final String value;
  final double tfSize;
  final double vfSize;
  final Color ttxtcolor;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Expanded(
          child: Text(
            title,
            textAlign: TextAlign.left,
            style: TextStyle(
              fontFamily: 'Roboto Slab',
              fontSize: tfSize,
              fontWeight: FontWeight.bold,
              color: ttxtcolor,
            ),
          ),
        ),
        //const Spacer(),

        Expanded(
            child: Center(
          child: Image(
            height: 40.0,
            width: 40,
            fit: BoxFit.cover,
            image: NetworkImage(value),
          ),
        ))
      ],
    );
  }
}
