import 'package:flutter/material.dart';

class TopView3 extends StatelessWidget {
  const TopView3({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      // transform: Matrix4.translationValues(0.0, 0.0, 0.0),
      child: Stack(
        clipBehavior: Clip.none,
        // alignment: Alignment.topCenter,
        children: [
          Image.asset(
            "assets/home/home_top.png",
            // height: 60,
            width: MediaQuery.of(context).size.width,
            fit: BoxFit.cover,
          ),
          Positioned(
            right: (MediaQuery.of(context).size.width - 184) / 2,
            bottom: 10,
            child: Image.asset(
              "assets/logo-instasure_small.png",
              height: 67,
              width: 184,
            ),
          ),
        ],
      ),
    );
  }
}
