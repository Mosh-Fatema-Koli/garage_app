import 'package:flutter/material.dart';

class ImageWidget extends StatelessWidget {
  final String imagePath;
  final VoidCallback onClicked;
  final double imageHeight;
  final double imageWidth;
  final double borderWidth;
  final double borderRadious;

  const ImageWidget({
    Key? key,
    required this.imagePath,
    required this.onClicked,
    required this.imageHeight,
    required this.imageWidth,
    required this.borderWidth,
    required this.borderRadious,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // final color = Theme.of(context).colorScheme.primary;

    return Center(
      child: buildImage(),
    );
  }

  Widget buildImage() {
    final image = AssetImage(imagePath);

    return Container(
        height: imageHeight,
        width: imageWidth,
        child: Padding(
            padding: EdgeInsets.all(borderWidth),
            child: Center(
              child: SizedBox(
                height: imageHeight - borderWidth,
                width: imageWidth - borderWidth,
                child: ClipRRect(
                  child: Image(
                    image: image,
                    fit: BoxFit.cover,
                  ),
                  borderRadius: BorderRadius.circular(borderWidth),
                ),
              ),
            )),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(borderRadious),
          boxShadow: const [
            BoxShadow(
                color: Color(0xFFFFFFFF),
                blurRadius: 6,
                spreadRadius: 0,
                offset: Offset(-3, -3)),
          ],
          color: const Color(0xffF0F3F6),
        ));
  }

  Widget buildCircle({
    required Widget child,
    required double all,
    required Color color,
  }) =>
      ClipOval(
        child: Container(
          padding: EdgeInsets.all(all),
          color: color,
          child: child,
        ),
      );
}
