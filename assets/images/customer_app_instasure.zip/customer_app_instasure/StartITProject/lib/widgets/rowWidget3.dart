import 'package:flutter/material.dart';

class RowWidget3 extends StatelessWidget {
  const RowWidget3(
      {Key? key,
      required this.title,
      required this.value,
      required this.tfSize,
      required this.vfSize,
      required this.txtcolor})
      : super(key: key);
  final String title;
  final String value;
  final double tfSize;
  final double vfSize;
  final Color txtcolor;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Expanded(
          child: Text(
            title,
            textAlign: TextAlign.left,
            style: TextStyle(
              fontFamily: 'Roboto Slab',
              fontWeight: FontWeight.bold,
              fontSize: tfSize,
              color: txtcolor,
            ),
          ),
        ),
        //const Spacer(),
        Expanded(
          child: Text(
            value,
            textAlign: TextAlign.left,
            style: TextStyle(
              fontFamily: 'Roboto Slab',
              fontSize: vfSize,
              color: txtcolor,
            ),
          ),
        )
      ],
    );
  }
}
