import 'package:flutter/material.dart';

class RowWidget extends StatelessWidget {
  const RowWidget(
      {Key? key, required this.title, required this.value, required this.fSize})
      : super(key: key);
  final String title;
  final String value;
  final double fSize;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Text(
          title,
          textAlign: TextAlign.left,
          style: TextStyle(
            fontFamily: 'Roboto Slab',
            fontSize: fSize,
            color: const Color(0xff002E5B),
          ),
        ),
        Expanded(
          child: Text(
            value,
            textAlign: TextAlign.left,
            style: TextStyle(
              fontFamily: 'Roboto Slab',
              fontSize: fSize,
              color: const Color(0xff86888A),
            ),
          ),
        )
      ],
    );
  }
}
