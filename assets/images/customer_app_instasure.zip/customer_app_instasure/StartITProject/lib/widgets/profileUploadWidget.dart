import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
class ProfileUploadWidget extends StatelessWidget {
  final String imagePath;
  final bool isEdit;
  final VoidCallback onClicked;

  const ProfileUploadWidget({
    Key? key,
    required this.imagePath,
    this.isEdit = false,
    required this.onClicked,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final color = Theme.of(context).colorScheme.primary;
    return Center(
      child: Column(
        children: [
          buildImageFront(),
          buildTitlleFront(),
          const SizedBox(
            height: 10,
          ),
          buildImageBack(),
          buildTitlleBack(),
        ],
      ),
    );
  }

  Widget buildImageFront() {
    final image = NetworkImage(imagePath);
    return GestureDetector(
      onTap: clickFront,
      child: Container(
          height: 150,
          width: 250,
          // color: Colors.red,
          child: Padding(
              padding: const EdgeInsets.all(5),
              child: Image.asset('assets/instasure_icon.png')),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(75),
            boxShadow: const [
              BoxShadow(
                  color: Color(0xFFFFFFFF),
                  blurRadius: 6,
                  spreadRadius: 0,
                  offset: Offset(-3, -3)),
            ],
            color: const Color(0xffF0F3F6),
          )),
    );
  }

  Widget buildImageBack() {
    final image = NetworkImage(imagePath);
    return Container(
        height: 150,
        width: 250,
        // color: Colors.red,
        child: Padding(
            padding: const EdgeInsets.all(5),
            child: Image.asset('assets/instasure_icon.png')),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(75),
          boxShadow: const [
            BoxShadow(
                color: Color(0xFFFFFFFF),
                blurRadius: 6,
                spreadRadius: 0,
                offset: Offset(-3, -3)),
          ],
          color: const Color(0xffF0F3F6),
        ));
  }

  Widget  buildTitlleFront(){
    return Container(
      alignment: Alignment.center,
      child: const Text(
        'Passport front',
        style: TextStyle(
            fontSize: 16,
            color: Color.fromRGBO(0, 0, 0, 0.87)),
      ),
    );
  }

  Widget  buildTitlleBack(){
    return Container(
      alignment: Alignment.center,
      child: const Text(
        'Passport back',
        style: TextStyle(
            fontSize: 16,
            color: Color.fromRGBO(0, 0, 0, 0.87)),
      ),
    );
  }

  Future<void> clickFront() async {
    final ImagePicker _picker = ImagePicker();
    final XFile? image = await _picker.pickImage(source: ImageSource.gallery);
    print(image);
  }
}
