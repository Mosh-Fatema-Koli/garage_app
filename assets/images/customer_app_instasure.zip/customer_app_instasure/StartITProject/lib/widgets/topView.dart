import 'package:flutter/material.dart';

class TopView extends StatelessWidget {
  const TopView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
        alignment: Alignment.center,
        //  padding: const EdgeInsets.only(bottom: 84),
        child: Image.asset(
          "assets/instasure_icon.png",
          height: 127,
          width: MediaQuery.of(context).size.width - 80,
          fit: BoxFit.fitWidth,
        )
        //
        );
  }
}
