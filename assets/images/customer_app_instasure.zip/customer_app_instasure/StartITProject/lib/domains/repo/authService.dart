// import 'package:dio/dio.dart';
import 'dart:io';

import 'package:instasure/domains/repo/authService_dio.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
//import '../../interfaces/login/login_interface.dart';

class AuthService extends AuthServiceDio {
  @override
  /*
  Future<UserModel?> login(String name, String phone, String password) async {
    final api = Uri.parse('https://dns.staritltdtest.website/api/register');
    final data = {"name": name, "phone": phone, "password": password};
    http.Response response;
    response = await http.post(api, body: data);
    if (response.statusCode == 200) {
      print("response:${response.body}");
      SharedPreferences storage = await SharedPreferences.getInstance();
      final body = json.decode(response.body);
      await storage.setString('TOKEN', body['token']);
      await storage.setString('PHONE', phone);
      return UserModel(phone: phone, token: body['token']);
    } else {
      return null;
    }
  }

  @override
  Future<UserModel?> getUser() async {
    SharedPreferences storage = await SharedPreferences.getInstance();
    final token = storage.getString('TOKEN');
    final phone = storage.getString('PHONE');
    if (token != null && phone != null) {
      return UserModel(phone: phone, token: token);
    } else {
      return null;
    }
  }
*/
  @override
  Future<bool> logout() async {
    SharedPreferences storage = await SharedPreferences.getInstance();
    final email = storage.getString('EMAIL');
    final token = storage.getString('TOKEN');
    if (email != null && token != null) {
      await storage.remove('TOKEN');
      await storage.remove('EMAIL');
      return true;
    } else {
      return false;
    }
  }
}
