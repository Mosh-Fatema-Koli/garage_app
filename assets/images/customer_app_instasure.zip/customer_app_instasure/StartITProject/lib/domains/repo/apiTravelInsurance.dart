import 'package:dio/dio.dart';
import 'package:instasure/Utilities/constant.dart';
import 'package:instasure/domains/repo/apis.dart';

class ApiTravelInsurance {
  final Dio _dio = Dio();

  Future<Response> getTravelInsuranceHistory(
      String accessToken, Map<String, dynamic> params) async {
    try {
      Response response = await _dio.get(
        Constants.BASE_URL + ApisEndPoints.travelInsuranceHistory,
        queryParameters: params,
        options: Options(headers: {'Authorization': 'Bearer $accessToken'}),
      );


      return response;
    } on DioError catch (e) {

      return e.response!;
    }
  }

  Future<Response> getTravelInsuranceHisDetailtData(
      String id, String accesstoken) async {
    try {
      Response response = await _dio.get(
        Constants.BASE_URL +
            ApisEndPoints.travelInsuranceHistoryDetail +
            '/$id',
        options: Options(
          headers: {
            'Authorization': 'Bearer $accesstoken',
          },
        ),
      );

    return response;
    } on DioError catch (e) {
      return e.response!;
    }
  }

  Future<Response> getTravelInsurancePlanData(
      Map<String, dynamic>? queryData, String accessToken) async {

    try {
      Response response = await _dio.post(
          Constants.BASE_URL + ApisEndPoints.travelInsurancePlan,
          data: queryData,
          options: Options(headers: {
            Headers.acceptHeader: "application/json",
            'Authorization': 'Bearer $accessToken'
          }));
      print('opo');
      print(response);
      print('zzz');
      return response;
    } on DioError catch (e) {
      return e.response!;
    }
  }

  Future<Response> getTravelInsuranceInvoiceData(
      String id, String accessToken) async {
    try {
      Response response = await _dio.get(
        Constants.BASE_URL + ApisEndPoints.travelInsuranceInvoice + '/$id',
        options: Options(headers: {
          'Authorization': 'Bearer $accessToken',
          'Accept': 'application/json',
        }),
      );
      return response;
    } on DioError catch (e) {
      return e.response!;
    }
  }

  Future<Response> travelInsuranceOrderCreate(
      Map<String, dynamic>? userData, String accesstoken) async {
    try {
      Response response = await _dio.post(
        Constants.BASE_URL + ApisEndPoints.travelInsuranceCreateOrder,
        data: userData,
        options: Options(
          headers: {
            'Authorization': 'Bearer $accesstoken',
            'Accept': 'application/json',
          },
        ),
      );
      return response;
    } on DioError catch (e) {
      return e.response!;
    }
  }

  Future<Response> getPlanCategory(
      Map<String, dynamic>? userData, String accesstoken) async {
    try {
      Response response = await _dio.post(
        Constants.BASE_URL + ApisEndPoints.getPlanCategory,
        data: userData,
        options: Options(
          headers: {
            'Authorization': 'Bearer $accesstoken',
            'Accept': 'application/json',
          },
        ),
      );
      return response;
    } on DioError catch (e) {
      return e.response!;
    }
  }

  Future<Response> travelInsuranceOrderPay(
      Map<String, dynamic>? data, String accesstoken) async {
    try {
      Response response = await _dio.post(
        Constants.BASE_URL + ApisEndPoints.payNow,
        data: data,
        options: Options(
          headers: {
            'Authorization': 'Bearer $accesstoken',
            'Accept': 'application/json',
          },
        ),
      );
      return response;
    } on DioError catch (e) {
      return e.response!;
    }
  }
}
