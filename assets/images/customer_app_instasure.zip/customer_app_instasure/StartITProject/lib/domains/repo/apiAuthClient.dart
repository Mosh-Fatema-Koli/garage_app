import 'package:dio/dio.dart';
import 'package:instasure/Utilities/constant.dart';
import 'package:instasure/domains/repo/apis.dart';
import 'package:http/http.dart' as http;

class ApiAuthClient {
  final Dio _dio = Dio();

  Future<Response> registerUser(Map<String, dynamic>? userData) async {
    try {
      Response response =
          await _dio.post(Constants.BASE_URL + ApisEndPoints.register,
              data: userData,
              options: Options(headers: {
                Headers.acceptHeader: "application/json",
              }));
      return response;
    } on DioError catch (e) {
      return e.response!;
    }
  }

  Future<Response> verifyOTP(Map<String, dynamic>? otpData) async {
    try {
      Response response =
          await _dio.post(Constants.BASE_URL + ApisEndPoints.optVerification,
              data: otpData,
              options: Options(headers: {
                Headers.acceptHeader: "application/json",
              }));
      return response;
    } on DioError catch (e) {
      return e.response!;
    }
  }

  Future<Response> login(Map<String, dynamic>? loginData) async {
    print(Constants.BASE_URL + ApisEndPoints.login);
    try {

      Response response =
          await _dio.post(Constants.BASE_URL + ApisEndPoints.login,
              data: loginData,
              options: Options(headers: {
                Headers.acceptHeader: "application/json",
              }));
      print(response);
      return response;


      /*final response2 = await http
          .post(Uri.parse(Constants.BASE_URL + ApisEndPoints.login));

      print(response2.body);

      Response response =
      await _dio.get('https://official-joke-api.appspot.com/random_joke',
          // data: loginData,
          options: Options(headers: {
            Headers.acceptHeader: "application/json",
          }));

      print(response);
      print('response');
      return response;*/






    } on DioError catch (e) {
      return e.response!;
    }
  }

  Future<Response> forgetPassword(Map<String, dynamic>? data) async {
    try {
      Response response =
          await _dio.post(Constants.BASE_URL + ApisEndPoints.forgetPassword,
              data: data,
              options: Options(headers: {
                Headers.acceptHeader: "application/json",
              }));
      return response;
    } on DioError catch (e) {
      return e.response!;
    }
  }

  Future<Response> phoneNumberCheck(Map<String, dynamic>? data) async {
    try {
      Response response =
          await _dio.post(Constants.BASE_URL + ApisEndPoints.phoneNumberCheck,
              data: data,
              options: Options(headers: {
                Headers.acceptHeader: "application/json",
              }));
      return response;
    } on DioError catch (e) {
      return e.response!;
    }
  }

  Future<Response> logout(String accessToken) async {
    try {
      Response response = await _dio.post(
        Constants.BASE_URL + ApisEndPoints.logout,
        options: Options(
          headers: {'Authorization': 'Bearer $accessToken'},
        ),
      );
      return response;
    } on DioError catch (e) {
      return e.response!;
    }
  }

  Future<Response> deviceInsurance(Map<String, dynamic>? deviceData,String accessToken) async {
    try {
      Response response =
      await _dio.post(Constants.BASE_URL + ApisEndPoints.login,
          data: deviceData,
          options: Options(headers: {
            'Authorization': 'Bearer $accessToken',
            'Accept': 'application/json',
          }));
      return response;
    } on DioError catch (e) {
      return e.response!;
    }
  }

}
