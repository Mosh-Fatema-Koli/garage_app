import 'package:dio/dio.dart';
import 'package:instasure/Utilities/constant.dart';
import 'package:instasure/domains/repo/apis.dart';

class ApiClientCustomerDasboard {
  final Dio _dio = Dio();

  Future<Response> getProfileData(String accesstoken) async {
    try {
      Response response = await _dio.get(
        Constants.BASE_URL + ApisEndPoints.customerProfile,
        options: Options(
          headers: {
            'Authorization': 'Bearer $accesstoken',
            'Accept': 'application/json',
          },
        ),
      );
      return response;
    } on DioError catch (e) {
      return e.response!;
    }
  }

  Future<Response> customerPasswordUpdate(
      Map<String, dynamic>? data, String accesstoken) async {
    try {
      Response response = await _dio.post(
          Constants.BASE_URL + ApisEndPoints.customerPasswordUpdate,
          data: data,
          options: Options(headers: {
            'Authorization': 'Bearer $accesstoken',
            'Accept': 'application/json',
          }));
      return response;
    } on DioError catch (e) {
      return e.response!;
    }
  }

  Future<Response> getDashBoardData(String accesstoken) async {
    try {
      Response response = await _dio.get(
        Constants.BASE_URL + ApisEndPoints.customerDashboard,
        options: Options(
          headers: {
            'Authorization': 'Bearer $accesstoken',
            'Accept': 'application/json',
          },
        ),
      );
      return response;
    } on DioError catch (e) {
      return e.response!;
    }
  }

  // Future<Response> getProfileData(String accesstoken) async {
  //   try {
  //     Response response = await _dio.get(
  //       Constants.BASE_URL + ApisEndPoints.customerProfile,
  //       queryParameters: {'apikey': 'YOUR_API_KEY'},
  //       options: Options(
  //         headers: {
  //           'Authorization': 'Bearer $accesstoken',
  //         },
  //       ),
  //     );
  //     return response.data;
  //   } on DioError catch (e) {
  //     return e.response!;
  //   }
  // }

  Future<Response> updateProfile(
      Map<String, dynamic>? profileData, String accesstoken) async {
    try {
      Response response = await _dio.post(
          Constants.BASE_URL + ApisEndPoints.customerProfileUpdate,
          data: profileData,
          options: Options(headers: {
            Headers.acceptHeader: "application/json",
          }));
      return response;
    } on DioError catch (e) {
      return e.response!;
    }
  }

  Future<Response> mobileDiagnosisReportStore(
      Map<String, dynamic>? data, String accesstoken) async {
    try {
      Response response = await _dio.post(
          Constants.BASE_URL + ApisEndPoints.mobileDiagnosisReportStore,
          data: data,
          options: Options(headers: {
            Headers.acceptHeader: "application/json",
          }));
      return response;
    } on DioError catch (e) {
      return e.response!;
    }
  }

  Future<Response> mobileDiagnosisReportDetails(
      String id, String accesstoken) async {
    try {
      Response response = await _dio.get(
        Constants.BASE_URL + ApisEndPoints.mobileDiagnosisReportDetails + '/$id',
        options: Options(
          headers: {
            'Authorization': 'Bearer $accesstoken',
            'Accept': 'application/json',
          },
        ),
      );
      return response;
    } on DioError catch (e) {
      return e.response!;
    }
  }


  Future<Response> mobileDiagnosisReportList(String accesstoken) async {
    try {
      Response response = await _dio.get(
        Constants.BASE_URL + ApisEndPoints.mobileDiagnosisReportList,
        options: Options(
          headers: {
            'Authorization': 'Bearer $accesstoken',
            'Accept': 'application/json',
          },
        ),
      );
      return response;
    } on DioError catch (e) {
      return e.response!;
    }
  }

  Future<Response> getDeviceInsurancePackage(
      String id, String accesstoken) async {
    try {
      Response response = await _dio.get(
        Constants.BASE_URL + ApisEndPoints.getDeviceInsurancePackage + '/$id',
        options: Options(
          headers: {
            'Authorization': 'Bearer $accesstoken',
            'Accept': 'application/json',
          },
        ),
      );
      return response;
    } on DioError catch (e) {
      return e.response!;
    }
  }

  Future<Response> purchaseDeviceInsurancePackage(
      Map<String, dynamic>? data, String accesstoken,String insuranceId) async {
    try {
      Response response = await _dio.post(
          Constants.BASE_URL + ApisEndPoints.purchaseDeviceInsurancePackage+ '/$insuranceId',
          data: data,
          options: Options(headers: {
            Headers.acceptHeader: "application/json",
          }));
      return response;
    } on DioError catch (e) {
      return e.response!;
    }
  }

  Future<Response> aamarpaySuccessResponse(
      Map<String, dynamic>? data, String accesstoken) async {
    try {
      Response response = await _dio.post(
          Constants.BASE_URL + ApisEndPoints.aamarpaySuccessResponse,
          data: data,
          options: Options(headers: {
            Headers.acceptHeader: "application/json",
          }));
      return response;
    } on DioError catch (e) {
      return e.response!;
    }
  }

  Future<Response> aamarpayCancleResponse(
      Map<String, dynamic>? data, String accesstoken) async {
    try {
      Response response = await _dio.post(
          Constants.BASE_URL + ApisEndPoints.aamarpayCancleResponse,
          data: data,
          options: Options(headers: {
            Headers.acceptHeader: "application/json",
          }));
      return response;
    } on DioError catch (e) {
      return e.response!;
    }
  }
}
