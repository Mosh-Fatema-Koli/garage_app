import 'package:dio/dio.dart';
import 'package:instasure/Utilities/constant.dart';
import 'package:instasure/domains/repo/apis.dart';

class ApiTourInsurance {
  final Dio _dio = Dio();

  Future<Response> getTourInsuranceHistory(
      String accessToken, Map<String, dynamic> params) async {
    try {
      Response response = await _dio.get(
        Constants.BASE_URL + ApisEndPoints.tourInsuranceHistory,
        queryParameters: params,
        options: Options(headers: {'Authorization': 'Bearer $accessToken'}),
      );
      print(response);


      return response;
    } on DioError catch (e) {

      return e.response!;
    }
  }



}
