import 'package:dio/dio.dart';
import 'package:instasure/Utilities/constant.dart';
import 'package:instasure/domains/repo/apis.dart';

class ApiClientDeviceInsurance {
  final Dio _dio = Dio();

  Future<Response> getDeviceInsuranceHistData(String accesstoken) async {
    try {
      Response response = await _dio.get(
        Constants.BASE_URL + ApisEndPoints.deviceInsuranceHistory,
        options: Options(
          headers: {
            'Authorization': 'Bearer $accesstoken',
            'Accept': 'application/json',
          },
        ),
      );
      return response;
    } on DioError catch (e) {
      return e.response!;
    }
  }

  Future<Response> getDeviceInsuranceHisDetailtData(
      String id, String accesstoken) async {
    try {
      Response response = await _dio.get(
        Constants.BASE_URL +
            ApisEndPoints.deviceInsuranceHistoryDetail +
            '/$id',
        options: Options(
          headers: {
            'Authorization': 'Bearer $accesstoken',
          },
        ),
      );
      return response;
    } on DioError catch (e) {
      return e.response!;
    }
  }

  Future<Response> deviceInsuranceSupportRequestForm(
      Map<String, dynamic>? data, String accesstoken) async {
    try {
      Response response = await _dio.post(
        Constants.BASE_URL + ApisEndPoints.deviceInsuranceSupportRequestForm,
        data: data,
        options: Options(
          headers: {
            'Authorization': 'Bearer $accesstoken',
            'Accept': 'application/json',
          },
        ),
      );
      return response;
    } on DioError catch (e) {
      return e.response!;
    }
  }

  Future<Response> deviceInsuranceSupportRequestStore(
      Map<String, dynamic>? data, String accesstoken) async {
    try {
      Response response = await _dio.post(
        Constants.BASE_URL + ApisEndPoints.deviceInsuranceSupportRequestStore,
        data: data,
        options: Options(
          headers: {
            'Authorization': 'Bearer $accesstoken',
            'Accept': 'application/json',
          },
        ),
      );
      return response;
    } on DioError catch (e) {
      return e.response!;
    }
  }

  Future<Response> deviceInsuranceSupportRequestStoreForLost(
      Map<String, dynamic>? data, String accesstoken) async {
    try {
      Response response = await _dio.post(
        Constants.BASE_URL +
            ApisEndPoints.deviceInsuranceSupportRequestStoreForLost,
        data: data,
        options: Options(
          headers: {
            'Authorization': 'Bearer $accesstoken',
            'Accept': 'application/json',
          },
        ),
      );
      return response;
    } on DioError catch (e) {
      return e.response!;
    }
  }

  Future<Response> getDistrictByDivision(
      Map<String, dynamic>? data, String accesstoken) async {
    try {
      Response response = await _dio.post(
        Constants.BASE_URL + ApisEndPoints.getDistrictByDivision,
        data: data,
        options: Options(
          headers: {
            'Authorization': 'Bearer $accesstoken',
            'Accept': 'application/json',
          },
        ),
      );
      return response;

      print(response);

    } on DioError catch (e) {
      return e.response!;
    }
  }

  Future<Response> getUpazilaByDistrict(
      Map<String, dynamic>? data, String accesstoken) async {
    try {
      Response response = await _dio.post(
        Constants.BASE_URL + ApisEndPoints.getUpazilaByDistrict,
        data: data,
        options: Options(
          headers: {
            'Authorization': 'Bearer $accesstoken',
            'Accept': 'application/json',
          },
        ),
      );
      return response;
    } on DioError catch (e) {
      return e.response!;
    }
  }

  Future<Response> getServiceCenter(
      Map<String, dynamic>? data, String accesstoken) async {
    try {
      Response response = await _dio.post(
        Constants.BASE_URL + ApisEndPoints.getServiceCenter,
        data: data,
        options: Options(
          headers: {
            'Authorization': 'Bearer $accesstoken',
            'Accept': 'application/json',
          },
        ),
      );
      return response;
    } on DioError catch (e) {
      return e.response!;
    }
  }

  Future<Response> getDeviceInsuranceSuppRequestData(String accesstoken) async {
    try {
      Response response = await _dio.get(
        Constants.BASE_URL + ApisEndPoints.deviceInsuranceSupportRequests,
        options: Options(
          headers: {
            'Authorization': 'Bearer $accesstoken',
            'Accept': 'application/json',
          },
        ),
      );
      return response;
    } on DioError catch (e) {
      return e.response!;
    }
  }

  Future<Response> getDeviceInsuranceClaimHistData(String accesstoken) async {
    try {
      Response response = await _dio.get(
        Constants.BASE_URL + ApisEndPoints.deviceInsuranceClaimHistory,
        options: Options(
          headers: {
            'Authorization': 'Bearer $accesstoken',
            'Accept': 'application/json',
          },
        ),
      );
      return response;
    } on DioError catch (e) {
      return e.response!;
    }
  }

  Future<Response> getDeviceInsuranceClaiDetailData(
      String id, String accesstoken) async {
    try {
      Response response = await _dio.get(
        Constants.BASE_URL + ApisEndPoints.deviceClaimDetails + '/$id',
        options: Options(
          headers: {
            'Authorization': 'Bearer $accesstoken',
            'Accept': 'application/json',
          },
        ),
      );
      return response;
    } on DioError catch (e) {
      return e.response!;
    }
  }

  Future<Response> getDeviceInsuranceClaimDetailDownloadData(
      String id, String accesstoken) async {
    try {
      Response response = await _dio.get(
        Constants.BASE_URL + ApisEndPoints.deviceClaimDetailsDownload + '/$id',
        options: Options(
          headers: {
            'Authorization': 'Bearer $accesstoken',
            'Accept': 'application/json',
          },
        ),
      );
      return response;
    } on DioError catch (e) {
      return e.response!;
    }
  }

  Future<Response> claimSubmit(Map<String, dynamic>? userData,String accesstoken) async {
    try {
      Response response =
      await _dio.post(Constants.BASE_URL + ApisEndPoints.register,
          data: userData,
          options: Options(headers: {
            Headers.acceptHeader: "application/json",
          }));
      return response;
    } on DioError catch (e) {
      return e.response!;
    }
  }


  Future<Response> payNowForDeviceInsurancePurchase(
      String? id, String accesstoken) async {
    try {
      Response response = await _dio.get(
        Constants.BASE_URL +
            ApisEndPoints.payNowForDeviceInsurancePurchase +
            "/$id",
        options: Options(
          headers: {
            'Authorization': 'Bearer $accesstoken',
            'Accept': 'application/json',
          },
        ),
      );
      return response;
    } on DioError catch (e) {
      return e.response!;
    }
  }
}
