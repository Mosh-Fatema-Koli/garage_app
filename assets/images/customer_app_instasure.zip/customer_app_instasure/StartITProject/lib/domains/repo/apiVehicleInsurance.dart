import 'package:dio/dio.dart';
import 'package:instasure/Utilities/constant.dart';
import 'package:instasure/domains/repo/apis.dart';

class ApiVehicleInsurance {
  final Dio _dio = Dio();

  Future<Response> getVehicleInsuranceForm(
      String accessToken, Map<String, dynamic> params) async {
    try {
      Response response = await _dio.get(
       'http://192.168.3.98:8000/api/motor_insurance_fields',
       // Constants.BASE_URL + ApisEndPoints.tourInsuranceHistory,
        queryParameters: params,
        options: Options(headers: {'Authorization': 'Bearer $accessToken'}),
      );
      print(response);


      return response;
    } on DioError catch (e) {

      return e.response!;
    }
  }


}