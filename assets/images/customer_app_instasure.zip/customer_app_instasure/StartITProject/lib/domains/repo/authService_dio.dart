import 'package:shared_preferences/shared_preferences.dart';
import 'package:dio/dio.dart';

abstract class AuthServiceDio {
  /*
  Future<UserModel?> login(String name, String phone, String password) async {
    final api = 'https://dns.staritltdtest.website/api/register';
    final data = {"name": name, "phone": phone, "password": password};
    final dio = Dio();

    Response response;
    response = await dio.post(api, data: data);
    if (response.statusCode == 200) {
      final body = response.data;
      return UserModel(phone: phone, token: body['token']);
    } else {
      return null;
    }
  }

  Future<UserModel?> getUser() async {
    SharedPreferences storage = await SharedPreferences.getInstance();
    final token = storage.getString('TOKEN');
    final phone = storage.getString('PHONE');
    if (token != null && phone != null) {
      return UserModel(phone: phone, token: token);
    } else {
      return null;
    }
  }
*/
  Future<bool> logout() async {
    SharedPreferences storage = await SharedPreferences.getInstance();
    return true;
  }
}
