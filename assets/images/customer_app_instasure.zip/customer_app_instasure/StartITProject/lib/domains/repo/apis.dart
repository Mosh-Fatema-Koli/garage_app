// Class for api tags
class ApisEndPoints {
  //Auth
  static const String register = 'register';
  static const String optVerification = 'opt_verification';
  static const String login = 'login';
  static const String logout = 'logout';
  static const String forgetPassword = 'reset_password';
  static const String phoneNumberCheck = 'phone_number_check';

  //Dashboard
  static const String customerProfile = 'customer_profile';
  static const String customerDashboard = 'customer_dashboard';
  static const String customerProfileUpdate = 'customer_profile_update';
  static const String customerPasswordUpdate = 'customer_password_update';
  static const String mobileDiagnosisReportList =
      'mobile_diagnosis_report_list';
  static const String mobileDiagnosisReportDetails =
      'mobile_diagnosis_report_details';
  static const String mobileDiagnosisReportStore =
      'mobile_diagnosis_report_store';

  //Device Insurance
  static const String deviceInsuranceHistory = 'device_insurance_history';
  static const String deviceInsuranceHistoryDetail = 'device_insurance_details';
 /* static const String deviceInsuranceSupportRequests =
      'device_insurance_support_requests';*/

  static const String deviceInsuranceSupportRequests =
      'device_insurance_support_history';

  static const String deviceInsuranceClaimHistory =
      'device_insurance_claim_history';
  static const String deviceClaimDetails = 'device_claim_details';
  static const String deviceClaimDetailsDownload =
      'device_claim_details_download';

  static const String deviceInsuranceSupportRequestForm =
      'device_insurance_support_request_form';
  static const String deviceInsuranceSupportRequestStore =
      'device_insurance_support_request_store';
  static const String deviceInsuranceSupportRequestStoreForLost =
      'device_insurance_support_request_store_for_lost';
  static const String getDistrictByDivision = 'get_district_by_division';
  static const String getUpazilaByDistrict = 'get_upazila_by_district';
  static const String getServiceCenter = 'get_service_center';

  //Travel Insurance
  static const String travelInsuranceHistory =
      'travel_insurance_purchase_history';
  static const String travelInsuranceHistoryDetail =
      'travel_insurance_purchase_details';
  static const String travelInsurancePlan =
      'get_travel_inc_plan_chart_with_provider';
  static const String travelInsuranceInvoice = 'travel_insurance_invoice';
  static const String travelInsuranceCreateOrder =
      'travel_insurance_order_create';
  static const String getPlanCategory = 'get_travel_ins_plan_category';
  static const String payNow = 'pay_now';
  static const String device_diagnostics = 'mobile_diagnosis_report_store';
  static const String getDeviceInsurancePackage =
      'get_device_insurance_package';
  static const String purchaseDeviceInsurancePackage =
      'purchase_device_insurance_package';

  static const String payNowForDeviceInsurancePurchase =
      'pay_now_for_device_insurance_purchase';
  static const String aamarpayCancleResponse = 'aamarpay_cancle_response';
  static const String aamarpaySuccessResponse = 'aamarpay_success_response';

  //Tour Insurance
  static const String tourInsuranceHistory = 'tour_insurance_purchase_history_for_customer';

  //Vehicle Insurance
  static const String vehicleInsuranceForm = 'tour_insurance_purchase_history_for_customer';


}
