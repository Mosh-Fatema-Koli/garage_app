import 'package:flutter/material.dart';
import 'package:instasure/domains/models/vehicleInsurance/vehicleInsurance_model.dart';

class FormFieldsProvider with ChangeNotifier {
  List<Packages> formFields = [];
  List<String> selectedCategories = [];
  List<String> selectedSubCategories = [];

  void addFormField(Packages field) {
    formFields.add(field);
    notifyListeners();
  }

  void setSelectedCategories(List<String> categories) {
    selectedCategories = categories;
    notifyListeners();
  }

  void setSelectedSubCategories(List<String> subCategories) {
    selectedSubCategories = subCategories;
    notifyListeners();
  }

  List<Packages> getFilteredPackages() {
    return formFields.where((field) {
      return selectedCategories.contains(field.category) &&
          selectedSubCategories.contains(field.subCategory);
    }).toList();
  }


}
