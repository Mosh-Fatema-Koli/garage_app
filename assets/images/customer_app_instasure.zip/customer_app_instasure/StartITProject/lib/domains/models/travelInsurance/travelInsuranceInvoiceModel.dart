class TravelInsuranceInvoiceModel {
  int? id;
  int? userId;
  int? dealerUserId;
  int? travelInsPlansCategoryId;
  dynamic travelInsuranceCategoryTitle;
  int? travelInsPlansChartsId;
  int? insuranceProviderId;
  dynamic fullName;
  dynamic email;
  dynamic phone;
  dynamic dob;
  dynamic age;
  dynamic passportNumber;
  dynamic passportExpireTill;
  dynamic policyNumber;
  dynamic insPrice;
  dynamic totalVat;
  dynamic vatPercentage;
  dynamic serviceAmount;
  dynamic serviceTotalAmount;
  dynamic grandTotal;
  dynamic parentDealerCommission;
  dynamic childDealerCommission;
  dynamic paymentStatus;
  dynamic amarpayStatus;
  dynamic status;
  dynamic flightNumber;
  dynamic flightDate;
  dynamic returnDate;
  dynamic totalDate;
  dynamic invoiceCode;
  dynamic paymentDetails;
  dynamic createdAt;
  dynamic updatedAt;
  dynamic defaultAddress;

  TravelInsuranceInvoiceModel(
      {this.id,
      this.userId,
      this.dealerUserId,
      this.travelInsPlansCategoryId,
      this.travelInsuranceCategoryTitle,
      this.travelInsPlansChartsId,
      this.insuranceProviderId,
      this.fullName,
      this.email,
      this.phone,
      this.dob,
      this.age,
      this.passportNumber,
      this.passportExpireTill,
      this.policyNumber,
      this.insPrice,
      this.totalVat,
      this.vatPercentage,
      this.serviceAmount,
      this.serviceTotalAmount,
      this.grandTotal,
      this.parentDealerCommission,
      this.childDealerCommission,
      this.paymentStatus,
      this.amarpayStatus,
      this.status,
      this.flightNumber,
      this.flightDate,
      this.returnDate,
      this.totalDate,
      this.invoiceCode,
      this.paymentDetails,
      this.createdAt,
      this.updatedAt,
      this.defaultAddress});

  TravelInsuranceInvoiceModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    userId = json['user_id'];
    dealerUserId = json['dealer_user_id'];
    travelInsPlansCategoryId = json['travel_ins_plans_category_id'];
    travelInsuranceCategoryTitle = json['travel_insurance_category_title'];
    travelInsPlansChartsId = json['travel_ins_plans_charts_id'];
    insuranceProviderId = json['insurance_provider_id'];
    fullName = json['full_name'];
    email = json['email'];
    phone = json['phone'];
    dob = json['dob'];
    age = json['age'];
    passportNumber = json['passport_number'];
    passportExpireTill = json['passport_expire_till'];
    policyNumber = json['policy_number'];
    insPrice = json['ins_price'];
    totalVat = json['total_vat'];
    vatPercentage = json['vat_percentage'];
    serviceAmount = json['service_amount'];
    serviceTotalAmount = json['service_total_amount'];
    grandTotal = json['grand_total'];
    parentDealerCommission = json['parent_dealer_commission'];
    childDealerCommission = json['child_dealer_commission'];
    paymentStatus = json['payment_status'];
    amarpayStatus = json['amarpay_status'];
    status = json['status'];
    flightNumber = json['flight_number'];
    flightDate = json['flight_date'];
    returnDate = json['return_date'];
    totalDate = json['total_date'];
    invoiceCode = json['invoice_code'];
    paymentDetails = json['payment_details'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    defaultAddress = json['default_address'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['user_id'] = this.userId;
    data['dealer_user_id'] = this.dealerUserId;
    data['travel_ins_plans_category_id'] = this.travelInsPlansCategoryId;
    data['travel_insurance_category_title'] = this.travelInsuranceCategoryTitle;
    data['travel_ins_plans_charts_id'] = this.travelInsPlansChartsId;
    data['insurance_provider_id'] = this.insuranceProviderId;
    data['full_name'] = this.fullName;
    data['email'] = this.email;
    data['phone'] = this.phone;
    data['dob'] = this.dob;
    data['age'] = this.age;
    data['passport_number'] = this.passportNumber;
    data['passport_expire_till'] = this.passportExpireTill;
    data['policy_number'] = this.policyNumber;
    data['ins_price'] = this.insPrice;
    data['total_vat'] = this.totalVat;
    data['vat_percentage'] = this.vatPercentage;
    data['service_amount'] = this.serviceAmount;
    data['service_total_amount'] = this.serviceTotalAmount;
    data['grand_total'] = this.grandTotal;
    data['parent_dealer_commission'] = this.parentDealerCommission;
    data['child_dealer_commission'] = this.childDealerCommission;
    data['payment_status'] = this.paymentStatus;
    data['amarpay_status'] = this.amarpayStatus;
    data['status'] = this.status;
    data['flight_number'] = this.flightNumber;
    data['flight_date'] = this.flightDate;
    data['return_date'] = this.returnDate;
    data['total_date'] = this.totalDate;
    data['invoice_code'] = this.invoiceCode;
    data['payment_details'] = this.paymentDetails;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    data['default_address'] = this.defaultAddress;
    return data;
  }
}
