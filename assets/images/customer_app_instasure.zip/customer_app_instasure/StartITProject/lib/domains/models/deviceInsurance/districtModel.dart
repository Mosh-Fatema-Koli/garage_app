class DistrictModel {
  int? id;
  dynamic divisionId;
  String? name;
  dynamic bnName;
  dynamic lat;
  dynamic lon;
  dynamic website;
  String? createdAt;
  String? updatedAt;

  DistrictModel(
      {this.id,
      this.divisionId,
      this.name,
      this.bnName,
      this.lat,
      this.lon,
      this.website,
      this.createdAt,
      this.updatedAt});

  DistrictModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    divisionId = json['division_id'];
    name = json['name'];
    bnName = json['bn_name'];
    lat = json['lat'];
    lon = json['lon'];
    website = json['website'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['division_id'] = this.divisionId;
    data['name'] = this.name;
    data['bn_name'] = this.bnName;
    data['lat'] = this.lat;
    data['lon'] = this.lon;
    data['website'] = this.website;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    return data;
  }
}