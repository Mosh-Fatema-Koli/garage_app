class DivisionModel {
  int? id;
  String? name;
  String? bnName;
  String? createdAt;
  String? updatedAt;

  DivisionModel(
      {this.id, this.name, this.bnName, this.createdAt, this.updatedAt});

  DivisionModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    bnName = json['bn_name'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['bn_name'] = this.bnName;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    return data;
  }
}
