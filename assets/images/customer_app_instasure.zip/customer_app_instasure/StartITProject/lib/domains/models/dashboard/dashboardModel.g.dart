part of 'dashboardModel.dart';
// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

DashboardModel _$DashboardFromJson(Map<String, dynamic> json) {
  return DashboardModel(
    totalMediclaimOrder: json['total_mediclaim_order'] as int,
    totalDeviceOrder: json['total_device_order'] as int,
    totalDeviceClaim: json['total_device_claim'] as int,
    totalDeviceServiceRequest: json['total_device_service_request'] as int,
  );
}

Map<String, dynamic> _$DashboardToJson(DashboardModel instance) =>
    <String, dynamic>{
      'total_mediclaim_order': instance.totalMediclaimOrder,
      'total_device_order': instance.totalDeviceOrder,
      'total_device_claim': instance.totalDeviceClaim,
      'total_device_service_request': instance.totalDeviceServiceRequest,
    };
