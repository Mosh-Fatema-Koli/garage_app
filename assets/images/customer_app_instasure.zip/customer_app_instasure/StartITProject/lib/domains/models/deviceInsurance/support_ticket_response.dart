import 'dart:convert';

//List<Support_ticket> support_ticketFromJson(String str) => List<Support_ticket>.from(json.decode(str).map((x) => Support_ticket.fromJson(x)));

//String support_ticketToJson(List<Support_ticket> data) => json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class Support_ticket {
  String? serviceCenterName;
  String? serviceCenterAddress;
  String? deviceName;
  String? brandName;
  String? modelName;
  String? claimType;
  String? claimNote;
  String? claimStatus;
  String? claimDate;

  Support_ticket(
      {this.serviceCenterName,
        this.serviceCenterAddress,
        this.deviceName,
        this.brandName,
        this.modelName,
        this.claimType,
        this.claimNote,
        this.claimStatus,
        this.claimDate});

  Support_ticket.fromJson(Map<String, dynamic> json) {
    serviceCenterName = json['service_center_name'];
    serviceCenterAddress = json['service_center_address'];
    deviceName = json['device_name'];
    brandName = json['brand_name'];
    modelName = json['model_name'];
    claimType = json['claim_type'];
    claimNote = json['claim_note'];
    claimStatus = json['claim_status'];
    claimDate = json['claim_date'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['service_center_name'] = this.serviceCenterName;
    data['service_center_address'] = this.serviceCenterAddress;
    data['device_name'] = this.deviceName;
    data['brand_name'] = this.brandName;
    data['model_name'] = this.modelName;
    data['claim_type'] = this.claimType;
    data['claim_note'] = this.claimNote;
    data['claim_status'] = this.claimStatus;
    data['claim_date'] = this.claimDate;
    return data;
  }
}




