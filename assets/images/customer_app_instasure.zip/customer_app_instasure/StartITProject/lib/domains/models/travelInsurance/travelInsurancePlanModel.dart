class TravelInsurancePlanModel {
  int? id;
  int? travelInsPlansCategoryId;
  int? policyProviderId;
  var  ageFrom;
  var ageTo;
  var periodFrom;
  var periodTo;
  var insPrice;
  var validateTill;
  var createdAt;
  var updatedAt;
  var travelDays;
  PolicyProvider? policyProvider;
  double? age;

  TravelInsurancePlanModel(
      {this.id,
      this.travelInsPlansCategoryId,
      this.policyProviderId,
      this.ageFrom,
      this.ageTo,
      this.periodFrom,
      this.periodTo,
      this.insPrice,
      this.validateTill,
      this.createdAt,
      this.updatedAt,
      this.travelDays,
      this.policyProvider,
      this.age});

  TravelInsurancePlanModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    travelInsPlansCategoryId = json['travel_ins_plans_category_id'];
    policyProviderId = json['policy_provider_id'];
    ageFrom = json['age_from'];
    ageTo = json['age_to'];
    periodFrom = json['period_from'];
    periodTo = json['period_to'];
    insPrice = json['ins_price'];
    validateTill = json['validate_till'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    travelDays = json['travel_days'];
    policyProvider = json['policy_provider'] != null
        ? new PolicyProvider.fromJson(json['policy_provider'])
        : null;
    age = json['age'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['travel_ins_plans_category_id'] = this.travelInsPlansCategoryId;
    data['policy_provider_id'] = this.policyProviderId;
    data['age_from'] = this.ageFrom;
    data['age_to'] = this.ageTo;
    data['period_from'] = this.periodFrom;
    data['period_to'] = this.periodTo;
    data['ins_price'] = this.insPrice;
    data['validate_till'] = this.validateTill;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    data['travel_days'] = this.travelDays;
    if (this.policyProvider != null) {
      data['policy_provider'] = this.policyProvider!.toJson();
    }
    data['age'] = this.age;
    return data;
  }
}

class PolicyProvider {
  int? id;
  var code;
  var companyName;
  var contactPersonName;
  var contactPersonEmail;
  var contactPersonPhone;
  int? isApi;
  var apiUrl;
  var apiKey;
  var apiSecret;
  var status;
  var logo;
  var templateImg;
  var createdAt;
  var updatedAt;
  var logoPath;

  PolicyProvider(
      {this.id,
      this.code,
      this.companyName,
      this.contactPersonName,
      this.contactPersonEmail,
      this.contactPersonPhone,
      this.isApi,
      this.apiUrl,
      this.apiKey,
      this.apiSecret,
      this.status,
      this.logo,
      this.templateImg,
      this.createdAt,
      this.updatedAt,
      this.logoPath});

  PolicyProvider.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    code = json['code'];
    companyName = json['company_name'];
    contactPersonName = json['contact_person_name'];
    contactPersonEmail = json['contact_person_email'];
    contactPersonPhone = json['contact_person_phone'];
    isApi = json['is_api'];
    apiUrl = json['api_url'];
    apiKey = json['api_key'];
    apiSecret = json['api_secret'];
    status = json['status'];
    logo = json['logo'];
    templateImg = json['template_img'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    logoPath = json['logo_path'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['code'] = this.code;
    data['company_name'] = this.companyName;
    data['contact_person_name'] = this.contactPersonName;
    data['contact_person_email'] = this.contactPersonEmail;
    data['contact_person_phone'] = this.contactPersonPhone;
    data['is_api'] = this.isApi;
    data['api_url'] = this.apiUrl;
    data['api_key'] = this.apiKey;
    data['api_secret'] = this.apiSecret;
    data['status'] = this.status;
    data['logo'] = this.logo;
    data['template_img'] = this.templateImg;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    data['logo_path'] = this.logoPath;
    return data;
  }
}
