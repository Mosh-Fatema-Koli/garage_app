class TourModel {
  int? id;
  int? userId;
  dynamic datetime;
  dynamic expireDate;
  dynamic attatchedExcel;
  dynamic packageInfo;
  dynamic tourTransportDetails;
  dynamic tourCountry;
  double? totalAmount;
  int? totalQty;
  int? packageRate;
  int? vat;
  int? serviceCharge;
  dynamic invoiceCode;
  dynamic paymentMethod;
  dynamic paymentStatus;
  dynamic paymentResponse;
  dynamic policyId;
  dynamic policyExpire;
  dynamic claimDetails;
  dynamic from;
  dynamic fromTime;
  dynamic updatedAt;
  dynamic createdAt;
  dynamic paid;
  dynamic approve;
  dynamic organizedBy;
  dynamic organizerDetails;
  dynamic tourName;
  dynamic tourLocation;
  dynamic name;
  dynamic nID;
  dynamic phone;
  dynamic profession;
  dynamic disease;
  dynamic insurance;

  TourModel(
      {this.id,
        this.userId,
        this.datetime,
        this.expireDate,
        this.attatchedExcel,
        this.packageInfo,
        this.tourTransportDetails,
        this.tourCountry,
        this.totalAmount,
        this.totalQty,
        this.packageRate,
        this.vat,
        this.serviceCharge,
        this.invoiceCode,
        this.paymentMethod,
        this.paymentStatus,
        this.paymentResponse,
        this.policyId,
        this.policyExpire,
        this.claimDetails,
        this.from,
        this.fromTime,
        this.updatedAt,
        this.createdAt,
        this.paid,
        this.approve,
        this.organizedBy,
        this.organizerDetails,
        this.tourName,
        this.tourLocation,
        this.name,
        this.nID,
        this.phone,
        this.profession,
        this.disease,
        this.insurance});

  TourModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    userId = json['user_id'];
    datetime = json['datetime'];
    expireDate = json['expire_date'];
    attatchedExcel = json['attatched_excel'];
    packageInfo = json['package_info'];
    tourTransportDetails = json['tour_transport_details'];
    tourCountry = json['tour_country'];
    totalAmount = json['total_amount'];
    totalQty = json['total_qty'];
    packageRate = json['package_rate'];
    vat = json['vat'];
    serviceCharge = json['service_charge'];
    invoiceCode = json['invoice_code'];
    paymentMethod = json['payment_method'];
    paymentStatus = json['payment_status'];
    paymentResponse = json['payment_response'];
    policyId = json['policy_id'];
    policyExpire = json['policy_expire'];
    claimDetails = json['claim_details'];
    from = json['from'];
    fromTime = json['from_time'];
    updatedAt = json['updated_at'];
    createdAt = json['created_at'];
    paid = json['paid'];
    approve = json['approve'];
    organizedBy = json['organized_by'];
    organizerDetails = json['organizer_details'];
    tourName = json['tour_name'];
    tourLocation = json['tour_location'];
    name = json['Name'];
    nID = json['NID'];
    phone = json['Phone'];
    profession = json['Profession'];
    disease = json['Disease'];
    insurance = json['insurance'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['user_id'] = this.userId;
    data['datetime'] = this.datetime;
    data['expire_date'] = this.expireDate;
    data['attatched_excel'] = this.attatchedExcel;
    data['package_info'] = this.packageInfo;
    data['tour_transport_details'] = this.tourTransportDetails;
    data['tour_country'] = this.tourCountry;
    data['total_amount'] = this.totalAmount;
    data['total_qty'] = this.totalQty;
    data['package_rate'] = this.packageRate;
    data['vat'] = this.vat;
    data['service_charge'] = this.serviceCharge;
    data['invoice_code'] = this.invoiceCode;
    data['payment_method'] = this.paymentMethod;
    data['payment_status'] = this.paymentStatus;
    data['payment_response'] = this.paymentResponse;
    data['policy_id'] = this.policyId;
    data['policy_expire'] = this.policyExpire;
    data['claim_details'] = this.claimDetails;
    data['from'] = this.from;
    data['from_time'] = this.fromTime;
    data['updated_at'] = this.updatedAt;
    data['created_at'] = this.createdAt;
    data['paid'] = this.paid;
    data['approve'] = this.approve;
    data['organized_by'] = this.organizedBy;
    data['organizer_details'] = this.organizerDetails;
    data['tour_name'] = this.tourName;
    data['tour_location'] = this.tourLocation;
    data['Name'] = this.name;
    data['NID'] = this.nID;
    data['Phone'] = this.phone;
    data['Profession'] = this.profession;
    data['Disease'] = this.disease;
    data['insurance'] = this.insurance;
    return data;
  }
}