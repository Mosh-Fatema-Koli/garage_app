import 'dart:convert';
import 'package:instasure/domains/models/deviceInsurance/deviceInfoModel.dart';
import 'package:instasure/domains/models/insurancePriceInfoModel.dart';
/*
class claimRequestModel {
  int? id;
  String? userId;
  String? parentDealerId;
  String? childDealerId;
  String? packageId;
  String? parentDealerCommission;
  String? childDealerCommission;
  String? otherDealerCommission;
  String? claimableAmount;
  String? claimedAmount;
  String? instasureAmount;
  String? subTotal;
  String? totalVat;
  String? totalDiscount;
  String? couponAmount;
  String? grandTotal;
  String? paymentMethod;
  String? paymentStatus;
  String? status;
  List<InsurancePriceInfoModel>? insuranceTypeValue;
  String? dealerWillPay;
  CustomerInfoModel? customerInfo;
  DeviceInfoModel? deviceInfo;
  String? policyNumber;
  String? invoiceCode;
  String? paymentDetails;
  String? totalAmountForCal;
  String? includedAmount;
  String? includedVatAmount;
  String? vatPecentage;
  String? parentWillPayToAdmin;
  String? parentWillPayToChild;
  String? protectionTimesFor;
  String? imeiOne;
  String? imeiTwo;
  String? createdAt;
  String? updatedAt;
  String? packageType;
  String? customerWillPayCharge;

  claimRequestModel(
      {this.id,
      this.userId,
      this.parentDealerId,
      this.childDealerId,
      this.packageId,
      this.parentDealerCommission,
      this.childDealerCommission,
      this.otherDealerCommission,
      this.claimableAmount,
      this.claimedAmount,
      this.instasureAmount,
      this.subTotal,
      this.totalVat,
      this.totalDiscount,
      this.couponAmount,
      this.grandTotal,
      this.paymentMethod,
      this.paymentStatus,
      this.status,
      this.insuranceTypeValue,
      this.dealerWillPay,
      this.customerInfo,
      this.deviceInfo,
      this.policyNumber,
      this.invoiceCode,
      this.paymentDetails,
      this.totalAmountForCal,
      this.includedAmount,
      this.includedVatAmount,
      this.vatPecentage,
      this.parentWillPayToAdmin,
      this.parentWillPayToChild,
      this.protectionTimesFor,
      this.imeiOne,
      this.imeiTwo,
      this.createdAt,
      this.updatedAt,
      this.packageType,
      this.customerWillPayCharge});

  claimRequestModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    userId = json['user_id'];
    parentDealerId = json['parent_dealer_id'];
    childDealerId = json['child_dealer_id'];
    packageId = json['package_id'];
    parentDealerCommission = json['parent_dealer_commission'];
    childDealerCommission = json['child_dealer_commission'];
    otherDealerCommission = json['other_dealer_commission'];
    claimableAmount = json['claimable_amount'];
    claimedAmount = json['claimed_amount'];
    instasureAmount = json['instasure_amount'];
    subTotal = json['sub_total'];
    totalVat = json['total_vat'];
    totalDiscount = json['total_discount'];
    couponAmount = json['coupon_amount'];
    grandTotal = json['grand_total'];
    paymentMethod = json['payment_method'];
    paymentStatus = json['payment_status'];
    status = json['status'];

    List jsonList = jsonDecode(json['insurance_type_value']) as List;
    List<InsurancePriceInfoModel> histories = jsonList
        .map((jsonElement) => InsurancePriceInfoModel.fromJson(jsonElement))
        .toList();
    insuranceTypeValue = histories;
    dealerWillPay = json['dealer_will_pay'];
    customerInfo =
        CustomerInfoModel.fromJson(jsonDecode(json['customer_info']));
    deviceInfo = DeviceInfoModel.fromJson(jsonDecode(json['device_info']));
    policyNumber = json['policy_number'];
    invoiceCode = json['invoice_code'];
    paymentDetails = json['payment_details'];
    totalAmountForCal = json['totalAmountForCal'];
    includedAmount = json['includedAmount'];
    includedVatAmount = json['includedVatAmount'];
    vatPecentage = json['vat_pecentage'];
    parentWillPayToAdmin = json['parent_will_pay_to_admin'];
    parentWillPayToChild = json['parent_will_pay_to_child'];
    protectionTimesFor = json['protection_times_for'];
    imeiOne = json['imei_one'];
    imeiTwo = json['imei_two'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    packageType = json['package_type'];
    customerWillPayCharge = json['customer_will_pay_charge'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['user_id'] = this.userId;
    data['parent_dealer_id'] = this.parentDealerId;
    data['child_dealer_id'] = this.childDealerId;
    data['package_id'] = this.packageId;
    data['parent_dealer_commission'] = this.parentDealerCommission;
    data['child_dealer_commission'] = this.childDealerCommission;
    data['other_dealer_commission'] = this.otherDealerCommission;
    data['claimable_amount'] = this.claimableAmount;
    data['claimed_amount'] = this.claimedAmount;
    data['instasure_amount'] = this.instasureAmount;
    data['sub_total'] = this.subTotal;
    data['total_vat'] = this.totalVat;
    data['total_discount'] = this.totalDiscount;
    data['coupon_amount'] = this.couponAmount;
    data['grand_total'] = this.grandTotal;
    data['payment_method'] = this.paymentMethod;
    data['payment_status'] = this.paymentStatus;
    data['status'] = this.status;
    data['insurance_type_value'] = this.insuranceTypeValue;
    data['dealer_will_pay'] = this.dealerWillPay;
    data['customer_info'] = this.customerInfo;
    data['device_info'] = this.deviceInfo;
    data['policy_number'] = this.policyNumber;
    data['invoice_code'] = this.invoiceCode;
    data['payment_details'] = this.paymentDetails;
    data['totalAmountForCal'] = this.totalAmountForCal;
    data['includedAmount'] = this.includedAmount;
    data['includedVatAmount'] = this.includedVatAmount;
    data['vat_pecentage'] = this.vatPecentage;
    data['parent_will_pay_to_admin'] = this.parentWillPayToAdmin;
    data['parent_will_pay_to_child'] = this.parentWillPayToChild;
    data['protection_times_for'] = this.protectionTimesFor;
    data['imei_one'] = this.imeiOne;
    data['imei_two'] = this.imeiTwo;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    data['package_type'] = this.packageType;
    data['customer_will_pay_charge'] = this.customerWillPayCharge;
    return data;
  }
}
*/


class claimRequestModel {
  String? serviceCenterName;
  String? serviceCenterAddress;
  String? deviceName;
  String? brandName;
  String? modelName;
  String? claimType;
  String? claimNote;
  String? claimStatus;
  String? claimDate;

  claimRequestModel(
      {this.serviceCenterName,
        this.serviceCenterAddress,
        this.deviceName,
        this.brandName,
        this.modelName,
        this.claimType,
        this.claimNote,
        this.claimStatus,
        this.claimDate});

  claimRequestModel.fromJson(Map<String, dynamic> json) {
    serviceCenterName = json['service_center_name'];
    serviceCenterAddress = json['service_center_address'];
    deviceName = json['device_name'];
    brandName = json['brand_name'];
    modelName = json['model_name'];
    claimType = json['claim_type'];
    claimNote = json['claim_note'];
    claimStatus = json['claim_status'];
    claimDate = json['claim_date'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['service_center_name'] = this.serviceCenterName;
    data['service_center_address'] = this.serviceCenterAddress;
    data['device_name'] = this.deviceName;
    data['brand_name'] = this.brandName;
    data['model_name'] = this.modelName;
    data['claim_type'] = this.claimType;
    data['claim_note'] = this.claimNote;
    data['claim_status'] = this.claimStatus;
    data['claim_date'] = this.claimDate;
    return data;
  }
}


