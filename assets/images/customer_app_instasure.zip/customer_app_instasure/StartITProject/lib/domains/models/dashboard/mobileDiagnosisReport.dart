class MobileDiagnosisReport {
  int? id;
  int? userId;
  int? dealerId;
  int? brandId;
  int? deviceModelId;
  int? imeiDataId;
  dynamic? validityPeriod;
  String? serialNumber;
  dynamic? batteryNumber;
  int? price;
  int? motherboardStatus;
  int? batteryHealthStatus;
  int? frontCameraStatus;
  int? backCameraStatus;
  int? microphoneStatus;
  int? ramStatus;
  int? romStatus;
  int? displayScreenStatus;
  dynamic? invoiceImage;
  String? deviceImages;
  String? imeiImage;
  String? status;
  int? isActive;
  String? note;
  String? createdAt;
  String? updatedAt;
  dynamic? nInvoiceImagePath;
  List<String>? lDeviceImagesPath;
  String? sImeiImagePath;
  int? iValidFor;
  String? sValidityMessage;
  Model? model;
  Brand? brand;

  MobileDiagnosisReport(
  {this.id,
  this.userId,
  this.dealerId,
  this.brandId,
  this.deviceModelId,
  this.imeiDataId,
  this.validityPeriod,
  this.serialNumber,
  this.batteryNumber,
  this.price,
  this.motherboardStatus,
  this.batteryHealthStatus,
  this.frontCameraStatus,
  this.backCameraStatus,
  this.microphoneStatus,
  this.ramStatus,
  this.romStatus,
  this.displayScreenStatus,
  this.invoiceImage,
  this.deviceImages,
  this.imeiImage,
  this.status,
  this.isActive,
  this.note,
  this.createdAt,
  this.updatedAt,
  this.nInvoiceImagePath,
  this.lDeviceImagesPath,
  this.sImeiImagePath,
  this.iValidFor,
  this.sValidityMessage,
  this.model,
  this.brand});

  MobileDiagnosisReport.fromJson(Map<String, dynamic> json) {
  id = json['id'];
  userId = json['user_id'];
  dealerId = json['dealer_id'];
  brandId = json['brand_id'];
  deviceModelId = json['device_model_id'];
  imeiDataId = json['imei_data_id'];
  validityPeriod = json['validity_period'];
  serialNumber = json['serial_number'];
  batteryNumber = json['battery_number'];
  price = json['price'];
  motherboardStatus = json['motherboard_status'];
  batteryHealthStatus = json['battery_health_status'];
  frontCameraStatus = json['front_camera_status'];
  backCameraStatus = json['back_camera_status'];
  microphoneStatus = json['microphone_status'];
  ramStatus = json['ram_status'];
  romStatus = json['rom_status'];
  displayScreenStatus = json['display_screen_status'];
  invoiceImage = json['invoice_image'];
  deviceImages = json['device_images'];
  imeiImage = json['imei_image'];
  status = json['status'];
  isActive = json['is_active'];
  note = json['note'];
  createdAt = json['created_at'];
  updatedAt = json['updated_at'];
  nInvoiceImagePath = json['_invoice_image_path'];
  lDeviceImagesPath = json['_device_images_path'].cast<String>();
  sImeiImagePath = json['_imei_image_path'];
  iValidFor = json['_valid_for'];
  sValidityMessage = json['_validity_message'];
  model = json['model'] != null ? new Model.fromJson(json['model']) : null;
  brand = json['brand'] != null ? new Brand.fromJson(json['brand']) : null;
  }

  Map<String, dynamic> toJson() {
  final Map<String, dynamic> data = new Map<String, dynamic>();
  data['id'] = this.id;
  data['user_id'] = this.userId;
  data['dealer_id'] = this.dealerId;
  data['brand_id'] = this.brandId;
  data['device_model_id'] = this.deviceModelId;
  data['imei_data_id'] = this.imeiDataId;
  data['validity_period'] = this.validityPeriod;
  data['serial_number'] = this.serialNumber;
  data['battery_number'] = this.batteryNumber;
  data['price'] = this.price;
  data['motherboard_status'] = this.motherboardStatus;
  data['battery_health_status'] = this.batteryHealthStatus;
  data['front_camera_status'] = this.frontCameraStatus;
  data['back_camera_status'] = this.backCameraStatus;
  data['microphone_status'] = this.microphoneStatus;
  data['ram_status'] = this.ramStatus;
  data['rom_status'] = this.romStatus;
  data['display_screen_status'] = this.displayScreenStatus;
  data['invoice_image'] = this.invoiceImage;
  data['device_images'] = this.deviceImages;
  data['imei_image'] = this.imeiImage;
  data['status'] = this.status;
  data['is_active'] = this.isActive;
  data['note'] = this.note;
  data['created_at'] = this.createdAt;
  data['updated_at'] = this.updatedAt;
  data['_invoice_image_path'] = this.nInvoiceImagePath;
  data['_device_images_path'] = this.lDeviceImagesPath;
  data['_imei_image_path'] = this.sImeiImagePath;
  data['_valid_for'] = this.iValidFor;
  data['_validity_message'] = this.sValidityMessage;
  if (this.model != null) {
  data['model'] = this.model!.toJson();
  }
  if (this.brand != null) {
  data['brand'] = this.brand!.toJson();
  }
  return data;
  }
}

class Model {
  int? id;
  int? brandId;
  String? name;
  String? slug;
  int? status;
  String? description;
  String? createdAt;
  String? updatedAt;

  Model(
      {this.id,
        this.brandId,
        this.name,
        this.slug,
        this.status,
        this.description,
        this.createdAt,
        this.updatedAt});

  Model.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    brandId = json['brand_id'];
    name = json['name'];
    slug = json['slug'];
    status = json['status'];
    description = json['description'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['brand_id'] = this.brandId;
    data['name'] = this.name;
    data['slug'] = this.slug;
    data['status'] = this.status;
    data['description'] = this.description;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    return data;
  }
}

class Brand {
  int? id;
  String? name;
  String? logo;
  String? slug;
  int? status;
  String? metaTitle;
  String? metaDescription;
  String? createdAt;
  String? updatedAt;

  Brand(
      {this.id,
        this.name,
        this.logo,
        this.slug,
        this.status,
        this.metaTitle,
        this.metaDescription,
        this.createdAt,
        this.updatedAt});

  Brand.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    logo = json['logo'];
    slug = json['slug'];
    status = json['status'];
    metaTitle = json['meta_title'];
    metaDescription = json['meta_description'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['logo'] = this.logo;
    data['slug'] = this.slug;
    data['status'] = this.status;
    data['meta_title'] = this.metaTitle;
    data['meta_description'] = this.metaDescription;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    return data;
  }

}