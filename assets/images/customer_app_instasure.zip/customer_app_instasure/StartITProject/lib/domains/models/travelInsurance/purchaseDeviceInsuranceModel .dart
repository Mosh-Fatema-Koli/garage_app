import 'dart:convert';

import 'package:instasure/domains/models/customerInfoModel.dart';
import 'package:instasure/domains/models/deviceInsurance/deviceInfoModel.dart';
import 'package:instasure/domains/models/insurancePriceInfoModel.dart';

class PurchaseDeviceInsuranceModel {
  CustomerInfoModel? customerInfo;
  DeviceInfoModel? deviceInfo;
  int? userId;
  String? imeiOne;
  String? imeiTwo;
  String? customerWillPayCharge;
  int? parentDealerId;
  int? childDealerId;
  String? packageType;
  int? packageId;
  int? invoiceCode;
  int? subTotal;
  String? totalVat;
  int? grandTotal;
  List<InsurancePriceInfoModel>? insuranceTypeValue;
  int? totalAmountForCal;
  int? includedAmount;
  String? includedVatAmount;
  String? vatPecentage;
  int? totalDiscount;
  int? parentWillPayToAdmin;
  int? parentWillPayToChild;
  int? parentDealerCommission;
  int? childDealerCommission;
  int? otherDealerCommission;
  int? instasureAmount;
  String? claimableAmount;
  int? claimedAmount;
  String? updatedAt;
  String? createdAt;
  int? id;

  PurchaseDeviceInsuranceModel(
      {this.customerInfo,
      this.deviceInfo,
      this.userId,
      this.imeiOne,
      this.imeiTwo,
      this.customerWillPayCharge,
      this.parentDealerId,
      this.childDealerId,
      this.packageType,
      this.packageId,
      this.invoiceCode,
      this.subTotal,
      this.totalVat,
      this.grandTotal,
      this.insuranceTypeValue,
      this.totalAmountForCal,
      this.includedAmount,
      this.includedVatAmount,
      this.vatPecentage,
      this.totalDiscount,
      this.parentWillPayToAdmin,
      this.parentWillPayToChild,
      this.parentDealerCommission,
      this.childDealerCommission,
      this.otherDealerCommission,
      this.instasureAmount,
      this.claimableAmount,
      this.claimedAmount,
      this.updatedAt,
      this.createdAt,
      this.id});

  PurchaseDeviceInsuranceModel.fromJson(Map<String, dynamic> json) {
    customerInfo =
        CustomerInfoModel.fromJson(jsonDecode(json['customer_info']));
    deviceInfo = DeviceInfoModel.fromJson(jsonDecode(json['device_info']));

    List jsonList = jsonDecode(json['insurance_type_value']) as List;
    List<InsurancePriceInfoModel> types = jsonList
        .map((jsonElement) => InsurancePriceInfoModel.fromJson(jsonElement))
        .toList();
    insuranceTypeValue = types;

    userId = json['user_id'];
    imeiOne = json['imei_one'];
    imeiTwo = json['imei_two'];
    customerWillPayCharge = json['customer_will_pay_charge'];
    parentDealerId = json['parent_dealer_id'];
    childDealerId = json['child_dealer_id'];
    packageType = json['package_type'];
    packageId = json['package_id'];
    invoiceCode = json['invoice_code'];
    subTotal = json['sub_total'];
    totalVat = json['total_vat'];
    grandTotal = json['grand_total'];
    totalAmountForCal = json['totalAmountForCal'];
    includedAmount = json['includedAmount'];
    includedVatAmount = json['includedVatAmount'];
    vatPecentage = json['vat_pecentage'];
    totalDiscount = json['total_discount'];
    parentWillPayToAdmin = json['parent_will_pay_to_admin'];
    parentWillPayToChild = json['parent_will_pay_to_child'];
    parentDealerCommission = json['parent_dealer_commission'];
    childDealerCommission = json['child_dealer_commission'];
    otherDealerCommission = json['other_dealer_commission'];
    instasureAmount = json['instasure_amount'];
    claimableAmount = json['claimable_amount'];
    claimedAmount = json['claimed_amount'];
    updatedAt = json['updated_at'];
    createdAt = json['created_at'];
    id = json['id'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['customer_info'] = this.customerInfo;
    data['device_info'] = this.deviceInfo;
    data['user_id'] = this.userId;
    data['imei_one'] = this.imeiOne;
    data['imei_two'] = this.imeiTwo;
    data['customer_will_pay_charge'] = this.customerWillPayCharge;
    data['parent_dealer_id'] = this.parentDealerId;
    data['child_dealer_id'] = this.childDealerId;
    data['package_type'] = this.packageType;
    data['package_id'] = this.packageId;
    data['invoice_code'] = this.invoiceCode;
    data['sub_total'] = this.subTotal;
    data['total_vat'] = this.totalVat;
    data['grand_total'] = this.grandTotal;
    data['insurance_type_value'] = this.insuranceTypeValue;
    data['totalAmountForCal'] = this.totalAmountForCal;
    data['includedAmount'] = this.includedAmount;
    data['includedVatAmount'] = this.includedVatAmount;
    data['vat_pecentage'] = this.vatPecentage;
    data['total_discount'] = this.totalDiscount;
    data['parent_will_pay_to_admin'] = this.parentWillPayToAdmin;
    data['parent_will_pay_to_child'] = this.parentWillPayToChild;
    data['parent_dealer_commission'] = this.parentDealerCommission;
    data['child_dealer_commission'] = this.childDealerCommission;
    data['other_dealer_commission'] = this.otherDealerCommission;
    data['instasure_amount'] = this.instasureAmount;
    data['claimable_amount'] = this.claimableAmount;
    data['claimed_amount'] = this.claimedAmount;
    data['updated_at'] = this.updatedAt;
    data['created_at'] = this.createdAt;
    data['id'] = this.id;
    return data;
  }
}
