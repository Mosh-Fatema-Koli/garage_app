class UpazilaModel {
  int? id;
  dynamic districtId;
  String? name;
  dynamic bnName;
  String? createdAt;
  String? updatedAt;

  UpazilaModel(
      {this.id,
      this.districtId,
      this.name,
      this.bnName,
      this.createdAt,
      this.updatedAt});

  UpazilaModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    districtId = json['district_id'];
    name = json['name'];
    bnName = json['bn_name'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['district_id'] = this.districtId;
    data['name'] = this.name;
    data['bn_name'] = this.bnName;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    return data;
  }
}
