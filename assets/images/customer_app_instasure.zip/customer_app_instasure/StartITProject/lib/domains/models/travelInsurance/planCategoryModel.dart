
class planCategoryModel {

  int? id;
  String? planTitle;
  String? countyDetails;
  String? countryType;
  String? createdAt;
  String? updatedAt;

  planCategoryModel(
      {this.id,
        this.planTitle,
        this.countyDetails,
        this.countryType,
        this.createdAt,
        this.updatedAt});

  planCategoryModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    planTitle = json['plan_title'];
    countyDetails = json['county_details'];
    countryType = json['country_type'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['plan_title'] = this.planTitle;
    data['county_details'] = this.countyDetails;
    data['country_type'] = this.countryType;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    return data;
  }
}
