class DeviceInfoModel {
  dynamic deviceModelId;
  dynamic brandId;
  String? brandName;
  String? modelName;
  var devicePrice;
  String? deviceName;
  String? imeiOne;
  String? imeiTwo;

  DeviceInfoModel(
      {this.deviceModelId,
      this.brandId,
      this.brandName,
      this.modelName,
      this.devicePrice,
      this.deviceName,
      this.imeiOne,
      this.imeiTwo});

  DeviceInfoModel.fromJson(Map<String, dynamic> json) {
    deviceModelId = json['device_model_id'];
    brandId = json['brand_id'];
    brandName = json['brand_name'];
    modelName = json['model_name'];
    devicePrice = json['device_price'];
    deviceName = json['device_name'];
    imeiOne = json['imei_one'];
    imeiTwo = json['imei_two'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['device_model_id'] = this.deviceModelId;
    data['brand_id'] = this.brandId;
    data['brand_name'] = this.brandName;
    data['model_name'] = this.modelName;
    data['device_price'] = this.devicePrice;
    data['device_name'] = this.deviceName;
    data['imei_one'] = this.imeiOne;
    data['imei_two'] = this.imeiTwo;
    return data;
  }
}
