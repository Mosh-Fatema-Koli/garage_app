class DeviceDiagnosticPackage {
  int? devicePrice;
  int? packageId;
  String? packageName;
  InsuranceTypeNames? insuranceTypeNames;

  DeviceDiagnosticPackage(
      {this.devicePrice,
        this.packageId,
        this.packageName,
        this.insuranceTypeNames});

  DeviceDiagnosticPackage.fromJson(Map<String, dynamic> json) {
    devicePrice = json['device_price'];
    packageId = json['package_id'];
    packageName = json['package_name'];
    insuranceTypeNames = json['insurance_type_names'] != null
        ? new InsuranceTypeNames.fromJson(json['insurance_type_names'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['device_price'] = this.devicePrice;
    data['package_id'] = this.packageId;
    data['package_name'] = this.packageName;
    if (this.insuranceTypeNames != null) {
      data['insurance_type_names'] = this.insuranceTypeNames!.toJson();
    }
    return data;
  }
}

class InsuranceTypeNames {
  ScreenProtection? screenProtection;
  Damage? damage;
  Damage? theft;

  InsuranceTypeNames({this.screenProtection, this.damage, this.theft});

  InsuranceTypeNames.fromJson(Map<String, dynamic> json) {
    screenProtection = json['Screen Protection'] != null
        ? new ScreenProtection.fromJson(json['Screen Protection'])
        : null;
    damage =
    json['Damage'] != null ? new Damage.fromJson(json['Damage']) : null;
    theft = json['Theft'] != null ? new Damage.fromJson(json['Theft']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.screenProtection != null) {
      data['Screen Protection'] = this.screenProtection!.toJson();
    }
    if (this.damage != null) {
      data['Damage'] = this.damage!.toJson();
    }
    if (this.theft != null) {
      data['Theft'] = this.theft!.toJson();
    }
    return data;
  }
}

class ScreenProtection {
  String? type;
  ProtectionTimesFor? protectionTimesFor;
  int? insurancePriceId;

  ScreenProtection({this.type, this.protectionTimesFor, this.insurancePriceId});

  ScreenProtection.fromJson(Map<String, dynamic> json) {
    type = json['type'];
    protectionTimesFor = json['protection_times_for'] != null
        ? new ProtectionTimesFor.fromJson(json['protection_times_for'])
        : null;
    insurancePriceId = json['insurance_price_id'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['type'] = this.type;
    if (this.protectionTimesFor != null) {
      data['protection_times_for'] = this.protectionTimesFor!.toJson();
    }
    data['insurance_price_id'] = this.insurancePriceId;
    return data;
  }
}

class ProtectionTimesFor {
  dynamic i0;
  dynamic i1;
  dynamic i2;

  ProtectionTimesFor({this.i0, this.i1, this.i2});

  ProtectionTimesFor.fromJson(Map<String, dynamic> json) {
    i0 = json['0'];
    i1 = json['1'];
    i2 = json['2'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['0'] = this.i0;
    data['1'] = this.i1;
    data['2'] = this.i2;
    return data;
  }
}

class Damage {
  dynamic price;
  int? insurancePriceId;

  Damage({this.price, this.insurancePriceId});

  Damage.fromJson(Map<String, dynamic> json) {
    price = json['price'];
    insurancePriceId = json['insurance_price_id'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['price'] = this.price;
    data['insurance_price_id'] = this.insurancePriceId;
    return data;
  }
}
