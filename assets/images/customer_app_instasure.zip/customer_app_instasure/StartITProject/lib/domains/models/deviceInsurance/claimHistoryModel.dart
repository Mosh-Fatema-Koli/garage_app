import 'package:json_annotation/json_annotation.dart';
//part 'dashboardModel.g.dart';

@JsonSerializable()
class ClaimHistoryModel {
  int? id;
  dynamic userId;
  dynamic serviceCenterId;
  dynamic deviceInsuranceId;
  dynamic claimId;
  dynamic amountWillPayInsProvider;
  dynamic settlementAmount;
  dynamic userWillPay;
  dynamic status;
  dynamic statusAdmin;
  dynamic paymentStatusAdmin;
  dynamic paymentStatus;
  dynamic deviceValue;
  dynamic document;
  dynamic totalAmount;
  dynamic paymentDetails;
  dynamic statusNote;
  dynamic claimOn;
  dynamic createdAt;
  dynamic updatedAt;
  List<String>? documentPath;

  ClaimHistoryModel(
      {this.id,
      this.userId,
      this.serviceCenterId,
      this.deviceInsuranceId,
      this.claimId,
      this.amountWillPayInsProvider,
      this.settlementAmount,
      this.userWillPay,
      this.status,
      this.statusAdmin,
      this.paymentStatusAdmin,
      this.paymentStatus,
      this.deviceValue,
      this.document,
      this.totalAmount,
      this.paymentDetails,
      this.statusNote,
      this.claimOn,
      this.createdAt,
      this.updatedAt,
      this.documentPath});

  ClaimHistoryModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    userId = json['user_id'];
    serviceCenterId = json['service_center_id'];
    deviceInsuranceId = json['device_insurance_id'];
    claimId = json['claim_id'];
    amountWillPayInsProvider = json['amount_will_pay_ins_provider'];
    settlementAmount = json['settlement_amount'];
    userWillPay = json['user_will_pay'];
    status = json['status'];
    statusAdmin = json['status_admin'];
    paymentStatusAdmin = json['payment_status_admin'];
    paymentStatus = json['payment_status'];
    deviceValue = json['device_value'];
    document = json['document'];
    totalAmount = json['total_amount'];
    paymentDetails = json['payment_details'];
    statusNote = json['status_note'];
    claimOn = json['claim_on'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    //documentPath = json['document_path'].cast<String>();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['user_id'] = this.userId;
    data['service_center_id'] = this.serviceCenterId;
    data['device_insurance_id'] = this.deviceInsuranceId;
    data['claim_id'] = this.claimId;
    data['amount_will_pay_ins_provider'] = this.amountWillPayInsProvider;
    data['settlement_amount'] = this.settlementAmount;
    data['user_will_pay'] = this.userWillPay;
    data['status'] = this.status;
    data['status_admin'] = this.statusAdmin;
    data['payment_status_admin'] = this.paymentStatusAdmin;
    data['payment_status'] = this.paymentStatus;
    data['device_value'] = this.deviceValue;
    data['document'] = this.document;
    data['total_amount'] = this.totalAmount;
    data['payment_details'] = this.paymentDetails;
    data['status_note'] = this.statusNote;
    data['claim_on'] = this.claimOn;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    data['document_path'] = this.documentPath;
    return data;
  }
}
