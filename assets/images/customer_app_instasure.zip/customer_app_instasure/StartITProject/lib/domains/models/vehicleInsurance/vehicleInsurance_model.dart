class VehicleInsuranceModel {
  List<String>? categorys;
  List<String>? subCategorys;
  List<Packages>? packages;

  VehicleInsuranceModel({this.categorys, this.subCategorys, this.packages});

  VehicleInsuranceModel.fromJson(Map<String, dynamic> json) {
    categorys = json['categorys'].cast<String>();
    subCategorys = json['sub_categorys'].cast<String>();
    if (json['packages'] != null) {
      packages = <Packages>[];
      json['packages'].forEach((v) {
        packages!.add(new Packages.fromJson(v));
      });
    }
  }


}

class Packages {
  int? id;
  String? category;
  String? subCategory;
  String? name;
  String? field;
  String? value;
  String? percentage;
  String? createdAt;
  String? updatedAt;
  String? elementType;
  dynamic? calculation;

  Packages(
      {this.id,
        this.category,
        this.subCategory,
        this.name,
        this.field,
        this.value,
        this.percentage,
        this.createdAt,
        this.updatedAt,
        this.elementType,
        this.calculation});

  Packages.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    category = json['category'];
    subCategory = json['sub_category'];
    name = json['name'];
    field = json['field'];
    value = json['value'];
    percentage = json['percentage'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    elementType = json['element_type'];
    calculation = json['calculation'];
  }

}