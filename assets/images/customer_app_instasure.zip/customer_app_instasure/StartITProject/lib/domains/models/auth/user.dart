import 'package:json_annotation/json_annotation.dart';
part 'user.g.dart';

@JsonSerializable()
class User {
  int? id;
  dynamic name;
  dynamic phone;
  dynamic userType;
  dynamic email;
  dynamic providerId;
  dynamic emailVerifiedAt;
  dynamic verificationCode;
  dynamic newEmailVerificiationCode;
  dynamic avatarOriginal;
  dynamic address;
  dynamic dob;
  dynamic passport;
  dynamic passportNumber;
  dynamic passportExpireTill;
  dynamic nid;
  dynamic passportImg;

  dynamic driving_licence_img;
  dynamic birthCertificate;

  User({
    this.id,
    this.name,
    this.phone,
    this.userType,
    this.avatarOriginal,
    this.email,
    this.providerId,
    this.emailVerifiedAt,
    this.verificationCode,
    this.newEmailVerificiationCode,
    this.address,
    this.dob,
    this.passport,
    this.passportNumber,
    this.passportExpireTill,
    this.nid,
    this.passportImg,
    this.birthCertificate,
    this.driving_licence_img,
  });

  factory User.fromJson(Map<String, dynamic> json) => _$UserFromJson(json);
  Map<String, dynamic> toJson() => _$UserToJson(this);
}
