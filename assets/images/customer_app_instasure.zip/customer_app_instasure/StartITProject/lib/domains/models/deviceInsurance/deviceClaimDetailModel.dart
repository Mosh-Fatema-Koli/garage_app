import 'dart:convert';


import 'package:instasure/domains/models/deviceInsurance/deviceInfoModel.dart';
import 'package:instasure/domains/models/insurancePriceInfoModel.dart';

import '../customerInfoModel.dart';

class DeviceClaimDetailModel {
  int? id;
  dynamic userId;
  dynamic serviceCenterId;
  dynamic deviceInsuranceId;
  dynamic claimId;
  dynamic amountWillPayInsProvider;
  dynamic settlementAmount;
  dynamic userWillPay;
  dynamic status;
  dynamic statusAdmin;
  dynamic paymentStatusAdmin;
  dynamic paymentStatus;
  dynamic deviceValue;
  dynamic document;
  dynamic totalAmount;
  dynamic paymentDetails;
  dynamic statusNote;
  dynamic claimOn;
  String? createdAt;
  String? updatedAt;
  List<String>? documentPath;
  DeviceInsurance? deviceInsurance;
  ServiceCenter? serviceCenter;
  List<DeviceClaimedParts>? deviceClaimedParts;

  DeviceClaimDetailModel(
      {this.id,
      this.userId,
      this.serviceCenterId,
      this.deviceInsuranceId,
      this.claimId,
      this.amountWillPayInsProvider,
      this.settlementAmount,
      this.userWillPay,
      this.status,
      this.statusAdmin,
      this.paymentStatusAdmin,
      this.paymentStatus,
      this.deviceValue,
      this.document,
      this.totalAmount,
      this.paymentDetails,
      this.statusNote,
      this.claimOn,
      this.createdAt,
      this.updatedAt,
      this.documentPath,
      this.deviceInsurance,
      this.serviceCenter,
      this.deviceClaimedParts});

  DeviceClaimDetailModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    userId = json['user_id'];
    serviceCenterId = json['service_center_id'];
    deviceInsuranceId = json['device_insurance_id'];
    claimId = json['claim_id'];
    amountWillPayInsProvider = json['amount_will_pay_ins_provider'];
    settlementAmount = json['settlement_amount'];
    userWillPay = json['user_will_pay'];
    status = json['status'];
    statusAdmin = json['status_admin'];
    paymentStatusAdmin = json['payment_status_admin'];
    paymentStatus = json['payment_status'];
    deviceValue = json['device_value'];
    document = json['document'];
    totalAmount = json['total_amount'];
    paymentDetails = json['payment_details'];
    statusNote = json['status_note'];
    claimOn = json['claim_on'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    documentPath = json['document_path'].cast<String>();
    deviceInsurance = json['device_insurance'] != null
        ? DeviceInsurance.fromJson(json['device_insurance'])
        : null;
    serviceCenter = json['service_center'] != null
        ? ServiceCenter.fromJson(json['service_center'])
        : null;
    if (json['device_claimed_parts'] != null) {
      deviceClaimedParts = <DeviceClaimedParts>[];
      json['device_claimed_parts'].forEach((v) {
        deviceClaimedParts!.add(DeviceClaimedParts.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['user_id'] = this.userId;
    data['service_center_id'] = this.serviceCenterId;
    data['device_insurance_id'] = this.deviceInsuranceId;
    data['claim_id'] = this.claimId;
    data['amount_will_pay_ins_provider'] = this.amountWillPayInsProvider;
    data['settlement_amount'] = this.settlementAmount;
    data['user_will_pay'] = this.userWillPay;
    data['status'] = this.status;
    data['status_admin'] = this.statusAdmin;
    data['payment_status_admin'] = this.paymentStatusAdmin;
    data['payment_status'] = this.paymentStatus;
    data['device_value'] = this.deviceValue;
    data['document'] = this.document;
    data['total_amount'] = this.totalAmount;
    data['payment_details'] = this.paymentDetails;
    data['status_note'] = this.statusNote;
    data['claim_on'] = this.claimOn;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    data['document_path'] = this.documentPath;
    if (this.deviceInsurance != null) {
      data['device_insurance'] = this.deviceInsurance!.toJson();
    }
    if (this.serviceCenter != null) {
      data['service_center'] = this.serviceCenter!.toJson();
    }
    if (this.deviceClaimedParts != null) {
      data['device_claimed_parts'] =
          this.deviceClaimedParts!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class DeviceInsurance {
  int? id;
  dynamic userId;
  dynamic parentDealerId;
  dynamic childDealerId;
  dynamic packageId;
  dynamic parentDealerCommission;
  dynamic childDealerCommission;
  dynamic otherDealerCommission;
  dynamic claimableAmount;
  dynamic claimedAmount;
  dynamic instasureAmount;
  dynamic subTotal;
  dynamic totalVat;
  dynamic totalDiscount;
  dynamic couponAmount;
  dynamic grandTotal;
  dynamic paymentMethod;
  String? paymentStatus;
  String? status;
  List<InsurancePriceInfoModel>? insuranceTypeValue;
  String? dealerWillPay;
  CustomerInfoModel? customerInfo;
  DeviceInfoModel? deviceInfo;
  dynamic policyNumber;
  dynamic invoiceCode;
  dynamic paymentDetails;
  dynamic totalAmountForCal;
  dynamic includedAmount;
  dynamic includedVatAmount;
  dynamic vatPecentage;
  dynamic parentWillPayToAdmin;
  dynamic parentWillPayToChild;
  dynamic protectionTimesFor;
  String? imeiOne;
  String? imeiTwo;
  String? createdAt;
  String? updatedAt;
  dynamic packageType;
  dynamic customerWillPayCharge;

  DeviceInsurance(
      {this.id,
      this.userId,
      this.parentDealerId,
      this.childDealerId,
      this.packageId,
      this.parentDealerCommission,
      this.childDealerCommission,
      this.otherDealerCommission,
      this.claimableAmount,
      this.claimedAmount,
      this.instasureAmount,
      this.subTotal,
      this.totalVat,
      this.totalDiscount,
      this.couponAmount,
      this.grandTotal,
      this.paymentMethod,
      this.paymentStatus,
      this.status,
      this.insuranceTypeValue,
      this.dealerWillPay,
      this.customerInfo,
      this.deviceInfo,
      this.policyNumber,
      this.invoiceCode,
      this.paymentDetails,
      this.totalAmountForCal,
      this.includedAmount,
      this.includedVatAmount,
      this.vatPecentage,
      this.parentWillPayToAdmin,
      this.parentWillPayToChild,
      this.protectionTimesFor,
      this.imeiOne,
      this.imeiTwo,
      this.createdAt,
      this.updatedAt,
      this.packageType,
      this.customerWillPayCharge});

  DeviceInsurance.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    userId = json['user_id'];
    parentDealerId = json['parent_dealer_id'];
    childDealerId = json['child_dealer_id'];
    packageId = json['package_id'];
    parentDealerCommission = json['parent_dealer_commission'];
    childDealerCommission = json['child_dealer_commission'];
    otherDealerCommission = json['other_dealer_commission'];
    claimableAmount = json['claimable_amount'];
    claimedAmount = json['claimed_amount'];
    instasureAmount = json['instasure_amount'];
    subTotal = json['sub_total'];
    totalVat = json['total_vat'];
    totalDiscount = json['total_discount'];
    couponAmount = json['coupon_amount'];
    grandTotal = json['grand_total'];
    paymentMethod = json['payment_method'];
    paymentStatus = json['payment_status'];
    status = json['status'];

    List jsonList = jsonDecode(json['insurance_type_value']) as List;
    List<InsurancePriceInfoModel> histories = jsonList
        .map((jsonElement) => InsurancePriceInfoModel.fromJson(jsonElement))
        .toList();
    insuranceTypeValue = histories;
    dealerWillPay = json['dealer_will_pay'];
    customerInfo =
        CustomerInfoModel.fromJson(jsonDecode(json['customer_info']));
    deviceInfo = DeviceInfoModel.fromJson(jsonDecode(json['device_info']));

    policyNumber = json['policy_number'];
    invoiceCode = json['invoice_code'];
    paymentDetails = json['payment_details'];
    totalAmountForCal = json['totalAmountForCal'];
    includedAmount = json['includedAmount'];
    includedVatAmount = json['includedVatAmount'];
    vatPecentage = json['vat_pecentage'];
    parentWillPayToAdmin = json['parent_will_pay_to_admin'];
    parentWillPayToChild = json['parent_will_pay_to_child'];
    protectionTimesFor = json['protection_times_for'];
    imeiOne = json['imei_one'];
    imeiTwo = json['imei_two'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    packageType = json['package_type'];
    customerWillPayCharge = json['customer_will_pay_charge'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['user_id'] = this.userId;
    data['parent_dealer_id'] = this.parentDealerId;
    data['child_dealer_id'] = this.childDealerId;
    data['package_id'] = this.packageId;
    data['parent_dealer_commission'] = this.parentDealerCommission;
    data['child_dealer_commission'] = this.childDealerCommission;
    data['other_dealer_commission'] = this.otherDealerCommission;
    data['claimable_amount'] = this.claimableAmount;
    data['claimed_amount'] = this.claimedAmount;
    data['instasure_amount'] = this.instasureAmount;
    data['sub_total'] = this.subTotal;
    data['total_vat'] = this.totalVat;
    data['total_discount'] = this.totalDiscount;
    data['coupon_amount'] = this.couponAmount;
    data['grand_total'] = this.grandTotal;
    data['payment_method'] = this.paymentMethod;
    data['payment_status'] = this.paymentStatus;
    data['status'] = this.status;
    data['insurance_type_value'] = this.insuranceTypeValue;
    data['dealer_will_pay'] = this.dealerWillPay;
    data['customer_info'] = this.customerInfo;
    data['device_info'] = this.deviceInfo;
    data['policy_number'] = this.policyNumber;
    data['invoice_code'] = this.invoiceCode;
    data['payment_details'] = this.paymentDetails;
    data['totalAmountForCal'] = this.totalAmountForCal;
    data['includedAmount'] = this.includedAmount;
    data['includedVatAmount'] = this.includedVatAmount;
    data['vat_pecentage'] = this.vatPecentage;
    data['parent_will_pay_to_admin'] = this.parentWillPayToAdmin;
    data['parent_will_pay_to_child'] = this.parentWillPayToChild;
    data['protection_times_for'] = this.protectionTimesFor;
    data['imei_one'] = this.imeiOne;
    data['imei_two'] = this.imeiTwo;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    data['package_type'] = this.packageType;
    data['customer_will_pay_charge'] = this.customerWillPayCharge;
    return data;
  }
}

class ServiceCenter {
  int? id;
  dynamic userId;
  dynamic parentId;
  dynamic brandId;
  dynamic divisionId;
  dynamic districtId;
  dynamic upazilaId;
  dynamic contactPersonName;
  dynamic contactPersonEmail;
  dynamic contactPersonPhone;
  dynamic serviceCenterName;
  dynamic logo;
  String? city;
  String? area;
  String? address;
  dynamic balance;
  String? dueBalance;
  String? createdAt;
  String? updatedAt;

  ServiceCenter(
      {this.id,
      this.userId,
      this.parentId,
      this.brandId,
      this.divisionId,
      this.districtId,
      this.upazilaId,
      this.contactPersonName,
      this.contactPersonEmail,
      this.contactPersonPhone,
      this.serviceCenterName,
      this.logo,
      this.city,
      this.area,
      this.address,
      this.balance,
      this.dueBalance,
      this.createdAt,
      this.updatedAt});

  ServiceCenter.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    userId = json['user_id'];
    parentId = json['parent_id'];
    brandId = json['brand_id'];
    divisionId = json['division_id'];
    districtId = json['district_id'];
    upazilaId = json['upazila_id'];
    contactPersonName = json['contact_person_name'];
    contactPersonEmail = json['contact_person_email'];
    contactPersonPhone = json['contact_person_phone'];
    serviceCenterName = json['service_center_name'];
    logo = json['logo'];
    city = json['city'];
    area = json['area'];
    address = json['address'];
    balance = json['balance'];
    dueBalance = json['due_balance'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['user_id'] = this.userId;
    data['parent_id'] = this.parentId;
    data['brand_id'] = this.brandId;
    data['division_id'] = this.divisionId;
    data['district_id'] = this.districtId;
    data['upazila_id'] = this.upazilaId;
    data['contact_person_name'] = this.contactPersonName;
    data['contact_person_email'] = this.contactPersonEmail;
    data['contact_person_phone'] = this.contactPersonPhone;
    data['service_center_name'] = this.serviceCenterName;
    data['logo'] = this.logo;
    data['city'] = this.city;
    data['area'] = this.area;
    data['address'] = this.address;
    data['balance'] = this.balance;
    data['due_balance'] = this.dueBalance;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    return data;
  }
}

class DeviceClaimedParts {
  int? id;
  dynamic deviceClaimId;
  dynamic deviceInsuranceId;
  dynamic partsName;
  dynamic partsIdentityNumber;
  dynamic partsPrice;
  dynamic partsDetails;
  dynamic status;
  String? createdAt;
  String? updatedAt;

  DeviceClaimedParts(
      {this.id,
      this.deviceClaimId,
      this.deviceInsuranceId,
      this.partsName,
      this.partsIdentityNumber,
      this.partsPrice,
      this.partsDetails,
      this.status,
      this.createdAt,
      this.updatedAt});

  DeviceClaimedParts.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    deviceClaimId = json['device_claim_id'];
    deviceInsuranceId = json['device_insurance_id'];
    partsName = json['parts_name'];
    partsIdentityNumber = json['parts_identity_number'];
    partsPrice = json['parts_price'];
    partsDetails = json['parts_details'];
    status = json['status'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['device_claim_id'] = this.deviceClaimId;
    data['device_insurance_id'] = this.deviceInsuranceId;
    data['parts_name'] = this.partsName;
    data['parts_identity_number'] = this.partsIdentityNumber;
    data['parts_price'] = this.partsPrice;
    data['parts_details'] = this.partsDetails;
    data['status'] = this.status;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    return data;
  }
}
