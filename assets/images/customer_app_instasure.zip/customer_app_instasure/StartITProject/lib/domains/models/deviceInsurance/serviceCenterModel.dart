class ServiceCenterModel {
  int? id;
  dynamic userId;
  dynamic parentId;
  dynamic brandId;
  dynamic divisionId;
  dynamic districtId;
  dynamic upazilaId;
  dynamic contactPersonName;
  dynamic contactPersonEmail;
  dynamic contactPersonPhone;
  dynamic serviceCenterName;
  dynamic logo;
  dynamic city;
  dynamic area;
  dynamic address;
  dynamic balance;
  dynamic dueBalance;
  dynamic active;
  dynamic createdAt;
  dynamic updatedAt;

  ServiceCenterModel(
      {this.id,
      this.userId,
      this.parentId,
      this.brandId,
      this.divisionId,
      this.districtId,
      this.upazilaId,
      this.contactPersonName,
      this.contactPersonEmail,
      this.contactPersonPhone,
      this.serviceCenterName,
      this.logo,
      this.city,
      this.area,
      this.address,
      this.balance,
      this.dueBalance,
      this.active,
      this.createdAt,
      this.updatedAt});

  ServiceCenterModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    userId = json['user_id'];
    parentId = json['parent_id'];
    brandId = json['brand_id'];
    divisionId = json['division_id'];
    districtId = json['district_id'];
    upazilaId = json['upazila_id'];
    contactPersonName = json['contact_person_name'];
    contactPersonEmail = json['contact_person_email'];
    contactPersonPhone = json['contact_person_phone'];
    serviceCenterName = json['service_center_name'];
    logo = json['logo'];
    city = json['city'];
    area = json['area'];
    address = json['address'];
    balance = json['balance'];
    dueBalance = json['due_balance'];
    active = json['active'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['user_id'] = this.userId;
    data['parent_id'] = this.parentId;
    data['brand_id'] = this.brandId;
    data['division_id'] = this.divisionId;
    data['district_id'] = this.districtId;
    data['upazila_id'] = this.upazilaId;
    data['contact_person_name'] = this.contactPersonName;
    data['contact_person_email'] = this.contactPersonEmail;
    data['contact_person_phone'] = this.contactPersonPhone;
    data['service_center_name'] = this.serviceCenterName;
    data['logo'] = this.logo;
    data['city'] = this.city;
    data['area'] = this.area;
    data['address'] = this.address;
    data['balance'] = this.balance;
    data['due_balance'] = this.dueBalance;
    data['active'] = this.active;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    return data;
  }
}
