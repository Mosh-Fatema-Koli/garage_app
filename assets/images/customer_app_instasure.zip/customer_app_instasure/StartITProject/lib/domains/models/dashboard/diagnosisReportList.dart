// ignore_for_file: unnecessary_new

import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:instasure/Utilities/userPref.dart';
import 'package:instasure/domains/models/dashboard/mobileDiagnosisReport.dart';
import 'package:instasure/domains/repo/apiClientCustomerDasboard.dart';
import 'package:instasure/Utilities/helper.dart';
import 'package:instasure/screens/dashboard/diagnosisReportDetail.dart';
import 'package:instasure/screens/mainPage.dart';
import 'package:instasure/widgets/topView4.dart';

class DiagnosisReportList extends StatefulWidget {
  const DiagnosisReportList({Key? key}) : super(key: key);

  @override
  _DiagnosisReportListState createState() => _DiagnosisReportListState();
}

class _DiagnosisReportListState extends State<DiagnosisReportList> {
  final ApiClientCustomerDasboard _apiClient = ApiClientCustomerDasboard();
  List<MobileDiagnosisReport> _mobileDiagnosisReportList = [];

  var loading = true;

  @override
  void initState() {
    super.initState();
    () async {
      await Future.delayed(Duration.zero);
      mobileDiagnosisReportList();
    }();
  }

  Future<void> mobileDiagnosisReportList() async {
    UserPref prefs = UserPref();
    Future<String?> token = prefs.getTokenFromPref();
    String? accessToken = await token;
    EasyLoading.instance.userInteractions = false;
    EasyLoading.show(status: 'Processing...');
    dynamic res = await _apiClient.mobileDiagnosisReportList(accessToken!);
    EasyLoading.dismiss();
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    if (res.statusCode == 200) {
      if (res.data['code'] == 200) {
        List jsonList = res.data['data'] as List;
        List<MobileDiagnosisReport> histories = jsonList
            .map((jsonElement) => MobileDiagnosisReport.fromJson(jsonElement))
            .toList();

        setState(() {
          _mobileDiagnosisReportList = histories;
          loading = false;
        });
      } else {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('${res.data['message']}'),
          backgroundColor: Colors.red.shade300,
        ));
        setState(() {
          loading = false;
        });
      }
    } else {
      setState(() {
        loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(
        // title: const Text('Home'),

        // title: Text("YOUR_APPBAR_TITLE"),
        // automaticallyImplyLeading: false,



        title: Image.asset('assets/instasure_icon.png',fit: BoxFit.contain, height: 32,),

        leading: new IconButton(
          icon: new Icon(Icons.arrow_back, color: const Color(0xff002E5B),),
          onPressed: () =>

             Navigator.push( context, MaterialPageRoute( builder: (context) => const MainPage()), ),
        ),


        automaticallyImplyLeading: true,
        backgroundColor: Colors.white,
        actions: <Widget>[
          IconButton(
            // AssetImage("assets/home/insurance.png"),
            icon: Icon(
              Icons.help_center,
              color: const Color(0xff002E5B),
            ),
            /*icon: Icon(
                Icons.settings,
                color: Colors.white,
              ),*/
            onPressed: () {
              setState(() {

              });
              /* Navigator.push(
                   context,
                   MaterialPageRoute(builder: (context) => const  MenuScreen()),
                 );*/

            },
          )
        ],
      ),




      body: Column(
          children: [
            SizedBox(
              height:20,
            ),
            createHeader(),
            Expanded(
                  child:ListView.builder(
                    primary: false,
                    scrollDirection: Axis.vertical,
                    shrinkWrap: true,
                    itemCount: _mobileDiagnosisReportList.length,
                    itemBuilder: (BuildContext context, int index) =>
                        _buildList(index),
                  ),
            )
                  ]
      )

     /* */


    );



    /*  body: loading
          ? const Center(
              child: Text(""),
            )
          : Center(
              child: Padding(
              padding: const EdgeInsets.all(0),
              child: Column(
                children: [
                  Stack(
                    children: [
                      Container(
                        child: Column(
                          children: [
                          SizedBox(height: 20)
                          ],
                        ),
                      ),
                      Positioned(
                        bottom: 20.0,
                        left: 40.0,
                        child: SizedBox(
                            height: 30,
                            width: 30,
                            // color: const Color.fromRGBO(0, 46, 91, 1.0),
                            // padding: const EdgeInsets.fromLTRB(10, 15, 10, 5),
                            child: TextButton(
                              child: Image.asset('assets/back_button_icon.png'),
                              onPressed: () {
                                Navigator.of(context).pop();
                              },
                            )),
                      )
                    ],
                  ),
                  const SizedBox(height: 10.0),
                  createHeader(),
                  // const SizedBox(height: 20.0),
                  // creatSearchBar(),
                  const SizedBox(height: 20.0),
                  Expanded(
                    child: ListView(
                      children: <Widget>[buildListView2(), SizedBox(height: 20.0)],
                    ),
                  ),
                  const SizedBox(height: 80.0),
                ],
              ),
            )),




      backgroundColor: const Color(0xFFEFF7FF),
    );*/
  }




  _buildList(index) {
    MobileDiagnosisReport mobileDiagnosisReport =
    _mobileDiagnosisReportList[index];


    return Padding(
      padding: const EdgeInsets.only(
          right: 14, top: 10, bottom: 10, left: 14),
      child: GestureDetector(
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => DiagnosisReportDetail(
                    id: "${mobileDiagnosisReport.serialNumber}",
                  )),
            );
          },

    child: Container(
      alignment: Alignment.centerLeft,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(13),
        boxShadow: [
          BoxShadow(
              color: const Color(0xff000000).withOpacity(0.51),
              blurRadius: 16,
              spreadRadius: 0,
              offset: const Offset(0, 0)),
        ],
        color: const Color(0xffF0F3F6),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          const SizedBox(height: 20.0),
          Align(
            alignment: Alignment.centerLeft,
            child: Padding(
              padding: const EdgeInsets.only(left: 30),
              child: RichText(
                text: TextSpan(
                  style: const TextStyle(
                      color: Colors.black, fontSize: 15),
                  children: <TextSpan>[
                    const TextSpan(
                        text: 'Brand Name: ',
                        style:
                        TextStyle(color: Color(0xFF002E5B))),
                    TextSpan(
                        text:
                        "${mobileDiagnosisReport.brand?.name}",
                        style: const TextStyle(
                            color: Color(0xFF86888A),
                            fontSize: 13)),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(height: 10.0),
          Padding(
            padding: const EdgeInsets.only(left: 30),
            child: RichText(
              text: TextSpan(
                style: const TextStyle(
                    color: Colors.black, fontSize: 15),
                children: <TextSpan>[
                  const TextSpan(
                      text: 'Model Name: ',
                      style: TextStyle(color: Color(0xFF002E5B))),
                  TextSpan(
                      text:
                      "${mobileDiagnosisReport.model?.name}",
                      style: const TextStyle(
                          color: Color(0xFF86888A),
                          fontSize: 13)),
                ],
              ),
            ),
          ),
          const SizedBox(height: 10.0),
          Padding(
            padding: const EdgeInsets.only(left: 30),
            child: RichText(
              text: TextSpan(
                style: const TextStyle(
                    color: Colors.black, fontSize: 15),
                children: <TextSpan>[
                  const TextSpan(
                      text: 'Serial No: ',
                      style: TextStyle(color: Color(0xFF002E5B))),
                  TextSpan(
                      text:
                      "${mobileDiagnosisReport.serialNumber}",
                      style: const TextStyle(
                          color: Color(0xFF86888A),
                          fontSize: 13)),
                ],
              ),
            ),
          ),
          const SizedBox(height: 10.0),
          Padding(
            padding: const EdgeInsets.only(left: 30),
            child: RichText(
              text: TextSpan(
                style: const TextStyle(
                    color: Colors.black, fontSize: 15),
                children: <TextSpan>[
                  const TextSpan(
                      text: 'Created date: ',
                      style: TextStyle(color: Color(0xFF002E5B))),
                  TextSpan(
                      text: getDateString(
                          mobileDiagnosisReport.createdAt ?? " ",
                          'dd MMM yyyy'),
                      style: const TextStyle(
                          color: Color(0xFF86888A),
                          fontSize: 13)),
                ],
              ),
            ),
          ),
          const SizedBox(height: 10.0),
          Padding(
            padding: const EdgeInsets.only(left: 30),
            child: RichText(
              text: TextSpan(
                style: const TextStyle(
                    color: Colors.black, fontSize: 15),
                children: <TextSpan>[
                  const TextSpan(
                      text: 'Validate For or Message: ',
                      style: TextStyle(color: Color(0xFF002E5B))),
                  TextSpan(
                      text:
                      "${mobileDiagnosisReport.iValidFor! <=0 ? mobileDiagnosisReport.sValidityMessage :mobileDiagnosisReport.iValidFor.toString()}",
                      style: const TextStyle(
                          color: Color(0xFF86888A),
                          fontSize: 13)),
                ],
              ),
            ),
          ),
          SizedBox(height:20)
        ],
      ),
    )
      ));

  }





  createHeader() {
    return Container(
      height: 38,
      child: const Center(
        child: Text(
          'Mobile Diagnosis Report list',
          textAlign: TextAlign.center,
          style: TextStyle(
            fontFamily: 'Roboto Slab',
            fontSize: 16,
            color: Color(0xff002E5B),
          ),
        ),
      ),
      decoration: const BoxDecoration(color: Color(0xffF0F3F6), boxShadow: [
        BoxShadow(
            color: Color(0xffffffff),
            blurRadius: 6,
            spreadRadius: 0,
            offset: Offset(-3, -3)),
        BoxShadow(
            color: Color(0xffDDE4EF),
            blurRadius: 6,
            spreadRadius: 0,
            offset: Offset(3, 3)),
      ]),
    );
  }

  creatSearchBar() {
    return Padding(
        padding: const EdgeInsets.only(right: 30, top: 0, bottom: 0, left: 30),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const SizedBox(
              width: 10,
            ),
            GestureDetector(
              onTap: () {},
              child: Container(
                height: 22,
                padding: const EdgeInsets.only(left: 5, right: 5),
                child: Row(
                  children: const [
                    Text(
                      'Search',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontFamily: 'Roboto Slab',
                        fontSize: 16,
                        color: Color(0xff002E5B),
                      ),
                    ),
                    SizedBox(
                      width: 5,
                    ),
                    Icon(Icons.search),
                  ],
                ),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(15),
                    boxShadow: const [
                      BoxShadow(
                          color: Color(0xFFFFFFFF),
                          blurRadius: 6,
                          spreadRadius: 0,
                          offset: Offset(-3, -3)),
                      BoxShadow(
                          color: Color(0xFFFFFFFF),
                          blurRadius: 6,
                          spreadRadius: 0,
                          offset: Offset(3, 3)),
                    ],
                    color: const Color(0xFFF0F3F6)),
              ),
            ),
          ],
        ));
  }



  buildListView2() {

    ListView.separated(
      itemCount: 25,
      separatorBuilder: (BuildContext context, int index) => const Divider(),
      itemBuilder: (BuildContext context, int index) {
        return ListTile(
          title: Text('item $index'),
        );
      },
    );
  }
}
