class InsurancePriceInfoModel {
  String? partsType;
  dynamic price;
  String? insType;

  InsurancePriceInfoModel({this.partsType, this.price, this.insType});

  InsurancePriceInfoModel.fromJson(Map<String, dynamic> json) {
    partsType = json['parts_type'];
    price = json['price'];
    insType = json['ins_type'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['parts_type'] = this.partsType;
    data['price'] = this.price;
    data['ins_type'] = this.insType;
    return data;
  }
}
