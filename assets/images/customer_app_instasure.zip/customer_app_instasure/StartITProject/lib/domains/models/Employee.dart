class Employee {
  int sl;
  String centerName;
  String centerAddress;
  String deviceName;
  String deviceBrand;
  String deviceModel;
  Employee({required this.sl, required this.centerName, required this.centerAddress, required this.deviceName, required this.deviceBrand, required this.deviceModel});
  static List<Employee> getUsers() {
    return <Employee>[
      Employee(
          sl: 1,
          centerName: "Instasure",
          centerAddress: "Instasure Address",
          deviceName: "Rewadme Note",
          deviceBrand: "Rewadme Note pro",
          deviceModel: "Rewadme Note max"),
      Employee(
          sl: 1,
          centerName: "Instasure",
          centerAddress: "Instasure Address",
          deviceName: "Rewadme Note",
          deviceBrand: "Rewadme Note pro",
          deviceModel: "Rewadme Note max"),
      Employee(
          sl: 1,
          centerName: "Instasure",
          centerAddress: "Instasure Address",
          deviceName: "Rewadme Note",
          deviceBrand: "Rewadme Note pro",
          deviceModel: "Rewadme Note max"),
      Employee(
          sl: 1,
          centerName: "Instasure",
          centerAddress: "Instasure Address",
          deviceName: "Rewadme Note",
          deviceBrand: "Rewadme Note pro",
          deviceModel: "Rewadme Note max"),
      Employee(
          sl: 1,
          centerName: "Instasure",
          centerAddress: "Instasure Address",
          deviceName: "Rewadme Note",
          deviceBrand: "Rewadme Note pro",
          deviceModel: "Rewadme Note max")
    ];
  }
}