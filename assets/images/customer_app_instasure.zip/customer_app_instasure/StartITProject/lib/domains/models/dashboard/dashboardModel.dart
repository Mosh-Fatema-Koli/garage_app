import 'package:json_annotation/json_annotation.dart';
part 'dashboardModel.g.dart';

@JsonSerializable()
class DashboardModel {
  int totalMediclaimOrder = 0;
  int totalDeviceOrder = 0;
  int totalDeviceClaim = 0;
  int totalDeviceServiceRequest = 0;

  DashboardModel({
    required this.totalMediclaimOrder,
    required this.totalDeviceOrder,
    required this.totalDeviceClaim,
    required this.totalDeviceServiceRequest,
  });

  factory DashboardModel.fromJson(Map<String, dynamic> json) =>
      _$DashboardFromJson(json);
  Map<String, dynamic> toJson() => _$DashboardToJson(this);
}
