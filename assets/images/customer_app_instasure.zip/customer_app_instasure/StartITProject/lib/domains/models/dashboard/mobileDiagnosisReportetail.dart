class MobileDiagnosisReportetail {
  int? id;
  int? userId;
  int? dealerId;
  int? brandId;
  int? deviceModelId;
  int? imeiDataId;
  String? validityPeriod;
  String? serialNumber;
  String? batteryNumber;
  int? price;
  int? motherboardStatus;
  int? batteryHealthStatus;
  int? frontCameraStatus;
  int? backCameraStatus;
  int? microphoneStatus;
  int? ramStatus;
  int? romStatus;
  int? displayScreenStatus;
  String? invoiceImage;
  String? deviceImages;
  String? imeiImage;
  String? status;
  int? isActive;
  String? note;
  String? validityMessage;
  /*String? is_order_paid;
  String? order_expire_date;
  var is_diagnosis_required;*/



  dynamic validFor;
  String? createdAt;
  String? updatedAt;
  String? sInvoiceImagePath;
  List<String>? lDeviceImagesPath;
  String? sImeiImagePath;

  MobileDiagnosisReportetail(
      {this.id,
      this.userId,
      this.dealerId,
      this.brandId,
      this.deviceModelId,
      this.imeiDataId,
      this.validityPeriod,
      this.serialNumber,
      this.batteryNumber,
      this.price,
      this.motherboardStatus,
      this.batteryHealthStatus,
      this.frontCameraStatus,
      this.backCameraStatus,
      this.microphoneStatus,
      this.ramStatus,
      this.romStatus,
      this.displayScreenStatus,
      this.invoiceImage,
      this.deviceImages,
      this.imeiImage,
      this.status,
      this.isActive,
      this.note,
      this.validityMessage,
      this.validFor,
      this.createdAt,
      this.updatedAt,
      this.sInvoiceImagePath,
      this.lDeviceImagesPath,
      this.sImeiImagePath,
     /* this.is_order_paid,
      this.order_expire_date,
      this.is_diagnosis_required*/
      });

  MobileDiagnosisReportetail.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    userId = json['user_id'];
    dealerId = json['dealer_id'];
    brandId = json['brand_id'];
    deviceModelId = json['device_model_id'];
    imeiDataId = json['imei_data_id'];
    validityPeriod = json['validity_period'];
    serialNumber = json['serial_number'];
    batteryNumber = json['battery_number'];
    price = json['price'];
    motherboardStatus = json['motherboard_status'];
    batteryHealthStatus = json['battery_health_status'];
    frontCameraStatus = json['front_camera_status'];
    backCameraStatus = json['back_camera_status'];
    microphoneStatus = json['microphone_status'];
    ramStatus = json['ram_status'];
    romStatus = json['rom_status'];
    displayScreenStatus = json['display_screen_status'];
    invoiceImage = json['invoice_image'];
    deviceImages = json['device_images'];
    imeiImage = json['imei_image'];
    status = json['status'];
    isActive = json['is_active'];
    note = json['note'];
    validityMessage = json['_validity_message'];
    validFor = json['_valid_for'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    sInvoiceImagePath = json['_invoice_image_path'];
    lDeviceImagesPath = json['_device_images_path'].cast<String>();
    sImeiImagePath = json['_imei_image_path'];
    /*is_order_paid = json['_is_order_paid'];
    order_expire_date = json['_order_expire_date'];
    is_diagnosis_required = json['_is_diagnosis_required'];*/
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['user_id'] = this.userId;
    data['dealer_id'] = this.dealerId;
    data['brand_id'] = this.brandId;
    data['device_model_id'] = this.deviceModelId;
    data['imei_data_id'] = this.imeiDataId;
    data['validity_period'] = this.validityPeriod;
    data['serial_number'] = this.serialNumber;
    data['battery_number'] = this.batteryNumber;
    data['price'] = this.price;
    data['motherboard_status'] = this.motherboardStatus;
    data['battery_health_status'] = this.batteryHealthStatus;
    data['front_camera_status'] = this.frontCameraStatus;
    data['back_camera_status'] = this.backCameraStatus;
    data['microphone_status'] = this.microphoneStatus;
    data['ram_status'] = this.ramStatus;
    data['rom_status'] = this.romStatus;
    data['display_screen_status'] = this.displayScreenStatus;
    data['invoice_image'] = this.invoiceImage;
    data['device_images'] = this.deviceImages;
    data['imei_image'] = this.imeiImage;
    data['status'] = this.status;
    data['is_active'] = this.isActive;
    data['note'] = this.note;
    data['_validity_message'] = this.validityMessage;
    data['_valid_for'] = this.validFor;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    data['_invoice_image_path'] = this.sInvoiceImagePath;
    data['_device_images_path'] = this.lDeviceImagesPath;
    data['_imei_image_path'] = this.sImeiImagePath;
    /*data['is_order_paid'] = this.is_order_paid;
    data['order_expire_date'] = this.order_expire_date;
    data['is_diagnosis_required'] = this.is_diagnosis_required;*/
    return data;
  }
}
