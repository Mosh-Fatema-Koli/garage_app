class TravelInsuranceOrderCreateResModel {
  int? userId;
  String? travelInsuranceCategoryTitle;
  String? travelInsPlansCategoryId;
  String? fullName;
  String? phone;
  String? email;
  String? dob;
  String? age;
  String? passportNumber;
  String? passportExpireTill;
  dynamic policyNumber;
  int? insPrice;
  int? travelInsPlansChartsId;
  int? insuranceProviderId;
  String? vatPercentage;
  String? totalVat;
  String? serviceAmount;
  String? serviceTotalAmount;
  int? grandTotal;
  String? flightNumber;
  String? flightDate;
  String? returnDate;
  dynamic totalDate;
  String? invoiceCode;
  String? updatedAt;
  String? createdAt;
  int? id;

  TravelInsuranceOrderCreateResModel(
      {this.userId,
      this.travelInsuranceCategoryTitle,
      this.travelInsPlansCategoryId,
      this.fullName,
      this.phone,
      this.email,
      this.dob,
      this.age,
      this.passportNumber,
      this.passportExpireTill,
      this.policyNumber,
      this.insPrice,
      this.travelInsPlansChartsId,
      this.insuranceProviderId,
      this.vatPercentage,
      this.totalVat,
      this.serviceAmount,
      this.serviceTotalAmount,
      this.grandTotal,
      this.flightNumber,
      this.flightDate,
      this.returnDate,
      this.totalDate,
      this.invoiceCode,
      this.updatedAt,
      this.createdAt,
      this.id});

  TravelInsuranceOrderCreateResModel.fromJson(Map<String, dynamic> json) {
    userId = json['user_id'];
    travelInsuranceCategoryTitle = json['travel_insurance_category_title'];
    travelInsPlansCategoryId = json['travel_ins_plans_category_id'];
    fullName = json['full_name'];
    phone = json['phone'];
    email = json['email'];
    dob = json['dob'];
    age = json['age'];
    passportNumber = json['passport_number'];
    passportExpireTill = json['passport_expire_till'];
    policyNumber = json['policy_number'];
    insPrice = json['ins_price'];
    travelInsPlansChartsId = json['travel_ins_plans_charts_id'];
    insuranceProviderId = json['insurance_provider_id'];
    vatPercentage = json['vat_percentage'];
    totalVat = json['total_vat'];
    serviceAmount = json['service_amount'];
    serviceTotalAmount = json['service_total_amount'];
    grandTotal = json['grand_total'];
    flightNumber = json['flight_number'];
    flightDate = json['flight_date'];
    returnDate = json['return_date'];
    totalDate = json['total_date'];
    invoiceCode = json['invoice_code'];
    updatedAt = json['updated_at'];
    createdAt = json['created_at'];
    id = json['id'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['user_id'] = this.userId;
    data['travel_insurance_category_title'] = this.travelInsuranceCategoryTitle;
    data['travel_ins_plans_category_id'] = this.travelInsPlansCategoryId;
    data['full_name'] = this.fullName;
    data['phone'] = this.phone;
    data['email'] = this.email;
    data['dob'] = this.dob;
    data['age'] = this.age;
    data['passport_number'] = this.passportNumber;
    data['passport_expire_till'] = this.passportExpireTill;
    data['policy_number'] = this.policyNumber;
    data['ins_price'] = this.insPrice;
    data['travel_ins_plans_charts_id'] = this.travelInsPlansChartsId;
    data['insurance_provider_id'] = this.insuranceProviderId;
    data['vat_percentage'] = this.vatPercentage;
    data['total_vat'] = this.totalVat;
    data['service_amount'] = this.serviceAmount;
    data['service_total_amount'] = this.serviceTotalAmount;
    data['grand_total'] = this.grandTotal;
    data['flight_number'] = this.flightNumber;
    data['flight_date'] = this.flightDate;
    data['return_date'] = this.returnDate;
    data['total_date'] = this.totalDate;
    data['invoice_code'] = this.invoiceCode;
    data['updated_at'] = this.updatedAt;
    data['created_at'] = this.createdAt;
    data['id'] = this.id;
    return data;
  }
}
