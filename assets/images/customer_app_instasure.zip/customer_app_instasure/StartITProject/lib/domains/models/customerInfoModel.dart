class CustomerInfoModel {
  dynamic name;
  dynamic customerName;
  dynamic customerPhone;
  dynamic customerEmail;
  dynamic incExcType;
  dynamic number;

  CustomerInfoModel(
      {this.name,
      this.customerName,
      this.customerPhone,
      this.customerEmail,
      this.incExcType,
      this.number});

  CustomerInfoModel.fromJson(Map<String, dynamic> json) {
    name = json['name'];
    customerName = json['customer_name'];
    customerPhone = json['customer_phone'];
    customerEmail = json['customer_email'];
    incExcType = json['inc_exc_type'];
    number = json['number'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['name'] = this.name;
    data['customer_name'] = this.customerName;
    data['customer_phone'] = this.customerPhone;
    data['customer_email'] = this.customerEmail;
    data['inc_exc_type'] = this.incExcType;
    data['number'] = this.number;
    return data;
  }
}
