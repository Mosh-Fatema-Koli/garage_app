// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'user.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

User _$UserFromJson(Map<String, dynamic> json) {
  return User(
    id: json['id'] as int,
    name: json['name'] as String,
    phone: json['phone'] as String,
    userType: json['user_type'] as String,
    email: json['email'] as String?,
    providerId: json['provider_id'] as String?,
    emailVerifiedAt: json['email_verified_at'] as String?,
    verificationCode: json['verification_code'] as String?,
    newEmailVerificiationCode: json['new_email_verificiation_code'] as String?,
    //  avatarOriginal: json['avatar_original'] as String?,
    avatarOriginal: json['avatar_original_img'] as String?,

    address: json['address'] as String?,
    dob: json['dob'] as String?,
    nid: json['nid'] as dynamic,
    passportImg: json['passport_img'] as dynamic,
    passport: json['passport'] as String?,
    passportNumber: json['passport_number'] as String?,
    passportExpireTill: json['passport_expire_till'] as String?,
    driving_licence_img: json['driving_licence_img'] as String?,
    birthCertificate: json['birth_certificate'] as String?,
  );
}

Map<String, dynamic> _$UserToJson(User instance) => <String, dynamic>{
      'id': instance.id,
      'name': instance.name,
      'email': instance.email,
      'phone': instance.phone,
      'user_type': instance.userType,
      'provider_id': instance.providerId,
      'email_verified_at': instance.emailVerifiedAt,
      'verification_code': instance.verificationCode,
      'new_email_verificiation_code': instance.newEmailVerificiationCode,
      'avatar_original_img': instance.avatarOriginal,
      'address': instance.address,
      'dob': instance.dob,
      'nid': instance.nid,
      'passport': instance.passport,
      'passport_number': instance.passportNumber,
      'passport_expire_till': instance.passportExpireTill,
      'driving_licence_img': instance.driving_licence_img,
      'birth_certificate': instance.birthCertificate,
    };

// ResponseData _$ResponseDataFromJson(Map<String, dynamic> json) {
//   return ResponseData(
//     code: json['code'] as int,
//     meta: json['meta'],
//     data: json['data'] as List,
//   );
// }

// Map<String, dynamic> _$ResponseDataToJson(ResponseData instance) =>
//     <String, dynamic>{
//       'code': instance.code,
//       'meta': instance.meta,
//       'data': instance.data,
//     };
