
import 'package:flutter/material.dart';

class vehicleInsuranceHistory extends StatefulWidget {
  const vehicleInsuranceHistory({Key? key}) : super(key: key);

  @override
  State<vehicleInsuranceHistory> createState() => _vehicleInsuranceHistoryState();
}

class _vehicleInsuranceHistoryState extends State<vehicleInsuranceHistory> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(

    );
  }
}
