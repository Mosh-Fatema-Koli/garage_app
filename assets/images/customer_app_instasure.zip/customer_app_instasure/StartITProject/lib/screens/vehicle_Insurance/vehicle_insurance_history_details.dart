
import 'package:flutter/material.dart';

class VahicleInauranceHistoryDetails extends StatefulWidget {
  const VahicleInauranceHistoryDetails({Key? key}) : super(key: key);

  @override
  State<VahicleInauranceHistoryDetails> createState() => _VahicleInauranceHistoryDetailsState();
}

class _VahicleInauranceHistoryDetailsState extends State<VahicleInauranceHistoryDetails> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(

    );
  }
}
