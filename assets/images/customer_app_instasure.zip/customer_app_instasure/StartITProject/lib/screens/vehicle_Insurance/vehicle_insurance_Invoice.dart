import 'package:flutter/material.dart';

class VehicleInvoice extends StatefulWidget {
  const VehicleInvoice({Key? key}) : super(key: key);

  @override
  State<VehicleInvoice> createState() => _VehicleInvoiceState();
}

class _VehicleInvoiceState extends State<VehicleInvoice> {
  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
