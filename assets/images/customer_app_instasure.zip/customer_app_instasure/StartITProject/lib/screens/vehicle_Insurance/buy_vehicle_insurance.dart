
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:instasure/Utilities/ShowMessage.dart';
import 'package:instasure/Utilities/userPref.dart';
import 'package:instasure/domains/models/vehicleInsurance/vehicleInsurance_model.dart';
import 'package:instasure/domains/repo/apiVehicleInsurance.dart';
import 'package:instasure/screens/vehicle_Insurance/payment.dart';

import '../../widgets/topView4.dart';

class BuyVehicleInsurance extends StatefulWidget {
  const BuyVehicleInsurance({Key? key}) : super(key: key);

  @override
  State<BuyVehicleInsurance> createState() => _BuyVehicleInsuranceState();
}

class _BuyVehicleInsuranceState extends State<BuyVehicleInsurance> {

  Color _containerColor = Color(0xFFEFF7FF);

  final ccCarSelectionOptions = ['Select', '800 cc - 1300 cc', '1301 cc - 1800 cc','1801cc - 3000 cc','Over 3000 cc',];
  final ccBikeSelectionOptions = ['Select', '50 cc - 150 cc', '151 cc - 250 cc', '251 cc - 350 cc'];

  String selectedType = 'Select';
  String selectedType1 = 'Select';
  String selectedCategory = 'Select';
  String planCategoryId = '1';
  final List<String> _selectedItems = [];
  bool isSelect = true;
  final List<String> items = [
    'Accidental Damages and Theft Coverage',
    'Flood Cyclone Coverage',
    'Earthquake Coverage',
    'Riot and Strike Damage Coverage'
  ];
  // This function is triggered when a checkbox is checked or unchecked

  void _itemChange(String itemValue, bool isSelected) {
    setState(() {
      if (isSelected) {
        _selectedItems.add(itemValue);
      } else {
        _selectedItems.remove(itemValue);
      }
    });
  }

  bool container1Selected = false;
  bool container2Selected = false;


  @override
  Widget build(BuildContext context) {
     return Scaffold(
        appBar: null,
        backgroundColor: const Color(0xFFEFF7FF),
        body: Padding(
            padding:
            const EdgeInsets.only(left: 0, top: 0, right: 0, bottom: 0),
            child: Column(
              children: [
                Stack(
                  children: [
                    const TopView4(),
                    Positioned(
                      bottom: 20.0,
                      left: 40.0,
                      child: SizedBox(
                          height: 30,
                          width: 30,
                          // color: const Color.fromRGBO(0, 46, 91, 1.0),
                          // padding: const EdgeInsets.fromLTRB(10, 15, 10, 5),
                          child: TextButton(
                            child: Image.asset('assets/back_button_icon.png'),
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                          )),
                    ),
                  ],
                ),
                const SizedBox(
                  height: 20,
                ),
                createHeaderWidget(),
                Expanded(
                  child: ListView(
                    children: [

                      Padding(
                        padding: const EdgeInsets.all(30.0),
                        child: Column(
                          children: <Widget>[

                            Container(
                              height: 40,
                              alignment: Alignment.centerLeft,
                              padding: const EdgeInsets.all(10),
                              child: const Text(
                                'Select Your insurance',
                                style: TextStyle(
                                    fontSize: 17, color: Colors.black),
                              ),
                            ),
                            const SizedBox(
                              height: 20,
                            ),
  //  Select Your insurance
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                GestureDetector(
                                  onTap: () {
                                    setState(() {
                                      container1Selected = true;
                                      container2Selected = false;
                                    });
                                  },
                                  child: Container(
                                    height: 50,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(10),
                                      color: container1Selected ?Color(0xff002E5B): Color(
                                          0x94063F62),
                                    ),
                                    alignment: Alignment.center,
                                    padding: const EdgeInsets.symmetric(horizontal: 20,vertical: 0),
                                    child: const Text(
                                      'Car Insurance',
                                      style: TextStyle(
                                          fontSize: 17, color: Colors.white),
                                    ),
                                  ),
                                ),
                                SizedBox(width: 10,),

                                GestureDetector(
                                  onTap: () {
                                    setState(() {
                                      container1Selected = false;
                                      container2Selected = true;
                                    });
                                  },
                                  child: Container(
                                    height: 50,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(10),
                                      color: container2Selected ? Color(0xff002E5B): Color(
                                          0x94063F62),
                                    ),
                                    alignment: Alignment.center,
                                    padding: const EdgeInsets.symmetric(horizontal: 20,vertical: 0),
                                    child: const Text(
                                      'Bike insurance',
                                      style: TextStyle(
                                          fontSize: 17, color:Colors.white),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            SizedBox(height: 10,),

  //  Select Car Motor CC
                            if (container1Selected)
                              Container(

                                width: double.infinity,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(20),
                                  // color: const Color(0xffF0F3F6),
                                ),
                                alignment: Alignment.center,
                                padding: const EdgeInsets.all(10),
                                child: Column(
                                  children: [

                                    Container(
                                      height: 60,
                                      alignment: Alignment.centerLeft,
                                      padding: const EdgeInsets.all(10),
                                      child: const Text(
                                        'Select Vehicle CC',
                                        style: TextStyle(
                                            fontSize: 17, color: Colors.black),
                                      ),
                                    ),
                                    Container(
                                      height: 40,
                                      alignment: Alignment.center,
                                      padding: const EdgeInsets.all(10),
                                      child: DropdownButton<String>(
                                        isExpanded: true,
                                        isDense: true,
                                        value: selectedType,
                                        icon: const Icon(Icons.arrow_downward),
                                        iconSize: 14,
                                        elevation: 10,
                                        underline: Container(),
                                        onChanged: (var newValue1) {
                                          setState(() {
                                            selectedType = newValue1!;
                                            // getPlanCategory(selectedType);
                                          });
                                        },
                                        items: List.generate(
                                          ccCarSelectionOptions.length,
                                              (index) => DropdownMenuItem(
                                            child: Text(ccCarSelectionOptions[index]),
                                            value: ccCarSelectionOptions[index],
                                          ),
                                        ),
                                      ),
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(20),
                                        boxShadow: const [
                                          BoxShadow(
                                              color: Color(0xFFFFFFFF),
                                              blurRadius: 6,
                                              spreadRadius: 0,
                                              offset: Offset(-3, -3)),
                                          BoxShadow(
                                              color: Color(0xFFDDE4EF),
                                              blurRadius: 6,
                                              spreadRadius: 0,
                                              offset: Offset(3, 3)),
                                        ],
                                        color: const Color(0xffF0F3F6),
                                      ),
                                    ),
                                    const SizedBox(
                                      height: 10,
                                    ),
                                    Container(
                                      height: 40,
                                      alignment: Alignment.centerLeft,
                                      padding: const EdgeInsets.all(10),
                                      child: const Text(
                                        'Price',
                                        style: TextStyle(
                                            fontSize: 17, color: Colors.black),
                                      ),
                                    ),

                                    Container(
                                      height: 40,
                                      padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
                                      child: TextField(
                                        // controller: fullNameController,
                                        decoration: InputDecoration(
                                          contentPadding: const EdgeInsets.only(
                                              left: 10, top: 0, right: 0, bottom: 0),
                                          fillColor: const Color(0xFFF0F3F6),
                                          filled: true,
                                          hintText: "Enter Price",
                                          enabledBorder: OutlineInputBorder(
                                            borderRadius: BorderRadius.circular(20.0),
                                            borderSide: const BorderSide(
                                                color: Colors.transparent, width: 0.0),
                                          ),
                                        ),
                                      ),
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(20),
                                        boxShadow: const [
                                          BoxShadow(
                                              color: Color(0xFFFFFFFF),
                                              blurRadius: 6,
                                              spreadRadius: 0,
                                              offset: Offset(-3, -3)),
                                          BoxShadow(
                                              color: Color(0xFFDDE4EF),
                                              blurRadius: 6,
                                              spreadRadius: 0,
                                              offset: Offset(3, 3)),
                                        ],
                                        color: const Color(0xffF0F3F6),
                                      ),
                                    ),
                                    const SizedBox(
                                      height: 10,
                                    ),
                                    Container(
                                      height: 40,
                                      alignment: Alignment.centerLeft,
                                      padding: const EdgeInsets.all(10),
                                      child: const Text(
                                        'Sit',
                                        style: TextStyle(
                                            fontSize: 17, color: Colors.black),
                                      ),
                                    ),

                                    Container(
                                      height: 40,
                                      padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
                                      child: TextField(
                                        // controller: fullNameController,
                                        decoration: InputDecoration(
                                          contentPadding: const EdgeInsets.only(
                                              left: 10, top: 0, right: 0, bottom: 0),
                                          fillColor: const Color(0xFFF0F3F6),
                                          filled: true,
                                          hintText: "Enter Sit Quantity",
                                          enabledBorder: OutlineInputBorder(
                                            borderRadius: BorderRadius.circular(20.0),
                                            borderSide: const BorderSide(
                                                color: Colors.transparent, width: 0.0),
                                          ),
                                        ),
                                      ),
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(20),
                                        boxShadow: const [
                                          BoxShadow(
                                              color: Color(0xFFFFFFFF),
                                              blurRadius: 6,
                                              spreadRadius: 0,
                                              offset: Offset(-3, -3)),
                                          BoxShadow(
                                              color: Color(0xFFDDE4EF),
                                              blurRadius: 6,
                                              spreadRadius: 0,
                                              offset: Offset(3, 3)),
                                        ],
                                        color: const Color(0xffF0F3F6),
                                      ),
                                    ),

                                    const SizedBox(
                                      height: 10,
                                    ),

                                    Container(
                                      height: 40,
                                      alignment: Alignment.centerLeft,
                                      padding: const EdgeInsets.all(10),
                                      child: const Text(
                                        'Coverages',
                                        style: TextStyle(
                                            fontSize: 17, color: Colors.black),
                                      ),
                                    ),
                                    ListBody(
                                      children: items
                                          .map((item) => CheckboxListTile(
                                       //checkColor: const Color(0xff000000),
                                        activeColor:const Color(0xff002E5B) ,

                                        value: _selectedItems.contains(item),
                                        title: Text(item),
                                        controlAffinity: ListTileControlAffinity.leading,
                                        onChanged: (isChecked) => _itemChange(item, isChecked!),
                                      ))
                                          .toList(),
                                    ),


                                    const SizedBox(
                                      height: 30,
                                    ),
                                    Container(
                                      height: 40,
                                      width: 250,
                                      // padding: const EdgeInsets.fromLTRB(10, 15, 10, 5),
                                      child: TextButton(
                                        child: const Text(
                                          'SUBMIT',
                                          style: TextStyle(color: Colors.white),
                                        ),
                                        onPressed:() {
                                          Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                                builder: (context) =>
                                                    VagiclePayment()),
                                          );

                                        },
                                      ),
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(20),
                                        boxShadow: [
                                          BoxShadow(
                                              color: const Color(0xff000000)
                                                  .withOpacity(0.16),
                                              blurRadius: 3,
                                              spreadRadius: 0,
                                              offset: const Offset(0, 3)),
                                        ],
                                        color: const Color(0xff002E5B),
                                      ),
                                    ),
                                    const SizedBox(
                                      height: 50,
                                    ),

                                  ],
                                ),
                              ),
                            if (container2Selected)
                              Container(

                              width: double.infinity,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(20),
                                // color: const Color(0xffF0F3F6),
                              ),
                              alignment: Alignment.center,
                              padding: const EdgeInsets.all(10),
                              child: Column(
                                children: [

                                  Container(
                                    height: 60,
                                    alignment: Alignment.centerLeft,
                                    padding: const EdgeInsets.all(10),
                                    child: const Text(
                                      'Select Vehicle CC',
                                      style: TextStyle(
                                          fontSize: 17, color: Colors.black),
                                    ),
                                  ),
                                  Container(
                                    height: 40,
                                    alignment: Alignment.center,
                                    padding: const EdgeInsets.all(10),
                                    child: DropdownButton<String>(
                                      isExpanded: true,
                                      isDense: true,
                                      value: selectedType1,
                                      icon: const Icon(Icons.arrow_downward),
                                      iconSize: 14,
                                      elevation: 10,
                                      underline: Container(),
                                      onChanged: (var newValue1) {
                                        setState(() {
                                          selectedType1 = newValue1!;
                                          // getPlanCategory(selectedType);
                                        });
                                      },
                                      items: List.generate(
                                        ccBikeSelectionOptions.length,
                                            (index) => DropdownMenuItem(
                                          child: Text(ccBikeSelectionOptions[index]),
                                          value: ccBikeSelectionOptions[index],
                                        ),
                                      ),
                                    ),
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(20),
                                      boxShadow: const [
                                        BoxShadow(
                                            color: Color(0xFFFFFFFF),
                                            blurRadius: 6,
                                            spreadRadius: 0,
                                            offset: Offset(-3, -3)),
                                        BoxShadow(
                                            color: Color(0xFFDDE4EF),
                                            blurRadius: 6,
                                            spreadRadius: 0,
                                            offset: Offset(3, 3)),
                                      ],
                                      color: const Color(0xffF0F3F6),
                                    ),
                                  ),
                                  const SizedBox(
                                    height: 10,
                                  ),
                                  Container(
                                    height: 40,
                                    alignment: Alignment.centerLeft,
                                    padding: const EdgeInsets.all(10),
                                    child: const Text(
                                      'Price',
                                      style: TextStyle(
                                          fontSize: 17, color: Colors.black),
                                    ),
                                  ),

                                  Container(
                                    height: 40,
                                    padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
                                    child: TextField(
                                      // controller: fullNameController,
                                      decoration: InputDecoration(
                                        contentPadding: const EdgeInsets.only(
                                            left: 10, top: 0, right: 0, bottom: 0),
                                        fillColor: const Color(0xFFF0F3F6),
                                        filled: true,
                                        hintText: "Enter Price",
                                        enabledBorder: OutlineInputBorder(
                                          borderRadius: BorderRadius.circular(20.0),
                                          borderSide: const BorderSide(
                                              color: Colors.transparent, width: 0.0),
                                        ),
                                      ),
                                    ),
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(20),
                                      boxShadow: const [
                                        BoxShadow(
                                            color: Color(0xFFFFFFFF),
                                            blurRadius: 6,
                                            spreadRadius: 0,
                                            offset: Offset(-3, -3)),
                                        BoxShadow(
                                            color: Color(0xFFDDE4EF),
                                            blurRadius: 6,
                                            spreadRadius: 0,
                                            offset: Offset(3, 3)),
                                      ],
                                      color: const Color(0xffF0F3F6),
                                    ),
                                  ),

                                  const SizedBox(
                                    height: 10,
                                  ),

                                  Container(
                                    height: 40,
                                    alignment: Alignment.centerLeft,
                                    padding: const EdgeInsets.all(10),
                                    child: const Text(
                                      'Coverages',
                                      style: TextStyle(
                                          fontSize: 17, color: Colors.black),
                                    ),
                                  ),
                                  ListBody(
                                    children: items
                                        .map((item) => CheckboxListTile(

                                      activeColor:const Color(0xff002E5B) ,
                                      value: _selectedItems.contains(item),
                                      title: Text(item),
                                      controlAffinity: ListTileControlAffinity.leading,
                                      onChanged: (isChecked) => _itemChange(item, isChecked!),
                                    ))
                                        .toList(),
                                  ),


                                  const SizedBox(
                                    height: 30,
                                  ),
                                  Container(
                                    height: 40,
                                    width: 250,
                                    // padding: const EdgeInsets.fromLTRB(10, 15, 10, 5),
                                    child: TextButton(
                                      child: const Text(
                                        'SUBMIT',
                                        style: TextStyle(color: Colors.white),
                                      ),
                                      onPressed:() {},
                                    ),
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(20),
                                      boxShadow: [
                                        BoxShadow(
                                            color: const Color(0xff000000)
                                                .withOpacity(0.16),
                                            blurRadius: 3,
                                            spreadRadius: 0,
                                            offset: const Offset(0, 3)),
                                      ],
                                      color: const Color(0xff002E5B),
                                    ),
                                  ),
                                  const SizedBox(
                                    height: 50,
                                  ),

                                ],
                              ),
                            ),



                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            )));
  }
  createHeaderWidget() {
    return Container(
      height: 38,
      child: const Center(
        child: Text(
          ' BUY MOTOR INSURANCE',
          textAlign: TextAlign.center,
          style: TextStyle(
            fontFamily: 'Roboto Slab',
            fontSize: 16,
            color: Color(0xff002E5B),
          ),
        ),
      ),
      decoration: const BoxDecoration(color: Color(0xffF0F3F6), boxShadow: [
        BoxShadow(
            color: Color(0xffffffff),
            blurRadius: 6,
            spreadRadius: 0,
            offset: Offset(-3, -3)),
        BoxShadow(
            color: Color(0xffDDE4EF),
            blurRadius: 6,
            spreadRadius: 0,
            offset: Offset(3, 3)),
      ]),
    );
  }


}
