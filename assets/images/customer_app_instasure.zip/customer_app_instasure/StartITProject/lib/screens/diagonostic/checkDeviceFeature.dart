import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:battery_info/battery_info_plugin.dart';
import 'package:camera/camera.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:device_information/device_information.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:headset_connection_event/headset_event.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:instasure/Utilities/ShowMessage.dart';
import 'package:multi_image_picker/multi_image_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:instasure/screens/dashboard/diagnosisReportDetail.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../Utilities/constant.dart';
import '../../Utilities/userPref.dart';
import '../../domains/repo/apis.dart';
import '../../widgets/topView4.dart';
import '../tabMenu/menuScreen.dart';

class CheckDeviceFeature extends StatefulWidget {
  const CheckDeviceFeature({Key? key}) : super(key: key);

  @override
  _CheckDeviceFeatureState createState() => _CheckDeviceFeatureState();
}

class _CheckDeviceFeatureState extends State<CheckDeviceFeature> {
  SharedPreferences? preferences;
  int error=0;
  //var loading = true;
  final _headsetPlugin = HeadsetEvent();
  HeadsetState? _headsetState;
  final _streamSubscriptions = <StreamSubscription<dynamic>>[];
  late StreamSubscription<dynamic> _streamSubscription;
  static final DeviceInfoPlugin deviceInfoPlugin = DeviceInfoPlugin();
  Map<String, dynamic> _deviceData = <String, dynamic>{};
  late var activationImageUri = null;
  late var imeiImageUri = null;
  bool isFrom_front = false;
  bool isForimei = false;
  bool ismotherboard = true;
  bool isBatteryHelath = false;
  bool isFrontCamera = false;
  bool isBackCamera = false;
  bool isSpeaker = false;
  bool isMicrophone = false;
  bool isRam = true;
  bool isRom = true;
  bool isDisplay = true;
  var brandName;
  var brandModel;
  var imei_1;
  var imei_2;
  var deviceSerialNumber;
  late String platformVersion,
      imeiNo = '',
      modelName = '',
      manufacturer = '',
      deviceName = '',
      productName = '',
      cpuType = '',
      hardware = '';
  var apiLevel;
  var loading = true;
  int img_count=0;

  List<Asset> images= <Asset>[];
  TextEditingController devicePriceController = TextEditingController();
  TextEditingController noteController = TextEditingController();
  final ImagePicker imagePicker = ImagePicker();
  List<XFile>? imageFileList = [];
  List<String> imageList = [];

  Future<void> initializePreference() async{
    this.preferences = await SharedPreferences.getInstance();
    // this.preferences?.setString("name", "Peter");
  }

  Future<void> deviceInsurance() async {
    UserPref prefs = UserPref();
    Future<String?> token = prefs.getTokenFromPref();
    // print('myt'+token.toString());
    String? accessToken = await token;
    var headers = {
      'Accept': 'application/json',
      'Authorization': 'Bearer $accessToken'
    };
    String uri = Constants.BASE_URL + ApisEndPoints.device_diagnostics;
    print('uri'+uri.toString());
    var request = http.MultipartRequest('POST', Uri.parse(uri));
    request.fields.addAll({
      "brand_name": brandName??"Unknown",
      "brand_model_name": brandModel,
      "device_serial_number": deviceSerialNumber??"Unknown",
      "motherboard_status": ismotherboard ? '1' : '0',
      "battery_health_status": isBatteryHelath ? '1' : '0',
      "front_camera_status": isFrom_front ? '1' : '0',
      "back_camera_status": isBackCamera ? '1' : '0',
      "microphone_status": isMicrophone ? '1' : '0',
      "ram_status": isRam ? '1' : '0',
      "rom_status": isRom ? '1' : '0',
      "display_screen_status": isDisplay ? '1' : '0',
      "device_price": devicePriceController.text,
      "note": noteController.text,
    });


/*if(devicePriceController.text.toString()==''){
  error=1;
  showMessage('Please enter device price');
}*/






    if (activationImageUri == null) {
      error=1;
      showMessage('Please upload device invoice photo');
    } else if (imeiImageUri == null) { error=1;
    showMessage('Please upload device imei photo');

    } else if (devicePriceController.text.isEmpty) { error=1;
    print('price no');
    showMessage('Please enter device price');

      // await Future.delay(Duration(milliseconds: 500);
      /*  print("function was run");
      return Future.value(null);*/

    }    else if (int.parse(devicePriceController.text)>2000000) { error=1;
    print('price no');
    showMessage('Invalid Device Price');

      // await Future.delay(Duration(milliseconds: 500);
      /*  print("function was run");
      return Future.value(null);*/

    }else if (imageFileList == null) { error=1;
    showMessage('Please upload device screen image');

    } else {
      request.files.add(await http.MultipartFile.fromPath(
          'invoice_image', activationImageUri));
      request.files
          .add(await http.MultipartFile.fromPath('imei_image', imeiImageUri));

      var itemlist = imageFileList?.toList();
      int cc=0;
      for(var  imte in itemlist!){
        cc++;
        request.files.add(await http.MultipartFile.fromPath('device_images[]', imte.path));
      }
      print('go');
      print(devicePriceController.text);
      print(cc.toString()+'cc');
      if(cc<1){
        error=1;
        showMessage('Please Take 1 to 3 picture (Front & Back without cover)');

      }
    }
    if(error==1){
      error=0;
      //showMessage('Please input all required data');

    }else{
      EasyLoading.instance.userInteractions = false;
      // EasyLoading.show(status: 'Processing...');
      showMessage('Image size should be 1 MB');
      request.headers.addAll(headers);
      //http.StreamedResponse response = await request.send();

      final response = await request.send();
      final respStr = await response.stream.bytesToString();

      if(respStr=='{"success":false,"code":201,"message":"Validation Error","data":["The device images field is required."]}'){
        EasyLoading.dismiss();
        print('err');
        showMessage('Validation Error!The device images field is required');

      }

      else{
        Map<String, dynamic> this_data = jsonDecode(respStr);
        //print(this_data['data']['id']);

        EasyLoading.dismiss();

        EasyLoading.dismiss();
        print('my-response:');
        print(response.statusCode);

        //  await Future.delayed(const Duration(seconds: 2), (){});

        if (response.statusCode == 200) {
          // showMessage('You are successfully submitted your device documents');


          setState(() {
            this.preferences?.setString("serial_number", this_data['data']['serial_number']);
          });


          Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => DiagnosisReportDetail(
                  id: "${this_data['data']['serial_number']}",
                )),
          );

          // Navigator.pop(context);
          print('hh');
        } else {
          //print(response.reasonPhrase);
          //print(this_data['data']);
          showMessage('Validation Error!The device images field is required');

        }
      }




    }

    // }
  }

  @override
  void initState() {
    super.initState();
    () async {
      await Future.delayed(Duration.zero);
      getDeviceInformation();
    }();
  }

  Future<void> getDeviceInfo() async {
    requestPermission(Permission.phone);

    try {
      platformVersion = await DeviceInformation.platformVersion;
      modelName = await DeviceInformation.deviceModel;
      manufacturer = await DeviceInformation.deviceManufacturer;
      apiLevel = await DeviceInformation.apiLevel;
      deviceName = await DeviceInformation.deviceName;
      productName = await DeviceInformation.productName;
      cpuType = await DeviceInformation.cpuName;
      hardware = await DeviceInformation.hardware;
      imeiNo = await DeviceInformation.deviceIMEINumber;
    } on PlatformException catch (e) {
      platformVersion = '${e.message}';
    }

    var batteryinfo = await BatteryInfoPlugin().androidBatteryInfo;
    if(batteryinfo?.health =="health_good"){
      isBatteryHelath = true;
    }else{
      isBatteryHelath = false;
    }
    print(batteryinfo);

    WidgetsFlutterBinding.ensureInitialized();
    final cameras = await availableCameras();
    print('My camera'+cameras.length.toString());
    if (cameras.length == 1) {
      isBackCamera = true;
    } else if (cameras.length > 1) {
      isFrontCamera = true;
      isBackCamera = true;
    } else {
      isFrontCamera = false;
      isBackCamera = false;
    }

    var deviceData = <String, dynamic>{};
    try {
      if (Platform.isAndroid) {
        deviceData = _readAndroidBuildData(await deviceInfoPlugin.androidInfo);
      } else if (Platform.isIOS) {
        deviceData = _readIosDeviceInfo(await deviceInfoPlugin.iosInfo);
      } else if (Platform.isWindows) {
        deviceData = _readWindowsDeviceInfo(await deviceInfoPlugin.windowsInfo);
      }
    } on PlatformException {
      deviceData = <String, dynamic>{
        'Error:': 'Failed to get platform version.'
      };
    }

    if (!mounted) return;

    setState(() {
      loading = false;
      _deviceData = deviceData;
      brandName = _deviceData['brand'];
      brandModel = _deviceData['model'];
      deviceSerialNumber = _deviceData['id'];
    });
  }

  Future<void> _getimeiNumber(String phoneNumber) async {
    final Uri launchUri = Uri(
      scheme: 'tel',
      path: phoneNumber,
    );
    await launchUrl(launchUri);
  }

  @override
  Widget build(BuildContext context) {
    /*
    return Scaffold(
      appBar: null,
      backgroundColor: const Color(0xFFEFF7FF),

      body: SingleChildScrollView(
        child: Container(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Stack(
                  children: [
                    const TopView4(),
                    Positioned(
                      bottom: 20.0,
                      left: 40.0,
                      child: SizedBox(
                          height: 30,
                          width: 30,
                          // color: const Color.fromRGBO(0, 46, 91, 1.0),
                          // padding: const EdgeInsets.fromLTRB(10, 15, 10, 5),
                          child: TextButton(
                            child: Image.asset(
                                'assets/back_button_icon.png'),
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                          )),
                    )
                  ],
                ),
                const SizedBox(
                  height: 10,
                ),
                const SizedBox(
                  height: 10,
                ),
                Container(
                  height: 40,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    color: const Color(0xffF0F3F6),
                  ),
                  alignment: Alignment.center,
                  padding: const EdgeInsets.all(0),
                  child: const Text(
                    'Device Diagnosis',
                    style: TextStyle(fontSize: 20, color: Colors.blue),
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),
                Container(
                  height: 20,
                  child: Padding(
                    padding: const EdgeInsets.all(0.0),
                    child: GestureDetector(
                        onTap: () {},
                        child: Row(
                          textDirection: TextDirection.ltr,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: const [
                            SizedBox(
                              width: 10,
                            ),
                            Align(
                              alignment: Alignment.center,
                              child: Text(
                                'Upload invoice date photo',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                    fontFamily: 'Roboto Slab',
                                    fontSize: 16.0,
                                    color: Color(0xFF002E5B)),
                              ),
                            ),
                            Spacer(),
                          ],
                        )),
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),
                GestureDetector(
                  onTap: () => _showChoiceDialog(context, true),
                  child: Container(
                      height: 100,
                      width: 100,
                      child: Padding(
                          padding: const EdgeInsets.all(5),
                          child: isFrom_front
                              ? Image.file(File(activationImageUri))
                              : Image.asset(
                              'assets/profile/nid_icon.png')),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(75),
                        boxShadow: const [
                          BoxShadow(
                              color: Color(0xFFFFFFFF),
                              blurRadius: 6,
                              spreadRadius: 0,
                              offset: Offset(-3, -3)),
                        ],
                        color: const Color(0xffF0F3F6),
                      )),
                ),
                const SizedBox(
                  height: 10,
                ),
                Align(
                    alignment: Alignment.centerLeft,
                    child: RichText(
                        textAlign: TextAlign.left,
                        text: TextSpan(children: [
                          const TextSpan(
                            text: "Dial *#06# and take screenshot and upload that image ",
                            style: TextStyle(
                                fontFamily: 'Roboto Slab',
                                fontSize: 16.0,
                                color: Color(0xFF002E5B)),
                          ),
                          TextSpan(
                              text: " Click Here",
                              style: const TextStyle(
                                fontSize: 16,
                                color: Colors.blue,
                                fontFamily: 'Roboto Slab',
                                decoration: TextDecoration.underline,
                              ),
                              recognizer: TapGestureRecognizer()
                                ..onTap = () async {
                                  _getDeviceImeiAlert(context);
                                }),
                        ]))),
                const SizedBox(
                  height: 10,
                ),
                Container(
                  height: 20,
                  child: Padding(
                    padding: const EdgeInsets.all(0.0),
                    child: GestureDetector(
                        onTap: () {},
                        child: Row(
                          textDirection: TextDirection.ltr,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: const [
                            SizedBox(
                              width: 10,
                            ),
                            Align(
                              alignment: Alignment.centerLeft,
                              child: Text(
                                'Upload device imei number photo',
                                textAlign: TextAlign.left,
                                style: TextStyle(
                                    fontFamily: 'Roboto Slab',
                                    fontSize: 16.0,
                                    color: Color(0xFF002E5B)),
                              ),
                            ),
                            Spacer(),
                          ],
                        )),
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),
                GestureDetector(
                  onTap: () => _showChoiceDialog(context, false),
                  child: Container(
                      height: 100,
                      width: 100,
                      child: Padding(
                          padding: const EdgeInsets.all(5),
                          child: isForimei
                              ? Image.file(File(imeiImageUri))
                              : Image.asset(
                              'assets/profile/nid_icon.png')),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(75),
                        boxShadow: const [
                          BoxShadow(
                              color: Color(0xFFFFFFFF),
                              blurRadius: 6,
                              spreadRadius: 0,
                              offset: Offset(-3, -3)),
                        ],
                        color: const Color(0xffF0F3F6),
                      )),
                ),
                const SizedBox(
                  height: 10,
                ),
                Align(
                    alignment: Alignment.centerLeft,
                    child: RichText(
                        textAlign: TextAlign.left,
                        text: TextSpan(children: [
                          const TextSpan(
                            text: "Take 2 pictures (Front & Back without cover) using another phone and transfer the pics in this phone for choose image",
                            style: TextStyle(
                                fontFamily: 'Roboto Slab',
                                fontSize: 16.0,
                                color: Color(0xFF002E5B)),
                          ),
                          TextSpan(
                              text: " Click Here",
                              style: const TextStyle(
                                fontSize: 16,
                                color: Colors.blue,
                                fontFamily: 'Roboto Slab',
                                decoration: TextDecoration.underline,
                              ),
                              recognizer: TapGestureRecognizer()
                                ..onTap = () async {
                                  //_getDeviceImeiAlert(context);
                                  selectImages();
                                }),
                        ]))),
                const SizedBox(
                  height: 10,
                ),
/*                GestureDetector(
                  onTap: () => selectImages(),
                  child: Container(
                      height: 100,
                      width: 100,
                      child: Padding(
                          padding: const EdgeInsets.all(5),
                          child: isForimei
                              ? Image.file(File(imeiImageUri))
                              : Image.asset(
                              'assets/profile/nid_icon.png')),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(75),
                        boxShadow: const [
                          BoxShadow(
                              color: Color(0xFFFFFFFF),
                              blurRadius: 6,
                              spreadRadius: 0,
                              offset: Offset(-3, -3)),
                        ],
                        color: const Color(0xffF0F3F6),
                      )),
                ),*/
                const SizedBox(
                  height: 10,
                ),
                Container(
                    height: 40,
                    padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
                    child: TextFormField(
                      textAlignVertical: TextAlignVertical.center,
                      controller: devicePriceController,
                      //validator: (value) =>
                      // Validator.validatePhoneNumber(value ?? ""),
                      decoration: InputDecoration(
                          contentPadding: const EdgeInsets.only(
                              left: 10, top: 5, right: 10, bottom: 5),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(20.0),
                            borderSide: const BorderSide(
                                color: Colors.transparent, width: 0.0),
                          ),
                          hintText: 'Enter Device Price',
                          // labelText: 'Enter Your Full Name',
                          isDense: true,
                          isCollapsed: false),
                      keyboardType: TextInputType.number,
                    ),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: const [
                        BoxShadow(
                            color: Color(0xFFFFFFFF),
                            blurRadius: 6,
                            spreadRadius: 0,
                            offset: Offset(-3, -3)),
                        BoxShadow(
                            color: Color(0xFFDDE4EF),
                            blurRadius: 6,
                            spreadRadius: 0,
                            offset: Offset(3, 3)),
                      ],
                      color: const Color(0xffF0F3F6),
                    )),
                const SizedBox(
                  height: 10,
                ),
                Container(
                    height: 40,
                    padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
                    child: TextFormField(
                      textAlignVertical: TextAlignVertical.center,
                      controller: noteController,
                      //validator: (value) =>
                      // Validator.validatePhoneNumber(value ?? ""),
                      decoration: InputDecoration(
                          contentPadding: const EdgeInsets.only(
                              left: 10, top: 5, right: 10, bottom: 5),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(20.0),
                            borderSide: const BorderSide(
                                color: Colors.transparent, width: 0.0),
                          ),
                          hintText: 'Add notes',
                          // labelText: 'Enter Your Full Name',
                          isDense: true,
                          isCollapsed: false),
                    ),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: const [
                        BoxShadow(
                            color: Color(0xFFFFFFFF),
                            blurRadius: 6,
                            spreadRadius: 0,
                            offset: Offset(-3, -3)),
                        BoxShadow(
                            color: Color(0xFFDDE4EF),
                            blurRadius: 6,
                            spreadRadius: 0,
                            offset: Offset(3, 3)),
                      ],
                      color: const Color(0xffF0F3F6),
                    )),
                const SizedBox(
                  height: 10,
                ),
                Row(
                  children: [
                    const SizedBox(
                      width: 10,
                      height: 30,
                    ),
                    const Text(
                      'Motherboard',
                    ),
                    Spacer(),
                    Text(
                      loading ? ' ': ismotherboard ? 'Ok' : 'Not Ok',
                    ),
                  ],
                ),
                const Divider(
                  height: 1,
                ),
                Row(
                  children: [
                    const SizedBox(
                      width: 10,
                      height: 30,
                    ),
                    const Text(
                      'Battery Health',
                    ),
                    const Spacer(),
                    Text(
                      loading ? ' ': isBatteryHelath ? 'Ok' : 'Not Ok',
                    ),
                  ],
                ),
                const Divider(
                  height: 1,
                ),
                Row(
                  children: [
                    const SizedBox(
                      width: 10,
                      height: 30,
                    ),
                    const Text(
                      'Front Camera',
                    ),
                    Spacer(),
                    Text(
                      loading ? ' ': isFrontCamera ? 'Ok' : 'Not Ok',
                    ),
                  ],
                ),
                const Divider(
                  height: 1,
                ),
                Row(
                  children: [
                    const SizedBox(
                      width: 10,
                      height: 30,
                    ),
                    const Text(
                      'Back Camera',
                    ),
                    Spacer(),
                    Text(
                      loading ? ' ': isBackCamera ? 'Ok' : 'Not Ok',
                    ),
                  ],
                ),
                const Divider(
                  height: 1,
                ),
                Row(
                  children: [
                    const SizedBox(
                      width: 10,
                      height: 30,
                    ),
                    const Text(
                      'Microphone Status',
                    ),
                    const Spacer(),
                    Text(
                      loading ? ' ': isMicrophone ? 'Ok' : 'Not Ok',
                    ),
                  ],
                ),
                const Divider(
                  height: 1,
                ),
                Row(
                  children: [
                    const SizedBox(
                      width: 10,
                      height: 30,
                    ),
                    const Text(
                      'Ram Status',
                    ),
                    Spacer(),
                    Text(
                      loading ? ' ': isRam ? 'Ok' : 'Not Ok',
                    ),
                  ],
                ),
                const Divider(
                  height: 1,
                ),
                Row(
                  children: [
                    const SizedBox(
                      width: 10,
                      height: 30,
                    ),
                    const Text(
                      'Rom Status',
                    ),
                    const Spacer(),
                    Text(
                      loading ? ' ': isRom ? 'Ok' : 'Not Ok',
                    ),
                  ],
                ),
                const Divider(
                  height: 1,
                ),
                Row(
                  children: [
                    const SizedBox(
                      width: 10,
                      height: 30,
                    ),
                    const Text(
                      'Display Screen',
                    ),
                    const Spacer(),
                    Text(
                      loading ? ' ': isDisplay ? 'Ok' : 'Not Ok',
                    ),
                  ],
                ),
                const Divider(
                  height: 1,
                ),
                const SizedBox(
                  height: 20,
                ),
                Container(
                  height: 40,
                  width: MediaQuery.of(context).size.width - 70,
                  //padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
                  child: TextButton(
                    child: const Text(
                      'Submit',
                      style: TextStyle(color: Colors.white,fontSize: 18),
                    ),
                    onPressed: () {
                      deviceInsurance();
                    },
                  ),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                          color:
                          const Color(0xff000000).withOpacity(0.16),
                          blurRadius: 3,
                          spreadRadius: 0,
                          offset: const Offset(0, 3)),
                    ],
                    color: const Color(0xff002E5B),
                  ),
                ),
              ],
            )),
      ),
    );
    */


    return MaterialApp(
      home: Scaffold(


        appBar: AppBar(
          // title: const Text('Home'),

          // title: Text("YOUR_APPBAR_TITLE"),
          // automaticallyImplyLeading: false,



          title: Image.asset('assets/instasure_icon.png',fit: BoxFit.contain, height: 32,),

          leading: new IconButton(
            icon: new Icon(Icons.arrow_back, color: const Color(0xff002E5B),),
            onPressed: () => Navigator.of(context).pop(),
          ),


          automaticallyImplyLeading: true,
          backgroundColor: Colors.white,
          actions: <Widget>[
            IconButton(
              // AssetImage("assets/home/insurance.png"),
              icon: Icon(
                Icons.help_center,
                color: const Color(0xff002E5B),
              ),
              /*icon: Icon(
                Icons.settings,
                color: Colors.white,
              ),*/
              onPressed: () {
                setState(() {

                });
                /* Navigator.push(
                   context,
                   MaterialPageRoute(builder: (context) => const  MenuScreen()),
                 );*/

              },
            )
          ],
        ),

        body: SingleChildScrollView(
          child: Container(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Stack(
                    children: [
                      //const TopView4(),
                      Container(
                        child: Column(


                        ),
                      ),
                      Positioned(
                        bottom: 20.0,
                        left: 40.0,
                        child: SizedBox(
                            height: 30,
                            width: 30,
                            // color: const Color.fromRGBO(0, 46, 91, 1.0),
                            // padding: const EdgeInsets.fromLTRB(10, 15, 10, 5),
                            child: TextButton(
                              child: Image.asset(
                                  'assets/back_button_icon.png'),
                              onPressed: () {
                                Navigator.of(context).pop();
                              },
                            )),
                      )
                    ],
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Container(
                    height: 40,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      color: const Color(0xffF0F3F6),
                    ),
                    alignment: Alignment.center,
                    padding: const EdgeInsets.all(0),
                    child: const Text(
                      'Device Diagnosis',
                      style: TextStyle(fontSize: 20, color: Colors.blue),
                    ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  Container(
                    height: 20,
                    child: Padding(
                      padding: const EdgeInsets.all(0.0),
                      child: GestureDetector(
                          onTap: () {},
                          child: Row(
                            textDirection: TextDirection.ltr,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: const [
                              SizedBox(
                                width: 10,
                              ),
                              Align(
                                alignment: Alignment.center,
                                child: Text(
                                  'Upload invoice date photo',
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                      fontFamily: 'Roboto Slab',
                                      fontSize: 16.0,
                                      color: Color(0xFF002E5B)),
                                ),
                              ),
                              Spacer(),
                            ],
                          )),
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  GestureDetector(
                    onTap: () => _showChoiceDialog(context, true),
                    child: Container(
                        height: 100,
                        width: 100,
                        child: Padding(
                            padding: const EdgeInsets.all(5),
                            child: isFrom_front
                                ? Image.file(File(activationImageUri))
                                : Image.asset(
                                'assets/profile/nid_icon.png')),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(75),
                          boxShadow: const [
                            BoxShadow(
                                color: Color(0xFFFFFFFF),
                                blurRadius: 6,
                                spreadRadius: 0,
                                offset: Offset(-3, -3)),
                          ],
                          color: const Color(0xffF0F3F6),
                        )),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Text(
                    '(photo size will be less than 1MB)',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        fontFamily: 'Roboto Slab',
                        fontSize: 14.0,
                        color: Color(0xFF5B000B)),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  Align(
                      alignment: Alignment.centerLeft,
                      child: RichText(
                          textAlign: TextAlign.left,
                          text: TextSpan(children: [
                            const TextSpan(
                              text: "Dial *#06# and take screenshot and upload that image ",
                              style: TextStyle(
                                  fontFamily: 'Roboto Slab',
                                  fontSize: 16.0,
                                  color: Color(0xFF002E5B)),
                            ),
                            TextSpan(
                                text: " Click Here",
                                style: const TextStyle(
                                  fontSize: 16,
                                  color: Colors.blue,
                                  fontFamily: 'Roboto Slab',
                                  decoration: TextDecoration.underline,
                                ),
                                recognizer: TapGestureRecognizer()
                                  ..onTap = () async {
                                    _getDeviceImeiAlert(context);
                                  }),
                          ]))),
                  const SizedBox(
                    height: 20,
                  ),
                  Container(
                    height: 20,
                    child: Padding(
                      padding: const EdgeInsets.all(0.0),
                      child: GestureDetector(
                          onTap: () {},
                          child: Row(
                            textDirection: TextDirection.ltr,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: const [
                              SizedBox(
                                width: 10,
                              ),
                              Align(
                                alignment: Alignment.centerLeft,
                                child: Text(
                                  'Upload device IMEI number photo',
                                  textAlign: TextAlign.left,
                                  style: TextStyle(
                                      fontFamily: 'Roboto Slab',
                                      fontSize: 16.0,
                                      color: Color(0xFF002E5B)),
                                ),
                              ),
                              Spacer(),
                            ],
                          )),
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  GestureDetector(
                    onTap: () => _showChoiceDialog(context, false),
                    child: Container(
                        height: 100,
                        width: 100,
                        child: Padding(
                            padding: const EdgeInsets.all(5),
                            child: isForimei
                                ? Image.file(File(imeiImageUri))
                                : Image.asset(
                                'assets/profile/nid_icon.png')),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(75),
                          boxShadow: const [
                            BoxShadow(
                                color: Color(0xFFFFFFFF),
                                blurRadius: 6,
                                spreadRadius: 0,
                                offset: Offset(-3, -3)),
                          ],
                          color: const Color(0xffF0F3F6),
                        )),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Text(
                    '(photo size will be less than 1MB)',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        fontFamily: 'Roboto Slab',
                        fontSize: 14.0,
                        color: Color(0xFF5B000B)),
                  ),

                  const SizedBox(
                    height: 20,
                  ),

                  Align(
                      alignment: Alignment.centerLeft,
                      child: RichText(
                          textAlign: TextAlign.left,
                          text: TextSpan(children: [
                            const TextSpan(
                              text: "Take 1 to 3 pictures (Front & Back without cover) using another phone and transfer the pics in this phone for choose image",
                              style: TextStyle(
                                  fontFamily: 'Roboto Slab',
                                  fontSize: 16.0,
                                  color: Color(0xFF002E5B)),
                            ),



                            /* TextSpan(
                                text: " Click Here",
                                style: const TextStyle(
                                  fontSize: 16,
                                  color: Colors.blue,
                                  fontFamily: 'Roboto Slab',
                                  decoration: TextDecoration.underline,
                                ),
                                recognizer: TapGestureRecognizer()
                                  ..onTap = () async {
                                    //_getDeviceImeiAlert(context);
                                    selectImages();
                                  }),*/
                          ]))),
                  MaterialButton(
                    color: Colors.blue,
                    child: Text(
                      "Choose image",
                      style: TextStyle(
                          color: Colors.white70, fontWeight: FontWeight.bold),
                    ),
                    onPressed: () {
                      selectImages();
                    },
                  ),
                  const SizedBox(
                    height: 5,
                  ),

                  Text("($img_count) Image Selected"),
                  const SizedBox(
                    height: 10,
                  ),
/*                GestureDetector(
                  onTap: () => selectImages(),
                  child: Container(
                      height: 100,
                      width: 100,
                      child: Padding(
                          padding: const EdgeInsets.all(5),
                          child: isForimei
                              ? Image.file(File(imeiImageUri))
                              : Image.asset(
                              'assets/profile/nid_icon.png')),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(75),
                        boxShadow: const [
                          BoxShadow(
                              color: Color(0xFFFFFFFF),
                              blurRadius: 6,
                              spreadRadius: 0,
                              offset: Offset(-3, -3)),
                        ],
                        color: const Color(0xffF0F3F6),
                      )),
                ),*/
                  const SizedBox(
                    height: 10,
                  ),
                  Container(
                      height: 40,
                      padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
                      child: TextFormField(
                        textAlignVertical: TextAlignVertical.center,
                        controller: devicePriceController,
                        //validator: (value) =>
                        // Validator.validatePhoneNumber(value ?? ""),
                        decoration: InputDecoration(
                            contentPadding: const EdgeInsets.only(
                                left: 10, top: 5, right: 10, bottom: 5),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20.0),
                              borderSide: const BorderSide(
                                  color: Colors.transparent, width: 0.0),
                            ),
                            hintText: 'Enter Device Price',
                            // labelText: 'Enter Your Full Name',
                            isDense: true,
                            isCollapsed: false),
                        keyboardType: TextInputType.number,
                      ),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: const [
                          BoxShadow(
                              color: Color(0xFFFFFFFF),
                              blurRadius: 6,
                              spreadRadius: 0,
                              offset: Offset(-3, -3)),
                          BoxShadow(
                              color: Color(0xFFDDE4EF),
                              blurRadius: 6,
                              spreadRadius: 0,
                              offset: Offset(3, 3)),
                        ],
                        color: const Color(0xffF0F3F6),
                      )),
                  const SizedBox(
                    height: 10,
                  ),
                  Container(
                      height: 40,
                      padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
                      child: TextFormField(
                        textAlignVertical: TextAlignVertical.center,
                        controller: noteController,
                        //validator: (value) =>
                        // Validator.validatePhoneNumber(value ?? ""),
                        decoration: InputDecoration(
                            contentPadding: const EdgeInsets.only(
                                left: 10, top: 5, right: 10, bottom: 5),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20.0),
                              borderSide: const BorderSide(
                                  color: Colors.transparent, width: 0.0),
                            ),
                            hintText: 'Add notes',
                            // labelText: 'Enter Your Full Name',
                            isDense: true,
                            isCollapsed: false),
                      ),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: const [
                          BoxShadow(
                              color: Color(0xFFFFFFFF),
                              blurRadius: 6,
                              spreadRadius: 0,
                              offset: Offset(-3, -3)),
                          BoxShadow(
                              color: Color(0xFFDDE4EF),
                              blurRadius: 6,
                              spreadRadius: 0,
                              offset: Offset(3, 3)),
                        ],
                        color: const Color(0xffF0F3F6),
                      )),
                  const SizedBox(
                    height: 10,
                  ),
                  Row(
                    children: [
                      const SizedBox(
                        width: 10,
                        height: 30,
                      ),
                      const Text(
                        'Motherboard',
                      ),
                      Spacer(),
                      Text(
                        loading ? ' ': ismotherboard ? 'Ok' : 'Not Ok',
                      ),
                    ],
                  ),
                  const Divider(
                    height: 1,
                  ),
                  Row(
                    children: [
                      const SizedBox(
                        width: 10,
                        height: 30,
                      ),
                      const Text(
                        'Battery Health',
                      ),
                      const Spacer(),
                      Text(
                        loading ? ' ': isBatteryHelath ? 'Ok' : 'Not Ok',
                      ),
                    ],
                  ),
                  const Divider(
                    height: 1,
                  ),
                  Row(
                    children: [
                      const SizedBox(
                        width: 10,
                        height: 30,
                      ),
                      const Text(
                        'Front Camera',
                      ),
                      Spacer(),
                      Text(
                        loading ? ' ': isFrontCamera ? 'Ok' : 'Not Ok',
                      ),
                    ],
                  ),
                  const Divider(
                    height: 1,
                  ),
                  Row(
                    children: [
                      const SizedBox(
                        width: 10,
                        height: 30,
                      ),
                      const Text(
                        'Back Camera',
                      ),
                      Spacer(),
                      Text(
                        loading ? ' ': isBackCamera ? 'Ok' : 'Not Ok',
                      ),
                    ],
                  ),
                  const Divider(
                    height: 1,
                  ),
                  Row(
                    children: [
                      const SizedBox(
                        width: 10,
                        height: 30,
                      ),
                      const Text(
                        'Microphone Status',
                      ),
                      const Spacer(),
                      Text(
                        loading ? ' ': isMicrophone ? 'Ok' : 'Not Ok',
                      ),
                    ],
                  ),
                  const Divider(
                    height: 1,
                  ),
                  Row(
                    children: [
                      const SizedBox(
                        width: 10,
                        height: 30,
                      ),
                      const Text(
                        'Ram Status',
                      ),
                      Spacer(),
                      Text(
                        loading ? ' ': isRam ? 'Ok' : 'Not Ok',
                      ),
                    ],
                  ),
                  const Divider(
                    height: 1,
                  ),
                  Row(
                    children: [
                      const SizedBox(
                        width: 10,
                        height: 30,
                      ),
                      const Text(
                        'Rom Status',
                      ),
                      const Spacer(),
                      Text(
                        loading ? ' ': isRom ? 'Ok' : 'Not Ok',
                      ),
                    ],
                  ),
                  const Divider(
                    height: 1,
                  ),
                  Row(
                    children: [
                      const SizedBox(
                        width: 10,
                        height: 30,
                      ),
                      const Text(
                        'Display Screen',
                      ),
                      const Spacer(),
                      Text(
                        loading ? ' ': isDisplay ? 'Ok' : 'Not Ok',
                      ),
                    ],
                  ),
                  const Divider(
                    height: 1,
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  Container(
                    height: 40,
                    width: MediaQuery.of(context).size.width - 70,
                    //padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
                    child: TextButton(
                      child: const Text(
                        'Submit',
                        style: TextStyle(color: Colors.white,fontSize: 18),
                      ),
                      onPressed: () {
                        deviceInsurance();
                      },
                    ),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [
                        BoxShadow(
                            color:
                            const Color(0xff000000).withOpacity(0.16),
                            blurRadius: 3,
                            spreadRadius: 0,
                            offset: const Offset(0, 3)),
                      ],
                      color: const Color(0xff002E5B),
                    ),
                  ),
                ],
              )),
        ),

      ), //Scaffold
      debugShowCheckedModeBanner: false, //Removing Debug Banner
    );

  }

  Future<void> openCamrea(bool isFront) async {
    final ImagePicker _picker = ImagePicker();
    final XFile? image = await _picker.pickImage(source: ImageSource.camera);
    setState(() {
      if (isFront) {
        isFrom_front = true;
        activationImageUri = image!.path.toString();
      } else {
        isForimei = true;
        imeiImageUri = image!.path.toString();
      }
    });
  }

  Future<void> openGallery(bool isFront) async {
    final ImagePicker _picker = ImagePicker();
    final XFile? image = await _picker.pickImage(source: ImageSource.gallery);
    setState(() {
      if (isFront) {
        isFrom_front = true;
        activationImageUri = image!.path.toString();
      } else {
        isForimei = true;
        imeiImageUri = image!.path.toString();
      }
    });
  }

  Future<void> _showChoiceDialog(BuildContext context, bool isFront) {
    return showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: const Text(
              "Choose option",
              style: TextStyle(color: Colors.blue),
            ),
            content: SingleChildScrollView(
              child: ListBody(
                children: [
                  const Divider(
                    height: 1,
                    color: Colors.blue,
                  ),
                  ListTile(
                    onTap: () {
                      openGallery(isFront);
                      Navigator.of(context).pop();
                    },
                    title: const Text("Gallery"),
                    leading: const Icon(
                      Icons.account_box,
                      color: Colors.blue,
                    ),
                  ),
                  const Divider(
                    height: 1,
                    color: Colors.blue,
                  ),
                  ListTile(
                    onTap: () {
                      openCamrea(isFront);
                      Navigator.of(context).pop();
                    },
                    title: const Text("Camera"),
                    leading: const Icon(
                      Icons.camera,
                      color: Colors.blue,
                    ),
                  ),
                ],
              ),
            ),
          );
        });
  }

  void selectImages() async {
    if(img_count<3){
      final List<XFile>? selectedImages = await
      imagePicker.pickMultiImage();
      if (selectedImages!.isNotEmpty) {
        imageFileList?.addAll(selectedImages);
      }
      setState((){
        img_count=img_count+1;
        ShowMessage.showMessage("Image Selected successfully");
        print(imageFileList);
      });
    }else{
      ShowMessage.showMessage("You can select maximum 3 image");
    }

  }

  Map<String, dynamic> _readAndroidBuildData(AndroidDeviceInfo build) {
    return <String, dynamic>{
      'version.securityPatch': build.version.securityPatch,
      'version.sdkInt': build.version.sdkInt,
      'version.release': build.version.release,
      'version.previewSdkInt': build.version.previewSdkInt,
      'version.incremental': build.version.incremental,
      'version.codename': build.version.codename,
      'version.baseOS': build.version.baseOS,
      'board': build.board,
      'bootloader': build.bootloader,
      'brand': build.brand,
      'device': build.device,
      'display': build.display,
      'fingerprint': build.fingerprint,
      'hardware': build.hardware,
      'host': build.host,
      'id': build.id,
      'manufacturer': build.manufacturer,
      'model': build.model,
      'product': build.product,
      'supported32BitAbis': build.supported32BitAbis,
      'supported64BitAbis': build.supported64BitAbis,
      'supportedAbis': build.supportedAbis,
      'tags': build.tags,
      'type': build.type,
      'isPhysicalDevice': build.isPhysicalDevice,
      //'androidId': build.androidId,
      'systemFeatures': build.systemFeatures,
    };
  }

  Map<String, dynamic> _readIosDeviceInfo(IosDeviceInfo data) {
    return <String, dynamic>{
      'name': data.name,
      'systemName': data.systemName,
      'systemVersion': data.systemVersion,
      'model': data.model,
      'localizedModel': data.localizedModel,
      'identifierForVendor': data.identifierForVendor,
      'isPhysicalDevice': data.isPhysicalDevice,
      'utsname.sysname:': data.utsname.sysname,
      'utsname.nodename:': data.utsname.nodename,
      'utsname.release:': data.utsname.release,
      'utsname.version:': data.utsname.version,
      'utsname.machine:': data.utsname.machine,
    };
  }

  Map<String, dynamic> _readWindowsDeviceInfo(WindowsDeviceInfo data) {
    return <String, dynamic>{
      'numberOfCores': data.numberOfCores,
      'computerName': data.computerName,
      'systemMemoryInMegabytes': data.systemMemoryInMegabytes,
    };
  }

   requestPermission(Permission setting) async {
    // setting.request() will return the status ALWAYS
    // if setting is already requested, it will return the status
    final _result = await setting.request();
    switch (_result) {
      case PermissionStatus.granted:
      case PermissionStatus.limited:
        return true;
      case PermissionStatus.denied:
      case PermissionStatus.restricted:
      case PermissionStatus.permanentlyDenied:
        return false;
    }
  }

  showMessage(String message) {
    Fluttertoast.showToast(
        msg: message,
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.CENTER,
        timeInSecForIosWeb: 1,
        backgroundColor: Colors.black,
        textColor: Colors.white,
        fontSize: 16.0);
  }

  getDeviceInformation(){
    EasyLoading.show(status: 'Getting device info...');
    _headsetPlugin.getCurrentState.then((_val) {
      setState(() {
        _headsetState = _val;
        /* if (_val?.name == "CONNECT") {
          isMicrophone = true;
        } else {
          isMicrophone = false;
        }*/

        isMicrophone = true;
      });
    });
    _headsetPlugin.setListener((_val) {
      setState(() {
        _headsetState = _val;
        if (_val.name == "CONNECT") {
          isMicrophone = true;
        } else {
          isMicrophone = false;
        }
      });
    });

    Timer(const Duration(seconds: 3), () {
      //loading = false;
      EasyLoading.dismiss();
      getDeviceInfo();
    });
  }

  void _getDeviceImeiAlert(BuildContext context) {
    showDialog(
        context: context,
        builder: (context) {
          return CupertinoAlertDialog(
            title: const Text('Instasure'),
            content: const Text('To get device imei number just dial *#06# , then take screen shoot and upload it.'),
            actions: <Widget>[
              TextButton(
                  onPressed: () {
                    Navigator.pop(context);
                    /*Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const CheckDeviceFeature()),
                    );*/
                    _getimeiNumber('');
                  },
                  child: Text('Yes')),
              TextButton(
                onPressed: () {
                  Navigator.pop(context); //close Dialog
                },
                child: Text('No'),
              )
            ],
          );
        });
  }
}
