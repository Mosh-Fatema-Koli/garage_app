import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:instasure/Utilities/ShowMessage.dart';
import 'package:instasure/domains/models/dashboard/deviceDiagnosticPackage.dart';
import 'package:instasure/widgets/topView4.dart';
import '../../Utilities/constant.dart';
import '../../Utilities/userPref.dart';
import '../../Utilities/validator.dart';
import '../../domains/models/insurancePriceInfoModel.dart';
import '../../domains/models/purchaseDeviceInsuranceModel.dart';
import '../../domains/repo/apiClientCustomerDasboard.dart';
import 'package:http/http.dart' as http;
import '../../domains/repo/apis.dart';
import 'dart:convert';

import '../dashboard/purchaseDetailsPage.dart';

class SelectPackage extends StatefulWidget {
  const SelectPackage(
      {Key? key,
      required this.deviceDiagnosticPackage,
      required this.insuranceId})
      : super(key: key);
  final DeviceDiagnosticPackage deviceDiagnosticPackage;
  final String insuranceId;

  @override
  _SelectPackageState createState() => _SelectPackageState();
}

class _SelectPackageState extends State<SelectPackage> {
  var loading = true;
  bool isTheft = false;
  bool isDamage = false;
  final bool _radioValue1 = false;
  bool _isVisible = false;
  var color = Colors.white;
  String package = 'Default Package';
  String? packageId;
  String? insuranceType = '';
  dynamic damageValue;
  dynamic theifValue;
  String radioButtonItem = 'One times';
  String? oneTimes = '';
  String? twoTmes = '';
  int id = 1;
  String selectedType = 'NID';
  String customerIdType = 'nid';
  final selectionOptions = ['NID', 'Passport'];
  String hintName = 'Enter your NID number';
  String? insurancePriceIdone;
  String? insurancePriceIdTwo;
  String? insurancePriceIdThree;
  String? protectionTimePrice;
  bool _isNidSelect = true;
  final ApiClientCustomerDasboard _apiClient = ApiClientCustomerDasboard();
  TextEditingController nidPassportController = TextEditingController();
  TextEditingController emailController = TextEditingController();

  @override
  void initState() {
    setState(() {
      package = widget.deviceDiagnosticPackage.packageName.toString();
      damageValue =
          widget.deviceDiagnosticPackage.insuranceTypeNames?.damage?.price;
      theifValue =
          widget.deviceDiagnosticPackage.insuranceTypeNames?.theft?.price;
      insurancePriceIdone = widget
          .deviceDiagnosticPackage.insuranceTypeNames?.damage?.insurancePriceId
          .toString();
      insurancePriceIdTwo = widget
          .deviceDiagnosticPackage.insuranceTypeNames?.theft?.insurancePriceId
          .toString();
      insurancePriceIdThree = widget.deviceDiagnosticPackage.insuranceTypeNames
          ?.screenProtection?.insurancePriceId
          .toString();
      insuranceType = widget
          .deviceDiagnosticPackage.insuranceTypeNames?.screenProtection?.type
          .toString();
      oneTimes = widget.deviceDiagnosticPackage.insuranceTypeNames
          ?.screenProtection?.protectionTimesFor?.i1
          ?.toString();
      twoTmes = widget.deviceDiagnosticPackage.insuranceTypeNames
          ?.screenProtection?.protectionTimesFor?.i2
          ?.toString();
      packageId = widget.deviceDiagnosticPackage.packageId.toString();
    });
  }

  Future<void> purchaseDeviceInsurancePackage() async {

    if (id == 1) {
      protectionTimePrice = oneTimes;
    } else if (id == 2) {
      protectionTimePrice = twoTmes;
    } else {
      protectionTimePrice = "0";
    }

    if (Validator.validateText(nidPassportController.text) != null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: const Text("Please enter your nid or passport number"),
        backgroundColor: Colors.red.shade300,
      ));
      return;
    }

    EasyLoading.instance.userInteractions = false;
    EasyLoading.show(status: 'Processing...');

    UserPref prefs = UserPref();
    Future<String?> token = prefs.getTokenFromPref();
    String? accessToken = await token;
    var headers = {
      'Accept': 'application/json',
      'Authorization': 'Bearer $accessToken'
    };
    var url = Constants.BASE_URL +
        ApisEndPoints.purchaseDeviceInsurancePackage +
        '/${widget.insuranceId}';
    var request = http.MultipartRequest('POST', Uri.parse(url));
    request.fields.addAll({
      'package_id': '$packageId',
      'email': emailController.text,
      'customer_id_type': customerIdType,
      'customer_id_number': nidPassportController.text,
      'protection_times_price': '$protectionTimePrice',
    });

    if (insuranceType != "included") {
      if (!isDamage) {
        request.fields.addAll({'protection_times_for': '$id'});
        if(isTheft){
          request.fields.addAll({
            'insurance_price_id[0]': '$insurancePriceIdTwo',
          });
        }
      }else{
        if (isDamage && isTheft) {
          request.fields.addAll({
            'insurance_price_id[0]': '$insurancePriceIdone',
            'insurance_price_id[1]': '$insurancePriceIdTwo',
          });
        } else if (isDamage) {
          request.fields.addAll({
            'insurance_price_id[0]': '$insurancePriceIdone',
          });
        } else if (isTheft) {
          request.fields.addAll({
            'insurance_price_id[0]': '$insurancePriceIdTwo',
          });
        }
      }
    } else {
      if (isDamage && isTheft) {
        request.fields.addAll({
          'insurance_price_id[0]': '$insurancePriceIdone',
          'insurance_price_id[1]': '$insurancePriceIdTwo',
          'insurance_price_id[2]': '$insurancePriceIdThree'
        });
      } else if (isDamage) {
        request.fields.addAll({
          'insurance_price_id[0]': '$insurancePriceIdone',
        });
      } else if (isTheft) {
        request.fields.addAll({
          'insurance_price_id[0]': '$insurancePriceIdTwo',
        });
      } else {
        request.fields
            .addAll({'insurance_price_id[0]': '$insurancePriceIdThree'});
      }
    }
    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();
    var responseString = await response.stream.bytesToString();
    print('Report Details');
    //print(responseString);
    print(response.statusCode);
    print('888');
    print('Status');
    EasyLoading.dismiss();
    if (response.statusCode == 200) {
      EasyLoading.dismiss();
      ShowMessage.showMessage("Insurance purchase submitted successfully.");
      final decodedMap = json.decode(responseString);
      print(decodedMap);
      PurchaseDeviceInsuranceModel _deviceDiagnosticPackage = PurchaseDeviceInsuranceModel.fromJson(decodedMap['data']);
      print(_deviceDiagnosticPackage);
      InsurancePriceInfoModel insurancePriceInfoModel =
      InsurancePriceInfoModel(partsType: '', price: 0, insType: '');
      _deviceDiagnosticPackage.insuranceTypeValue!
          .insert(0, insurancePriceInfoModel);
       Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => PurchaseDetailsPage(
              purchaseDeviceInsuranceModel: _deviceDiagnosticPackage,
            )),
      );

    } else {
      EasyLoading.dismiss();
      Map<String, dynamic> user = jsonDecode(responseString);

print(user['data']);

      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(user['data']),
        backgroundColor: Colors.red.shade300,
      ));


print('kk');

    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: null,
        backgroundColor: const Color(0xFFEFF7FF),
        body: Padding(
            padding:
                const EdgeInsets.only(left: 0, top: 0, right: 0, bottom: 0),
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.only(
                      left: 0.0, top: 0, right: 0, bottom: 5),
                  child: Stack(
                    children: [
                      Stack(
                        children: [
                          const TopView4(),
                          Positioned(
                            bottom: 20.0,
                            left: 40.0,
                            child: SizedBox(
                                height: 30,
                                width: 30,
                                // color: const Color.fromRGBO(0, 46, 91, 1.0),
                                // padding: const EdgeInsets.fromLTRB(10, 15, 10, 5),
                                child: TextButton(
                                  child: Image.asset(
                                      'assets/back_button_icon.png'),
                                  onPressed: () {
                                    Navigator.of(context).pop();
                                  },
                                )),
                          )
                        ],
                      ),
                    ],
                  ),
                ),

      /* Container(
          padding: const EdgeInsets.only(
              left: 20.0, top: 0, right: 20, bottom: 5),*/

                 Expanded(

                  child: Padding(
                    padding: const EdgeInsets.only(
                        left: 10.0, top: 0, right: 10, bottom: 5),
                    child: ListView(
                      children: <Widget>[
                        const SizedBox(
                          height: 10,
                        ),
                        Container(
                            height: 50,
                            alignment: Alignment.center,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(0),
                              boxShadow: const [
                                BoxShadow(
                                    color: Color(0xFFFFFFFF),
                                    blurRadius: 6,
                                    spreadRadius: 0,
                                    offset: Offset(-3, -3)),
                                BoxShadow(
                                    color: Color(0xFFDDE4EF),
                                    blurRadius: 6,
                                    spreadRadius: 0,
                                    offset: Offset(3, 3)),
                              ],
                              color: const Color(0xffF0F3F6),
                            ),
                            child: const Text(
                              'Device Insurance Sale - Select Customer',
                              style: TextStyle(
                                  fontSize: 16,
                                  color: Color.fromRGBO(0, 0, 0, 0.87)),
                            )),
                        const SizedBox(
                          height: 10,
                        ),
                        Padding(
                          padding: const EdgeInsets.only(
                              left: 0, right: 0, bottom: 0, top: 0),
                          child: Container(
                            height: 40,
                            alignment: Alignment.center,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(20),
                              boxShadow: const [
                                BoxShadow(
                                    color: Color(0xFFFFFFFF),
                                    blurRadius: 6,
                                    spreadRadius: 0,
                                    offset: Offset(-3, -3)),
                                BoxShadow(
                                    color: Color(0xFFDDE4EF),
                                    blurRadius: 6,
                                    spreadRadius: 0,
                                    offset: Offset(3, 3)),
                              ],
                              color: const Color(0xffF0F3F6),
                            ),
                            child: Padding(
                              padding: const EdgeInsets.only(
                                  left: 20, right: 20, bottom: 0, top: 0),
                              child: DropdownButton<String>(
                                isExpanded: true,
                                isDense: true,
                                value: selectedType,
                                icon: const Icon(Icons.arrow_drop_down_sharp),
                                iconSize: 30,
                                elevation: 10,
                                underline: Container(),
                                onChanged: (var newValue) {
                                  setState(() {
                                    selectedType = newValue!;
                                    if (selectedType == 'NID') {
                                      hintName = 'Enter your NID number';
                                      _isNidSelect = true;
                                      customerIdType = "nid";
                                    } else {
                                      hintName = 'Enter your passport number';
                                      _isNidSelect = false;
                                      customerIdType = "passport";
                                    }
                                  });
                                },
                                items: List.generate(
                                  selectionOptions.length,
                                  (index) => DropdownMenuItem(
                                    value: selectionOptions[index],
                                    child: Text(selectionOptions[index]),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        Container(
                            height: 40,
                            padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
                            child: TextFormField(
                              textAlignVertical: TextAlignVertical.center,
                              controller: nidPassportController,
                              //validator: (value) =>
                              // Validator.validatePhoneNumber(value ?? ""),
                              decoration: InputDecoration(
                                  contentPadding: const EdgeInsets.only(
                                      left: 10, top: 0, right: 10, bottom: 0),
                                  suffixIcon: const Icon(
                                    Icons.email,
                                    color: Color(0xFFEFF7FF),
                                  ),
                                  enabledBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(20.0),
                                    borderSide: const BorderSide(
                                        color: Colors.transparent, width: 0.0),
                                  ),
                                  hintText: hintName,
                                  // labelText: 'Enter Your Full Name',
                                  isDense: true,
                                  isCollapsed: false),
                            ),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(20),
                              boxShadow: const [
                                BoxShadow(
                                    color: Color(0xFFFFFFFF),
                                    blurRadius: 6,
                                    spreadRadius: 0,
                                    offset: Offset(-3, -3)),
                                BoxShadow(
                                    color: Color(0xFFDDE4EF),
                                    blurRadius: 6,
                                    spreadRadius: 0,
                                    offset: Offset(3, 3)),
                              ],
                              color: const Color(0xffF0F3F6),
                            )),
                        const SizedBox(
                          height: 10,
                        ),
                        Container(
                            height: 40,
                            padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
                            child: TextFormField(
                              textAlignVertical: TextAlignVertical.center,
                              controller: emailController,
                              //validator: (value) =>
                              // Validator.validatePhoneNumber(value ?? ""),
                              decoration: InputDecoration(
                                  contentPadding: const EdgeInsets.only(
                                      left: 10, top: 0, right: 10, bottom: 0),
                                  suffixIcon: const Icon(
                                    Icons.email,
                                    color: Color(0xFFEFF7FF),
                                  ),
                                  enabledBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(20.0),
                                    borderSide: const BorderSide(
                                        color: Colors.transparent, width: 0.0),
                                  ),
                                  hintText: 'Enter Your email',
                                  // labelText: 'Enter Your Full Name',
                                  isDense: true,
                                  isCollapsed: false),
                            ),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(20),
                              boxShadow: const [
                                BoxShadow(
                                    color: Color(0xFFFFFFFF),
                                    blurRadius: 6,
                                    spreadRadius: 0,
                                    offset: Offset(-3, -3)),
                                BoxShadow(
                                    color: Color(0xFFDDE4EF),
                                    blurRadius: 6,
                                    spreadRadius: 0,
                                    offset: Offset(3, 3)),
                              ],
                              color: const Color(0xffF0F3F6),
                            )),
                        const SizedBox(
                          height: 10,
                        ),
                        Container(
                          height: 40.0,
                          alignment: Alignment.center,
                          width: MediaQuery.of(context).size.width,
                          color: const Color(0xFF00B3FF),
                          child: Text(
                            package,
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                              fontFamily: 'Roboto Slab',
                              fontSize: 16,
                              color: Colors.white,
                            ),
                          ),
                        ),
                        /*Padding(
                          padding: const EdgeInsets.only(
                              left: 0, right: 00, bottom: 0, top: 0),
                          child:*/

                      Center(
                          child: Column(children: <Widget>[
                            Container(
                              margin: EdgeInsets.all(2),
                              child: Table(
                                columnWidths: {
                                  0: FlexColumnWidth(2),
                                  1: FlexColumnWidth(4),
                                },


                                border: TableBorder.all(
                                    color: Colors.black26,
                                    style: BorderStyle.solid,
                                    width: 1),
                                children: [
                                  TableRow( children: [
                                    Column(children:[Padding(
                                      padding: const EdgeInsets.all(4.0),
                                      child: Text('Insurance Type', style: TextStyle(fontSize:16.0,fontWeight: FontWeight.bold)),
                                    )]),
                                    Column(children:[Text('Price', style: TextStyle(fontSize: 18.0,fontWeight: FontWeight.bold))]),

                                  ]),
                                  TableRow( children: [
                                    Column(children:[Padding(
                                      padding: const EdgeInsets.only(top:64.0),
                                      child: Text('Screen Protection'),
                                    )]),
                                    Column(children:[

                                          Padding(
                                          padding: const EdgeInsets.all(0),
                                          child: Column(
                                            children: [
                                                  Container(
                                                  //scrollDirection: Axis.horizontal,
                                                  child: Ink(
                                                    color: color,
                                                    width:
                                                    MediaQuery.of(context).size.width,
                                                    child: Column(
                                                      mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                      children: <Widget>[
                                                        if (_isVisible) ...[
                                                          Image.asset('assets/cancle.png'),
                                                        ] else if (insuranceType !=
                                                            'excluded') ...[
                                                          const Center(
                                                            child: Text(
                                                              'Included',
                                                              style:
                                                              TextStyle(fontSize: 20.0),
                                                            ),
                                                          ),
                                                        ] else ...[


                Row(
                  children: [
                    Radio(
                      value: 1,
                      groupValue: id,
                      onChanged: (val) {
                        setState(() {
                          radioButtonItem =
                          'One times $oneTimes';
                          id = 1;
                        });
                      },
                    ),
                    Text(
                      'One times $oneTimes',
                      style:
                      TextStyle(fontSize: 10.0),
                    ),
                  ],
                ),










                                                          Row(
                                                            children: [
                                                              Radio(
                                                                value: 2,
                                                                groupValue: id,
                                                                onChanged: (val) {
                                                                  setState(() {
                                                                    radioButtonItem =
                                                                    'Two times $twoTmes';
                                                                    id = 2;
                                                                  });
                                                                },
                                                              ),
                                                              Text(
                                                                'Two times $twoTmes',
                                                                style: TextStyle(
                                                                  fontSize: 10.0,
                                                                ),
                                                              ),

                                                            ],
                                                          ),




                                                          Row(
                                                            children: [
                                                              Radio(
                                                                value: 3,
                                                                groupValue: id,
                                                                onChanged: (val) {
                                                                  setState(() {
                                                                    radioButtonItem =
                                                                    'None of any';
                                                                    id = 3;
                                                                  });
                                                                },
                                                              ),
                                                              const Text(
                                                                'None of any',
                                                                style:
                                                                TextStyle(fontSize: 10.0),
                                                              ),

                                                            ],
                                                          ),





                                                        ],
                                                      ],
                                                    ),
                                                  ),
                                                ),

                                            ],
                                          ),
                                        ),


                                    ]),

                                  ]),
                                  TableRow( children: [
                                    Column(children:[Padding(
                                      padding: const EdgeInsets.all(24.0),
                                      child: Text('Damage'),
                                    )]),
                                    Column(children:[

                                      Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: Row(
                                          children: [


                                                Text('৳ $damageValue',
                                                    style: TextStyle(color: Colors.black)),

                                                Checkbox(
                                                  value: isDamage,
                                                  onChanged: (value) {
                                                    damageBox(value!);
                                                  },
                                                  activeColor: Colors.pink,
                                                  checkColor: Colors.white,
                                                  tristate: false,
                                                ),


                                          ],
                                        ),
                                      ),


                                    ]),

                                  ]),
                                  TableRow( children: [
                                    Column(children:[Padding(
                                      padding: const EdgeInsets.all(24.0),
                                      child: Text('Theft'),
                                    )]),
                                    Column(children:[


                                      Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: Row(
                                          children: [


                                            Text('৳ $theifValue',
                                                style: TextStyle(color: Colors.black)),

                                            Checkbox(
                                              value: isTheft,
                                              onChanged: (value) {
                                                theftBox(value!);
                                              },
                                              activeColor: Colors.pink,
                                              checkColor: Colors.white,
                                              tristate: false,
                                            ),


                                          ],
                                        ),
                                      ),

                                    ]),

                                  ]),
                                ],
                              ),
                            ),
                          ])
                      ),


                        const SizedBox(
                          height: 20,
                        ),
                        Container(
                          height: 40,
                          width: MediaQuery.of(context).size.width - 70,
                          //padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
                          child: TextButton(
                            child: const Text(
                              'Submit',
                              style: TextStyle(color: Colors.white, fontSize: 18),
                            ),
                            onPressed: () {
                              purchaseDeviceInsurancePackage();
                            },
                          ),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(20),
                            boxShadow: [
                              BoxShadow(
                                  color:
                                      const Color(0xff000000).withOpacity(0.16),
                                  blurRadius: 3,
                                  spreadRadius: 0,
                                  offset: const Offset(0, 3)),
                            ],
                            color: const Color(0xff002E5B),
                          ),
                        ),
                      ],
                    ),
                  ),

                ),
        // )

              ],
            )));
  }

  void theftBox(bool value) {
    if (isTheft == false) {
      setState(() {
        isTheft = true;
      });
    } else {
      setState(() {
        isTheft = false;
      });
    }
  }

  void damageBox(bool value) {
    if (isDamage == false) {
      setState(() {
        isDamage = true;
        if (insuranceType == "included") {
          _isVisible = false;
        } else {
          _isVisible = true;
          color = Colors.red;
        }
      });
    } else {
      setState(() {
        isDamage = false;
        _isVisible = false;
        color = Colors.white;
      });
    }
  }
}
