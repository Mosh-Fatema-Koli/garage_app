// ignore_for_file: unnecessary_new

import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:instasure/Utilities/helper.dart';
import 'package:instasure/Utilities/userPref.dart';
import 'package:instasure/domains/models/deviceInsurance/claimHistoryModel.dart';
import 'package:instasure/domains/repo/apiClientDeviceInsurance.dart';
import 'package:instasure/screens/deviceInsurance/deviceInsuranceClaimRequestDetail.dart';
import 'package:instasure/widgets/rowWidget.dart';
import 'package:instasure/widgets/topView4.dart';

import '../../Utilities/ShowMessage.dart';

class DeviceInsuranceClaimHistory extends StatefulWidget {
  const DeviceInsuranceClaimHistory({Key? key}) : super(key: key);

  @override
  _InsuranceClaimHistoryState createState() => _InsuranceClaimHistoryState();
}

class _InsuranceClaimHistoryState extends State<DeviceInsuranceClaimHistory> {
  final ApiClientDeviceInsurance _apiClient = ApiClientDeviceInsurance();
  List<ClaimHistoryModel> _cliamedHistories = [];

  var loading = true;

  @override
  void initState() {
    super.initState();
    () async {
      await Future.delayed(Duration.zero);
      getInsuranceClaimedHistoryData();
    }();
  }

  Future<void> getInsuranceClaimedHistoryData() async {
    UserPref prefs = UserPref();
    Future<String?> token = prefs.getTokenFromPref();
    String? accessToken = await token;
    EasyLoading.instance.userInteractions = false;
    EasyLoading.show(status: 'Processing...');
    dynamic res =
        await _apiClient.getDeviceInsuranceClaimHistData(accessToken!);
    //ScaffoldMessenger.of(context).hideCurrentSnackBar();
    EasyLoading.dismiss();
    if (res.statusCode == 200) {
      if (res.data['code'] == 200) {
        // InsuranceHistoryModel histories =

        List jsonList = res.data['data']['data'] as List;

        List<ClaimHistoryModel> histories = jsonList
            .map((jsonElement) => ClaimHistoryModel.fromJson(jsonElement))
            .toList();

        setState(() {
          _cliamedHistories = histories;
          if(_cliamedHistories.length ==0){
            ShowMessage.showMessage("No insurance claim history found.");
          }
          loading = false;
        });
      } else {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('${res.data['message']}'),
          backgroundColor: Colors.red.shade300,
        ));
        setState(() {
          loading = false;
        });
      }
    } else {
      setState(() {
        loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: loading
          ? Center(
              child: Center(
                child:  const Text(""),
              ),
            )
          : Center(
              child: Padding(
              padding: const EdgeInsets.all(0),
              child: Column(
                children: [
                  Stack(
                    children: [
                      const TopView4(),
                      Positioned(
                        bottom: 20.0,
                        left: 40.0,
                        child: SizedBox(
                            height: 30,
                            width: 30,
                            // color: const Color.fromRGBO(0, 46, 91, 1.0),
                            // padding: const EdgeInsets.fromLTRB(10, 15, 10, 5),
                            child: TextButton(
                              child: Image.asset('assets/back_button_icon.png'),
                              onPressed: () {
                                Navigator.of(context).pop();
                              },
                            )),
                      )
                    ],
                  ),
                  Expanded(
                    child: ListView(
                      children: <Widget>[
                        const SizedBox(height: 0.0),
                        createHeader(),
                        const SizedBox(height: 20.0),
                        buildListView(),
                        const SizedBox(height: 80.0),
                      ],
                    ),
                  ),
                ],
              ),
            )),
      backgroundColor: const Color(0xFFEFF7FF),
    );
  }

  createHeader() {
    return Container(
      height: 38,
      child: const Center(
        child: Text(
          'DEVICE INSURANCE CLAIM HISTORY',
          textAlign: TextAlign.center,
          style: TextStyle(
            fontFamily: 'Roboto Slab',
            fontSize: 16,
            color: Color(0xff002E5B),
          ),
        ),
      ),
      decoration: const BoxDecoration(color: Color(0xffF0F3F6), boxShadow: [
        BoxShadow(
            color: Color(0xffffffff),
            blurRadius: 6,
            spreadRadius: 0,
            offset: Offset(-3, -3)),
        BoxShadow(
            color: Color(0xffDDE4EF),
            blurRadius: 6,
            spreadRadius: 0,
            offset: Offset(3, 3)),
      ]),
    );
  }

  createInfoWidget(ClaimHistoryModel claimHistoryModel) {
    return Padding(
        padding:
            const EdgeInsets.only(right: 14, top: 10, bottom: 10, left: 14),
        child: Container(
            // padding: const EdgeInsets.all(10.0),
            //width: (MediaQuery.of(context).size.width - 45) / 3,
            height: 280,
            alignment: Alignment.centerLeft,
            // padding: const EdgeInsets.only(top: 20),
            child: Padding(
              padding: const EdgeInsets.only(
                left: 30,
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  const SizedBox(height: 10.0),
                  Row(
                    children: [
                      Image.asset('assets/profile/calendar_icon.png'),
                      const SizedBox(width: 10.0),
                      Text(
                        getDateString(
                            claimHistoryModel.createdAt ?? '', 'dd MMM yyyy'),
                        textAlign: TextAlign.left,
                        style: const TextStyle(
                          fontFamily: 'Roboto Slab',
                          fontSize: 14,
                          color: Color(0xff000000),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10.0),
                  Text(
                    loading ? '' : "CLAIM TYPE: ${claimHistoryModel.claimOn}",
                    textAlign: TextAlign.left,
                    style: const TextStyle(
                      fontFamily: 'Roboto Slab',
                      fontSize: 16,
                      color: Color(0xff002E5B),
                      decoration: TextDecoration.underline,
                    ),
                  ),
                  const SizedBox(height: 5.0),
                  RowWidget(
                      title: "Claim Status: ",
                      value: claimHistoryModel.status ?? '',
                      fSize: 16),
                  const SizedBox(height: 5.0),
                  RowWidget(
                      title: "Claim Status Note: ",
                      value: claimHistoryModel.statusNote ?? '',
                      fSize: 16),
                  const SizedBox(height: 5.0),
                  RowWidget(
                      title: "Payment Status: ",
                      value: claimHistoryModel.paymentStatus ?? '',
                      fSize: 16),
                  const SizedBox(height: 5.0),
                  RowWidget(
                      title: "Payment Details: ",
                      value: claimHistoryModel.paymentDetails ?? '',
                      fSize: 16),
                  const SizedBox(height: 5.0),
                  RowWidget(
                      title: "Amount: ",
                      value: "৳${claimHistoryModel.userWillPay}",
                      fSize: 16),
                  const SizedBox(height: 5.0),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [

                      TextButton.icon(
                        icon: const Icon(
                          Icons.visibility,
                          size: 20,
                          color: Color(0xff2969E9),
                        ),
                        label: const Text(
                          ' View Details',
                          textAlign: TextAlign.left,
                          style: TextStyle(
                            fontFamily: 'Roboto Slab',
                            fontSize: 16,
                            color: Color(0xff2969E9),
                          ),
                        ),
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) =>
                                    DeviceInsuranceClaimRequestDetail(
                                      id: '${claimHistoryModel.id!}',
                                    )),
                          );
                        },
                      ),
                    ],
                  ),
                ],
              ),
            ),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(40),
              boxShadow: const [
                BoxShadow(
                    color: Color(0xFFFFFFFF),
                    blurRadius: 6,
                    spreadRadius: 0,
                    offset: Offset(-3, -3)),
              ],
              color: const Color(0xFFF0F3F6),
            )));
  }

  buildListView() {
    return SizedBox(
      height: 600,
      // color: Colors.red,

      //width: (MediaQuery.of(context).size.width - 30) / 3,
      child: ListView.separated(
          primary: false,
          scrollDirection: Axis.vertical,
          shrinkWrap: true,
          itemCount: _cliamedHistories.length,
          itemBuilder: (BuildContext context, int index) {
            ClaimHistoryModel claimHistoryModel = _cliamedHistories[index];
            return GestureDetector(
                onTap: () {
                  print("clicked");
                   Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                  builder: (context) =>
                                                      DeviceInsuranceClaimRequestDetail(
                                                        id: '${claimHistoryModel.id!}',
                                                      )),
                                            );
                },
                child: createInfoWidget(claimHistoryModel));

            // );
          },
          separatorBuilder: (context, index) => const SizedBox(
                height: 8,
              )),
    );
  }
}
