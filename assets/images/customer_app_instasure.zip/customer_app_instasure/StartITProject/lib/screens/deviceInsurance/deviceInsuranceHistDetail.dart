// ignore_for_file: unnecessary_new

import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:instasure/Utilities/helper.dart';
import 'package:instasure/Utilities/userPref.dart';
import 'package:instasure/domains/models/dashboard/diagnosisReportList.dart';
import 'package:instasure/domains/models/deviceInsurance/deviceInsuranceDetailModel.dart';
import 'package:instasure/domains/models/deviceInsurance/devisionModel.dart';
import 'package:instasure/domains/models/insurancePriceInfoModel.dart';
import 'package:instasure/domains/repo/apiClientDeviceInsurance.dart';
import 'package:instasure/domains/repo/apiTravelInsurance.dart';
import 'package:instasure/screens/claimProcess/claimPage.dart';
import 'package:instasure/screens/claimProcess/serviceCenterLocation.dart';
import 'package:instasure/screens/travelInsurance/paymentWebView.dart';
import 'package:instasure/widgets/rowWidget.dart';
import 'package:instasure/widgets/topView4.dart';

class DeviceInsuranceHistoryDetails extends StatefulWidget {
  const DeviceInsuranceHistoryDetails({Key? key, required this.id})
      : super(key: key);

  final String id;

  @override
  _DeviceInsuranceHistoryDetailsState createState() =>
      _DeviceInsuranceHistoryDetailsState();
}

class _DeviceInsuranceHistoryDetailsState
    extends State<DeviceInsuranceHistoryDetails> {
  final ApiTravelInsurance _apiTravelInsuraneClient = ApiTravelInsurance();

  final ApiClientDeviceInsurance _apiClient = ApiClientDeviceInsurance();
  late DeviceInsuranceDetailModel? deviceInsuranceDetailModel;
  var loading = true;

  final selectionOptions = ['Damage', 'Theft'];
  String selectedType = 'Damage';
  List<DivisionModel> divisions = [];

  @override
  void initState() {
    super.initState();
    print('i am here');
    () async {
      await Future.delayed(Duration.zero);

      getDeviceInsuranceHistoryDetailData();
    }();
  }

  Future<void> getDeviceInsuranceHistoryDetailData() async {
    UserPref prefs = UserPref();
    Future<String?> token = prefs.getTokenFromPref();
    String? accessToken = await token;
    EasyLoading.instance.userInteractions = false;
    EasyLoading.show(status: 'Processing...');
    dynamic res = await _apiClient.getDeviceInsuranceHisDetailtData(
        widget.id, accessToken!);
    print(res);
    //ScaffoldMessenger.of(context).hideCurrentSnackBar();
    EasyLoading.dismiss();
    if (res.statusCode == 200) {
      if (res.data['code'] == 200) {
        // InsuranceHistoryModel histories =
        DeviceInsuranceDetailModel _deviceInsuranceDetailModel =
            DeviceInsuranceDetailModel.fromJson(res.data['data']);
        InsurancePriceInfoModel insurancePriceInfoModel =
            InsurancePriceInfoModel(partsType: '', price: 0, insType: '');
        _deviceInsuranceDetailModel.insuranceTypeValue!
            .insert(0, insurancePriceInfoModel);

        if (_deviceInsuranceDetailModel.deviceInsuraceDetails!.isNotEmpty) {
          _deviceInsuranceDetailModel.deviceInsuraceDetails!
              .insert(0, DeviceInsuraceDetails());
        }
        setState(() {
          deviceInsuranceDetailModel = _deviceInsuranceDetailModel;
          loading = false;
        });
      } else {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('${res.data['message']}'),
          backgroundColor: Colors.red.shade300,
        ));
        setState(() {
          deviceInsuranceDetailModel = null;
          loading = false;
        });
      }
    } else {
      setState(() {
        deviceInsuranceDetailModel = null;
        loading = false;
      });
    }
  }

  Future<void> getDivisions() async {
/*    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: const Text('Processing Data'),
      backgroundColor: Colors.green.shade300,
    ));*/
    EasyLoading.instance.userInteractions = false;
    EasyLoading.show(status: 'Processing...');
    Map<String, dynamic> data = {
      "device_insurance_id": widget.id,
      "claim_type": selectedType,
    };
    UserPref prefs = UserPref();
    Future<String?> token = prefs.getTokenFromPref();
    String? accessToken = await token;
    dynamic res =
        await _apiClient.deviceInsuranceSupportRequestForm(data, accessToken!);
    //ScaffoldMessenger.of(context).hideCurrentSnackBar();

    //print(res);
    EasyLoading.dismiss();
    if (res.statusCode == 200) {
      if (res.data['code'] == 200) {
        List jsonList = res.data['data']['_divisions'] as List;
        List<DivisionModel> _divisions = jsonList
            .map((jsonElement) => DivisionModel.fromJson(jsonElement))
            .toList();
        divisions = _divisions;
        divisions.insert(0, DivisionModel(id: 0, name: "Select"));
        Navigator.push(
          context,
          MaterialPageRoute(
              builder: (context) => ServiceCenterLocation(
                    deviceInsuranceId: "${deviceInsuranceDetailModel?.id}",
                    divisions: divisions,
                  )),
        );
      }
    } else {}
    // }
  }

  Future<void> payNow() async {
    EasyLoading.instance.userInteractions = false;
    EasyLoading.show(status: 'Processing...');
    Map<String, dynamic> data = {
      "order_id": deviceInsuranceDetailModel?.id ?? '',
    };
    UserPref prefs = UserPref();
    Future<String?> token = prefs.getTokenFromPref();
    String? accessToken = await token;
    dynamic res = await _apiTravelInsuraneClient.travelInsuranceOrderPay(
        data, accessToken!);
    EasyLoading.dismiss();
    if (res.statusCode == 200) {
      Navigator.push(
          context,
          MaterialPageRoute(
              builder: (context) => PaymentWebview(
                    url: res.data.toString(),
                    id: '0',
                  )));
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('${res.data['message']}'),
        backgroundColor: Colors.red.shade300,
      ));
      // ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      //   content: Text('Error: ${res.data['data']['phone'][0]}'),
      //   backgroundColor: Colors.red.shade300,
      // ));

    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: loading
          ? Center(
              child: Center(
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: const [
                    CircularProgressIndicator(),
                    SizedBox(
                      width: 10,
                    ),
                    Text("Loading"),
                  ],
                ),
              ),
            )
          : deviceInsuranceDetailModel == null
              ? const Center(
                  child: Text(
                    "No data found",
                    textAlign: TextAlign.center,
                  ),
                )
              : Center(
                  child: Padding(
                  padding: const EdgeInsets.all(0),
                  child: Column(
                    children: [
                      Stack(
                        children: [
                          const TopView4(),
                          Positioned(
                            bottom: 20.0,
                            left: 40.0,
                            child: SizedBox(
                                height: 30,
                                width: 30,
                                // color: const Color.fromRGBO(0, 46, 91, 1.0),
                                // padding: const EdgeInsets.fromLTRB(10, 15, 10, 5),
                                child: TextButton(
                                  child: Image.asset(
                                      'assets/back_button_icon.png'),
                                  onPressed: () {
                                    Navigator.of(context).pop();
                                  },
                                )),
                          )
                        ],
                      ),
                      Expanded(
                        child: ListView(
                          children: <Widget>[
                            const SizedBox(height: 0.0),
                            createHeaderWidget(),
                            const SizedBox(height: 20.0),
                            if (deviceInsuranceDetailModel?.policyNumber !=
                                null)
                              Center(
                                child: Text(
                                    'Policy Number: ${deviceInsuranceDetailModel?.policyNumber}'),
                              ),
                            if (deviceInsuranceDetailModel?.policyNumber !=
                                null)
                              const SizedBox(height: 20.0),
                            createCustomerInfoWidget(),
                            createDeviceDetailsWidget(),
                            createPriceDetailsWidget(),
                            createRemainingClaimWidget(),
                            createTotalPriceInfoWidget(),
                            const SizedBox(height: 20.0),
                            createBottomButtonWidget(),
                            const SizedBox(height: 80.0),
                          ],
                        ),
                      ),
                    ],
                  ),
                )),
      backgroundColor: const Color(0xFFEFF7FF),
    );
  }

  createHeaderWidget() {
    return Container(
      height: 56,
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            const Text(
              "Device Insurance History ",
              textAlign: TextAlign.center,
              style: TextStyle(
                fontFamily: 'Roboto Slab',
                fontSize: 16,
                color: Color(0xff002E5B),
              ),
            ),
            const SizedBox(
              height: 3,
            ),
            Text(
              getDateString(
                  deviceInsuranceDetailModel?.createdAt ?? " ", 'dd MMM yyyy'),
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontFamily: 'Roboto Slab',
                fontSize: 12,
                color: Color(0xff002E5B),
              ),
            ),
          ],
        ),
      ),
      decoration: const BoxDecoration(color: Color(0xffF0F3F6), boxShadow: [
        BoxShadow(
            color: Color(0xffffffff),
            blurRadius: 6,
            spreadRadius: 0,
            offset: Offset(-3, -3)),
        BoxShadow(
            color: Color(0xffDDE4EF),
            blurRadius: 6,
            spreadRadius: 0,
            offset: Offset(3, 3)),
      ]),
    );
  }

  createBottomButtonWidget() {
    // if (deviceInsuranceDetailModel?.paymentStatus == 'paid' &&
    //   DateTime.now()
    //           .difference(
    //               DateTime.parse('${deviceInsuranceDetailModel?.updatedAt}'))
    //           .inDays >
    //       30
    if (deviceInsuranceDetailModel?.paymentStatus == 'paid') {
      return Padding(
        padding:
            const EdgeInsets.only(right: 35, top: 10, bottom: 10, left: 35),
        child: SizedBox(
          height: 50,
          child: Container(
            height: 40,
            //padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
            child: TextButton(
              child: Text(
                deviceInsuranceDetailModel?.sClaimOption == "Make Claim" ||
                        deviceInsuranceDetailModel?.sClaimOption ==
                            "Request Pending"
                    ? '${deviceInsuranceDetailModel?.sClaimOption}'
                    : 'Claim will Active after:\n${deviceInsuranceDetailModel?.sClaimOption}',
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.white),
              ),
              //

              onPressed: () {
                if (deviceInsuranceDetailModel?.sClaimOption == "Make Claim") {
                  showPopUp(context);
                }
              },
            ),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                    color: const Color(0xff000000).withOpacity(0.16),
                    blurRadius: 3,
                    spreadRadius: 0,
                    offset: const Offset(0, 3)),
              ],
              color: deviceInsuranceDetailModel?.sClaimOption == "Make Claim" ||
                      deviceInsuranceDetailModel?.sClaimOption ==
                          "Request Pending"
                  ? const Color(0xff002E5B)
                  : Colors.redAccent,
            ),
          ),
        ),
      );
    } else {
      return   Padding(
        padding: EdgeInsets.only(right: 35, top: 10, bottom: 10, left: 35),
        child:  TextButton(
      child: Text('View More',
        textAlign: TextAlign.center,
        style: const TextStyle(color: Colors.greenAccent),
      ),
    //

    onPressed: () {
      Navigator.push( context, MaterialPageRoute( builder: (context) => const DiagnosisReportList()), );

    },
    ) /*Text(
           'This Invoice Not paid.',
          style: TextStyle(
            color: Colors.redAccent,
          ),
        ),*/

      );
    }
  }

  // createBottomButtonWidget() {
  //   if (widget.deviceHistoryModel.paymentStatus == 'unpaid') {
  //     return Padding(
  //       padding:
  //           const EdgeInsets.only(right: 35, top: 10, bottom: 10, left: 35),
  //       child: SizedBox(
  //         height: 30,
  //         child: Container(
  //           height: 30,
  //           //padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
  //           child: TextButton(
  //             child: const Text(
  //               'Make Payment',
  //               style: TextStyle(color: Colors.white),
  //             ),
  //             onPressed: payNow,
  //           ),
  //           decoration: BoxDecoration(
  //             borderRadius: BorderRadius.circular(20),
  //             boxShadow: [
  //               BoxShadow(
  //                   color: const Color(0xff000000).withOpacity(0.16),
  //                   blurRadius: 3,
  //                   spreadRadius: 0,
  //                   offset: const Offset(0, 3)),
  //             ],
  //             color: const Color(0xff002E5B),
  //           ),
  //         ),
  //       ),
  //     );
  //   } else {
  //     return Padding(
  //       padding:
  //           const EdgeInsets.only(right: 35, top: 10, bottom: 10, left: 35),
  //       child: SizedBox(
  //         height: 30,
  //         child: Container(
  //           height: 30,
  //           //padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
  //           child: TextButton(
  //             child: const Text(
  //               'Make Claim',
  //               style: TextStyle(color: Colors.white),
  //             ),
  //             onPressed: () {},
  //           ),
  //           decoration: BoxDecoration(
  //             borderRadius: BorderRadius.circular(20),
  //             boxShadow: [
  //               BoxShadow(
  //                   color: const Color(0xff000000).withOpacity(0.16),
  //                   blurRadius: 3,
  //                   spreadRadius: 0,
  //                   offset: const Offset(0, 3)),
  //             ],
  //             color: const Color(0xff002E5B),
  //           ),
  //         ),
  //       ),
  //     );
  //   }
  // }

  createCustomerInfoWidget() {
    return Padding(
        padding:
            const EdgeInsets.only(right: 14, top: 10, bottom: 10, left: 14),
        child: Container(
            // padding: const EdgeInsets.all(10.0),
            //width: (MediaQuery.of(context).size.width - 45) / 3,
            height: 164,
            alignment: Alignment.centerLeft,
            // padding: const EdgeInsets.only(top: 20),
            child: Padding(
              padding: const EdgeInsets.only(
                left: 30,
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  const SizedBox(height: 10.0),
                  const Text(
                    "CUSTOMER INFO",
                    textAlign: TextAlign.left,
                    style: TextStyle(
                      fontFamily: 'Roboto Slab',
                      fontSize: 16,
                      color: Color(0xff002E5B),
                      decoration: TextDecoration.underline,
                    ),
                  ),
                  const SizedBox(height: 10.0),
                  RowWidget(
                      title: "Contact Person Name: ",
                      value: deviceInsuranceDetailModel
                              ?.customerInfo?.customerName ??
                          " ",
                      fSize: 16),
                  const SizedBox(height: 10.0),
                  RowWidget(
                      title: "Contact Person Phone: ",
                      value: deviceInsuranceDetailModel
                              ?.customerInfo?.customerPhone ??
                          " ",
                      fSize: 16),
                  const SizedBox(height: 10.0),
                  RowWidget(
                      title: "Contact Person Email: ",
                      value: deviceInsuranceDetailModel
                              ?.customerInfo?.customerEmail ??
                          " ",
                      fSize: 16),
                  const SizedBox(height: 10.0),
                  RowWidget(
                      title: "Customer NID Number: ",
                      value: deviceInsuranceDetailModel?.customerInfo?.number ??
                          " ",
                      fSize: 16),
                ],
              ),
            ),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(40),
              boxShadow: const [
                BoxShadow(
                    color: Color(0xFFFFFFFF),
                    blurRadius: 6,
                    spreadRadius: 0,
                    offset: Offset(-3, -3)),
              ],
              color: const Color(0xFFF0F3F6),
            )));
  }

  createDeviceDetailsWidget() {
    return Padding(
        padding:
            const EdgeInsets.only(right: 14, top: 10, bottom: 10, left: 14),
        child: Container(
            // padding: const EdgeInsets.all(10.0),
            //width: (MediaQuery.of(context).size.width - 45) / 3,
            height: 164,
            alignment: Alignment.centerLeft,
            // padding: const EdgeInsets.only(top: 20),
            child: Padding(
              padding: const EdgeInsets.only(
                left: 30,
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  const SizedBox(height: 10.0),
                  const Text(
                    "DEVICE INFO",
                    textAlign: TextAlign.left,
                    style: TextStyle(
                      fontFamily: 'Roboto Slab',
                      fontSize: 16,
                      color: Color(0xff002E5B),
                      decoration: TextDecoration.underline,
                    ),
                  ),
                  const SizedBox(height: 10.0),
                  RowWidget(
                      title: "Device Name: ",
                      value:
                          deviceInsuranceDetailModel?.deviceInfo?.deviceName ??
                              " ",
                      fSize: 16),
                  const SizedBox(height: 5.0),
                  RowWidget(
                      title: "Device Brand: ",
                      value:
                          deviceInsuranceDetailModel?.deviceInfo?.brandName ??
                              " ",
                      fSize: 16),
                  const SizedBox(height: 5.0),
                  RowWidget(
                      title: "Device Model:  ",
                      value:
                          deviceInsuranceDetailModel?.deviceInfo?.modelName ??
                              " ",
                      fSize: 16),
                  const SizedBox(height: 5.0),
                  RowWidget(
                      title: "Device Price:  ",
                      value:
                          "৳ ${deviceInsuranceDetailModel?.deviceInfo?.devicePrice}",
                      fSize: 16),
                ],
              ),
            ),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(40),
              boxShadow: const [
                BoxShadow(
                    color: Color(0xFFFFFFFF),
                    blurRadius: 6,
                    spreadRadius: 0,
                    offset: Offset(-3, -3)),
              ],
              color: const Color(0xFFF0F3F6),
            )));
  }

  createPriceDetailsWidget() {
    return Padding(
        padding:
            const EdgeInsets.only(right: 14, top: 10, bottom: 10, left: 14),
        child: Container(
            // padding: const EdgeInsets.all(10.0),
            //width: (MediaQuery.of(context).size.width - 45) / 3,
            alignment: Alignment.centerLeft,
            // padding: const EdgeInsets.only(top: 20),
            child: Padding(
              padding: const EdgeInsets.only(
                left: 30,
                right: 30,
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  const SizedBox(height: 10.0),
                  const Text(
                    "INSURANCE PRICE INFO",
                    textAlign: TextAlign.left,
                    style: TextStyle(
                      fontFamily: 'Roboto Slab',
                      fontSize: 16,
                      color: Color(0xff002E5B),
                      decoration: TextDecoration.underline,
                    ),
                  ),
                  const SizedBox(height: 10.0),
                  Center(
                    child: SizedBox(
                        width: 280,
                        child: Table(
                          columnWidths: const {
                            0: FlexColumnWidth(1),
                            1: FixedColumnWidth(60),
                            2: FlexColumnWidth(1),
                          },
                          border: TableBorder.all(
                            color: Colors.grey,
                            //style: BorderStyle.solid,
                            style: BorderStyle.solid,
                            width: 1.0,
                          ),
                          // Allows to add a border decoration around your table
                          children: deviceInsuranceDetailModel!
                              .insuranceTypeValue!
                              .map((insurancePriceInfo) {
                            return TableRow(children: [
                              Center(
                                  child: Padding(
                                padding:
                                    const EdgeInsets.only(top: 20, bottom: 20),
                                child: Text(
                                  deviceInsuranceDetailModel
                                              ?.insuranceTypeValue!
                                              .indexOf(insurancePriceInfo) ==
                                          0
                                      ? 'Insurance Type'
                                      : '${insurancePriceInfo.partsType}',
                                  textAlign: TextAlign.left,
                                  style: const TextStyle(
                                    fontFamily: 'Roboto Slab',
                                    fontSize: 12,
                                    color: Color(0xff002E5B),
                                  ),
                                ),
                              )),
                              Center(
                                child: Padding(
                                  padding: const EdgeInsets.only(
                                      top: 20, bottom: 20),
                                  child: Text(
                                    deviceInsuranceDetailModel
                                                ?.insuranceTypeValue!
                                                .indexOf(insurancePriceInfo) ==
                                            0
                                        ? 'Price'
                                        : '৳${insurancePriceInfo.price}',
                                    textAlign: TextAlign.left,
                                    style: const TextStyle(
                                      fontFamily: 'Roboto Slab',
                                      fontSize: 12,
                                      color: Color(0xff002E5B),
                                    ),
                                  ),
                                ),
                              ),
                              Center(
                                  child: Padding(
                                padding:
                                    const EdgeInsets.only(top: 20, bottom: 20),
                                child: Text(
                                  deviceInsuranceDetailModel
                                              ?.insuranceTypeValue!
                                              .indexOf(insurancePriceInfo) ==
                                          0
                                      ? 'Insurance Type'
                                      : '${insurancePriceInfo.insType}',
                                  textAlign: TextAlign.left,
                                  style: const TextStyle(
                                    fontFamily: 'Roboto Slab',
                                    fontSize: 12,
                                    color: Color(0xff002E5B),
                                  ),
                                ),
                              )),
                            ]);
                          }).toList(),
                        )),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                ],
              ),
            ),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(40),
              boxShadow: const [
                BoxShadow(
                    color: Color(0xFFFFFFFF),
                    blurRadius: 6,
                    spreadRadius: 0,
                    offset: Offset(-3, -3)),
              ],
              color: const Color(0xFFF0F3F6),
            )));
  }

  createRemainingClaimWidget() {
    return Padding(
        padding:
            const EdgeInsets.only(right: 14, top: 10, bottom: 10, left: 14),
        child: Container(
            // padding: const EdgeInsets.all(10.0),
            //width: (MediaQuery.of(context).size.width - 45) / 3,
            alignment: Alignment.centerLeft,
            // padding: const EdgeInsets.only(top: 20),
            child: Padding(
              padding: const EdgeInsets.only(
                left: 30,
                right: 30,
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  const SizedBox(height: 10.0),
                  const Text(
                    "REMAINING CLAIM",
                    textAlign: TextAlign.left,
                    style: TextStyle(
                      fontFamily: 'Roboto Slab',
                      fontSize: 16,
                      color: Color(0xff002E5B),
                      decoration: TextDecoration.underline,
                    ),
                  ),
                  const SizedBox(height: 10.0),
                  Center(
                    child: SizedBox(
                        width: 280,
                        child: Table(
                          columnWidths: const {
                            0: FlexColumnWidth(1),
                            2: FlexColumnWidth(1),
                          },
                          border: TableBorder.all(
                            color: Colors.grey,
                            //style: BorderStyle.solid,
                            style: BorderStyle.solid,
                            width: 1.0,
                          ),
                          // Allows to add a border decoration around your table
                          children: deviceInsuranceDetailModel!
                              .deviceInsuraceDetails!
                              .map((deviceInsuraceDetail) {
                            return TableRow(children: [
                              Center(
                                  child: Padding(
                                padding:
                                    const EdgeInsets.only(top: 20, bottom: 20),
                                child: Text(
                                  deviceInsuranceDetailModel
                                              ?.deviceInsuraceDetails!
                                              .indexOf(deviceInsuraceDetail) ==
                                          0
                                      ? 'Insurance Type'
                                      : '${deviceInsuraceDetail.partsType}',
                                  textAlign: TextAlign.left,
                                  style: const TextStyle(
                                    fontFamily: 'Roboto Slab',
                                    fontSize: 12,
                                    color: Color(0xff002E5B),
                                  ),
                                ),
                              )),
                              Center(
                                child: Padding(
                                  padding: const EdgeInsets.only(
                                      top: 20, bottom: 20),
                                  child: Text(
                                    deviceInsuranceDetailModel
                                                ?.deviceInsuraceDetails!
                                                .indexOf(
                                                    deviceInsuraceDetail) ==
                                            0
                                        ? 'Remaining Claim'
                                        : deviceInsuraceDetail
                                                    .protectionTimesFor !=
                                                null
                                            ? '${deviceInsuraceDetail.protectionTimesFor} Times Remaining'
                                            : '৳${deviceInsuraceDetail.claimAmount} Remaining',
                                    textAlign: TextAlign.left,
                                    style: const TextStyle(
                                      fontFamily: 'Roboto Slab',
                                      fontSize: 12,
                                      color: Color(0xff002E5B),
                                    ),
                                  ),
                                ),
                              ),
                            ]);
                          }).toList(),
                        )),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                ],
              ),
            ),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(40),
              boxShadow: const [
                BoxShadow(
                    color: Color(0xFFFFFFFF),
                    blurRadius: 6,
                    spreadRadius: 0,
                    offset: Offset(-3, -3)),
              ],
              color: const Color(0xFFF0F3F6),
            )));
  }

  createRemainingClaimWidget2() {
    return Padding(
        padding:
            const EdgeInsets.only(right: 14, top: 10, bottom: 10, left: 14),
        child: Container(
            // padding: const EdgeInsets.all(10.0),
            //width: (MediaQuery.of(context).size.width - 45) / 3,
            height: 164,
            alignment: Alignment.centerLeft,
            // padding: const EdgeInsets.only(top: 20),
            child: Padding(
              padding: const EdgeInsets.only(
                left: 30,
                right: 30,
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  const SizedBox(height: 10.0),
                  const Text(
                    "REMAINING CLAIM",
                    textAlign: TextAlign.left,
                    style: TextStyle(
                      fontFamily: 'Roboto Slab',
                      fontSize: 16,
                      color: Color(0xff002E5B),
                      decoration: TextDecoration.underline,
                    ),
                  ),
                  const SizedBox(height: 10.0),
                  Center(
                      child: SizedBox(
                    width: 280,
                    child: Table(
                        columnWidths: const {
                          0: FlexColumnWidth(1),
                          1: FlexColumnWidth(1),
                        },
                        border: TableBorder.all(
                          color: Colors.grey,
                          //style: BorderStyle.solid,
                          style: BorderStyle.solid,
                          width: 1.0,
                        ),
                        // Allows to add a border decoration around your table
                        children: [
                          const TableRow(children: [
                            Center(
                                child: Padding(
                              padding: EdgeInsets.only(top: 20, bottom: 20),
                              child: Text(
                                'Insurance Type',
                                textAlign: TextAlign.left,
                                style: TextStyle(
                                  fontFamily: 'Roboto Slab',
                                  fontSize: 12,
                                  color: Color(0xff002E5B),
                                ),
                              ),
                            )),
                            Center(
                              child: Padding(
                                padding: EdgeInsets.only(top: 20, bottom: 20),
                                child: Text(
                                  'Remaining Claim',
                                  textAlign: TextAlign.left,
                                  style: TextStyle(
                                    fontFamily: 'Roboto Slab',
                                    fontSize: 12,
                                    color: Color(0xff002E5B),
                                  ),
                                ),
                              ),
                            )
                          ]),
                          TableRow(children: [
                            const Center(
                                child: Padding(
                              padding: EdgeInsets.all(10),
                              child: Text(
                                '',
                                textAlign: TextAlign.left,
                                style: TextStyle(
                                  fontFamily: 'Roboto Slab',
                                  fontSize: 11,
                                  color: Color(0xff002E5B),
                                ),
                              ),
                            )),
                            Center(
                              child: Padding(
                                padding: const EdgeInsets.all(10),
                                child: Text(
                                  '৳ ${int.parse(deviceInsuranceDetailModel!.claimableAmount!) - int.parse(deviceInsuranceDetailModel!.claimedAmount!)}',
                                  textAlign: TextAlign.left,
                                  style: const TextStyle(
                                    fontFamily: 'Roboto Slab',
                                    fontSize: 11,
                                    color: Color(0xff002E5B),
                                  ),
                                ),
                              ),
                            )
                          ]),
                        ]),
                  )),
                ],
              ),
            ),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(40),
              boxShadow: const [
                BoxShadow(
                    color: Color(0xFFFFFFFF),
                    blurRadius: 6,
                    spreadRadius: 0,
                    offset: Offset(-3, -3)),
              ],
              color: const Color(0xFFF0F3F6),
            )));
  }

  createTotalPriceInfoWidget() {
    return Padding(
        padding:
            const EdgeInsets.only(right: 70, top: 10, bottom: 10, left: 70),
        child: Container(
            // padding: const EdgeInsets.all(10.0),
            //width: (MediaQuery.of(context).size.width - 45) / 3,
            height: 164,
            alignment: Alignment.center,
            // padding: const EdgeInsets.only(top: 20),
            child: Padding(
              padding: const EdgeInsets.only(
                left: 30,
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  const SizedBox(height: 10.0),
                  const Text(
                    "TOTAL PRICE INFO",
                    textAlign: TextAlign.left,
                    style: TextStyle(
                      fontFamily: 'Roboto Slab',
                      fontSize: 16,
                      color: Color(0xff002E5B),
                      decoration: TextDecoration.underline,
                    ),
                  ),
                  const SizedBox(height: 10.0),
                  Text(
                    "Sub Total: ৳${deviceInsuranceDetailModel?.subTotal ?? '0'}",
                    textAlign: TextAlign.left,
                    style: const TextStyle(
                      fontFamily: 'Roboto Slab',
                      fontSize: 16,
                      color: Color(0xff002E5B),
                    ),
                  ),
                  const SizedBox(height: 10.0),
                  Text(
                    "VAT: ৳${deviceInsuranceDetailModel?.totalVat ?? '0'}",
                    textAlign: TextAlign.left,
                    style: const TextStyle(
                      fontFamily: 'Roboto Slab',
                      fontSize: 16,
                      color: Color(0xff002E5B),
                    ),
                  ),
                  const SizedBox(height: 10.0),
                  Text(
                    "Total: ৳${deviceInsuranceDetailModel?.grandTotal ?? '0'}",
                    textAlign: TextAlign.left,
                    style: const TextStyle(
                      fontFamily: 'Roboto Slab',
                      fontSize: 16,
                      color: Color(0xff002E5B),
                    ),
                  ),
                ],
              ),
            ),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(40),
              boxShadow: const [
                BoxShadow(
                    color: Color(0xFFFFFFFF),
                    blurRadius: 6,
                    spreadRadius: 0,
                    offset: Offset(-3, -3)),
              ],
              color: const Color(0xFFF0F3F6),
            )));
  }

  Future<Future> showPopUp(context) async {
    Size size = MediaQuery.of(context).size;
    return showDialog(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext context) {
          return StatefulBuilder(builder: (context, setState) {
            return AlertDialog(
              backgroundColor: Colors.white,
              shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.all(Radius.circular(20.0))),
              content: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    const Text(
                      "Select Insurance Type",
                      style: TextStyle(color: Colors.black, fontSize: 20),
                    ),
                    const Padding(
                      padding: EdgeInsets.only(top: 15.0, bottom: 5),
                      child: Text(
                        "Claim Type",
                        style: TextStyle(color: Colors.black, fontSize: 16),
                      ),
                    ),
                    Container(
                      height: 30,
                      width: 150,
                      padding: const EdgeInsets.only(left: 5, right: 5),
                      child: DropdownButton<String>(
                        isExpanded: false,
                        value: selectedType,
                        // icon: const Icon(Icons.arrow_downward),
                        // iconSize: 14,
                        elevation: 10,
                        underline: Container(),
                        onChanged: (var newValue) {
                          setState(() {
                            selectedType = newValue!;
                          });
                        },
                        items: List.generate(
                          selectionOptions.length,
                          (index) => DropdownMenuItem(
                            child: Text(selectionOptions[index]),
                            value: selectionOptions[index],
                          ),
                        ),
                      ),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(5),
                          boxShadow: const [
                            BoxShadow(
                                color: Color(0xFFFFFFFF),
                                blurRadius: 6,
                                spreadRadius: 0,
                                offset: Offset(-3, -3)),
                            BoxShadow(
                                color: Color(0xFFFFFFFF),
                                blurRadius: 6,
                                spreadRadius: 0,
                                offset: Offset(3, 3)),
                          ],
                          color: const Color(0xFFF0F3F6)),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: <Widget>[
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Container(
                              height: 35,
                              width: 75,
                              // padding: const EdgeInsets.fromLTRB(10, 15, 10, 5),
                              child: TextButton(
                                child: const Text(
                                  'Close',
                                  style: TextStyle(color: Colors.white),
                                ),
                                onPressed: () {
                                  Navigator.of(context).pop();
                                },
                              ),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(20),
                                boxShadow: [
                                  BoxShadow(
                                      color: const Color(0xff000000)
                                          .withOpacity(0.16),
                                      blurRadius: 3,
                                      spreadRadius: 0,
                                      offset: const Offset(0, 3)),
                                ],
                                color: const Color(0xff002E5B),
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Container(
                              height: 35,
                              width: 75,
                              // padding: const EdgeInsets.fromLTRB(10, 15, 10, 5),
                              child: TextButton(
                                child: const Text(
                                  'Submit',
                                  style: TextStyle(color: Colors.white),
                                ),
                                onPressed: () {
                                  if (selectedType.compareTo("Damage") == 0) {
                                    Navigator.of(context).pop();

                                    getDivisions();
                                  } else {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => ClaimPage(
                                              deviceInsuranceId: widget.id)),
                                    );
                                  }
                                },
                              ),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(20),
                                boxShadow: [
                                  BoxShadow(
                                      color: const Color(0xff000000)
                                          .withOpacity(0.16),
                                      blurRadius: 3,
                                      spreadRadius: 0,
                                      offset: const Offset(0, 3)),
                                ],
                                color: const Color(0xff002E5B),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            );
          });
        });
  }
}
