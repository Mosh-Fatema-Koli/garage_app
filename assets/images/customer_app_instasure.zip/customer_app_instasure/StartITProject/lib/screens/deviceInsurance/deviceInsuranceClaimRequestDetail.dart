// ignore_for_file: unnecessary_new

import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:instasure/Utilities/helper.dart';
import 'package:instasure/Utilities/userPref.dart';
import 'package:instasure/domains/models/deviceInsurance/deviceClaimDetailModel.dart';
import 'package:instasure/domains/models/deviceInsurance/deviceClaimDetailsDownloadModel.dart';
import 'package:instasure/domains/repo/apiClientDeviceInsurance.dart';
import 'package:instasure/widgets/rowWidget.dart';
import 'package:instasure/widgets/topView4.dart';

class DeviceInsuranceClaimRequestDetail extends StatefulWidget {
  const DeviceInsuranceClaimRequestDetail({Key? key, required this.id})
      : super(key: key);
  final String id;

  @override
  _ClaimedInvoiceState createState() => _ClaimedInvoiceState();
}

class _ClaimedInvoiceState extends State<DeviceInsuranceClaimRequestDetail> {
  final ApiClientDeviceInsurance _apiClient = ApiClientDeviceInsurance();
  late DeviceClaimDetailModel _deviceClaimDetailModel;
  late DeviceClaimDetailsDownloadModel _deviceClaimDetailsDownloadModel;

  var loading = true;

  @override
  void initState() {
    super.initState();
    () async {
      await Future.delayed(Duration.zero);
      // getInsuranceClaimedReqDetailData();
      getDeviceClaimDetailsDownloadData();
    }();
  }

  Future<void> getInsuranceClaimedReqDetailData() async {
    UserPref prefs = UserPref();
    Future<String?> token = prefs.getTokenFromPref();
    String? accessToken = await token;
    EasyLoading.instance.userInteractions = false;
    EasyLoading.show(status: 'Processing...');
    dynamic res = await _apiClient.getDeviceInsuranceClaiDetailData(
        widget.id, accessToken!);
    //ScaffoldMessenger.of(context).hideCurrentSnackBar();
    EasyLoading.dismiss();
    if (res.statusCode == 200) {
      if (res.data['code'] == 200) {
        // InsuranceHistoryModel histories =
        DeviceClaimDetailModel deviceClaimDetailModel =
            DeviceClaimDetailModel.fromJson(res.data['data']);

        setState(() {
          _deviceClaimDetailModel = deviceClaimDetailModel;
          loading = false;
        });
      } else {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('${res.data['message']}'),
          backgroundColor: Colors.red.shade300,
        ));
        setState(() {
          loading = false;
        });
      }
    } else {
      setState(() {
        loading = false;
      });
    }
  }

  Future<void> getDeviceClaimDetailsDownloadData() async {
    UserPref prefs = UserPref();
    Future<String?> token = prefs.getTokenFromPref();
    String? accessToken = await token;

    dynamic res = await _apiClient.getDeviceInsuranceClaimDetailDownloadData(
        widget.id, accessToken!);
    ScaffoldMessenger.of(context).hideCurrentSnackBar();

    if (res.statusCode == 200) {
      if (res.data['code'] == 200) {
        // InsuranceHistoryModel histories =
        DeviceClaimDetailsDownloadModel deviceClaimDetailsDownloadModel =
            DeviceClaimDetailsDownloadModel.fromJson(res.data['data']);

        setState(() {
          _deviceClaimDetailsDownloadModel = deviceClaimDetailsDownloadModel;
          loading = false;
        });
      } else {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('${res.data['message']}'),
          backgroundColor: Colors.red.shade300,
        ));
      }
    } else {}
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: loading
          ? const Center(
              child: Text(""),
            )
          : Center(
              child: Padding(
              padding: const EdgeInsets.all(0),
              child: Column(
                children: [
                  Stack(
                    children: [
                      const TopView4(),
                      Positioned(
                        bottom: 20.0,
                        left: 40.0,
                        child: SizedBox(
                            height: 30,
                            width: 30,
                            // color: const Color.fromRGBO(0, 46, 91, 1.0),
                            // padding: const EdgeInsets.fromLTRB(10, 15, 10, 5),
                            child: TextButton(
                              child: Image.asset('assets/back_button_icon.png'),
                              onPressed: () {
                                Navigator.of(context).pop();
                              },
                            )),
                      )
                    ],
                  ),
                  Expanded(
                    child: ListView(
                      children: <Widget>[
                        const SizedBox(height: 0.0),
                        createHeaderWidget(),
                        createCompanyInfoWidget(),
                        createServiceCenterInfoWidget(),
                        createInvoiceInfoWidget(),
                        createCustomerInfoWidget(),
                        createDeviceInfoWidget(),
                        createPriceInfoWidget(),
                        createClaimWidget(),
                        const SizedBox(height: 20.0),
                        //createBottomButtonWidget(),
                        const SizedBox(height: 40.0),
                      ],
                    ),
                  ),
                ],
              ),
            )),
      backgroundColor: const Color(0xFFEFF7FF),
    );
  }

  createHeaderWidget() {
    return Container(
      height: 40,
      child: const Center(
        child: Text(
          'CLAIM INVOICE',
          textAlign: TextAlign.center,
          style: TextStyle(
            fontFamily: 'Roboto-Bold',
            fontSize: 18,
            color: Color(0xff000000),
          ),
        ),
      ),
    );
  }

  createBottomButtonWidget() {
    return Align(
      alignment: Alignment.centerRight,
      child: Container(
        margin: const EdgeInsets.only(right: 30),
        height: 44,
        width: 44,
        //padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
        child: TextButton(
          child: const Icon(
            Icons.print,
            size: 20,
            color: Color(0xff000000),
          ),
          onPressed: () {},
        ),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          boxShadow: const [
            BoxShadow(
                color: Color(0xffffffff),
                blurRadius: 6,
                spreadRadius: 0,
                offset: Offset(-3, -3)),
          ],
          color: const Color(0xFFF0F3F6),
        ),
      ),
    );
  }

  createCompanyInfoWidget() {
    return Padding(
        padding:
            const EdgeInsets.only(right: 14, top: 10, bottom: 10, left: 14),
        child: Container(
          // padding: const EdgeInsets.all(10.0),
          //width: (MediaQuery.of(context).size.width - 45) / 3,
          height: 140,
          alignment: Alignment.centerLeft,
          // padding: const EdgeInsets.only(top: 20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: const <Widget>[
              SizedBox(height: 10.0),
              Text(
                'Company Info',
                textAlign: TextAlign.left,
                style: TextStyle(
                  fontFamily: 'Roboto Slab',
                  fontSize: 16,
                  color: Color(0xff002E5B),
                ),
              ),
              Text(
                'Instasure',
                textAlign: TextAlign.left,
                style: TextStyle(
                  fontFamily: 'Roboto Slab',
                  fontSize: 14,
                  color: Color(0xff002E5B),
                ),
              ),
              SizedBox(height: 5.0),
              RowWidget(
                  title: "Address: ",
                  value:
                      'House#67 (1st Floor), Road#17, Block# C, Banani, Dhaka-1213',
                  fSize: 12),
              SizedBox(height: 5.0),
              RowWidget(title: "Phone: ", value: '02-9820580-1', fSize: 12),
              SizedBox(height: 5.0),
              RowWidget(title: "Cell-Phone: ", value: '01915828248', fSize: 12),
              SizedBox(height: 5.0),
              RowWidget(
                  title: "Email: ", value: 'info@instasure.com', fSize: 12),
            ],
          ),
        ));
  }

  createServiceCenterInfoWidget() {
    return Padding(
        padding:
            const EdgeInsets.only(right: 14, top: 10, bottom: 10, left: 14),
        child: Container(
          // padding: const EdgeInsets.all(10.0),
          //width: (MediaQuery.of(context).size.width - 45) / 3,
          height: 110,
          alignment: Alignment.centerLeft,
          // padding: const EdgeInsets.only(top: 20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              SizedBox(height: 10.0),
              const Text(
                'Service Center Info',
                textAlign: TextAlign.left,
                style: TextStyle(
                  fontFamily: 'Roboto Slab',
                  fontSize: 16,
                  color: Color(0xff002E5B),
                ),
              ),
              const SizedBox(height: 5.0),
              RowWidget(
                  title: "Name: ",
                  value: loading
                      ? ''
                      : _deviceClaimDetailsDownloadModel
                              .serviceCenter?.serviceCenterName ??
                          '',
                  fSize: 12),
              const SizedBox(height: 5.0),
              RowWidget(
                  title: "Phone: ",
                  value: loading
                      ? ''
                      : _deviceClaimDetailsDownloadModel
                              .serviceCenter?.contactPersonPhone ??
                          '',
                  fSize: 12),
              const SizedBox(height: 5.0),
              RowWidget(
                  title: "Email: ",
                  value: loading
                      ? ''
                      : _deviceClaimDetailsDownloadModel
                              .serviceCenter?.contactPersonEmail ??
                          '',
                  fSize: 12),
              const SizedBox(height: 5.0),
              RowWidget(
                  title: "Address: ",
                  value: loading
                      ? ''
                      : _deviceClaimDetailsDownloadModel
                              .serviceCenter?.address ??
                          '',
                  fSize: 12),
            ],
          ),
        ));
  }

  createInvoiceInfoWidget() {
    return Padding(
        padding:
            const EdgeInsets.only(right: 14, top: 10, bottom: 10, left: 14),
        child: Container(
          // padding: const EdgeInsets.all(10.0),
          //width: (MediaQuery.of(context).size.width - 45) / 3,
          height: 70,
          alignment: Alignment.centerLeft,
          // padding: const EdgeInsets.only(top: 20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              const SizedBox(height: 10.0),
              RowWidget(
                  title: "Invoice Number: ",
                  value: loading
                      ? ''
                      : _deviceClaimDetailsDownloadModel.claimId ?? '',
                  fSize: 12),
              const SizedBox(height: 5.0),
              RowWidget(
                  title: "Date: ",
                  value: loading
                      ? ''
                      : getDateString(
                          _deviceClaimDetailsDownloadModel.createdAt ?? " ",
                          'MMM dd, yyyy hh:mm:a'),
                  fSize: 12),
            ],
          ),
        ));
  }

  createCustomerInfoWidget() {
    return Container(
      // padding: const EdgeInsets.all(10.0),
      //width: (MediaQuery.of(context).size.width - 45) / 3,
      height: 120,
      alignment: Alignment.centerLeft,
      // padding: const EdgeInsets.only(top: 20),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Container(
            height: 30.0,
            alignment: Alignment.centerLeft,
            width: MediaQuery.of(context).size.width,
            padding: const EdgeInsets.only(left: 20),
            child: const Text(
              "Customer Information",
              textAlign: TextAlign.left,
              style: TextStyle(
                fontFamily: 'Roboto Slab',
                fontSize: 16,
                color: Colors.white,
              ),
            ),
            color: const Color(0xFF86888A),
          ),
          Center(
              child: SizedBox(
            width: MediaQuery.of(context).size.width,
            child: Table(
                columnWidths: const {
                  0: FlexColumnWidth(1),
                  1: FlexColumnWidth(1),
                },
                border: const TableBorder(
                    left: BorderSide(color: Color(0xff707070), width: 1),
                    right: BorderSide(color: Color(0xff707070), width: 1),
                    top: BorderSide(color: Color(0xff707070), width: 1),
                    bottom: BorderSide(color: Color(0xff707070), width: 1),
                    horizontalInside:
                        BorderSide(color: Color(0xff707070), width: 1),
                    verticalInside:
                        BorderSide(color: Color(0xff707070), width: 2)),
                /*.all(
                  color: const Color(0xff707070),
                  style: BorderStyle.solid,
                  width: 1.0,
                ),*/
                // Allows to add a border decoration around your table
                children: [
                  const TableRow(children: [
                    Center(
                        child: Padding(
                      padding: EdgeInsets.only(top: 10, bottom: 10),
                      child: Text(
                        'Customer Name',
                        textAlign: TextAlign.left,
                        style: TextStyle(
                          fontFamily: 'Roboto Slab',
                          fontSize: 12,
                          color: Color(0xff002E5B),
                        ),
                      ),
                    )),
                    Padding(
                      padding: EdgeInsets.only(top: 10, bottom: 10),
                      child: Text(
                        'Phone',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontFamily: 'Roboto Slab',
                          fontSize: 12,
                          color: Color(0xff002E5B),
                        ),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(top: 10, bottom: 10),
                      child: Text(
                        'Email',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontFamily: 'Roboto Slab',
                          fontSize: 12,
                          color: Color(0xff002E5B),
                        ),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(top: 10, bottom: 10),
                      child: Text(
                        'NID Number',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontFamily: 'Roboto Slab',
                          fontSize: 12,
                          color: Color(0xff002E5B),
                        ),
                      ),
                    ),
                  ]),
                  TableRow(children: [
                    Padding(
                      padding: const EdgeInsets.only(
                          left: 2, top: 10, right: 2, bottom: 10),
                      child: Text(
                        loading
                            ? ''
                            : _deviceClaimDetailsDownloadModel.deviceInsurance
                                    ?.customerInfo?.customerName ??
                                '',
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          fontFamily: 'Roboto Slab',
                          fontSize: 10,
                          color: Color(0xff002E5B),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(
                          left: 2, top: 10, right: 2, bottom: 10),
                      child: Text(
                        loading
                            ? ''
                            : _deviceClaimDetailsDownloadModel.deviceInsurance
                                    ?.customerInfo?.customerPhone ??
                                '',
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          fontFamily: 'Roboto Slab',
                          fontSize: 10,
                          color: Color(0xff002E5B),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(
                          left: 2, top: 10, right: 2, bottom: 10),
                      child: Text(
                        loading
                            ? ''
                            : _deviceClaimDetailsDownloadModel.deviceInsurance
                                    ?.customerInfo?.customerEmail ??
                                '',
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          fontFamily: 'Roboto Slab',
                          fontSize: 10,
                          color: Color(0xff002E5B),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(
                          left: 2, top: 10, right: 2, bottom: 10),
                      child: Text(
                        loading
                            ? ''
                            : _deviceClaimDetailsDownloadModel
                                    .deviceInsurance?.customerInfo?.number ??
                                '',
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          fontFamily: 'Roboto Slab',
                          fontSize: 10,
                          color: Color(0xff002E5B),
                        ),
                      ),
                    ),
                  ]),
                ]),
          )),
        ],
      ),
    );
  }

  createDeviceInfoWidget() {
    return Container(
      // padding: const EdgeInsets.all(10.0),
      //width: (MediaQuery.of(context).size.width - 45) / 3,
      height: 120,
      alignment: Alignment.centerLeft,
      // padding: const EdgeInsets.only(top: 20),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Container(
            height: 30.0,
            alignment: Alignment.centerLeft,
            width: MediaQuery.of(context).size.width,
            padding: const EdgeInsets.only(left: 20),
            child: const Text(
              "Device Information",
              textAlign: TextAlign.left,
              style: TextStyle(
                fontFamily: 'Roboto Slab',
                fontSize: 16,
                color: Colors.white,
              ),
            ),
            color: const Color(0xFF86888A),
          ),
          Center(
              child: SizedBox(
            width: MediaQuery.of(context).size.width,
            child: Table(
                columnWidths: const {
                  0: FlexColumnWidth(1),
                  1: FlexColumnWidth(1),
                },
                border: const TableBorder(
                    left: BorderSide(color: Color(0xff707070), width: 1),
                    right: BorderSide(color: Color(0xff707070), width: 1),
                    top: BorderSide(color: Color(0xff707070), width: 1),
                    bottom: BorderSide(color: Color(0xff707070), width: 1),
                    horizontalInside:
                        BorderSide(color: Color(0xff707070), width: 1),
                    verticalInside:
                        BorderSide(color: Color(0xff707070), width: 2)),
                // Allows to add a border decoration around your table
                children: [
                  const TableRow(children: [
                    Center(
                        child: Padding(
                      padding: EdgeInsets.only(top: 10, bottom: 10),
                      child: Text(
                        'Device Name',
                        textAlign: TextAlign.left,
                        style: TextStyle(
                          fontFamily: 'Roboto Slab',
                          fontSize: 12,
                          color: Color(0xff002E5B),
                        ),
                      ),
                    )),
                    Center(
                      child: Padding(
                        padding: EdgeInsets.only(top: 10, bottom: 10),
                        child: Text(
                          'Brand',
                          textAlign: TextAlign.left,
                          style: TextStyle(
                            fontFamily: 'Roboto Slab',
                            fontSize: 12,
                            color: Color(0xff002E5B),
                          ),
                        ),
                      ),
                    ),
                    Center(
                      child: Padding(
                        padding: EdgeInsets.only(top: 10, bottom: 10),
                        child: Text(
                          'Model',
                          textAlign: TextAlign.left,
                          style: TextStyle(
                            fontFamily: 'Roboto Slab',
                            fontSize: 12,
                            color: Color(0xff002E5B),
                          ),
                        ),
                      ),
                    ),
                    Center(
                      child: Padding(
                        padding: EdgeInsets.only(top: 10, bottom: 10),
                        child: Text(
                          'Price',
                          textAlign: TextAlign.left,
                          style: TextStyle(
                            fontFamily: 'Roboto Slab',
                            fontSize: 12,
                            color: Color(0xff002E5B),
                          ),
                        ),
                      ),
                    )
                  ]),
                  TableRow(children: [
                    Center(
                        child: Padding(
                      padding: const EdgeInsets.only(
                          left: 2, top: 10, right: 2, bottom: 10),
                      child: Text(
                        loading
                            ? ''
                            : _deviceClaimDetailsDownloadModel
                                    .deviceInsurance?.deviceInfo?.deviceName ??
                                '',
                        textAlign: TextAlign.left,
                        style: const TextStyle(
                          fontFamily: 'Roboto Slab',
                          fontSize: 10,
                          color: Color(0xff002E5B),
                        ),
                      ),
                    )),
                    Center(
                      child: Padding(
                        padding: const EdgeInsets.only(
                            left: 2, top: 10, right: 2, bottom: 10),
                        child: Text(
                          loading
                              ? ''
                              : _deviceClaimDetailsDownloadModel
                                      .deviceInsurance?.deviceInfo?.brandName ??
                                  '',
                          textAlign: TextAlign.left,
                          style: const TextStyle(
                            fontFamily: 'Roboto Slab',
                            fontSize: 10,
                            color: Color(0xff002E5B),
                          ),
                        ),
                      ),
                    ),
                    Center(
                      child: Padding(
                        padding: const EdgeInsets.only(
                            left: 2, top: 10, right: 2, bottom: 10),
                        child: Text(
                          loading
                              ? ''
                              : _deviceClaimDetailsDownloadModel
                                      .deviceInsurance?.deviceInfo?.modelName ??
                                  '',
                          textAlign: TextAlign.left,
                          style: const TextStyle(
                            fontFamily: 'Roboto Slab',
                            fontSize: 10,
                            color: Color(0xff002E5B),
                          ),
                        ),
                      ),
                    ),
                    Center(
                      child: Padding(
                        padding: const EdgeInsets.only(
                            left: 2, top: 10, right: 2, bottom: 10),
                        child: Text(
                          loading
                              ? ''
                              : "৳${_deviceClaimDetailsDownloadModel.deviceInsurance?.deviceInfo?.devicePrice}",
                          textAlign: TextAlign.left,
                          style: const TextStyle(
                            fontFamily: 'Roboto Slab',
                            fontSize: 10,
                            color: Color(0xff002E5B),
                          ),
                        ),
                      ),
                    )
                  ]),
                ]),
          )),
        ],
      ),
    );
  }

  createPriceInfoWidget() {
    return Container(
      // padding: const EdgeInsets.all(10.0),
      //width: (MediaQuery.of(context).size.width - 45) / 3,
      height: 120,
      alignment: Alignment.centerLeft,
      // padding: const EdgeInsets.only(top: 20),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Container(
            height: 30.0,
            alignment: Alignment.centerLeft,
            width: MediaQuery.of(context).size.width,
            padding: const EdgeInsets.only(left: 20),
            child: const Text(
              "Insurance Price Information",
              textAlign: TextAlign.left,
              style: TextStyle(
                fontFamily: 'Roboto Slab',
                fontSize: 16,
                color: Colors.white,
              ),
            ),
            color: const Color(0xFF86888A),
          ),
          Center(
              child: SizedBox(
            width: MediaQuery.of(context).size.width,
            child: Table(
                columnWidths: const {
                  0: FlexColumnWidth(1),
                  1: FlexColumnWidth(1),
                },
                border: const TableBorder(
                    left: BorderSide(color: Color(0xff707070), width: 1),
                    right: BorderSide(color: Color(0xff707070), width: 1),
                    top: BorderSide(color: Color(0xff707070), width: 1),
                    bottom: BorderSide(color: Color(0xff707070), width: 1),
                    horizontalInside:
                        BorderSide(color: Color(0xff707070), width: 1),
                    verticalInside:
                        BorderSide(color: Color(0xff707070), width: 2)),
                // Allows to add a border decoration around your table
                children: [
                  const TableRow(children: [
                    Center(
                        child: Padding(
                      padding: EdgeInsets.only(top: 10, bottom: 10),
                      child: Text(
                        'Status',
                        textAlign: TextAlign.left,
                        style: TextStyle(
                          fontFamily: 'Roboto Slab',
                          fontSize: 12,
                          color: Color(0xff002E5B),
                        ),
                      ),
                    )),
                    Center(
                      child: Padding(
                        padding: EdgeInsets.only(top: 10, bottom: 10),
                        child: Text(
                          'Note',
                          textAlign: TextAlign.left,
                          style: TextStyle(
                            fontFamily: 'Roboto Slab',
                            fontSize: 12,
                            color: Color(0xff002E5B),
                          ),
                        ),
                      ),
                    ),
                    Center(
                      child: Padding(
                        padding: EdgeInsets.only(top: 10, bottom: 10),
                        child: Text(
                          'Payment Status',
                          textAlign: TextAlign.left,
                          style: TextStyle(
                            fontFamily: 'Roboto Slab',
                            fontSize: 12,
                            color: Color(0xff002E5B),
                          ),
                        ),
                      ),
                    ),
                    Center(
                      child: Padding(
                        padding: EdgeInsets.only(top: 10, bottom: 10),
                        child: Text(
                          'Payment Details',
                          textAlign: TextAlign.left,
                          style: TextStyle(
                            fontFamily: 'Roboto Slab',
                            fontSize: 12,
                            color: Color(0xff002E5B),
                          ),
                        ),
                      ),
                    )
                  ]),
                  TableRow(children: [
                    Center(
                        child: Padding(
                      padding: const EdgeInsets.only(
                          left: 2, top: 10, right: 2, bottom: 10),
                      child: Text(
                        loading
                            ? ''
                            : "${_deviceClaimDetailsDownloadModel.status}",
                        textAlign: TextAlign.left,
                        style: const TextStyle(
                          fontFamily: 'Roboto Slab',
                          fontSize: 10,
                          color: Color(0xff002E5B),
                        ),
                      ),
                    )),
                    const Center(
                      child: Padding(
                        padding: EdgeInsets.only(
                            left: 2, top: 10, right: 2, bottom: 10),
                        child: Text(
                          '',
                          textAlign: TextAlign.left,
                          style: TextStyle(
                            fontFamily: 'Roboto Slab',
                            fontSize: 10,
                            color: Color(0xff002E5B),
                          ),
                        ),
                      ),
                    ),
                    Center(
                      child: Padding(
                        padding: const EdgeInsets.only(
                            left: 2, top: 10, right: 2, bottom: 10),
                        child: Text(
                          loading
                              ? ''
                              : "${_deviceClaimDetailsDownloadModel.paymentStatus}",
                          textAlign: TextAlign.left,
                          style: const TextStyle(
                            fontFamily: 'Roboto Slab',
                            fontSize: 10,
                            color: Color(0xff002E5B),
                          ),
                        ),
                      ),
                    ),
                    Center(
                      child: Padding(
                        padding: const EdgeInsets.only(
                            left: 2, top: 10, right: 2, bottom: 10),
                        child: Text(
                          loading
                              ? ''
                              : "${_deviceClaimDetailsDownloadModel.paymentDetails}",
                          textAlign: TextAlign.left,
                          style: const TextStyle(
                            fontFamily: 'Roboto Slab',
                            fontSize: 10,
                            color: Color(0xff002E5B),
                          ),
                        ),
                      ),
                    )
                  ]),
                ]),
          )),
        ],
      ),
    );
  }

  createClaimWidget() {
    return Container(
      // padding: const EdgeInsets.all(10.0),
      //width: (MediaQuery.of(context).size.width - 45) / 3,
      height: 90,
      alignment: Alignment.centerLeft,
      // padding: const EdgeInsets.only(top: 20),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          SizedBox(
            width: 200,
            child: Table(
                columnWidths: const {
                  0: FlexColumnWidth(1),
                  1: FlexColumnWidth(1),
                },
                border: const TableBorder(
                    left: BorderSide(color: Color(0xff707070), width: 1),
                    right: BorderSide(color: Color(0xff707070), width: 1),
                    top: BorderSide(color: Color(0xff707070), width: 1),
                    bottom: BorderSide(color: Color(0xff707070), width: 1),
                    horizontalInside:
                        BorderSide(color: Color(0xff707070), width: 1),
                    verticalInside:
                        BorderSide(color: Color(0xff707070), width: 2)),
                // Allows to add a border decoration around your table
                children: [
                  const TableRow(children: [
                    Center(
                        child: Padding(
                      padding: EdgeInsets.only(top: 10, bottom: 10),
                      child: Text(
                        'Claim For',
                        textAlign: TextAlign.left,
                        style: TextStyle(
                          fontFamily: 'Roboto Slab',
                          fontSize: 12,
                          color: Color(0xff002E5B),
                        ),
                      ),
                    )),
                    Center(
                      child: Padding(
                        padding: EdgeInsets.only(top: 10, bottom: 10),
                        child: Text(
                          'Paid Amount',
                          textAlign: TextAlign.left,
                          style: TextStyle(
                            fontFamily: 'Roboto Slab',
                            fontSize: 12,
                            color: Color(0xff002E5B),
                          ),
                        ),
                      ),
                    ),
                  ]),
                  TableRow(children: [
                    Center(
                        child: Padding(
                      padding: const EdgeInsets.only(
                          left: 2, top: 10, right: 2, bottom: 10),
                      child: Text(
                        loading
                            ? ''
                            : "${_deviceClaimDetailsDownloadModel.claimOn}",
                        textAlign: TextAlign.left,
                        style: const TextStyle(
                          fontFamily: 'Roboto Slab',
                          fontSize: 10,
                          color: Color(0xff002E5B),
                        ),
                      ),
                    )),
                    Center(
                      child: Padding(
                        padding: const EdgeInsets.only(
                            left: 2, top: 10, right: 2, bottom: 10),
                        child: Text(
                          loading
                              ? ''
                              : "৳${_deviceClaimDetailsDownloadModel.userWillPay}",
                          textAlign: TextAlign.left,
                          style: const TextStyle(
                            fontFamily: 'Roboto Slab',
                            fontSize: 10,
                            color: Color(0xff002E5B),
                          ),
                        ),
                      ),
                    ),
                  ]),
                ]),
          ),
        ],
      ),
    );
  }
}
