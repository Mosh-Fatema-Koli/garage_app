

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:instasure/Utilities/homeMenu.dart';
import 'package:instasure/domains/models/dashboard/diagnosisReportList.dart';
import 'package:instasure/domains/models/menuItesmListModel.dart';
import 'package:instasure/domains/repo/apiAuthClient.dart';
import 'package:instasure/screens/dashboard/diagnosisReportDetail.dart';
import 'package:instasure/screens/deviceInsurance/claimRequests.dart';
import 'package:instasure/screens/deviceInsurance/deviceInsuranceClaimHistory.dart';
import 'package:instasure/screens/deviceInsurance/deviceInsuranceHistory.dart';
import 'package:instasure/screens/diagonostic/checkDeviceFeature.dart';
import 'package:instasure/widgets/topView4.dart';
import 'package:shared_preferences/shared_preferences.dart';

class DeviceSubMenu extends StatefulWidget {
  const DeviceSubMenu({Key? key}) : super(key: key);

  @override
  State<DeviceSubMenu> createState() => _DeviceSubMenuState();
}

class _DeviceSubMenuState extends State<DeviceSubMenu> {

  SharedPreferences? preferences;
  final ApiAuthClient _apiClient = ApiAuthClient();
  bool _isShown = true;

  List<Menu> data = [];
  @override
  void initState() {
    super.initState();

    initializePreference().whenComplete((){
      setState(() {
//        this.preferences?.setInt("counter", 7);
//        this.preferences?.setString("serial_number", "zxcxzv");
      });
    });


    dataList.forEach((element) {
      data.add(Menu.fromJson(element));
    });
    //Navigator.of(context).popUntil((route) => route.isFirst);
  }


  Future<void> initializePreference() async{
    this.preferences = await SharedPreferences.getInstance();
    // this.preferences?.setString("name", "Peter");
  }

  void _diagnosisAlert(BuildContext context) {
    showDialog(
        context: context,
        builder: (context) {
          return CupertinoAlertDialog(
            title: const Text('Device Diagnosis'),
            content: const Text('Are you sure you want to device diagnosis? If yes, then please attach microphone with your device.'),
            actions: <Widget>[
              TextButton(
                  onPressed: () {
                    Navigator.pop(context);
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const CheckDeviceFeature()),
                    );
                  },
                  child: Text('Yes')),
              TextButton(
                onPressed: () {
                  Navigator.pop(context); //close Dialog
                },
                child: Text('No'),
              )
            ],
          );
        });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: null,
        backgroundColor: const Color(0xFFEFF7FF),
        body: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(5),
              child: Column(
                children: <Widget>[
                  Stack(
                    children: [
                      const TopView4(),
                      Positioned(
                        bottom: 20.0,
                        left: 40.0,
                        child: SizedBox(
                            height: 30,
                            width: 30,
                            // color: const Color.fromRGBO(0, 46, 91, 1.0),
                            // padding: const EdgeInsets.fromLTRB(10, 15, 10, 5),
                            child: TextButton(
                              child: Image.asset('assets/back_button_icon.png'),
                              onPressed: () {
                                Navigator.of(context).pop();
                              },
                            )),
                      )
                    ],
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Container(
                      height: 50,
                      alignment: Alignment.center,
                      child: Text("Device Insurance"
                        ,
                        style: const TextStyle(
                            fontSize: 16, color: Color.fromRGBO(0, 0, 0, 0.87)),
                      ),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(0),
                        boxShadow: const [
                          BoxShadow(
                              color: Color(0xFFFFFFFF),
                              blurRadius: 6,
                              spreadRadius: 0,
                              offset: Offset(-3, -3)),
                          BoxShadow(
                              color: Color(0xFFDDE4EF),
                              blurRadius: 6,
                              spreadRadius: 0,
                              offset: Offset(3, 3)),
                        ],
                        color: const Color(0xffF0F3F6),
                      )),
                  const SizedBox(
                    height: 50,
                  ),
                  Row(
                    children: [
                      Expanded(
                        flex: 1,

                        child: Padding(
                          padding: const EdgeInsets.all(5),
                          child: GestureDetector(
                            onTap: () {
                              print("Test");

                              //this.preferences.getBool(Constant().IS_TESTING)
                              if(this.preferences?.getString("serial_number")==''){
                                print(1);
                              }
                              else if(this.preferences?.getString("serial_number")==null){
                                _diagnosisAlert(context);

                              }else if(this.preferences?.getString("serial_number")!=null){
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => DiagnosisReportDetail(
                                        id: "${this.preferences?.getString("serial_number")}",
                                      )),
                                );
                              }else if(this.preferences?.getString("serial_number")!=''){
                                print(4);
                              }else{
                                print(5);
                              }
                            },
                            child: Container(
                              //width: (MediaQuery.of(context).size.width - 45) / 3,
                                alignment: Alignment.center,
                                child: GestureDetector(
                                  onTap: () {
                                    print("Test");

                                    //this.preferences.getBool(Constant().IS_TESTING)
                                    if(this.preferences?.getString("serial_number")==''){
                                      print(1);
                                    }
                                    else if(this.preferences?.getString("serial_number")==null){
                                      _diagnosisAlert(context);

                                    }else if(this.preferences?.getString("serial_number")!=null){
                                      Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) => DiagnosisReportDetail(
                                              id: "${this.preferences?.getString("serial_number")}",
                                            )),
                                      );
                                    }else if(this.preferences?.getString("serial_number")!=''){
                                      print(4);
                                    }else{
                                      print(5);
                                    }
                                  },
                                  child: Padding(
                                    padding: const EdgeInsets.only(
                                        left: 6, right: 4, top: 6, bottom: 2),
                                    child: Column(
                                      children: [
                                        const SizedBox(
                                          height: 10,
                                        ),
                                        Image(
                                          image: AssetImage("assets/buy_now.png"),
                                          height: 60,
                                        ),

                                        const SizedBox(
                                          height: 10,
                                        ),
                                        Text("Buy Insurance",
                                          textAlign: TextAlign.center,
                                          style: const TextStyle(
                                            fontFamily: 'Roboto Slab',
                                            fontSize: 12,
                                            fontWeight: FontWeight.bold,
                                            color: Color(0xff000000),
                                          ),
                                        ),
                                        const SizedBox(
                                          height: 20,
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(40),
                                  border: Border.all(
                                      color: const Color(0xffF0F3F6), width: 6),
                                  boxShadow: const [
                                    BoxShadow(
                                        color: Color(0xFFFFFFFF),
                                        blurRadius: 6,
                                        spreadRadius: 0,
                                        offset: Offset(-3, -3)),
                                  ],
                                  color: const Color(0xFFffffff),
                                )),
                          ),
                        ),
                      ),
                      Expanded(
                        flex: 1,
                        child: Padding(
                          padding: const EdgeInsets.all(5),
                          child: GestureDetector(
                            onTap:() {
                              print("Test");
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => const DiagnosisReportList()),
                              );
                            } ,


                            child: Container(
                              //width: (MediaQuery.of(context).size.width - 45) / 3,
                                alignment: Alignment.center,
                                child: GestureDetector(
                                  onTap: () {
                                    print("Test");
                                     Navigator.push(
                                       context,
                                      MaterialPageRoute(
                                           builder: (context) => const DiagnosisReportList()),
                                     );
                                  },
                                  child: Padding(
                                    padding: const EdgeInsets.only(
                                        left: 6, right: 4, top: 6, bottom: 2),
                                    child: Column(
                                      children: [
                                        const SizedBox(
                                          height: 10,
                                        ),
                                        Image(
                                          image: AssetImage("assets/1055644.png"),
                                          height: 60,
                                        ),

                                        const SizedBox(
                                          height: 10,
                                        ),
                                        Text("Diagnosis Report List",
                                          textAlign: TextAlign.center,
                                          style: const TextStyle(
                                            fontFamily: 'Roboto Slab',
                                            fontSize: 12,
                                            fontWeight: FontWeight.bold,
                                            color: Color(0xff000000),
                                          ),
                                        ),
                                        const SizedBox(
                                          height: 20,
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(40),
                                  border: Border.all(
                                      color: const Color(0xffF0F3F6), width: 6),
                                  boxShadow: const [
                                    BoxShadow(
                                        color: Color(0xFFFFFFFF),
                                        blurRadius: 6,
                                        spreadRadius: 0,
                                        offset: Offset(-3, -3)),
                                  ],
                                  color: const Color(0xFFffffff),
                                )),
                          ),
                        ),
                      ),

                    ],
                  ),

                  Row(
                    children: [
                      Expanded(
                        flex: 1,

                        child: Padding(
                          padding: const EdgeInsets.all(5),
                          child: GestureDetector(
                            onTap: () {
                              print("Test");
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => const DeviceInsuranceHistory()),
                              );
                            },
                            child: Container(
                              //width: (MediaQuery.of(context).size.width - 45) / 3,
                                alignment: Alignment.center,
                                child: GestureDetector(
                                  onTap: () {
                                    print("Test");
                                     Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => const DeviceInsuranceHistory()),
                                    );
                                  },
                                  child: Padding(
                                    padding: const EdgeInsets.only(
                                        left: 6, right: 4, top: 6, bottom: 2),
                                    child: Column(
                                      children: [
                                        const SizedBox(
                                          height: 10,
                                        ),
                                        Image(
                                          image: AssetImage("assets/purchase.png"),
                                          height: 60,
                                        ),

                                        const SizedBox(
                                          height: 10,
                                        ),
                                        Text("Purchase History",
                                          textAlign: TextAlign.center,
                                          style: const TextStyle(
                                            fontFamily: 'Roboto Slab',
                                            fontSize: 12,
                                            fontWeight: FontWeight.bold,
                                            color: Color(0xff000000),
                                          ),
                                        ),
                                        const SizedBox(
                                          height: 20,
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(40),
                                  border: Border.all(
                                      color: const Color(0xffF0F3F6), width: 6),
                                  boxShadow: const [
                                    BoxShadow(
                                        color: Color(0xFFFFFFFF),
                                        blurRadius: 6,
                                        spreadRadius: 0,
                                        offset: Offset(-3, -3)),
                                  ],
                                  color: const Color(0xFFffffff),
                                )),
                          ),
                        ),
                      ),
                      Expanded(
                        flex: 1,
                        child: Padding(
                          padding: const EdgeInsets.all(5),
                          child: GestureDetector(
                            onTap: () {
                              print("Test");
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => ClaimRequests()),
                              );
                            },
                            child: Container(
                              //width: (MediaQuery.of(context).size.width - 45) / 3,
                                alignment: Alignment.center,
                                child: GestureDetector(
                                  onTap: () {
                                    print("Test");
                                     Navigator.push(
                                      context,
                                       MaterialPageRoute(
                                         builder: (context) => ClaimRequests()),
                                     );
                                  },
                                  child: Padding(
                                    padding: const EdgeInsets.only(
                                        left: 6, right: 4, top: 6, bottom: 2),
                                    child: Column(
                                      children: [
                                        const SizedBox(
                                          height: 10,
                                        ),
                                        Image(
                                          image: AssetImage("assets/support.png"),
                                          height: 60,
                                        ),

                                        const SizedBox(
                                          height: 10,
                                        ),
                                        Text("Support Status",
                                          textAlign: TextAlign.center,
                                          style: const TextStyle(
                                            fontFamily: 'Roboto Slab',
                                            fontSize: 12,
                                            fontWeight: FontWeight.bold,
                                            color: Color(0xff000000),
                                          ),
                                        ),
                                        const SizedBox(
                                          height: 20,
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(40),
                                  border: Border.all(
                                      color: const Color(0xffF0F3F6), width: 6),
                                  boxShadow: const [
                                    BoxShadow(
                                        color: Color(0xFFFFFFFF),
                                        blurRadius: 6,
                                        spreadRadius: 0,
                                        offset: Offset(-3, -3)),
                                  ],
                                  color: const Color(0xFFffffff),
                                )),
                          ),
                        ),
                      ),

                    ],
                  ),

                  Padding(
                    padding: const EdgeInsets.all(5),
                    child: GestureDetector(
                      onTap: () {
                        print("Test");
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => const DeviceInsuranceClaimHistory()),
                        );
                      },
                      child: Container(
                        width: (MediaQuery.of(context).size.width - 45) / 2,
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(40),
                            border: Border.all(
                                color: const Color(0xffF0F3F6), width: 6),
                            boxShadow: const [
                              BoxShadow(
                                  color: Color(0xFFFFFFFF),
                                  blurRadius: 6,
                                  spreadRadius: 0,
                                  offset: Offset(-3, -3)),
                            ],
                            color: const Color(0xFFffffff),
                          ),
                          child: GestureDetector(
                            onTap: () {
                              print("Test");
                               Navigator.push(
                                 context,
                                MaterialPageRoute(
                                    builder: (context) => const DeviceInsuranceClaimHistory()),
                               );
                            },
                            child: Padding(
                              padding: const EdgeInsets.only(
                                  left: 6, right: 4, top: 6, bottom: 2),
                              child: Column(
                                children: [
                                  const SizedBox(
                                    height: 10,
                                  ),
                                  Image(
                                    image: AssetImage("assets/report.png"),
                                    height: 60,
                                  ),

                                  const SizedBox(
                                    height: 10,
                                  ),
                                  Text("Claim History",
                                    textAlign: TextAlign.center,
                                    style: const TextStyle(
                                      fontFamily: 'Roboto Slab',
                                      fontSize: 12,
                                      fontWeight: FontWeight.bold,
                                      color: Color(0xff000000),
                                    ),
                                  ),
                                  const SizedBox(
                                    height: 20,
                                  ),
                                ],
                              ),
                            ),
                          )),
                    ),
                  ),
                ],
              ),
            )));
  }

}
