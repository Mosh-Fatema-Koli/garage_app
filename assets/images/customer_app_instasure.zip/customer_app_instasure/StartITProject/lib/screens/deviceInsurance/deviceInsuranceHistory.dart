// ignore_for_file: unnecessary_new

import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:instasure/Utilities/userPref.dart';
import 'package:instasure/domains/models/deviceInsurance/deviceHistoryModel.dart';
import 'package:instasure/domains/repo/apiClientDeviceInsurance.dart';
import 'package:instasure/screens/deviceInsurance/deviceInsuranceHistDetail.dart';
import 'package:instasure/Utilities/helper.dart';
import 'package:instasure/widgets/topView4.dart';

import '../../Utilities/ShowMessage.dart';

class DeviceInsuranceHistory extends StatefulWidget {
  const DeviceInsuranceHistory({Key? key}) : super(key: key);

  @override
  _DeviceInsuranceHistoryState createState() => _DeviceInsuranceHistoryState();
}

class _DeviceInsuranceHistoryState extends State<DeviceInsuranceHistory> {
  final ApiClientDeviceInsurance _apiClient = ApiClientDeviceInsurance();
  List<DeviceHistoryModel> _insuranceHistories = [];

  var loading = true;

  @override
  void initState() {
    super.initState();
    () async {
      await Future.delayed(Duration.zero);
      getInsuranceHistoryData();
    }();
  }

  Future<void> getInsuranceHistoryData() async {
    UserPref prefs = UserPref();
    Future<String?> token = prefs.getTokenFromPref();
    String? accessToken = await token;
    EasyLoading.instance.userInteractions = false;
    EasyLoading.show(status: 'Processing...');
    dynamic res = await _apiClient.getDeviceInsuranceHistData(accessToken!);
    EasyLoading.dismiss();
    //ScaffoldMessenger.of(context).hideCurrentSnackBar();
    if (res.statusCode == 200) {
      if (res.data['code'] == 200) {
        List jsonList = res.data['data']['data'] as List;
        List<DeviceHistoryModel> histories = jsonList
            .map((jsonElement) => DeviceHistoryModel.fromJson(jsonElement))
            .toList();

        setState(() {
          _insuranceHistories = histories;
          if(_insuranceHistories.length ==0){
            ShowMessage.showMessage("No device history found.");
          }
          loading = false;
        });
      } else {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('${res.data['message']}'),
          backgroundColor: Colors.red.shade300,
        ));
        setState(() {
          loading = false;
        });
      }
    } else {
      setState(() {
        loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: loading
          ? const Center(
              child: Text(""),
            )
          : Center(
              child: Padding(
              padding: const EdgeInsets.all(0),
              child: Column(
                children: [
                  Stack(
                    children: [
                      const TopView4(),
                      Positioned(
                        bottom: 20.0,
                        left: 40.0,
                        child: SizedBox(
                            height: 30,
                            width: 30,
                            // color: const Color.fromRGBO(0, 46, 91, 1.0),
                            // padding: const EdgeInsets.fromLTRB(10, 15, 10, 5),
                            child: TextButton(
                              child: Image.asset('assets/back_button_icon.png'),
                              onPressed: () {
                                Navigator.of(context).pop();
                              },
                            )),
                      )
                    ],
                  ),
                  const SizedBox(height: 10.0),
                  createHeader(),
                  // const SizedBox(height: 20.0),
                  // creatSearchBar(),
                  const SizedBox(height: 20.0),
                  Expanded(
                    child: ListView(
                      children: <Widget>[buildListView()],
                    ),
                  ),
                  const SizedBox(height: 80.0),
                ],
              ),
            )),
      backgroundColor: const Color(0xFFEFF7FF),
    );
  }

  createHeader() {
    return Container(
      height: 38,
      child: const Center(
        child: Text(
          'Device Insurance History',
          textAlign: TextAlign.center,
          style: TextStyle(
            fontFamily: 'Roboto Slab',
            fontSize: 16,
            color: Color(0xff002E5B),
          ),
        ),
      ),
      decoration: const BoxDecoration(color: Color(0xffF0F3F6), boxShadow: [
        BoxShadow(
            color: Color(0xffffffff),
            blurRadius: 6,
            spreadRadius: 0,
            offset: Offset(-3, -3)),
        BoxShadow(
            color: Color(0xffDDE4EF),
            blurRadius: 6,
            spreadRadius: 0,
            offset: Offset(3, 3)),
      ]),
    );
  }

  creatSearchBar() {
    return Padding(
        padding: const EdgeInsets.only(right: 30, top: 0, bottom: 0, left: 30),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const SizedBox(
              width: 10,
            ),
            GestureDetector(
              onTap: () {
                print("Test");
                // Navigator.push(
                //   context,
                //   MaterialPageRoute(
                //       builder: (context) => SecondRoute(
                //             title: vehicles[index],
                //             subTitle: 'test',
                //           )),
                // );
              },
              child: Container(
                height: 22,
                padding: const EdgeInsets.only(left: 5, right: 5),
                child: Row(
                  children: const [
                    Text(
                      'Search',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontFamily: 'Roboto Slab',
                        fontSize: 16,
                        color: Color(0xff002E5B),
                      ),
                    ),
                    SizedBox(
                      width: 5,
                    ),
                    Icon(Icons.search),
                  ],
                ),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(15),
                    boxShadow: const [
                      BoxShadow(
                          color: Color(0xFFFFFFFF),
                          blurRadius: 6,
                          spreadRadius: 0,
                          offset: Offset(-3, -3)),
                      BoxShadow(
                          color: Color(0xFFFFFFFF),
                          blurRadius: 6,
                          spreadRadius: 0,
                          offset: Offset(3, 3)),
                    ],
                    color: const Color(0xFFF0F3F6)),
              ),
            ),
          ],
        ));
  }

  buildListView() {
    return ListView.separated(
        primary: false,
        scrollDirection: Axis.vertical,
        shrinkWrap: true,
        itemCount: _insuranceHistories.length,
        itemBuilder: (BuildContext context, int index) {
          DeviceHistoryModel insuranceHistoryModel = _insuranceHistories[index];
          return Padding(
              padding: const EdgeInsets.only(
                  right: 14, top: 10, bottom: 10, left: 14),
              child: Container(
                  // padding: const EdgeInsets.all(10.0),
                  //width: (MediaQuery.of(context).size.width - 45) / 3,
                  height: 108,
                  alignment: Alignment.center,
                  // padding: const EdgeInsets.only(top: 20),
                  child: GestureDetector(
                    onTap: () {
                      print("Test");
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) =>
                                DeviceInsuranceHistoryDetails(
                                  id: "${insuranceHistoryModel.id}",
                                )),
                      );
                    },
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        const SizedBox(height: 10.0),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(
                              children: [
                                const SizedBox(width: 35.0),
                                Image.asset('assets/profile/calendar_icon.png'),
                                const SizedBox(width: 10.0),
                                Text(
                                  getDateString(
                                      insuranceHistoryModel.createdAt ?? " ",
                                      'dd MMM yyyy'),
                                  textAlign: TextAlign.left,
                                  style: const TextStyle(
                                    fontFamily: 'Roboto Slab',
                                    fontSize: 14,
                                    color: Color(0xff000000),
                                  ),
                                ),
                              ],
                            ),
                            Padding(
                              padding: const EdgeInsets.only(right: 20),
                              child: Container(
                                height: 22,
                                width: 55,
                                child: Center(
                                  child: Text(
                                    insuranceHistoryModel.paymentStatus ?? " ",
                                    textAlign: TextAlign.left,
                                    style: TextStyle(
                                      fontFamily: 'Roboto Slab',
                                      fontWeight: FontWeight.normal,
                                      fontSize: 15,
                                      color: getColorFromStatus(
                                          insuranceHistoryModel.paymentStatus ??
                                              " "),
                                    ),
                                  ),
                                ),
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(11),
                                    boxShadow: const [
                                      BoxShadow(
                                          color: Color(0xFFFFFFFF),
                                          blurRadius: 6,
                                          spreadRadius: 0,
                                          offset: Offset(-3, -3)),
                                    ],
                                    color: const Color(0xFFF0F3F6)),
                              ),
                            )
                          ],
                        ),
                        const SizedBox(height: 10.0),
                        Row(
                          children: [
                            const SizedBox(width: 35.0),
                            Expanded(
                              child: Text(
                                insuranceHistoryModel.deviceInfo?.modelName ??
                                    " ",
                                textAlign: TextAlign.left,
                                style: const TextStyle(
                                  fontFamily: 'Roboto Slab',
                                  fontSize: 14,
                                  color: Color(0xff000000),
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 10.0),
                        Row(
                          children: [
                            const SizedBox(width: 25.0),
                            SizedBox(
                              height: 30,
                              child: TextButton(
                                onPressed: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) =>
                                            DeviceInsuranceHistoryDetails(
                                              id: "${insuranceHistoryModel.id}",
                                            )),
                                  );
                                },
                                child: const Text(
                                  'View Details',
                                  textAlign: TextAlign.left,
                                  style: TextStyle(
                                    fontFamily: 'Roboto Slab',
                                    fontSize: 15,
                                    color: Color(0xff2969E9),
                                  ),
                                ),
                              ),
                            )
                          ],
                        ),
                      ],
                    ),
                  ),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(40),
                    boxShadow: const [
                      BoxShadow(
                          color: Color(0xFFFFFFFF),
                          blurRadius: 6,
                          spreadRadius: 0,
                          offset: Offset(-3, -3)),
                    ],
                    color: const Color(0xFFF0F3F6),
                  )));

          // );
        },
        separatorBuilder: (context, index) => const SizedBox(
              height: 8,
            ));
  }
}
