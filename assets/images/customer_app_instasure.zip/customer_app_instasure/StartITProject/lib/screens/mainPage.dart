// ignore_for_file: unnecessary_new

import 'package:flutter/material.dart';
import 'package:instasure/screens/tabMenu/homePage.dart';
import 'package:instasure/screens/tabMenu/howToClaim.dart';
import 'package:instasure/screens/tabMenu/myInsurance.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:onesignal_flutter/onesignal_flutter.dart';
import 'tabMenu/menuScreen.dart';

import 'package:flutter/cupertino.dart'
    hide CupertinoTabBar, CupertinoTabScaffold;

class MainPage extends StatefulWidget {
  const MainPage({Key? key}) : super(key: key);

  @override
  _MainPageState createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {


  int _currentIndex = 0;
  late List<Widget> _children;
int show_appbar=1;
  SharedPreferences? preferences;
  @override
  void initState() {

    _currentIndex = 0;
    _children = [
      const HomePage(),
      const MyInsurance(),
      const HowToClaim(),
      const MenuScreen(),
    ];
    super.initState();

    initializePreference().whenComplete((){
      setState(() {

       // this.preferences?.setInt("counter", 7);

      });

    });

    initPlatfrrmState();

  }


  final String oneSignalAppId= "15a2ad08-7c50-42b9-9f11-9e4f6772af6b";

  Future <void> initPlatfrrmState()async {
    OneSignal.shared.setAppId(oneSignalAppId);
  }


  Future<void> initializePreference() async{
    this.preferences = await SharedPreferences.getInstance();

    /*if(this.preferences?.getString("serial_number")==null){
      this.preferences?.setString("serial_number", "Peter");
    }*/

    print('kkk');
    print(this.preferences?.getString("serial_number"));
  }

  List pages = [
    const HomePage(),
    const MyInsurance(),
    const HowToClaim(),
    const MenuScreen(),
  ];

  @override

  Widget build(BuildContext context) {
   if(show_appbar==0){
    return MaterialApp(
      home: Scaffold(
        bottomNavigationBar: showBottomNav(),//AppBar
        body: pages.elementAt(_currentIndex),
      ), //Scaffold
      debugShowCheckedModeBanner: false, //Removing Debug Banner
    );
  }else{
     return MaterialApp(
       home: Scaffold(


         appBar: AppBar(
           // title: const Text('Home'),
           title: Image.asset('assets/instasure_icon.png',fit: BoxFit.contain,
             height: 32,),

           backgroundColor: Colors.white,
           actions: <Widget>[
             IconButton(
               // AssetImage("assets/home/insurance.png"),
               icon: Icon(
                 Icons.live_help,
                 color: const Color(0xff002E5B),
               ),
               /*icon: Icon(
                Icons.settings,
                color: Colors.white,
              ),*/
               onPressed: () {
                 setState(() {
                   _currentIndex = 2;
                 });
                /* Navigator.push(
                   context,
                   MaterialPageRoute(builder: (context) => const  MenuScreen()),
                 );*/

               },
             )
           ],
         ),





         bottomNavigationBar: showBottomNav(),//AppBar
         body: pages.elementAt(_currentIndex),
       ), //Scaffold
       debugShowCheckedModeBanner: false, //Removing Debug Banner
     );
   }
}




    /*return Scaffold(


        appBar: AppBar(
          title: const Text('Test Bar'),
        ), //AppBar
        body:  pages.elementAt(_currentIndex),*/





      /*   //   bottomNavigationBar: showBottomNav(),
       body: WillPopScope(
        onWillPop: _onBackPress,
        body: Navigator(
          onGenerateRoute: (settings) {
            // Widget page = pages.elementAt(_selectedIndex);
            // if (settings.name == 'page2') page = Page2();
            print(_currentIndex);
            return MaterialPageRoute(
                builder: (_) => pages.elementAt(_currentIndex));
          },
        ),
      //  body: pages.elementAt(_currentIndex)
        //),
        ),
    debugShowCheckedModeBanner: false,

  };*/

  void onTabTapped(int index) {
    setState(() {
      _currentIndex = index;
    });
  }

  void _onItemTapped(int index) {
    setState(() {
      _currentIndex = index;
    });
  }

  Widget showBottomNav() {
    return Container(
      decoration: const BoxDecoration(
        borderRadius: BorderRadius.only(
            topRight: Radius.circular(30), topLeft: Radius.circular(30)),
        boxShadow: [
          BoxShadow(color: Colors.black38, spreadRadius: 0, blurRadius: 10),
        ],
      ),
      child: ClipRRect(
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(30.0),
          topRight: Radius.circular(30.0),
        ),
        child: BottomNavigationBar(
          backgroundColor: const Color(0xff002E5B),
          // backgroundColor: Colors.black,
          type: BottomNavigationBarType.fixed,
          iconSize: 25,
          showSelectedLabels: true,
          showUnselectedLabels: true,
          selectedFontSize: 12,
          selectedIconTheme: const IconThemeData(color: Colors.green, size: 25),
          selectedItemColor: Colors.green,
          selectedLabelStyle: const TextStyle(fontWeight: FontWeight.bold),
          unselectedIconTheme: const IconThemeData(
            color: Colors.white,
          ),
          unselectedItemColor: Colors.white,
          //mouseCursor: SystemMouseCursors.grab,
          currentIndex: _currentIndex,
          onTap: _onItemTapped,
          items: const <BottomNavigationBarItem>[
            BottomNavigationBarItem(
              icon: Icon(
                Icons.home,
                color: Color(0xFFffffff),
              ),
              label: 'Home',
            ),
            BottomNavigationBarItem(
              icon: ImageIcon(
                AssetImage("assets/home/insurance.png"),
                color: Color(0xFFffffff),
              ),
              label: 'My Insurance',
            ),
            BottomNavigationBarItem(
              icon: ImageIcon(
                AssetImage("assets/home/claim.png"),
                color: Color(0xFFffffff),
              ),
              label: 'Claim',
            ),
            BottomNavigationBarItem(
              icon: Icon(
                Icons.menu,
                color: Color(0xFFffffff),
              ),
              label: 'Menu',
            ),
          ],
        ),
      ),
    );
  }
}
