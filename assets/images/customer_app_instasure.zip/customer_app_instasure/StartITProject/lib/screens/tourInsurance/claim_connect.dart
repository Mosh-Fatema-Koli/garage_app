
import 'package:flutter/material.dart';
import 'package:instasure/screens/mainPage.dart';

class ConnectClaim extends StatefulWidget {
  const ConnectClaim({Key? key}) : super(key: key);

  @override
  State<ConnectClaim> createState() => _ConnectClaimState();
}

class _ConnectClaimState extends State<ConnectClaim> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(
        // title: const Text('Home'),

        // title: Text("YOUR_APPBAR_TITLE"),
        // automaticallyImplyLeading: false,


        title: Image.asset(
          'assets/instasure_icon.png', fit: BoxFit.contain, height: 32,),

        leading: new IconButton(
          icon: new Icon(Icons.arrow_back, color: const Color(0xff002E5B),),
          onPressed: () =>
              Navigator.push(
                context, MaterialPageRoute(builder: (context) => MainPage()),),
        ),


        automaticallyImplyLeading: true,
        backgroundColor: Colors.white,
        actions: <Widget>[
          IconButton(
            // AssetImage("assets/home/insurance.png"),
            icon: Icon(
              Icons.help_center,
              color: const Color(0xff002E5B),
            ),
            onPressed: () {
              setState(() {

              });
              /* Navigator.push(
                   context,
                   MaterialPageRoute(builder: (context) => const  MenuScreen()),
                 );*/

            },
          )
        ],
      ),


      body: Center(
          child: Padding(
            padding: const EdgeInsets.all(0),
            child: Column(
              children: [
                Stack(
                  children: [

                    Container(
                      child: Column(

                      ),
                    ),

                    //const TopView4(),
                    Positioned(
                      bottom: 20.0,
                      left: 40.0,
                      child: SizedBox(
                          height: 30,
                          width: 30,
                          child: TextButton(
                            child: Image.asset('assets/back_button_icon.png'),
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                          )),
                    )
                  ],
                ),
                SizedBox(
                  height: 20,
                ),
                createHeader(),
                SizedBox(
                  height: 20,
                ),
                Container(
                  height: 500,
                    child: Center(child: Text("Please Contact Your Tour Coordinator ",style: TextStyle(fontSize: 14,fontWeight: FontWeight.bold),))),



              ],
            ),
          )),
      backgroundColor: const Color(0xFFEFF7FF),

    );
  }

  createHeader() {
    return Container(
      height: 38,
      child: const Center(
        child: Text(
          'Claim For Tour',
          textAlign: TextAlign.center,
          style: TextStyle(
            fontFamily: 'Roboto Slab',
            fontSize: 16,
            color: Color(0xff002E5B),
          ),
        ),
      ),
      decoration: const BoxDecoration(color: Color(0xffF0F3F6), boxShadow: [
        BoxShadow(
            color: Color(0xffffffff),
            blurRadius: 6,
            spreadRadius: 0,
            offset: Offset(-3, -3)),
        BoxShadow(
            color: Color(0xffDDE4EF),
            blurRadius: 6,
            spreadRadius: 0,
            offset: Offset(3, 3)),
      ]),
    );
  }

}
