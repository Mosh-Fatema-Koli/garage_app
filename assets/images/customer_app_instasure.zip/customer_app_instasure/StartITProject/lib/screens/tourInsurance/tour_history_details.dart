import 'package:flutter/material.dart';
import 'package:instasure/domains/models/tourInsurance/tour_insurance_model.dart';
import 'package:instasure/screens/mainPage.dart';
import 'package:instasure/screens/tourInsurance/claim_connect.dart';



class TourHistoryDetails extends StatefulWidget {
  TourHistoryDetails({Key? key, required this.tourDtls ,}) : super(key: key);

final String tourDtls;

  @override

  State<TourHistoryDetails> createState() => _TourHistoryDetailsState();
}

class _TourHistoryDetailsState extends State<TourHistoryDetails> {

  late final TourModel tour;


  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(
        title: Image.asset(
          'assets/instasure_icon.png', fit: BoxFit.contain, height: 32,),

        leading: new IconButton(
          icon: new Icon(Icons.arrow_back, color: const Color(0xff002E5B),),
          onPressed: () =>
              Navigator.push(
                context, MaterialPageRoute(builder: (context) => MainPage()),),
        ),


        automaticallyImplyLeading: true,
        backgroundColor: Colors.white,
        actions: <Widget>[
          IconButton(
            icon: Icon(
              Icons.help_center,
              color: const Color(0xff002E5B),
            ),
            onPressed: () {
              setState(() {

              });
            },
          )
        ],
      ),


      body: Center(
          child: Padding(
            padding: const EdgeInsets.all(0),
            child: Column(
              children: [
                Stack(
                  children: [

                    Container(
                      child: Column(

                      ),
                    ),

                    //const TopView4(),
                    Positioned(
                      bottom: 20.0,
                      left: 40.0,
                      child: SizedBox(
                          height: 30,
                          width: 30,
                          child: TextButton(
                            child: Image.asset('assets/back_button_icon.png'),
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                          )),
                    )
                  ],
                ),
                SizedBox(
                  height: 20,
                ),
                createHeader(),
                SizedBox(
                  height: 20,
                ),
                Padding(
                  padding: const EdgeInsets.all(20),
                  child: Container(

                  width: MediaQuery.of(context).size.width,
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      children: [
                        Text("tour.name",style: TextStyle(fontSize: 18,fontWeight: FontWeight.bold),),
                        SizedBox(
                          height: 20,
                        ),
                        Row(

                          children: [
                            Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [


                                Text("Route :"),
                                SizedBox(
                                  height: 5,
                                ),
                                Text("Starting Date & Time :"),
                                SizedBox(
                                  height: 3,
                                ),
                                Text("End Date & Time :"),
                                SizedBox(
                                  height: 3,
                                ),
                                Text("Transport :"),
                                SizedBox(
                                  height: 3,
                                ),
                                Text("Total Tourist :"),
                                SizedBox(
                                  height: 3,
                                ),
                                Text("Stay in Hotel :"),
                                SizedBox(
                                  height: 3,
                                ),
                                Text("Departure Location :"),
                                SizedBox(
                                  height: 3,
                                ),
                                Text("Application Date :"),
                                SizedBox(
                                  height: 3,
                                ),
                                Text("policy Id :"),
                                SizedBox(
                                  height: 3,
                                ),
                                Text("Coordinator Name :"),
                                SizedBox(
                                  height: 3,
                                ),
                                Text("Coordinator Number : "),
                                SizedBox(
                                  height: 5,
                                ),
                                Text("Tour Status : "),


                              ],
                            ),
                            SizedBox(width: 5,),
                            Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: const [



                                SizedBox(
                                    height: 20,
                                    child: Text("tour.name")),
                                SizedBox(
                                  height: 5,
                                ),
                                Text("27-02-2023 | 45:30:45 PM"),
                                SizedBox(
                                  height: 3,
                                ),
                                Text("29-02-2023 | 45:30:45 PM"),
                                SizedBox(
                                  height: 3,
                                ),
                                Text("Bus"),
                                SizedBox(
                                  height: 3,
                                ),
                                Text("20"),
                                SizedBox(
                                  height: 3,
                                ),
                                Text("XXXXXX Hotel Coxbazar"),
                                SizedBox(
                                  height: 3,
                                ),
                                Text("Departure Location"),
                                SizedBox(
                                  height: 3,
                                ),
                                Text("Application Date"),
                                SizedBox(
                                  height: 3,
                                ),
                                Text("policy Id"),
                                SizedBox(
                                  height: 3,
                                ),
                                Text("Cordinator Name"),
                                SizedBox(
                                  height: 3,
                                ),
                                Text("01302607702"),
                                SizedBox(
                                  height: 5,
                                ),
                                Text("Expired "),

                              ],
                            ),
                          ],
                        ),
                        SizedBox(
                          height: 10,
                        ),
                      ],
                    ),
                  ),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: const Color(0xFFF0F3F6),
                    boxShadow: [
                      BoxShadow(
                          color: const Color(0xff000000).withOpacity(0.16),
                          blurRadius: 3,
                          spreadRadius: 0,
                          offset: const Offset(0, 3)),
                    ],
                  ),

                  ),
                ),
                Container(
                  height: 38,
                  width: 100,
                  child: TextButton(
                    child: const Text(
                      'Claim',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontFamily: 'Roboto Slab',
                        fontSize: 12,
                        color: Colors.white,
                      ),
                    ),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const ConnectClaim()),
                      );

                    },
                  ),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    boxShadow: [
                      BoxShadow(
                          color: const Color(0xff000000).withOpacity(0.16),
                          blurRadius: 3,
                          spreadRadius: 0,
                          offset: const Offset(0, 3)),
                    ],
                    color: const Color(0xff002E5B),
                  ),
                ),


              ],
            ),
          )),
      backgroundColor: const Color(0xFFEFF7FF),

    );
  }

  createHeader() {
    return Container(
      height: 38,
      child: const Center(
        child: Text(
          'Tour History Details',
          textAlign: TextAlign.center,
          style: TextStyle(
            fontFamily: 'Roboto Slab',
            fontSize: 16,
            color: Color(0xff002E5B),
          ),
        ),
      ),
      decoration: const BoxDecoration(color: Color(0xffF0F3F6), boxShadow: [
        BoxShadow(
            color: Color(0xffffffff),
            blurRadius: 6,
            spreadRadius: 0,
            offset: Offset(-3, -3)),
        BoxShadow(
            color: Color(0xffDDE4EF),
            blurRadius: 6,
            spreadRadius: 0,
            offset: Offset(3, 3)),
      ]),
    );
  }

}
