import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:instasure/Utilities/userPref.dart';
import 'package:instasure/domains/models/deviceInsurance/devisionModel.dart';
import 'package:instasure/domains/models/deviceInsurance/districtModel.dart';
import 'package:instasure/domains/models/deviceInsurance/upazilaModel.dart';
import 'package:instasure/domains/repo/apiClientDeviceInsurance.dart';
import 'package:instasure/screens/claimProcess/nearestServiceCenter.dart';
import 'package:instasure/widgets/topView4.dart';

class ServiceCenterLocation extends StatefulWidget {
  const ServiceCenterLocation(
      {Key? key, required this.deviceInsuranceId, required this.divisions})
      : super(key: key);
  final String deviceInsuranceId;
  final List<DivisionModel> divisions;

  @override
  _ServiceCenterLocationState createState() => _ServiceCenterLocationState();
}

class _ServiceCenterLocationState extends State<ServiceCenterLocation> {
  final ApiClientDeviceInsurance _apiClient = ApiClientDeviceInsurance();
  List<DistrictModel> districts = [];
  List<UpazilaModel> allUpazila = [];

  String selectedDevision = 'Select';
  String selectedDevisionId = "0";

  String selectedDistrict = '';
  String selectedDistrictId = "0";

  String selectedUpazila = '';
  String selectedUpazilaId = "0";

  Future<void> getDistricts() async {
/*    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: const Text('Processing Data'),
      backgroundColor: Colors.green.shade300,
    ));*/
    EasyLoading.instance.userInteractions = false;
    EasyLoading.show(status: 'Processing...');
    Map<String, dynamic> data = {
      "division_id": selectedDevisionId,
    };
    UserPref prefs = UserPref();
    Future<String?> token = prefs.getTokenFromPref();
    String? accessToken = await token;
    dynamic res = await _apiClient.getDistrictByDivision(data, accessToken!);
    //ScaffoldMessenger.of(context).hideCurrentSnackBar();
    EasyLoading.dismiss();
    if (res.statusCode == 200) {
      // User _user = User.fromJson(res.data['data']['result']);
      List jsonList = res.data as List;

      List<DistrictModel> dist = jsonList
          .map((jsonElement) => DistrictModel.fromJson(jsonElement))
          .toList();
      setState(() {
        selectedDistrict = dist[0].name!;
        selectedDistrictId = "${dist[0].id}";
        districts = dist;
      });
      getAllUpazila();
    } else {}
    // }
  }

  Future<void> getAllUpazila() async {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: const Text('Processing Data'),
      backgroundColor: Colors.green.shade300,
    ));
    Map<String, dynamic> data = {
      "district_id": selectedDistrictId,
    };
    UserPref prefs = UserPref();
    Future<String?> token = prefs.getTokenFromPref();
    String? accessToken = await token;
    dynamic res = await _apiClient.getUpazilaByDistrict(data, accessToken!);
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    if (res.statusCode == 200) {
      // User _user = User.fromJson(res.data['data']['result']);
      List jsonList = res.data as List;

      List<UpazilaModel> upazila = jsonList
          .map((jsonElement) => UpazilaModel.fromJson(jsonElement))
          .toList();
      setState(() {
        selectedUpazila = upazila[0].name!;
        selectedUpazilaId = "${upazila[0].id}";

        allUpazila = upazila;
      });
    } else {}
    // }
  }

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: null,
      backgroundColor: const Color(0xffEFF7FF),
      body: SingleChildScrollView(
          child: Column(
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.only(left: 0, right: 0, top: 0),
            child: Stack(
              children: [
                Stack(
                  children: [
                    const TopView4(),
                    Positioned(
                      bottom: 20.0,
                      left: 40.0,
                      child: SizedBox(
                          height: 30,
                          width: 30,
                          // color: const Color.fromRGBO(0, 46, 91, 1.0),
                          child: TextButton(
                            child: Image.asset('assets/back_button_icon.png'),
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                          )),
                    )
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(
            height: 20,
          ),
          Container(
              height: 38,
              alignment: Alignment.center,
              child: const Text(
                'Service Center Location',
                style: TextStyle(
                    fontSize: 16, color: Color.fromRGBO(0, 0, 0, 0.87)),
              ),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(0),
                boxShadow: const [
                  BoxShadow(
                      color: Color(0xFFFFFFFF),
                      blurRadius: 6,
                      spreadRadius: 0,
                      offset: Offset(-3, -3)),
                  BoxShadow(
                      color: Color(0xFFDDE4EF),
                      blurRadius: 6,
                      spreadRadius: 0,
                      offset: Offset(3, 3)),
                ],
                color: const Color(0xffF0F3F6),
              )),
          const SizedBox(
            height: 30,
          ),
          Container(
              alignment: Alignment.centerLeft,
              padding: const EdgeInsets.only(left: 20),
              child: const Text(
                'Division',
                style: TextStyle(
                    fontSize: 12, color: Color.fromRGBO(0, 46, 91, 1)),
              )),
          const SizedBox(
            height: 10,
          ),
          Padding(
            padding: const EdgeInsets.only(left: 20.0, right: 20, bottom: 20),
            child: Container(
                height: 40,
                alignment: Alignment.center,
                padding: const EdgeInsets.all(10),
                child: DropdownButtonHideUnderline(
                  child: ButtonTheme(
                    alignedDropdown: true,
                    child: DropdownButton(
                      isExpanded: true,
                      value: selectedDevision,
                      icon: const Icon(Icons.keyboard_arrow_down),
                      items: widget.divisions.map((item) {
                        return DropdownMenuItem(
                            value: item.name, child: Text("${item.name}"));
                      }).toList(),
                      onChanged: (newValue) {
                        setState(() {
                          selectedDevision = "$newValue";
                          districts = [];
                          allUpazila = [];
                          selectedDistrict = '';
                          selectedDistrictId = "0";
                          selectedUpazila = '';
                          selectedUpazilaId = "0";

                          if (selectedDevision.compareTo("Select") == 0) {
                          } else {
                            var filteredDiv = widget.divisions
                                .where((x) => x.name == selectedDevision)
                                .toList();
                            selectedDevisionId = "${filteredDiv[0].id}";
                            getDistricts();
                          }
                        });
                      },
                    ),
                  ),
                ),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: const [
                    BoxShadow(
                        color: Color(0xFFFFFFFF),
                        blurRadius: 6,
                        spreadRadius: 0,
                        offset: Offset(-3, -3)),
                    BoxShadow(
                        color: Color(0xFFDDE4EF),
                        blurRadius: 6,
                        spreadRadius: 0,
                        offset: Offset(3, 3)),
                  ],
                  color: const Color(0xffF0F3F6),
                )),
          ),
          Container(
              alignment: Alignment.centerLeft,
              padding: const EdgeInsets.only(left: 20, top: 10),
              child: const Text(
                'District',
                style: TextStyle(
                    fontSize: 12, color: Color.fromRGBO(0, 46, 91, 1)),
              )),
          const SizedBox(
            height: 10,
          ),
          Padding(
            padding: const EdgeInsets.only(left: 20.0, right: 20, bottom: 20),
            child: Container(
                height: 40,
                alignment: Alignment.center,
                padding: const EdgeInsets.all(10),
                child: DropdownButtonHideUnderline(
                  child: ButtonTheme(
                    alignedDropdown: true,
                    child: DropdownButton(
                      isExpanded: true,
                      value: selectedDistrict,
                      icon: const Icon(Icons.keyboard_arrow_down),
                      items: districts.map((item) {
                        return DropdownMenuItem(
                            value: "${item.name}", child: Text("${item.name}"));
                      }).toList(),
                      onChanged: (var newValue) {
                        setState(() {
                          allUpazila = [];
                          selectedUpazila = '';
                          selectedUpazilaId = "0";
                          selectedDistrict = "$newValue";
                          if (selectedDistrict.compareTo("Select") == 0) {
                          } else {
                            var filteredDistricts = districts
                                .where((x) => x.name == selectedDistrict)
                                .toList();
                            selectedDistrictId = "${filteredDistricts[0].id}";
                            getAllUpazila();
                          }
                        });
                      },
                    ),
                  ),
                ),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: const [
                    BoxShadow(
                        color: Color(0xFFFFFFFF),
                        blurRadius: 6,
                        spreadRadius: 0,
                        offset: Offset(-3, -3)),
                    BoxShadow(
                        color: Color(0xFFDDE4EF),
                        blurRadius: 6,
                        spreadRadius: 0,
                        offset: Offset(3, 3)),
                  ],
                  color: const Color(0xffF0F3F6),
                )),
          ),
          Container(
              alignment: Alignment.centerLeft,
              padding: const EdgeInsets.only(left: 20, top: 10),
              child: const Text(
                'Upozila',
                style: TextStyle(
                    fontSize: 12, color: Color.fromRGBO(0, 46, 91, 1)),
              )),
          const SizedBox(
            height: 10,
          ),
          Padding(
            padding: const EdgeInsets.only(left: 20.0, right: 20),
            child: Container(
                height: 40,
                alignment: Alignment.center,
                padding: const EdgeInsets.all(10),
                child: DropdownButtonHideUnderline(
                  child: ButtonTheme(
                    alignedDropdown: true,
                    child: DropdownButton(
                      isExpanded: true,
                      value: selectedUpazila,
                      icon: const Icon(Icons.keyboard_arrow_down),
                      items: allUpazila.map((item) {
                        return DropdownMenuItem(
                            value: "${item.name}", child: Text("${item.name}"));
                      }).toList(),
                      onChanged: (var newValue) {
                        setState(() {
                          selectedUpazila = "$newValue";
                          if (selectedUpazila.compareTo("Select") == 0) {
                          } else {
                            var filteredUpazila = allUpazila
                                .where((x) => x.name == selectedUpazila)
                                .toList();
                            selectedUpazilaId = "${filteredUpazila[0].id}";
                          }
                        });
                      },
                    ),
                  ),
                ),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: const [
                    BoxShadow(
                        color: Color(0xFFFFFFFF),
                        blurRadius: 6,
                        spreadRadius: 0,
                        offset: Offset(-3, -3)),
                    BoxShadow(
                        color: Color(0xFFDDE4EF),
                        blurRadius: 6,
                        spreadRadius: 0,
                        offset: Offset(3, 3)),
                  ],
                  color: const Color(0xffF0F3F6),
                )),
          ),
          const SizedBox(
            height: 20,
          ),
        ],
      )),
      bottomSheet: Padding(
        padding: const EdgeInsets.all(30.0),
        child: GestureDetector(
          onTap: () {
            if (selectedDevisionId == "0") {
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                content: Text("Please select a Division"),
                backgroundColor: Colors.red.shade300,
              ));
              return;
            }
            if (selectedDistrictId == "0") {
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                content: Text("Please selecte a district"),
                backgroundColor: Colors.red.shade300,
              ));
              return;
            }
            if (selectedUpazilaId == "0") {
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                content: Text("Please select an upazilla"),
                backgroundColor: Colors.red.shade300,
              ));
              return;
            }

            Map<String, dynamic> parametes = {
              "division_id": selectedDevisionId,
              "district_id": selectedDistrictId,
              "upazila_id": selectedUpazilaId,
              "device_insurance_id": widget.deviceInsuranceId,
            };
            Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => NearestServiceCenter(
                    parameters: parametes,
                  )),
            );
          },
          child: Container(
            height: 40,
            //alignment: Alignment.bottomCenter,
            alignment: Alignment.center,
            child: TextButton(
              child: const Text(
                'Search',
                style: TextStyle(color: Colors.white),
              ),
              onPressed: () {
                if (selectedDevisionId == "0") {
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                    content: Text("Please select a Division"),
                    backgroundColor: Colors.red.shade300,
                  ));
                  return;
                }
                if (selectedDistrictId == "0") {
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                    content: Text("Please selecte a district"),
                    backgroundColor: Colors.red.shade300,
                  ));
                  return;
                }
                if (selectedUpazilaId == "0") {
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                    content: Text("Please select an upazilla"),
                    backgroundColor: Colors.red.shade300,
                  ));
                  return;
                }

                Map<String, dynamic> parametes = {
                  "division_id": selectedDevisionId,
                  "district_id": selectedDistrictId,
                  "upazila_id": selectedUpazilaId,
                  "device_insurance_id": widget.deviceInsuranceId,
                };
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => NearestServiceCenter(
                            parameters: parametes,
                          )),
                );
              },
            ),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                    color: const Color(0xff000000).withOpacity(0.16),
                    blurRadius: 3,
                    spreadRadius: 0,
                    offset: const Offset(0, 3)),
              ],
              color: const Color(0xff002E5B),
            ),
          ),
        ),
      ),
    );
  }
}
