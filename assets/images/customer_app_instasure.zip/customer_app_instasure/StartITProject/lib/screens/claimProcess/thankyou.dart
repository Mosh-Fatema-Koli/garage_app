import 'dart:async';

import 'package:flutter/material.dart';
import 'package:instasure/screens/mainPage.dart';
import 'package:instasure/widgets/topView4.dart';
import '../../widgets/topView.dart';

class Thankyou extends StatefulWidget {
  const Thankyou({Key? key}) : super(key: key);

  @override
  _ThankyouState createState() => _ThankyouState();
}

class _ThankyouState extends State<Thankyou> {
  @override
  void initState() {
    super.initState();

    Timer(const Duration(seconds: 5),
        () =>

            //Navigator.of(context).popUntil((route) => route.isFirst)

       Navigator.push(
        context,
         MaterialPageRoute(
             builder: (context) => const MainPage()),
      )

    );
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: null,
        backgroundColor: const Color(0xffEFF7FF),
        body: Column(
          children: [
            const TopView4(),
            Container(
                decoration: const BoxDecoration(
                  image: DecorationImage(
                    image: AssetImage("assets/splash.png"),
                    fit: BoxFit.cover,
                  ),
                ),
                child: Padding(
                    padding: const EdgeInsets.only(left: 30, right: 30, top: 0),
                    child: Column(
                      children: <Widget>[
                        Stack(
                          children: [
                            Container(
                                alignment: Alignment.center,
                                padding:
                                    const EdgeInsets.only(top: 100, bottom: 32),
                                child: Image.asset(
                                  "assets/successfully.png",
                                  fit: BoxFit.cover,
                                )
                                //
                                )
                          ],
                        ),
                        Container(
                            alignment: Alignment.center,
                            padding: const EdgeInsets.all(15),
                            child: const Text(
                              'Your Request Successfully Submitted',
                              style: TextStyle(fontSize: 17),
                            ))
                      ],
                    ))),
          ],
        ));
  }
}
