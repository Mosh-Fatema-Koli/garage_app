import 'dart:ffi';

import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:image_picker/image_picker.dart';
import 'package:instasure/screens/claimProcess/thankyou.dart';
import 'package:instasure/widgets/topView4.dart';
import '../../Utilities/ShowMessage.dart';
import '../../Utilities/constant.dart';
import '../../Utilities/userPref.dart';
import '../../Utilities/validator.dart';
import '../../domains/repo/apis.dart';
import 'package:http/http.dart' as http;
class ClaimPage extends StatefulWidget {
  const ClaimPage({Key? key, required this.deviceInsuranceId}) : super(key: key);
   final String deviceInsuranceId;
  @override
  _ClaimPageState createState() => _ClaimPageState();
}

class _ClaimPageState extends State<ClaimPage> {
  late var imageUri = null;
  final List<Widget> _cardList = [];
  final List<String> _documentList = [];
  TextEditingController imageFileChoose = TextEditingController();
  TextEditingController noFileChosen = TextEditingController();
  TextEditingController notesController = TextEditingController();
  int img_count=0;
  final ImagePicker imagePicker = ImagePicker();
  List<XFile>? imageFileList = [];

  @override
  void initState() {
    imageFileChoose.text = 'No file chosen';
    noFileChosen.text = 'No file chosen';
    super.initState();
  }

  void _addCardWidget() {
    setState(() {
      _cardList.add(_imageField());
    });
  }

  void _removeWidget() {
    setState(() {
      _cardList.removeLast();
    });
  }


  void selectImages() async {
    if(img_count<3){
      final List<XFile>? selectedImages = await
      imagePicker.pickMultiImage();
      if (selectedImages!.isNotEmpty) {
        imageFileList?.addAll(selectedImages);
      }
      setState((){
        img_count=img_count+1;
        ShowMessage.showMessage("Image Selected successfully");
        print(imageFileList);
      });
    }else{
      ShowMessage.showMessage("You can select maximum 3 image");
    }

  }

  Widget _imageField() {
    return Column(
      children: <Widget>[
        Container(
            alignment: Alignment.centerLeft,
            padding: const EdgeInsets.only(left: 20),
            child: const Text(
              'Upload FIR Copy',
              style: TextStyle(
                  fontSize: 12, color: Color.fromRGBO(0, 46, 91, 1)),
            )),
        const SizedBox(
          height: 10,
        ),
        Padding(
          padding: const EdgeInsets.only(left: 10.0, right: 10),
          child: Container(
            height: 60,
            alignment: Alignment.center,
            padding: const EdgeInsets.all(10),
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: <Widget>[
                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: const [
                      BoxShadow(
                          color: Color(0xFFFFFFFF),
                          blurRadius: 6,
                          spreadRadius: 0,
                          offset: Offset(-3, -3)),
                      BoxShadow(
                          color: Color(0xFFDDE4EF),
                          blurRadius: 6,
                          spreadRadius: 0,
                          offset: Offset(3, 3)),
                    ],
                    color: const Color(0xffF0F3F6),
                  ),
                  height: 60,
                  child: Padding(
                    padding: const EdgeInsets.only(left: 0, right: 10),
                    child: Row(
                      children: [
                        GestureDetector(

                          child: Container(
                              alignment: Alignment.center,
                              height: 80,
                              decoration: const BoxDecoration(
                                borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(20),
                                  topRight: Radius.circular(0),
                                  bottomLeft: Radius.circular(20),
                                  bottomRight: Radius.circular(0),
                                ),
                                boxShadow: [
                                  BoxShadow(
                                    color: Color(0xFF707070),
                                  ),
                                ],
                              ),
                              width: 90.0,
                              child: const Text(
                                'Choose File',
                                style: TextStyle(
                                    fontSize: 12,
                                    color: Color.fromRGBO(0, 46, 91, 1)),
                              )),
                        ),
                        Container(
                            alignment: Alignment.center,
                            width: 100.0,
                            child: Text(
                              noFileChosen.text,
                              style: const TextStyle(
                                  fontSize: 12,
                                  color: Color.fromRGBO(0, 46, 91, 1)),
                            )),
                      ],
                    ),
                  ),
                ),
                GestureDetector(
                  onTap: _removeWidget,
                  child: Padding(
                    padding: const EdgeInsets.only(left: 20.0),
                    child: Container(
                      decoration: const BoxDecoration(
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(10),
                          topRight: Radius.circular(10),
                          bottomLeft: Radius.circular(10),
                          bottomRight: Radius.circular(10),
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: Color(0xFFBF0000),
                          ),
                        ],
                      ),
                      height: 60,
                      child: Padding(
                        padding: const EdgeInsets.only(left: 10, right: 10),
                        child: Row(
                          children: [
                            Container(
                              alignment: Alignment.center,
                              width: 40.0,
                              child: TextButton(
                                child: Image.asset(
                                  'assets/icon_plus.png',
                                  height: 30,
                                ),
                                onPressed: () {
                                  _removeWidget();
                                },
                              ),
                            ),
                            Container(
                                alignment: Alignment.center,
                                width: 70.0,
                                child: const Text(
                                  'Cancel',
                                  style: TextStyle(
                                      fontSize: 12,
                                      color: Color(0xFFFFFFFF)),
                                )),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Future<void> claimLostRequest() async {

   /* if (_documentList.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: const Text(('Please upload image')),
        backgroundColor: Colors.red.shade300,
      ));
      return;
    }

    if (Validator.validateText(notesController.text) != null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: const Text("Please add note"),
        backgroundColor: Colors.red.shade300,
      ));
      return;
    }*/

    EasyLoading.instance.userInteractions = false;
    EasyLoading.show(status: 'Processing...');
    UserPref prefs = UserPref();
    Future<String?> token = prefs.getTokenFromPref();
    String? accessToken = await token;

    var headers = {
      'Accept': 'application/json',
      'Authorization': 'Bearer $accessToken'
    };
    print('1');
    String uri = Constants.BASE_URL + ApisEndPoints.deviceInsuranceSupportRequestStoreForLost;
    var request = http.MultipartRequest('POST', Uri.parse(uri));
    request.fields.addAll({
      'device_insurance_id': widget.deviceInsuranceId,
      'claim_type': 'Theft',
      'claim_note': notesController.text
    });
/*    if(_documentList.isNotEmpty){

      request.files.add(await http.MultipartFile.fromPath('document', _documentList));
    }else{
      request.files.add(await http.MultipartFile.fromPath('document', _documentList.first.toString()));
    }*/



    if (imageFileList == null) {
   // showMessage('Please upload device screen image');

    } else {
      var itemlist = imageFileList?.toList();
      int cc = 0;
      for (var imte in itemlist!) {
        cc++;
        request.files.add(
            await http.MultipartFile.fromPath('document[]', imte.path));
      }
    }

   // request.files.add(await http.MultipartFile.fromPath('document', _documentList.first.toString()));

    request.headers.addAll(headers);

      final response = await request.send();
      final respStr = await response.stream.bytesToString();


    //http.StreamedResponse response = await request.send();
    //print(response.statusCode);
    //EasyLoading.dismiss();
    if (response.statusCode == 200) {
      Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (c) => const Thankyou()),
              (route) => true);
    }
    else {
      print(response.reasonPhrase);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: null,
        backgroundColor: const Color(0xFFEFF7FF),
        body: SingleChildScrollView(
            child: Column(
          children: <Widget>[
            Stack(
              children: [
                const TopView4(),
                Positioned(
                  bottom: 20.0,
                  left: 40.0,
                  child: SizedBox(
                      height: 30,
                      width: 30,
                      // color: const Color.fromRGBO(0, 46, 91, 1.0),
                      // padding: const EdgeInsets.fromLTRB(10, 15, 10, 5),
                      child: TextButton(
                        child: Image.asset('assets/back_button_icon.png'),
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                      )),
                )
              ],
            ),
            const SizedBox(
              height: 5,
            ),
            Container(
                height: 38,
                alignment: Alignment.center,
                child: const Text(
                  'Select Insurance',
                  style: TextStyle(
                      fontSize: 16, color: Color.fromRGBO(0, 0, 0, 0.87)),
                ),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(0),
                  boxShadow: const [
                    BoxShadow(
                        color: Color(0xFFFFFFFF),
                        blurRadius: 6,
                        spreadRadius: 0,
                        offset: Offset(-3, -3)),
                    BoxShadow(
                        color: Color(0xFFDDE4EF),
                        blurRadius: 6,
                        spreadRadius: 0,
                        offset: Offset(3, 3)),
                  ],
                  color: const Color(0xffF0F3F6),
                )),
            const SizedBox(
              height: 30,
            ),
            Container(
                alignment: Alignment.centerLeft,
                padding: const EdgeInsets.only(left: 20),
                child: const Text(
                  'Claim Type',
                  style: TextStyle(
                      fontSize: 12, color: Color.fromRGBO(0, 46, 91, 1)),
                )),
            const SizedBox(
              height: 10,
            ),
            Padding(
              padding: const EdgeInsets.only(left: 20.0, right: 20),
              child: Container(
                  height: 40,
                  alignment: Alignment.center,
                  padding: const EdgeInsets.all(10),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Container(
                        alignment: Alignment.center,
                        child: const Text(
                          'Theft',
                          style: TextStyle(
                              fontSize: 16,
                              color: Color.fromRGBO(0, 0, 0, 0.87)),
                        ),
                      ),
                      Container(
                        alignment: Alignment.center,
                       /* child: TextButton(
                          child: Image.asset(
                            'assets/arrow_down.png',
                            height: 10,
                          ),
                          onPressed: () {
                            Navigator.of(context).pop();
                          },
                        ),*/
                      ),
                    ],
                  ),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: const [
                      BoxShadow(
                          color: Color(0xFFFFFFFF),
                          blurRadius: 6,
                          spreadRadius: 0,
                          offset: Offset(-3, -3)),
                      BoxShadow(
                          color: Color(0xFFDDE4EF),
                          blurRadius: 6,
                          spreadRadius: 0,
                          offset: Offset(3, 3)),
                    ],
                    color: const Color(0xffF0F3F6),
                  )),
            ),
            const SizedBox(
              height: 10,
            ),
          Container(
                alignment: Alignment.centerLeft,
                padding: const EdgeInsets.only(left: 20),
                child: const Text(
                  'Upload FIR Copy',
                  style: TextStyle(
                      fontSize: 12, color: Color.fromRGBO(0, 46, 91, 1)),
                )),
           /* Padding(
              padding: const EdgeInsets.only(left: 10.0, right: 10),
              child: Container(
                height: 60,
                alignment: Alignment.center,
                padding: const EdgeInsets.all(10),
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  children: <Widget>[
                    Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: const [
                          BoxShadow(
                              color: Color(0xFFFFFFFF),
                              blurRadius: 6,
                              spreadRadius: 0,
                              offset: Offset(-3, -3)),
                          BoxShadow(
                              color: Color(0xFFDDE4EF),
                              blurRadius: 6,
                              spreadRadius: 0,
                              offset: Offset(3, 3)),
                        ],
                        color: const Color(0xffF0F3F6),
                      ),
                      height: 60,
                      child: Padding(
                        padding: const EdgeInsets.only(left: 0, right: 10),
                        child: Row(
                          children: [
                            GestureDetector(

                              child: Container(
                                  alignment: Alignment.center,
                                  height: 80,
                                  decoration: const BoxDecoration(
                                    borderRadius: BorderRadius.only(
                                      topLeft: Radius.circular(20),
                                      topRight: Radius.circular(0),
                                      bottomLeft: Radius.circular(20),
                                      bottomRight: Radius.circular(0),
                                    ),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Color(0xFF707070),
                                      ),
                                    ],
                                  ),
                                  width: 90.0,
                                  child: const Text(
                                    'Choose File',
                                    style: TextStyle(
                                        fontSize: 12,
                                        color: Color.fromRGBO(0, 46, 91, 1)),
                                  )),
                            ),
                            Container(
                                alignment: Alignment.center,
                                width: 100.0,
                                child: Text(
                                  imageFileChoose.text,
                                  style: const TextStyle(
                                      fontSize: 12,
                                      color: Color.fromRGBO(0, 46, 91, 1)),
                                )),
                          ],
                        ),
                      ),
                    ),
                    GestureDetector(
                      onTap: _addCardWidget,
                      child: Padding(
                        padding: const EdgeInsets.only(left: 20.0),
                        child: Container(
                          decoration: const BoxDecoration(
                            borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(10),
                              topRight: Radius.circular(10),
                              bottomLeft: Radius.circular(10),
                              bottomRight: Radius.circular(10),
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0xFF002E5B),
                              ),
                            ],
                          ),
                          height: 60,
                          child: Padding(
                            padding: const EdgeInsets.only(left: 10, right: 10),
                            child: Row(
                              children: [
                                Container(
                                  alignment: Alignment.center,
                                  width: 40.0,
                                  child: TextButton(
                                    child: Image.asset(
                                      'assets/icon_plus.png',
                                      height: 30,
                                    ),
                                    onPressed: () {
                                      _addCardWidget();
                                    },
                                  ),
                                ),
                                Container(
                                    alignment: Alignment.center,
                                    width: 70.0,
                                    child: const Text(
                                      'Add More',
                                      style: TextStyle(
                                          fontSize: 12,
                                        color: Color(0xFFFFFFFF)),
                                    )),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),*/
           /* Container(
              alignment: Alignment.center,
              padding: const EdgeInsets.only(top: 0),
              child: ListView.builder(
                  shrinkWrap: true,
                  itemCount: _cardList.length,
                  itemBuilder: (context,index){
                    return _cardList[index];
                  }),
            ),*/
            const SizedBox(
              height: 10,
            ),
            MaterialButton(
              color: Colors.blue,
              child: Text(
                "Choose image",
                style: TextStyle(
                    color: Colors.white70, fontWeight: FontWeight.bold),
              ),
              onPressed: () {
                selectImages();
              },
            ),

            const SizedBox(
              height: 5,
            ),
            Text("($img_count) Image Selected"),

            const SizedBox(
              height: 10,
            ),
            Container(
              height: 40,
              alignment: Alignment.centerLeft,
              padding: const EdgeInsets.only(left: 30,right: 30),
              child: const Text(
                'Notes',
                style: TextStyle(
                    fontSize: 17, color: Colors.black),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 30,right: 30),
              child: Container(
                height: 60,
                child: TextField(
                  controller: notesController,
                  decoration: InputDecoration(
                    fillColor: const Color(0xFFF0F3F6),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(20.0),
                      borderSide: const BorderSide(
                          color: Colors.transparent, width: 0.0),
                    ),
                  ),
                ),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: const [
                    BoxShadow(
                        color: Color(0xFFFFFFFF),
                        blurRadius: 6,
                        spreadRadius: 0,
                        offset: Offset(-3, -3)),
                    BoxShadow(
                        color: Color(0xFFDDE4EF),
                        blurRadius: 6,
                        spreadRadius: 0,
                        offset: Offset(3, 3)),
                  ],
                  color: const Color(0xffF0F3F6),
                ),
              ),
            ),
            const SizedBox(
              height: 10,
            ),
            Padding(
              padding: const EdgeInsets.only(left: 20.0, right: 20),
              child: Container(
                  height: 40,
                  width: 400,
                  decoration: const BoxDecoration(
                      borderRadius: BorderRadius.all(Radius.circular(20)),
                      color: Color.fromRGBO(0, 46, 91, 1.0)),
                  child: TextButton(
                    child: const Text(
                      'Submit',
                      style: TextStyle(color: Colors.white, fontSize: 16),
                    ),
                    onPressed: () {
                      // Navigator.push(
                      //   context,
                      //   MaterialPageRoute(
                      //       builder: (context) => const Payment()),
                      // );
                      claimLostRequest();
                    },
                  )),
            ),
          ],
        )));
  }



 /* Future<void> openCamrea() async {
    final ImagePicker _picker = ImagePicker();
    final XFile? image = await _picker.pickImage(source: ImageSource.camera);
    setState(() {
      imageUri = image!.path.toString();
      _documentList.add(imageUri);
      imageFileChoose.text = imageUri.toString();
      noFileChosen.text = imageUri.toString();
    });
  }

  Future<void> openGallery() async {
    final ImagePicker _picker = ImagePicker();
    final XFile? image = await _picker.pickImage(source: ImageSource.gallery);
    setState(() {
      imageUri = image!.path.toString();
      _documentList.add(imageUri);
      imageFileChoose.text = imageUri.toString();
      noFileChosen.text = imageUri.toString();
    });
  }*/

 /* Future<void> _showChoiceDialog(BuildContext context, bool isFront) {
    return showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: const Text(
              "Choose option",
              style: TextStyle(color: Colors.blue),
            ),
            content: SingleChildScrollView(
              child: ListBody(
                children: [
                  const Divider(
                    height: 1,
                    color: Colors.blue,
                  ),
                  ListTile(
                    onTap: () {
                      openGallery();
                      Navigator.of(context).pop();
                    },
                    title: const Text("Gallery"),
                    leading: const Icon(
                      Icons.account_box,
                      color: Colors.blue,
                    ),
                  ),
                  const Divider(
                    height: 1,
                    color: Colors.blue,
                  ),
                  ListTile(
                    onTap: () {
                      openCamrea();
                      Navigator.of(context).pop();
                    },
                    title: const Text("Camera"),
                    leading: const Icon(
                      Icons.camera,
                      color: Colors.blue,
                    ),
                  ),
                ],
              ),
            ),
          );
        });
  }*/
}
