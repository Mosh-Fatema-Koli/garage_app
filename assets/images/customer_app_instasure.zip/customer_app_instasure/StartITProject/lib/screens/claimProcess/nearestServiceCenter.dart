import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:instasure/Utilities/userPref.dart';
import 'package:instasure/domains/models/deviceInsurance/defaultCerviceCenterAddress.dart';
import 'package:instasure/domains/models/deviceInsurance/serviceCenterModel.dart';
import 'package:instasure/domains/repo/apiClientDeviceInsurance.dart';
import 'package:instasure/screens/claimProcess/thankyou.dart';
import 'package:instasure/widgets/topView4.dart';

class NearestServiceCenter extends StatefulWidget {
  const NearestServiceCenter({Key? key, required this.parameters})
      : super(key: key);
  final Map<String, dynamic> parameters;

  @override
  _NearestServiceCenterState createState() => _NearestServiceCenterState();
}

class _NearestServiceCenterState extends State<NearestServiceCenter> {
  final ApiClientDeviceInsurance _apiClient = ApiClientDeviceInsurance();
  TextEditingController claimNotController = TextEditingController();

  List<ServiceCenterModel> serviceCenters = [];
  DefaultCerviceCenterAddress? defaultCerviceCenterAddress;
  List<String> allPickupStatus = ["Select", "To Service Center", "From Home"];

  String selectedServiceCenter = 'Select';
  String serviceCenterUserID = "0";
  String selectedPickupStatus = 'Select';
  var loading = true;

  @override
  void initState() {
    super.initState();
    () async {
      await Future.delayed(Duration.zero);
      getNearestServiceCenters();
    }();
  }

  Future<void> getNearestServiceCenters() async {
    UserPref prefs = UserPref();
    Future<String?> token = prefs.getTokenFromPref();
    String? accessToken = await token;
    dynamic res =
        await _apiClient.getServiceCenter(widget.parameters, accessToken!);

    if (res.statusCode == 200) {
      if (res.data['code'] == 200) {
        if (res.data['data']['serviceCenters'] != null) {
          List jsonList = res.data['data']['serviceCenters'] as List;

          List<ServiceCenterModel> centers = jsonList
              .map((jsonElement) => ServiceCenterModel.fromJson(jsonElement))
              .toList();
          setState(() {
            selectedServiceCenter = centers[0].serviceCenterName!;
            serviceCenterUserID = "${centers[0].userId}";
            serviceCenters = centers;
            loading = false;
          });
        } else {
          if (res.data['data']['defaultAddress'] != null) {
            setState(() {
              defaultCerviceCenterAddress =
                  DefaultCerviceCenterAddress.fromJson(
                      res.data['data']['defaultAddress']);
              serviceCenters = [];
              loading = false;
            });
          } else {
            setState(() {
              serviceCenters = [];
              loading = false;
            });
          }
        }
      } else {
        setState(() {
          serviceCenters = [];
          loading = false;
        });
      }
    } else {
      setState(() {
        serviceCenters = [];
        loading = false;
      });
    }
    // }
  }

  Future<void> deviceInsuranceSupportRequestStore() async {
    if (serviceCenterUserID == "0") {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: const Text("Pleaseselect a service center"),
        backgroundColor: Colors.red.shade300,
      ));
      return;
    }

    if (selectedPickupStatus == "Select") {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: const Text("Please select a Pickup status"),
        backgroundColor: Colors.red.shade300,
      ));
      return;
    }

    if (claimNotController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: const Text("Please write a claim note"),
        backgroundColor: Colors.red.shade300,
      ));
      return;
    }

    //   if (passwordController.text != null) {
    //   ScaffoldMessenger.of(context).showSnackBar(SnackBar(
    //     content: Text("${Validator.validatePassword(passwordController.text)}"),
    //     backgroundColor: Colors.red.shade300,
    //   ));
    //   return;
    // }

    EasyLoading.instance.userInteractions = false;
    EasyLoading.show(status: 'Processing...');

    Map<String, dynamic> data = {
      "device_insurance_id": widget.parameters['device_insurance_id'],
      "claim_type": "Damage",
      "sc_user_id": serviceCenterUserID,
      "pick_up_status": selectedServiceCenter,
      "claim_note": claimNotController.text,
    };

    UserPref prefs = UserPref();
    Future<String?> token = prefs.getTokenFromPref();
    String? accessToken = await token;
    dynamic res =
        await _apiClient.deviceInsuranceSupportRequestStore(data, accessToken!);
   // ScaffoldMessenger.of(context).hideCurrentSnackBar();
    EasyLoading.dismiss();
    if (res.statusCode == 200) {
      if (res.data['code'] == 200) {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => const Thankyou()),
        );
      }
    } else {}
    // }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: null,
      backgroundColor: const Color(0xffEFF7FF),
      body: SingleChildScrollView(
          child: Column(
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.only(left: 0, right: 0, top: 0),
            child: Stack(
              children: [
                Stack(
                  children: [
                    const TopView4(),
                    Positioned(
                      bottom: 20.0,
                      left: 40.0,
                      child: SizedBox(
                          height: 30,
                          width: 30,
                          // color: const Color.fromRGBO(0, 46, 91, 1.0),
                          child: TextButton(
                            child: Image.asset('assets/back_button_icon.png'),
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                          )),
                    )
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(
            height: 20,
          ),
          Container(
              height: 40,
              alignment: Alignment.center,
              child: const Text(
                'Here are the Nearest Service Center',
                style: TextStyle(
                    fontSize: 16, color: Color.fromRGBO(0, 0, 0, 0.87)),
              ),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(0),
                boxShadow: const [
                  BoxShadow(
                      color: Color(0xFFFFFFFF),
                      blurRadius: 6,
                      spreadRadius: 0,
                      offset: Offset(-3, -3)),
                  BoxShadow(
                      color: Color(0xFFDDE4EF),
                      blurRadius: 6,
                      spreadRadius: 0,
                      offset: Offset(3, 3)),
                ],
                color: const Color(0xffF0F3F6),
              )),
          const SizedBox(
            height: 30,
          ),
          loading
              ? Center(
                  child: Center(
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: const [
                        CircularProgressIndicator(),
                        SizedBox(
                          width: 10,
                        ),
                        Text("Loading"),
                      ],
                    ),
                  ),
                )
              : !loading && serviceCenters.isEmpty
                  ? Padding(
                      padding: const EdgeInsets.all(20.0),
                      child: Column(
                        children: [
                          const Center(
                              child: Text(
                            "No service center available to this location. Please contact below",
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                fontSize: 20, color: Colors.redAccent),
                          )),
                          const SizedBox(
                            height: 40,
                          ),
                          Center(
                              child: Text(
                            "${defaultCerviceCenterAddress?.value}",
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                                fontSize: 20, color: Colors.black),
                          )),
                        ],
                      ),
                    )
                  : Column(
                      children: [
                        Container(
                            alignment: Alignment.centerLeft,
                            padding: const EdgeInsets.only(left: 20),
                            child: const Text(
                              'Service Center',
                              style: TextStyle(
                                  fontSize: 12,
                                  color: Color.fromRGBO(0, 46, 91, 1)),
                            )),
                        const SizedBox(
                          height: 10,
                        ),
                        Padding(
                          padding: const EdgeInsets.only(
                              left: 20.0, right: 20, bottom: 20),
                          child: Container(
                              height: 40,
                              alignment: Alignment.center,
                              padding: const EdgeInsets.all(10),
                              child: DropdownButtonHideUnderline(
                                child: ButtonTheme(
                                  alignedDropdown: true,
                                  child: DropdownButton(
                                    isExpanded: true,
                                    value: selectedServiceCenter,
                                    icon: const Icon(Icons.keyboard_arrow_down),
                                    items: serviceCenters.map((item) {
                                      return DropdownMenuItem(
                                          value: "${item.serviceCenterName}",
                                          child: Text(
                                              "${item.serviceCenterName}"));
                                    }).toList(),
                                    onChanged: (newValue) {
                                      setState(() {
                                        selectedServiceCenter = "$newValue";

                                        if (selectedServiceCenter
                                                .compareTo("Select") ==
                                            0) {
                                        } else {
                                          var filteredCenters = serviceCenters
                                              .where((x) =>
                                                  x.serviceCenterName ==
                                                  selectedServiceCenter)
                                              .toList();
                                          serviceCenterUserID =
                                              "${filteredCenters[0].userId}";
                                        }
                                      });
                                    },
                                  ),
                                ),
                              ),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(20),
                                boxShadow: const [
                                  BoxShadow(
                                      color: Color(0xFFFFFFFF),
                                      blurRadius: 6,
                                      spreadRadius: 0,
                                      offset: Offset(-3, -3)),
                                  BoxShadow(
                                      color: Color(0xFFDDE4EF),
                                      blurRadius: 6,
                                      spreadRadius: 0,
                                      offset: Offset(3, 3)),
                                ],
                                color: const Color(0xffF0F3F6),
                              )),
                        ),
                        Container(
                            alignment: Alignment.centerLeft,
                            padding: const EdgeInsets.only(left: 20, top: 20),
                            child: const Text(
                              'Device Pick Up Status',
                              style: TextStyle(
                                  fontSize: 12,
                                  color: Color.fromRGBO(0, 46, 91, 1)),
                            )),
                        const SizedBox(
                          height: 10,
                        ),
                        Padding(
                          padding: const EdgeInsets.only(
                              left: 20.0, right: 20, bottom: 20),
                          child: Container(
                              height: 40,
                              alignment: Alignment.center,
                              padding: const EdgeInsets.all(10),
                              child: DropdownButtonHideUnderline(
                                child: ButtonTheme(
                                  alignedDropdown: true,
                                  child: DropdownButton(
                                    isExpanded: true,
                                    value: selectedPickupStatus,
                                    icon: const Icon(Icons.keyboard_arrow_down),
                                    items: allPickupStatus.map((item) {
                                      return DropdownMenuItem(
                                          value: item, child: Text(item));
                                    }).toList(),
                                    onChanged: (newValue) {
                                      setState(() {
                                        selectedPickupStatus = "$newValue";
                                      });
                                    },
                                  ),
                                ),
                              ),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(20),
                                boxShadow: const [
                                  BoxShadow(
                                      color: Color(0xFFFFFFFF),
                                      blurRadius: 6,
                                      spreadRadius: 0,
                                      offset: Offset(-3, -3)),
                                  BoxShadow(
                                      color: Color(0xFFDDE4EF),
                                      blurRadius: 6,
                                      spreadRadius: 0,
                                      offset: Offset(3, 3)),
                                ],
                                color: const Color(0xffF0F3F6),
                              )),
                        ),
                        Container(
                            alignment: Alignment.centerLeft,
                            padding: const EdgeInsets.only(left: 20, top: 20),
                            child: const Text(
                              'Claim Note',
                              style: TextStyle(
                                  fontSize: 14,
                                  color: Color.fromRGBO(0, 46, 91, 1)),
                            )),
                        Padding(
                          padding: const EdgeInsets.only(
                              left: 20, top: 10, right: 20),
                          child: Container(
                              height: 100,
                              child: TextField(
                                maxLines: 5, //or null
                                controller: claimNotController,
                                decoration: InputDecoration(
                                  fillColor: const Color(0xFFF0F3F6),
                                  filled: true,
                                  enabledBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10.0),
                                    borderSide: const BorderSide(
                                        color: Colors.transparent, width: 0.0),
                                  ),
                                ),
                              ),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                boxShadow: const [
                                  BoxShadow(
                                      color: Color(0xFFFFFFFF),
                                      blurRadius: 6,
                                      spreadRadius: 0,
                                      offset: Offset(-3, -3)),
                                  BoxShadow(
                                      color: Color(0xFFDDE4EF),
                                      blurRadius: 6,
                                      spreadRadius: 0,
                                      offset: Offset(3, 3)),
                                ],
                                color: const Color(0xffF0F3F6),
                              )),
                        ),
                        const SizedBox(
                          height: 30,
                        ),
                        Container(
                            height: 40,
                            width: MediaQuery.of(context).size.width * 0.85,
                            // color: const Color.fromRGBO(0, 46, 91, 1.0),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(20),
                              boxShadow: [
                                BoxShadow(
                                    color: const Color(0xff000000)
                                        .withOpacity(0.16),
                                    blurRadius: 3,
                                    spreadRadius: 0,
                                    offset: const Offset(0, 3)),
                              ],
                              color: const Color(0xff002E5B),
                            ),
                            // padding: const EdgeInsets.fromLTRB(10, 15, 10, 5),
                            child: TextButton(
                              child: const Text(
                                'Submit',
                                style: TextStyle(color: Colors.white),
                              ),
                              onPressed: deviceInsuranceSupportRequestStore,
                            )),
                      ],
                    ),
        ],
      )),
    );
  }
}
