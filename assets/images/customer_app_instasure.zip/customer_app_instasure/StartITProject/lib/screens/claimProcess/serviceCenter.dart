// ignore_for_file: unnecessary_new

import 'package:flutter/material.dart';
import 'package:instasure/widgets/topView4.dart';
import '../../Utilities/homeMenu.dart';

class ServiceCenter extends StatefulWidget {
  const ServiceCenter({Key? key}) : super(key: key);

  @override
  _ServiceCenterState createState() => _ServiceCenterState();
}

class _ServiceCenterState extends State<ServiceCenter> {
//class LoginPage extends StatelessWidget {
  final selectionOptions = ['Select', 'Service', 'Collection'];
  String selectedType = 'Select';
  var _serviceCenters = serviceCenters;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
          child: Padding(
        padding: const EdgeInsets.all(0),
        child: Column(
          children: [
            Stack(
              children: [
                const TopView4(),
                Positioned(
                  bottom: 20.0,
                  left: 40.0,
                  child: SizedBox(
                      height: 30,
                      width: 30,
                      // color: const Color.fromRGBO(0, 46, 91, 1.0),
                      // padding: const EdgeInsets.fromLTRB(10, 15, 10, 5),
                      child: TextButton(
                        child: Image.asset('assets/back_button_icon.png'),
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                      )),
                )
              ],
            ),
            Expanded(
              child: ListView(
                children: <Widget>[
                  const SizedBox(height: 0.0),
                  creatSearchBar(),
                  const SizedBox(height: 20.0),
                  buildListView()
                ],
              ),
            ),
          ],
        ),
      )),
      backgroundColor: const Color(0xFFEFF7FF),
    );
  }

  creatSearchBar() {
    return Padding(
        padding: const EdgeInsets.only(right: 30, top: 0, bottom: 0, left: 30),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Container(
              height: 22,
              padding: const EdgeInsets.only(left: 5, right: 5),
              child: DropdownButton<String>(
                isExpanded: false,
                value: selectedType,
                icon: const Icon(Icons.arrow_downward),
                iconSize: 14,
                elevation: 10,
                underline: Container(),
                onChanged: (var newValue) {
                  setState(() {
                    selectedType = newValue!;
                    if (selectedType.compareTo("Select") == 0) {
                      _serviceCenters = serviceCenters;
                    } else {
                      _serviceCenters = serviceCenters
                          .where((x) => x['type'] == selectedType + ' Center')
                          .toList();
                    }
                  });
                },
                items: List.generate(
                  selectionOptions.length,
                  (index) => DropdownMenuItem(
                    child: Text(selectionOptions[index]),
                    value: selectionOptions[index],
                  ),
                ),
              ),
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(15),
                  boxShadow: const [
                    BoxShadow(
                        color: Color(0xFFFFFFFF),
                        blurRadius: 6,
                        spreadRadius: 0,
                        offset: Offset(-3, -3)),
                    BoxShadow(
                        color: Color(0xFFFFFFFF),
                        blurRadius: 6,
                        spreadRadius: 0,
                        offset: Offset(3, 3)),
                  ],
                  color: const Color(0xFFF0F3F6)),
            ),
            GestureDetector(
              onTap: () {
                print("Test");
                // Navigator.push(
                //   context,
                //   MaterialPageRoute(
                //       builder: (context) => SecondRoute(
                //             title: vehicles[index],
                //             subTitle: 'test',
                //           )),
                // );
              },
              child: Container(
                height: 22,
                padding: const EdgeInsets.only(left: 5, right: 5),
                child: Row(
                  children: [
                    const Text(
                      'Search',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontFamily: 'Roboto Slab',
                        fontSize: 16,
                        color: Color(0xff002E5B),
                      ),
                    ),
                    const SizedBox(
                      width: 5,
                    ),
                    Image.asset("assets/centername_icon.png"),
                  ],
                ),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(15),
                    boxShadow: const [
                      BoxShadow(
                          color: Color(0xFFFFFFFF),
                          blurRadius: 6,
                          spreadRadius: 0,
                          offset: Offset(-3, -3)),
                      BoxShadow(
                          color: Color(0xFFFFFFFF),
                          blurRadius: 6,
                          spreadRadius: 0,
                          offset: Offset(3, 3)),
                    ],
                    color: const Color(0xFFF0F3F6)),
              ),
            ),
          ],
        ));
  }

  buildListView() {
    return SizedBox(
      height: 600,
      // color: Colors.red,

      //width: (MediaQuery.of(context).size.width - 30) / 3,
      child: ListView.separated(
          primary: false,
          scrollDirection: Axis.vertical,
          shrinkWrap: true,
          itemCount: _serviceCenters.length,
          itemBuilder: (BuildContext context, int index) {
            var center = _serviceCenters[index];
            return Padding(
                padding: const EdgeInsets.only(
                    right: 30, top: 10, bottom: 10, left: 30),
                child: Container(
                    // padding: const EdgeInsets.all(10.0),
                    //width: (MediaQuery.of(context).size.width - 45) / 3,
                    height: 188,
                    alignment: Alignment.center,
                    // padding: const EdgeInsets.only(top: 20),
                    child: GestureDetector(
                      onTap: () {
                        print("Test");
                        // Navigator.push(
                        //   context,
                        //   MaterialPageRoute(
                        //       builder: (context) => SecondRoute(
                        //             title: vehicles[index],
                        //             subTitle: 'test',
                        //           )),
                        // );
                      },
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: <Widget>[
                          const SizedBox(height: 10.0),
                          Text(
                            center["type"],
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                              fontFamily: 'Roboto Slab',
                              fontSize: 14,
                              color: Color(0xff000000),
                              decoration: TextDecoration.underline,
                            ),
                          ),
                          const SizedBox(height: 20.0),
                          Row(
                            children: [
                              const SizedBox(width: 35.0),
                              Image.asset(center['centerIcon']),
                              const SizedBox(width: 10.0),
                              Text(
                                center["name"],
                                textAlign: TextAlign.left,
                                style: const TextStyle(
                                  fontFamily: 'Roboto Slab',
                                  fontSize: 14,
                                  color: Color(0xff000000),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 10.0),
                          Row(
                            children: [
                              const SizedBox(width: 35.0),
                              Image.asset(center['locIcon']),
                              const SizedBox(width: 10.0),
                              Text(
                                center["location"],
                                textAlign: TextAlign.left,
                                style: const TextStyle(
                                  fontFamily: 'Roboto Slab',
                                  fontSize: 14,
                                  color: Color(0xff000000),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 10.0),
                          Row(
                            children: [
                              const SizedBox(width: 35.0),
                              Image.asset(center['emailIcon']),
                              const SizedBox(width: 10.0),
                              Text(
                                center["email"],
                                textAlign: TextAlign.left,
                                style: const TextStyle(
                                  fontFamily: 'Roboto Slab',
                                  fontSize: 14,
                                  color: Color(0xff000000),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 10.0),
                          Row(
                            children: [
                              const SizedBox(width: 35.0),
                              Image.asset(center['phoneIcon']),
                              const SizedBox(width: 10.0),
                              Text(
                                center["phone"],
                                textAlign: TextAlign.left,
                                style: const TextStyle(
                                  fontFamily: 'Roboto Slab',
                                  fontSize: 14,
                                  color: Color(0xff000000),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(40),
                      boxShadow: [
                        BoxShadow(
                            color: const Color(0xFF626262).withOpacity(0.34),
                            blurRadius: 20,
                            spreadRadius: 0,
                            offset: const Offset(0, 0)),
                      ],
                      color: const Color(0xFFF0F3F6),
                    )));

            // );
          },
          separatorBuilder: (context, index) => const SizedBox(
                height: 8,
              )),
    );
  }
}
