
import 'package:flutter/material.dart';
import 'package:instasure/screens/mainPage.dart';
import 'package:instasure/screens/studentsInsurance/claim_history_dtls.dart';

class ClaimHistory extends StatefulWidget {
  const ClaimHistory({Key? key}) : super(key: key);

  @override
  State<ClaimHistory> createState() => _ClaimHistoryState();
}

class _ClaimHistoryState extends State<ClaimHistory> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(
        // title: const Text('Home'),

        // title: Text("YOUR_APPBAR_TITLE"),
        // automaticallyImplyLeading: false,


        title: Image.asset(
          'assets/instasure_icon.png', fit: BoxFit.contain, height: 32,),

        leading: new IconButton(
          icon: new Icon(Icons.arrow_back, color: const Color(0xff002E5B),),
          onPressed: () =>
              Navigator.push(
                context, MaterialPageRoute(builder: (context) => MainPage()),),
        ),


        automaticallyImplyLeading: true,
        backgroundColor: Colors.white,
        actions: <Widget>[
          IconButton(
            // AssetImage("assets/home/insurance.png"),
            icon: Icon(
              Icons.help_center,
              color: const Color(0xff002E5B),
            ),
            /*icon: Icon(
                Icons.settings,
                color: Colors.white,
              ),*/
            onPressed: () {
              setState(() {

              });
              /* Navigator.push(
                   context,
                   MaterialPageRoute(builder: (context) => const  MenuScreen()),
                 );*/

            },
          )
        ],
      ),


      body: Center(
          child: Padding(
            padding: const EdgeInsets.all(0),
            child: Column(
              children: [
                Stack(
                  children: [

                    Container(
                      child: Column(

                      ),
                    ),

                    //const TopView4(),
                    Positioned(
                      bottom: 20.0,
                      left: 40.0,
                      child: SizedBox(
                          height: 30,
                          width: 30,
                          // color: const Color.fromRGBO(0, 46, 91, 1.0),
                          // padding: const EdgeInsets.fromLTRB(10, 15, 10, 5),
                          child: TextButton(
                            child: Image.asset('assets/back_button_icon.png'),
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                          )),
                    )
                  ],
                ),
                SizedBox(
                  height: 20,
                ),
                createHeader(),
                SizedBox(
                  height: 20,
                ),

                Expanded(child: buildListView())

              ],
            ),
          )),
      backgroundColor: const Color(0xFFEFF7FF),

    );
  }

  createHeader() {
    return Container(
      height: 38,
      child: const Center(
        child: Text(
          'Claim History',
          textAlign: TextAlign.center,
          style: TextStyle(
            fontFamily: 'Roboto Slab',
            fontSize: 16,
            color: Color(0xff002E5B),
          ),
        ),
      ),
      decoration: const BoxDecoration(color: Color(0xffF0F3F6), boxShadow: [
        BoxShadow(
            color: Color(0xffffffff),
            blurRadius: 6,
            spreadRadius: 0,
            offset: Offset(-3, -3)),
        BoxShadow(
            color: Color(0xffDDE4EF),
            blurRadius: 6,
            spreadRadius: 0,
            offset: Offset(3, 3)),
      ]),
    );
  }

  buildListView() {
    return ListView.separated(
        primary: false,
        scrollDirection: Axis.vertical,
        shrinkWrap: true,
        itemCount: 1,
        itemBuilder: (BuildContext context, int index) {
          // TravelInsuranceHistoryModel insuranceHistoryModel = _insuranceHistories[index];
          return GestureDetector(
            onTap: (){
               Navigator.push(
                context, MaterialPageRoute(builder: (context) => ClaimHistorydetails()),);
            },
            child: Padding(
                padding: const EdgeInsets.only(right: 14, top: 5, bottom: 5, left: 14),
                child: Container(
                  // padding: const EdgeInsets.all(10.0),
                  // width: (MediaQuery.of(context).size.width - 45) / 3,
                  //height: 108,
                  alignment: Alignment.center,
                  // padding: const EdgeInsets.only(top: 20),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(40),
                    boxShadow: const [
                      BoxShadow(
                          color: Color(0xFFFFFFFF),
                          blurRadius: 6,
                          spreadRadius: 0,
                          offset: Offset(-3, -3)),
                    ],
                    color: const Color(0xFFF0F3F6),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 30 ,vertical:10),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        const SizedBox(height: 10.0),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [

                                Image.asset('assets/profile/calendar_icon.png',height: 16,),
                                const SizedBox(width: 10.0),
                                Text(
                                  "12.05.2023",
                                  textAlign: TextAlign.left,
                                  style: const TextStyle(
                                    fontFamily: 'Roboto Slab',
                                    fontSize: 14,
                                    color: Color(0xff000000),
                                  ),
                                ),
                              ],
                            ),
                            Text(
                              "Stutas : Runninng",
                              textAlign: TextAlign.left,
                              style: TextStyle(
                                fontFamily: 'Roboto Slab',
                                fontSize: 14,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 10.0),
                        Text(
                          "Bangladesh University ",
                          textAlign: TextAlign.left,
                          style: TextStyle(
                            fontFamily: 'Roboto Slab',
                            fontSize: 16,
                          ),
                        ),
                        const SizedBox(height: 5.0),
                        Text(
                          "Programm : BSc in CSE",
                          textAlign: TextAlign.left,
                          style: TextStyle(
                            fontFamily: 'Roboto Slab',
                            fontSize: 14,
                          ),
                        ),
                        const SizedBox(height: 5.0),
                        Text(
                          "Semester :  1",
                          textAlign: TextAlign.left,
                          style: TextStyle(
                            fontFamily: 'Roboto Slab',
                            fontSize: 14,
                          ),
                        ),
                        const SizedBox(height: 5.0),
                        Text(
                          "Payment Status : Paid",
                          textAlign: TextAlign.left,
                          style: TextStyle(
                            fontFamily: 'Roboto Slab',
                            fontSize: 14,
                          ),
                        ),
                        const SizedBox(height: 10.0),

                      ],
                    ),
                  ),

                )),
          );

          // );
        },
        separatorBuilder: (context, index) => const SizedBox(
          height: 8,
        ));
  }

}
