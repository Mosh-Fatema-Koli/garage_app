
import 'package:flutter/material.dart';
import 'package:instasure/screens/mainPage.dart';

class StudentInfo extends StatefulWidget {
  const StudentInfo({Key? key}) : super(key: key);

  @override
  State<StudentInfo> createState() => _StudentInfoState();
}

class _StudentInfoState extends State<StudentInfo> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(
        // title: const Text('Home'),

        // title: Text("YOUR_APPBAR_TITLE"),
        // automaticallyImplyLeading: false,


        title: Image.asset(
          'assets/instasure_icon.png', fit: BoxFit.contain, height: 32,),

        leading: new IconButton(
          icon: new Icon(Icons.arrow_back, color: const Color(0xff002E5B),),
          onPressed: () =>
              Navigator.push(
                context, MaterialPageRoute(builder: (context) => MainPage()),),
        ),


        automaticallyImplyLeading: true,
        backgroundColor: Colors.white,
        actions: <Widget>[
          IconButton(
            // AssetImage("assets/home/insurance.png"),
            icon: Icon(
              Icons.help_center,
              color: const Color(0xff002E5B),
            ),
            /*icon: Icon(
                Icons.settings,
                color: Colors.white,
              ),*/
            onPressed: () {
              setState(() {

              });
              /* Navigator.push(
                   context,
                   MaterialPageRoute(builder: (context) => const  MenuScreen()),
                 );*/

            },
          )
        ],
      ),


      body: Center(
          child: Padding(
            padding: const EdgeInsets.all(0),
            child: Column(
              children: [
                Stack(
                  children: [

                    Container(
                      child: Column(

                      ),
                    ),

                    //const TopView4(),
                    Positioned(
                      bottom: 20.0,
                      left: 40.0,
                      child: SizedBox(
                          height: 30,
                          width: 30,
                          // color: const Color.fromRGBO(0, 46, 91, 1.0),
                          // padding: const EdgeInsets.fromLTRB(10, 15, 10, 5),
                          child: TextButton(
                            child: Image.asset('assets/back_button_icon.png'),
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                          )),
                    )
                  ],
                ),
                SizedBox(
                  height: 20,
                ),
                createHeader(),
                SizedBox(
                  height: 20,
                ),
                Padding(
                  padding: const EdgeInsets.all(20),
                  child: Container(

                    width: MediaQuery.of(context).size.width,
                    child: Padding(
                      padding: const EdgeInsets.all(20),
                      child: Column(
                        children: [
                          Image.asset("assets/profile/profile.png",height: 100,width: 100,fit: BoxFit.cover,),
                          SizedBox(
                            height: 20,
                          ),
                          Text("Bangladesh University ",style: TextStyle(fontSize: 18,fontWeight: FontWeight.bold),),
                          SizedBox(
                            height: 20,
                          ),
                          Row(

                            children: [
                              Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [


                                  Row(

                                    children: [
                                      Text("Student Id : ",style: TextStyle(fontWeight: FontWeight.bold),),
                                      Text("2023566884215"),
                                    ],
                                  ),
                                  SizedBox(
                                    height: 5,
                                  ),
                                  Row(
                                    children: [
                                      Text("Student name : ",style: TextStyle(fontWeight: FontWeight.bold),),
                                      Text("Abuullah alif mashrafi bin Salam"),
                                    ],
                                  ),
                                  SizedBox(
                                    height: 5,
                                  ),
                                  Row(
                                    children: [
                                      Text("Programm : ",style: TextStyle(fontWeight: FontWeight.bold),),
                                      Text("BSc in CSE "),
                                    ],
                                  ),
                                  SizedBox(
                                    height: 5,
                                  ),
                                  Row(
                                    children: [
                                      Text("Semester : ",style: TextStyle(fontWeight: FontWeight.bold),),
                                      Text("12"),
                                    ],
                                  ),
                                  SizedBox(
                                    height: 5,
                                  ),
                                  Row(
                                    children: [
                                      Text("Admission Date : ",style: TextStyle(fontWeight: FontWeight.bold),),
                                      Text("1-1-2023 "),
                                    ],
                                  ),
                                  SizedBox(
                                    height: 5,
                                  ),    Row(
                                    children: [
                                      Text("Expired Date : ",style: TextStyle(fontWeight: FontWeight.bold),),
                                      Text("20-04-2027"),
                                    ],
                                  ),
                                  SizedBox(
                                    height: 5,
                                  ),    Row(
                                    children: [
                                      Text("Insurance Package Name : ",style: TextStyle(fontWeight: FontWeight.bold),),
                                      Text("madical "),
                                    ],
                                  ),
                                  SizedBox(
                                    height: 5,
                                  ),
                                  Row(
                                    children: [
                                      Text("Payable Amount : ",style: TextStyle(fontWeight: FontWeight.bold),),
                                      Text("6000"),
                                    ],
                                  ),
                                  SizedBox(
                                    height: 5,
                                  ),
                                  Row(
                                    children: [
                                      Text("Already Paid : ",style: TextStyle(fontWeight: FontWeight.bold),),
                                      Text("500"),
                                    ],
                                  ),
                                  SizedBox(
                                    height: 5,
                                  ),
                                  Row(
                                    children: [
                                      Text("Premun Amount: ",style: TextStyle(fontWeight: FontWeight.bold),),
                                      Text("1000 "),
                                    ],
                                  ),
                                  SizedBox(
                                    height: 5,
                                  ),
                                  Row(
                                    children: [
                                      Text("Payable amount per Semester : ",style: TextStyle(fontWeight: FontWeight.bold),),
                                      Text("500 "),
                                    ],
                                  ),
                                  SizedBox(
                                    height: 5,
                                  ),
                                  Row(
                                    children: [
                                      Text("Status : ",style: TextStyle(fontWeight: FontWeight.bold),),

                                      Text("Continue "),
                                    ],
                                  ),
                                  SizedBox(
                                    height: 5,
                                  ),






                                ],
                              ),

                            ],
                          ),
                          SizedBox(
                            height: 10,
                          ),
                        ],
                      ),
                    ),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: const Color(0xFFF0F3F6),
                      boxShadow: [
                        BoxShadow(
                            color: const Color(0xff000000).withOpacity(0.16),
                            blurRadius: 3,
                            spreadRadius: 0,
                            offset: const Offset(0, 3)),
                      ],
                    ),

                  ),
                ),



              ],
            ),
          )),
      backgroundColor: const Color(0xFFEFF7FF),

    );
  }

  createHeader() {
    return Container(
      height: 38,
      child: const Center(
        child: Text(
          'Insurance Details',
          textAlign: TextAlign.center,
          style: TextStyle(
            fontFamily: 'Roboto Slab',
            fontSize: 16,
            color: Color(0xff002E5B),
          ),
        ),
      ),
      decoration: const BoxDecoration(color: Color(0xffF0F3F6), boxShadow: [
        BoxShadow(
            color: Color(0xffffffff),
            blurRadius: 6,
            spreadRadius: 0,
            offset: Offset(-3, -3)),
        BoxShadow(
            color: Color(0xffDDE4EF),
            blurRadius: 6,
            spreadRadius: 0,
            offset: Offset(3, 3)),
      ]),
    );
  }

}