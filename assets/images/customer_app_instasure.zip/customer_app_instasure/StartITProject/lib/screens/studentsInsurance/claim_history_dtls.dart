
import 'package:flutter/material.dart';
import 'package:instasure/screens/mainPage.dart';

class ClaimHistorydetails extends StatefulWidget {
  const ClaimHistorydetails({Key? key}) : super(key: key);

  @override
  State<ClaimHistorydetails> createState() => _ClaimHistorydetailsState();
}

class _ClaimHistorydetailsState extends State<ClaimHistorydetails> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(
        // title: const Text('Home'),

        // title: Text("YOUR_APPBAR_TITLE"),
        // automaticallyImplyLeading: false,


        title: Image.asset(
          'assets/instasure_icon.png', fit: BoxFit.contain, height: 32,),

        leading: new IconButton(
          icon: new Icon(Icons.arrow_back, color: const Color(0xff002E5B),),
          onPressed: () =>
              Navigator.push(
                context, MaterialPageRoute(builder: (context) => MainPage()),),
        ),


        automaticallyImplyLeading: true,
        backgroundColor: Colors.white,
        actions: <Widget>[
          IconButton(
            // AssetImage("assets/home/insurance.png"),
            icon: Icon(
              Icons.help_center,
              color: const Color(0xff002E5B),
            ),
            /*icon: Icon(
                Icons.settings,
                color: Colors.white,
              ),*/
            onPressed: () {
              setState(() {

              });
              /* Navigator.push(
                   context,
                   MaterialPageRoute(builder: (context) => const  MenuScreen()),
                 );*/

            },
          )
        ],
      ),


      body: Center(
          child: Padding(
            padding: const EdgeInsets.all(0),
            child: Column(
              children: [
                Stack(
                  children: [

                    Container(
                      child: Column(

                      ),
                    ),

                    //const TopView4(),
                    Positioned(
                      bottom: 20.0,
                      left: 40.0,
                      child: SizedBox(
                          height: 30,
                          width: 30,
                          // color: const Color.fromRGBO(0, 46, 91, 1.0),
                          // padding: const EdgeInsets.fromLTRB(10, 15, 10, 5),
                          child: TextButton(
                            child: Image.asset('assets/back_button_icon.png'),
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                          )),
                    )
                  ],
                ),
                SizedBox(
                  height: 20,
                ),
                createHeader(),
                SizedBox(
                  height: 20,
                ),
                Padding(
                  padding: const EdgeInsets.all(20),
                  child: Container(

                    width: MediaQuery.of(context).size.width,
                    child: Padding(
                      padding: const EdgeInsets.all(20),
                      child: Column(
                        children: [
                          Text("Bangladesh University ",style: TextStyle(fontSize: 18,fontWeight: FontWeight.bold),),
                          SizedBox(
                            height: 20,
                          ),
                          Row(

                            children: [
                              Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [


                                  Text("Route :"),
                                  SizedBox(
                                    height: 5,
                                  ),
                                  Text("Starting Date & Time :"),
                                  SizedBox(
                                    height: 3,
                                  ),
                                  Text("End Date & Time :"),
                                  SizedBox(
                                    height: 3,
                                  ),
                                  Text("Transport :"),
                                  SizedBox(
                                    height: 3,
                                  ),
                                  Text("Total Tourist :"),
                                  SizedBox(
                                    height: 3,
                                  ),
                                  Text("Stay in Hotel :"),
                                  SizedBox(
                                    height: 3,
                                  ),
                                  Text("Departure Location :"),
                                  SizedBox(
                                    height: 3,
                                  ),
                                  Text("Application Date :"),
                                  SizedBox(
                                    height: 3,
                                  ),
                                  Text("policy Id :"),
                                  SizedBox(
                                    height: 3,
                                  ),
                                  Text("Coordinator Name :"),
                                  SizedBox(
                                    height: 3,
                                  ),
                                  Text("Coordinator Number : "),
                                  SizedBox(
                                    height: 5,
                                  ),
                                  Text("Tour Status : "),


                                ],
                              ),
                              SizedBox(width: 5,),
                              Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: const [



                                  SizedBox(
                                      height: 20,
                                      child: Text("Dhk-Cox-Dhk-Dhk")),
                                  SizedBox(
                                    height: 5,
                                  ),
                                  Text("27-02-2023 | 45:30:45 PM"),
                                  SizedBox(
                                    height: 3,
                                  ),
                                  Text("29-02-2023 | 45:30:45 PM"),
                                  SizedBox(
                                    height: 3,
                                  ),
                                  Text("Bus"),
                                  SizedBox(
                                    height: 3,
                                  ),
                                  Text("20"),
                                  SizedBox(
                                    height: 3,
                                  ),
                                  Text("XXXXXX Hotel Coxbazar"),
                                  SizedBox(
                                    height: 3,
                                  ),
                                  Text("Departure Location"),
                                  SizedBox(
                                    height: 3,
                                  ),
                                  Text("Application Date"),
                                  SizedBox(
                                    height: 3,
                                  ),
                                  Text("policy Id"),
                                  SizedBox(
                                    height: 3,
                                  ),
                                  Text("Cordinator Name"),
                                  SizedBox(
                                    height: 3,
                                  ),
                                  Text("01302607702"),
                                  SizedBox(
                                    height: 5,
                                  ),
                                  Text("Expired "),

                                ],
                              ),
                            ],
                          ),
                          SizedBox(
                            height: 10,
                          ),
                        ],
                      ),
                    ),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: const Color(0xFFF0F3F6),
                      boxShadow: [
                        BoxShadow(
                            color: const Color(0xff000000).withOpacity(0.16),
                            blurRadius: 3,
                            spreadRadius: 0,
                            offset: const Offset(0, 3)),
                      ],
                    ),

                  ),
                ),



              ],
            ),
          )),
      backgroundColor: const Color(0xFFEFF7FF),

    );
  }

  createHeader() {
    return Container(
      height: 38,
      child: const Center(
        child: Text(
          'Claim History Details',
          textAlign: TextAlign.center,
          style: TextStyle(
            fontFamily: 'Roboto Slab',
            fontSize: 16,
            color: Color(0xff002E5B),
          ),
        ),
      ),
      decoration: const BoxDecoration(color: Color(0xffF0F3F6), boxShadow: [
        BoxShadow(
            color: Color(0xffffffff),
            blurRadius: 6,
            spreadRadius: 0,
            offset: Offset(-3, -3)),
        BoxShadow(
            color: Color(0xffDDE4EF),
            blurRadius: 6,
            spreadRadius: 0,
            offset: Offset(3, 3)),
      ]),
    );
  }

}