
import 'package:flutter/material.dart';
import 'package:instasure/widgets/topView4.dart';

class ContactUs extends StatefulWidget {
  const ContactUs({Key? key}) : super(key: key);

  @override
  State<ContactUs> createState() => _ContactUsState();
}

class _ContactUsState extends State<ContactUs> {
  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      body:
      // loading
      //     ? const Center(
      //         child: CircularProgressIndicator(),
      //       )
      //     :
      Center(
          child: Padding(
            padding: const EdgeInsets.all(0),
            child: Column(
              children: [
                Stack(
                  children: [
                    const TopView4(),
                    Positioned(
                      bottom: 20.0,
                      left: 40.0,
                      child: SizedBox(
                          height: 30,
                          width: 30,
                          // color: const Color.fromRGBO(0, 46, 91, 1.0),
                          // padding: const EdgeInsets.fromLTRB(10, 15, 10, 5),
                          child: TextButton(
                            child: Image.asset('assets/back_button_icon.png'),
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                          )),
                    )
                  ],
                ),
                const SizedBox(height: 30),
                createHeaderWidget(),
                const SizedBox(height: 40),
                Image.asset("assets/contactus.png",height: 200,fit: BoxFit.cover,),
                const SizedBox(height: 30),
                Text("CONTACT US BY PHONE NUMBER OR EMAIL ADDRESS",style: TextStyle(
                  fontFamily: 'Roboto Slab',
                  fontSize: 14,
                  color: Color(0xff002E5B),
                ),),
                const SizedBox(height: 20),
                Text("+0880960-6252525",
                  style: TextStyle(
                    fontFamily: 'Roboto Slab',
                    fontSize: 16,
                    color: Color(0xff59a3ec),
                  ),),
                const SizedBox(height: 5),

                Text("OR",style: TextStyle(
                  fontFamily: 'Roboto Slab',
                  fontSize: 16,
                  color: Color(0xff283848),
                ),),
                const SizedBox(height: 5),
                Text("info@instasure.xyz",style: TextStyle(
                  fontFamily: 'Roboto Slab',
                  fontSize: 16,
                  color: Color(0xff002E5B),
                ),),

              ],
            ),
          )),
      backgroundColor: const Color(0xFFEFF7FF),
    );
  }
  createHeaderWidget() {
    return Container(
      height: 38,
      child: const Center(
        child: Text(
          'Contact Us',
          textAlign: TextAlign.center,
          style: TextStyle(
            fontFamily: 'Roboto Slab',
            fontSize: 16,
            color: Color(0xff002E5B),
          ),
        ),
      ),
      decoration: const BoxDecoration(color: Color(0xffF0F3F6), boxShadow: [
        BoxShadow(
            color: Color(0xffffffff),
            blurRadius: 6,
            spreadRadius: 0,
            offset: Offset(-3, -3)),
        BoxShadow(
            color: Color(0xffDDE4EF),
            blurRadius: 6,
            spreadRadius: 0,
            offset: Offset(3, 3)),
      ]),
    );
  }
}
