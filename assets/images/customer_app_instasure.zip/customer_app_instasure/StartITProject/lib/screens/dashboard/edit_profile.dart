
import 'package:flutter/material.dart';

class EditProfile extends StatefulWidget {
  const EditProfile({Key? key}) : super(key: key);

  @override
  State<EditProfile> createState() => _EditProfileState();
}

class _EditProfileState extends State<EditProfile> {

  late var imagePath = null;
  late var avatorImage = null;
  late var passFrontimagePath = null;
  late var passBackImagePath = null;
  late var nidFrontimagePath = null;
  late var nidBackImagePath = null;
  late var drivingLicenceImagePath = null;
  DateTime? _selectedDate;
  bool isDataOfBirthClick = false;
  bool isFromUpdated = false;
  var loading = true;

  TextEditingController nameController = TextEditingController();
  TextEditingController phoneController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController passportNumberController = TextEditingController();
  TextEditingController dateOfBirthController = TextEditingController();
  TextEditingController addressController = TextEditingController();
  TextEditingController passportController = TextEditingController();
  TextEditingController nidController = TextEditingController();
  TextEditingController drivingLicenceController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
