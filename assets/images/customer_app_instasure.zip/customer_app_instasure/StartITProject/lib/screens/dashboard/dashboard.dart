// ignore_for_file: unnecessary_new

import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:instasure/Utilities/homeMenu.dart';
import 'package:instasure/Utilities/userPref.dart';
import 'package:instasure/domains/models/dashboard/dashboardModel.dart';
import 'package:instasure/domains/repo/apiClientCustomerDasboard.dart';
import 'package:instasure/screens/deviceInsurance/claimRequests.dart';
import 'package:instasure/screens/deviceInsurance/deviceInsuranceClaimHistory.dart';
import 'package:instasure/screens/deviceInsurance/deviceInsuranceHistory.dart';
import 'package:instasure/screens/travelInsurance/travelInsuranceHistory.dart';
import 'package:instasure/widgets/topView4.dart';

class DashBoard extends StatefulWidget {
  const DashBoard({Key? key}) : super(key: key);

  @override
  _DashBoardState createState() => _DashBoardState();
}

class _DashBoardState extends State<DashBoard> {
//class LoginPage extends StatelessWidget {
  final ApiClientCustomerDasboard _apiClient = ApiClientCustomerDasboard();
  late DashboardModel dashboardModel;
  var loading = true;

  @override
  void initState() {
    super.initState();
    () async {
      await Future.delayed(Duration.zero);
      getdashboardData();
    }();
  }

  Future<void> getdashboardData() async {
    EasyLoading.instance.userInteractions = false;
    EasyLoading.show(status: 'Processing...');
    UserPref prefs = UserPref();
    Future<String?> token = prefs.getTokenFromPref();
    String? accessToken = await token;
    print("accessToken:$accessToken");
    dynamic res = await _apiClient.getDashBoardData(accessToken!);
    EasyLoading.dismiss();
    if (res.statusCode == 200) {
      if (res.data['code'] == 200) {
        DashboardModel _dashboardModel =
            DashboardModel.fromJson(res.data['data']);
        setState(() {
          dashboardModel = _dashboardModel;
          loading = false;
        });
      } else {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('${res.data['message']}'),
          backgroundColor: Colors.red.shade300,
        ));
        // ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        //   content: Text('Error: ${res.data['data']['phone'][0]}'),
        //   backgroundColor: Colors.red.shade300,
        // ));

      }
    } else {}
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body:
          // loading
          //     ? const Center(
          //         child: CircularProgressIndicator(),
          //       )
          //     :
          Center(
              child: Padding(
        padding: const EdgeInsets.all(0),
        child: SingleChildScrollView(
          child: Column(
            children: [
              Stack(
                children: [
                  const TopView4(),
                  Positioned(
                    bottom: 20.0,
                    left: 40.0,
                    child: SizedBox(
                        height: 30,
                        width: 30,
                        // color: const Color.fromRGBO(0, 46, 91, 1.0),
                        // padding: const EdgeInsets.fromLTRB(10, 15, 10, 5),
                        child: TextButton(
                          child: Image.asset('assets/back_button_icon.png'),
                          onPressed: () {
                            Navigator.of(context).pop();
                          },
                        )),
                  )
                ],
              ),
              const SizedBox(height: 20),
              createHeaderWidget(),
              const SizedBox(height: 20),
              buildGridView(),
            ],
          ),
        ),
      )),
      backgroundColor: const Color(0xFFEFF7FF),
    );
  }

  buildGridView() {
    return Padding(
      padding: const EdgeInsets.only(right: 20, top: 0, bottom: 0, left: 20),
      child: SizedBox(
        height: 600,
        // color: Colors.red,
        //width: (MediaQuery.of(context).size.width - 30) / 3,
        child: GridView.count(
          crossAxisCount: 2,
          crossAxisSpacing: 35,
          mainAxisSpacing: 30,
          childAspectRatio: 0.71,
          children: List.generate(
            dashBoardMenus.length,
            (index) {
              var menu = dashBoardMenus[index];
              var total = '';
              if (index == 0) {
                total = loading ? '' : '${dashboardModel.totalMediclaimOrder}';
              } else if (index == 1) {
                total = loading ? '' : '${dashboardModel.totalDeviceOrder}';
              } else if (index == 2) {
                total = loading ? '' : '${dashboardModel.totalDeviceClaim}';
              } else if (index == 3) {
                total = loading
                    ? ''
                    : '${dashboardModel.totalDeviceServiceRequest}';
              }
              return GestureDetector(
                onTap: () {
                  if (index == 0) {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const TravelInsuranceHistory()),
                    );
                  } else if (index == 1) {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const DeviceInsuranceHistory()),
                    );
                  } else if (index == 2) {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) =>
                              const DeviceInsuranceClaimHistory()),
                    );
                  } else if (index == 3) {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const ClaimRequests()),
                    );
                  }
                },
                child: Container(
                    width: (MediaQuery.of(context).size.width - 45) / 3,
                    alignment: Alignment.center,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        const SizedBox(
                          height: 20,
                        ),
                        Stack(
                          alignment: Alignment.center,
                          children: [
                            Image(
                              image: AssetImage(menu["img"]),
                              height: 50,
                            ),

                          ],
                        ),
                        const SizedBox(height: 10.0),
                        Container(
                          width: 40,
                          height: 25,
                          child: Center(
                            child: Text(
                              total,
                              textAlign: TextAlign.center,
                              style: const TextStyle(
                                fontFamily: 'Roboto Slab',
                                fontSize: 22,
                                color: Color(0xffffffff),
                              ),
                            ),
                          ),
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(5),
                              color: Colors.black87),
                        ),
                        const SizedBox(height: 28.0),

                        Text(
                          menu["name"],
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            fontFamily: 'Roboto Slab',
                            fontSize: 14,
                            color: Color(0xff000000),
                          ),
                        ),

                      ],
                    ),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(40),
                      boxShadow: const [
                        BoxShadow(
                            color: Color(0xFFFFFFFF),
                            blurRadius: 6,
                            spreadRadius: 0,
                            offset: Offset(-3, -3)),
                      ],
                      color: const Color(0xFFF0F3F6),
                    )),
              );

              // );
            },
          ),
        ),
      ),
    );
  }
  createHeaderWidget() {
    return Container(
      height: 38,
      child: const Center(
        child: Text(
          'Dashboard',
          textAlign: TextAlign.center,
          style: TextStyle(
            fontFamily: 'Roboto Slab',
            fontSize: 16,
            color: Color(0xff002E5B),
          ),
        ),
      ),
      decoration: const BoxDecoration(color: Color(0xffF0F3F6), boxShadow: [
        BoxShadow(
            color: Color(0xffffffff),
            blurRadius: 6,
            spreadRadius: 0,
            offset: Offset(-3, -3)),
        BoxShadow(
            color: Color(0xffDDE4EF),
            blurRadius: 6,
            spreadRadius: 0,
            offset: Offset(3, 3)),
      ]),
    );
  }
}

class $dashboardModel {}
