import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:image_picker/image_picker.dart';
import 'package:instasure/Utilities/menuList.dart';
import 'package:instasure/Utilities/profile.dart';
import 'package:instasure/Utilities/userPref.dart';
import 'package:instasure/domains/models/auth/user.dart';
import 'package:instasure/domains/repo/apiClientCustomerDasboard.dart';
import 'package:instasure/screens/profileDocument/nidUploadDocumnet.dart';
import 'package:instasure/screens/profileDocument/passportUploadDocumnet.dart';
import 'package:instasure/widgets/topView4.dart';
import 'package:intl/intl.dart';
import '../../Utilities/constant.dart';
import '../../domains/repo/apis.dart';
import '../profileDocument/drivingLicenceUploadDocument.dart';
import 'package:http/http.dart' as http;
import 'package:instasure/Utilities/validator.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({Key? key}) : super(key: key);

  @override
  _ProfileScreenState createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  late var imagePath = null;
  late var avatorImage = null;
  late var passFrontimagePath = null;
  late var passBackImagePath = null;
  late var nidFrontimagePath = null;
  late var nidBackImagePath = null;
  late var drivingLicenceImagePath = null;
  DateTime? _selectedDate;
  bool isDataOfBirthClick = false;
  bool isFromUpdated = false;
  final ApiClientCustomerDasboard _apiClient = ApiClientCustomerDasboard();
  late User? user;
  var loading = true;
  TextEditingController userTypeController = TextEditingController();
  TextEditingController nameController = TextEditingController();
  TextEditingController phoneController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController passportNumberController = TextEditingController();
  TextEditingController dateOfBirthController = TextEditingController();
  TextEditingController addressController = TextEditingController();
  TextEditingController passportController = TextEditingController();
  TextEditingController nidController = TextEditingController();
  TextEditingController drivingLicenceController = TextEditingController();

  TextEditingController controller = TextEditingController();

  late List<ProfileAttribute> profileAttributes;

  @override
  void initState() {
    super.initState();
    profileAttributes = ProfileAttribute.getProfileAttributes();
        () async {
      await Future.delayed(Duration.zero);
      getUsereProfileData();
    }();
  }

  Future<void> updateProfileInfo() async {
    if (Validator.validateName(nameController.text) != null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: const Text('Enter your name'),
        backgroundColor: Colors.red.shade300,
      ));
      return;
    }

    if (Validator.validatePhoneNumber(phoneController.text) != null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: const Text('Enter valid phone number'),
        backgroundColor: Colors.red.shade300,
      ));
      return;
    }

    if (Validator.validateEmail(emailController.text) != null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: const Text('Enter valid email'),
        backgroundColor: Colors.red.shade300,
      ));
      return;
    }

    EasyLoading.instance.userInteractions = false;
    EasyLoading.show(status: 'Processing...');

    UserPref prefs = UserPref();
    Future<String?> token = prefs.getTokenFromPref();
    String? accessToken = await token;
    var headers = {
      'Accept': 'application/json',
      'Authorization': 'Bearer $accessToken'
    };
    String uri = Constants.BASE_URL + ApisEndPoints.customerProfileUpdate;
    var request = http.MultipartRequest('POST', Uri.parse(uri));
    request.fields.addAll({
      'name': nameController.text,
      'phone': phoneController.text,
      'email': emailController.text,
      'address': addressController.text,
      'passport_number': passportNumberController.text,
      'dob': dateOfBirthController.text
    });
    if (avatorImage == null) {
      // do nothing
    } else {
      request.files.add(
          await http.MultipartFile.fromPath('avatar_original', avatorImage));
    }

    request.headers.addAll(headers);
    http.StreamedResponse response = await request.send();
    // ScaffoldMessenger.of(context).hideCurrentSnackBar();
    EasyLoading.dismiss();
    if (response.statusCode == 200) {
      isFromUpdated = true;
      //showMessage('Your profile successfully updated');
      // print(await response.stream.bytesToString());
      getUsereProfileData();
    } else {
      print(response.reasonPhrase);
    }
  }

  Future<void> getUsereProfileData() async {
    EasyLoading.instance.userInteractions = false;
    EasyLoading.show(status: 'Processing...');

    UserPref prefs = UserPref();
    Future<String?> token = prefs.getTokenFromPref();
    String? accessToken = await token;
    dynamic res = await _apiClient.getProfileData(accessToken!);
    EasyLoading.dismiss();
    // ScaffoldMessenger.of(context).hideCurrentSnackBar();
    if (res.statusCode == 200) {
      if (res.data['code'] == 200) {
        User _user = User.fromJson(res.data['data']);
        if(isFromUpdated){
          showMessage('Your profile successfully updated');
          isFromUpdated = false;
        }
        setState(() {
          user = _user;
          loading = false;
          nameController.text = user?.name ?? '';
          phoneController.text = user?.phone ?? '';
          emailController.text = user?.email ?? '';
          imagePath = user?.avatarOriginal;
          passFrontimagePath = user?.passportImg = user?.passportImg ;
          passBackImagePath = user?.passportImg = user?.passportImg;
          nidFrontimagePath = user?.nid = user?.nid;
          nidBackImagePath = user?.nid = user?.nid;
          passportNumberController.text = user?.passportNumber;
          drivingLicenceImagePath = user?.driving_licence_img;
          userTypeController.text = user?.userType ?? '';
          addressController.text = user?.address ?? '';
          nameController.text = user?.name ?? '';
          phoneController.text = user?.phone ?? '';
          emailController.text = user?.email ?? '';
        });
      } else {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('${res.data['message']}'),
          backgroundColor: Colors.red.shade300,
        ));
      }
    } else {}
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () {
        Navigator.pop(context);
        return Future.value(false);
      },
      child: Scaffold(
        body: Column(
          // mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Stack(
              children: [
                const TopView4(),
                Positioned(
                  bottom: 20.0,
                  left: 40.0,
                  child: SizedBox(
                      height: 30,
                      width: 30,
                      // color: const Color.fromRGBO(0, 46, 91, 1.0),
                      // padding: const EdgeInsets.fromLTRB(10, 15, 10, 5),
                      child: TextButton(
                        child: Image.asset('assets/back_button_icon.png'),
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                      )),
                )
              ],
            ),
            /*ProfileWidget(
              imagePath: loading ? '' : user?.avatarOriginal ?? '',
              isEdit: true,
              onClicked: () async {
                //_showChoiceDialog(context);
                print("object");
              },
            ),*/
            const SizedBox(
              height: 10,
            ),
            buildProfileImage(context),
            const SizedBox(
              height: 10,
            ),
            buildProfile(),
          ],
        ),
        backgroundColor: const Color(0xFFEFF7FF),
      ),
    );
  }

  Widget buildProfile() {
    return Expanded(
      child: ListView.builder(
        primary: false,
        scrollDirection: Axis.vertical,
        shrinkWrap: true,
        // ignore: unnecessary_null_comparison
        itemCount: profileAttributes.length,
        itemBuilder: (BuildContext context, int index) {
          var profileAttribute = profileAttributes[index];
          if (index == 0) {
            controller = userTypeController;
            loading
                ? controller.text = ''
                : controller.text = user?.userType ?? '';
          } else if (index == 1) {
            controller = nameController;
            loading ? controller.text = '' : controller.text = user?.name ?? '';
          } else if (index == 2) {
            controller = phoneController;
            loading
                ? controller.text = ''
                : controller.text = user?.phone ?? '';
          } else if (index == 3) {
            controller = emailController;
            loading
                ? controller.text = ''
                : controller.text = user?.email ?? '';
          } else if (index == 4) {
            controller = passportNumberController;
            loading
                ? controller.text = ''
                : controller.text = user?.passportNumber ?? '';
          } else if (index == 5) {
            controller = dateOfBirthController;
            isDataOfBirthClick
                ? controller.text = dateOfBirthController.text
                : loading
                ? controller.text = ''
                : controller.text = user?.dob ?? '';
          } else if (index == 6) {
            controller = addressController;
            loading
                ? controller.text = ''
                : controller.text = user?.address ?? '';
          } else if (index == 7) {
            controller = passportController;
          } else if (index == 8) {
            controller = nidController;
          } else if (index == 9) {
            controller = drivingLicenceController;
          }

          return Padding(
            padding: const EdgeInsets.only(left: 55.0, right: 55.0, top: 10),
            child: GestureDetector(
              onTap: () => onTapAction(profileAttribute.type),
              child: index == 10
                  ? Padding(
                padding: const EdgeInsets.only(top: 20, bottom: 60),
                child: Container(
                  height: 30,
                  width: MediaQuery.of(context).size.width - 70,
                  //padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
                  child: TextButton(
                    child: const Text(
                      'Update Profile',
                      style: TextStyle(color: Colors.white),
                    ),
                    onPressed: () {
                      updateProfileInfo();
                    },
                  ),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                          color:
                          const Color(0xff000000).withOpacity(0.16),
                          blurRadius: 3,
                          spreadRadius: 0,
                          offset: const Offset(0, 3)),
                    ],
                    color: const Color(0xff002E5B),
                  ),
                ),
              )
                  : Container(
                  height: 35,
                  padding: const EdgeInsets.fromLTRB(0, 0, 0, 0),
                  child: TextField(
                    enabled: profileAttribute.isEnable,
                    textAlignVertical: TextAlignVertical.center,
                    controller: controller,

                    // validator: (value) =>
                    //     Validator.validatePhoneNumber(value ?? ""),
                    decoration: InputDecoration(
                        contentPadding: const EdgeInsets.only(
                            left: 5, top: 0, right: 5, bottom: 0),
                        prefixIcon: Image.asset(profileAttribute.image),
                        suffixIcon: index > 6
                            ? Image.asset(
                            'assets/profile/visiblity_icon.png')
                            : null,
                        filled: true,
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20.0),
                          borderSide: const BorderSide(
                              color: Colors.transparent, width: 0.0),
                        ),
                        hintText: profileAttribute.name,
                        isDense: true,
                        isCollapsed: false),
                  ),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: const [
                      BoxShadow(
                          color: Color(0xFFFFFFFF),
                          blurRadius: 6,
                          spreadRadius: 0,
                          offset: Offset(-3, -3)),
                      BoxShadow(
                          color: Color(0xFFDDE4EF),
                          blurRadius: 6,
                          spreadRadius: 0,
                          offset: Offset(3, 3)),
                    ],
                    color: const Color(0xffF0F3F6),
                  )),
            ),
          );
        },
      ),
    );
  }

  onTapAction(profileAttributesTypes type) {
    print('onTapAction:$type');
    if (type == profileAttributesTypes.passport) {
/*      Navigator.push(context,
          MaterialPageRoute(builder: (context) => const PassportUploadDocumnet(
        frontImage: passFrontimagePath,
        backImage: passBackImagePath));*/
      Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => PassportUploadDocumnet(
                passportfrontImageUri: passFrontimagePath,
                )),
      );
    } else if (type == profileAttributesTypes.nid) {
      Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => NidUploadDocumnet(
                nidFrontimagePath: nidFrontimagePath,
                nidBackImagePath: nidBackImagePath)),
      );
    } else if (type == profileAttributesTypes.drivingLincence) {
      Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) =>
                DrivingLicence(drivingLicenceImage: drivingLicenceImagePath)),
      );
    } else if (type == profileAttributesTypes.dateOfBirth) {
      isDataOfBirthClick = true;
      _presentDatePicker();
    }
  }

  Widget buildProfileImage(BuildContext context) {
    var image;
    if (loading) {
      image = const AssetImage('assets/user_default_profile.png');
    } else {
      image = avatorImage != null
          ? FileImage(File(avatorImage))
          : NetworkImage(imagePath);
    }

    return GestureDetector(
      onTap: () => _showChoiceDialog(context),
      child: Container(
          height: 150,
          width: 150,
          // color: Colors.red,
          child: Padding(
              padding: const EdgeInsets.all(5),
              child: CircleAvatar(
                backgroundImage: image,
                radius: 70,
                backgroundColor: Colors.transparent,
              )),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(75),
            boxShadow: const [
              BoxShadow(
                  color: Color(0xFFFFFFFF),
                  blurRadius: 6,
                  spreadRadius: 0,
                  offset: Offset(-3, -3)),
            ],
            color: const Color(0xffF0F3F6),
          )),
    );
  }

  Future<void> _showChoiceDialog(BuildContext context) {
    return showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: const Text(
              "Choose option",
              style: TextStyle(color: Colors.blue),
            ),
            content: SingleChildScrollView(
              child: ListBody(
                children: [
                  const Divider(
                    height: 1,
                    color: Colors.blue,
                  ),
                  ListTile(
                    onTap: () {
                      openGallery();
                      Navigator.of(context).pop();
                    },
                    title: const Text("Gallery"),
                    leading: const Icon(
                      Icons.account_box,
                      color: Colors.blue,
                    ),
                  ),
                  const Divider(
                    height: 1,
                    color: Colors.blue,
                  ),
                  ListTile(
                    onTap: () {
                      openCamrea();
                      Navigator.of(context).pop();
                    },
                    title: const Text("Camera"),
                    leading: const Icon(
                      Icons.camera,
                      color: Colors.blue,
                    ),
                  ),
                ],
              ),
            ),
          );
        });
  }

  Future<void> openCamrea() async {
    final ImagePicker _picker = ImagePicker();
    final XFile? image = await _picker.pickImage(source: ImageSource.camera);
    setState(() {
      avatorImage = image!.path.toString();
    });
  }

  Future<void> openGallery() async {
    final ImagePicker _picker = ImagePicker();
    final XFile? image = await _picker.pickImage(source: ImageSource.gallery);
    print("image:${image}");
    if (image != null) {
      setState(() {
        avatorImage = image.path.toString();
      });
    }
  }

  showMessage(String message) {
    Fluttertoast.showToast(
        msg: message,
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.CENTER,
        timeInSecForIosWeb: 1,
        backgroundColor: Colors.blue,
        textColor: Colors.white,
        fontSize: 16.0);
  }

  void _presentDatePicker() {
    showDatePicker(
        context: context,
        initialDate: DateTime.now(),
        firstDate: DateTime(1900),
        lastDate: DateTime.now())
        .then((pickedDate) {
      // Check if no date is selected
      if (pickedDate == null) {
        return;
      }
      setState(() {
        // using state so that the UI will be rerendered when date is picked
        _selectedDate = pickedDate;
        final DateFormat formatter = DateFormat('yyyy-MM-dd');
        final String formatted = formatter.format(_selectedDate!);
        dateOfBirthController.text = formatted.toString();
      });
    });
  }
}
