// ignore_for_file: unnecessary_new
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:instasure/Utilities/helper.dart';
import 'package:instasure/Utilities/userPref.dart';
import 'package:instasure/domains/models/dashboard/deviceDiagnosticPackage.dart';
import 'package:instasure/domains/models/dashboard/mobileDiagnosisReportetail.dart';
import 'package:instasure/domains/repo/apiClientCustomerDasboard.dart';
import 'package:instasure/screens/diagonostic/checkDeviceFeature.dart';
import 'package:instasure/widgets/rowWidget2.dart';
import 'package:instasure/widgets/rowWidget3.dart';
import 'package:instasure/widgets/topView4.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../domains/models/dashboard/diagnosisReportList.dart';
import '../diagonostic/childDealerSelectPackage.dart';
import 'package:device_info_plus/device_info_plus.dart';

class DiagnosisReportDetail extends StatefulWidget {
  const DiagnosisReportDetail({Key? key, required this.id}) : super(key: key);
  final String id;

  @override
  State<DiagnosisReportDetail> createState() => _DiagnosisReportDetailState();
}

class _DiagnosisReportDetailState extends State<DiagnosisReportDetail> {
  final ApiClientCustomerDasboard _apiClient = ApiClientCustomerDasboard();
  MobileDiagnosisReportetail? mobileDiagnosisReportetail;
  DeviceDiagnosticPackage? deviceDiagnosticPackage;
  static final DeviceInfoPlugin deviceInfoPlugin = DeviceInfoPlugin();
  SharedPreferences? preferences;
int have_details=0;
int run_diag_2=0;
  String _is_order_paid='';
  String _order_expire_date='';
  var _is_diagnosis_required='0';
  int not_show_start=1;

  int load_done=0;

  var loading = true;




  Map<String, dynamic> _deviceData = <String, dynamic>{};
  ///////////////////////////////////////////////////

  //////////////////////////////////////////////////











  @override
void initState()  {
    super.initState();


    initializePreference().whenComplete((){
    });


    () async {
      await Future.delayed(Duration.zero);
      getParentDealerDetails();
    }();

  }


  Future<void> initializePreference() async{


    var deviceData = <String, dynamic>{};
    try {
      if (Platform.isAndroid) {
        deviceData = _readAndroidBuildData(await deviceInfoPlugin.androidInfo);
      } else if (Platform.isIOS) {
        deviceData = _readIosDeviceInfo(await deviceInfoPlugin.iosInfo);
      }
    }on Exception catch (_) {
      print('never reached');
    }


    setState(() {
      loading = false;
      _deviceData = deviceData;

    });






    this.preferences = await SharedPreferences.getInstance();
   // this.preferences?.setString("name", "Peter");
  }


  Future<void> getParentDealerDetails() async {
    UserPref prefs = UserPref();
    Future<String?> token = prefs.getTokenFromPref();
    String? accessToken = await token;
    EasyLoading.instance.userInteractions = false;
    EasyLoading.show(status: 'Processing...');

    dynamic res =
        await _apiClient.mobileDiagnosisReportDetails(widget.id, accessToken!);
    EasyLoading.dismiss();
    print(res);


    have_details=res.statusCode;

    if (res.statusCode == 200) {
      if (res.data['code'] == 200) {
        // InsuranceHistoryModel histories =
        MobileDiagnosisReportetail _mobileDiagnosisReportetail =
            MobileDiagnosisReportetail.fromJson(res.data['data']);

print('ddt');

        _is_order_paid=res.data['data']['_is_order_paid'].toString();
        _order_expire_date=res.data['data']['_order_expire_date'].toString();
        _is_diagnosis_required=res.data['data']['_is_diagnosis_required'].toString();

        print(res.data['data']['_is_order_paid'].toString());

        /*_is_order_paid='paid';
        _order_expire_date='date';
        _is_diagnosis_required='1';*/


print(_is_order_paid+_order_expire_date);

        //String serial_data_=_mobileDiagnosisReportetail.serialNumber;

        print('\\\\');





        setState(() {
          run_diag_2=1;
          mobileDiagnosisReportetail = _mobileDiagnosisReportetail;
          print('auto_id');
          print(_deviceData['id']);

          print('batteryHealthStatus');
          print(mobileDiagnosisReportetail?.batteryHealthStatus);

          if(_deviceData['id']==mobileDiagnosisReportetail?.serialNumber){
            not_show_start=0;
          }else{
            not_show_start=1;
          }

          loading = false;
          String? gg=mobileDiagnosisReportetail?.serialNumber;
          print('this_is'+gg!);
           this.preferences?.setString("serial_number", _deviceData['id']??"Unknown");
        });


     //   initializePreference().whenComplete((){
        //  setState(() {



         // });
       // });



      } else {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('${res.data['message']}'),
          backgroundColor: Colors.red.shade300,
        ));
        // ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        //   content: Text('Error: ${res.data['data']['phone'][0]}'),
        //   backgroundColor: Colors.red.shade300,
        // ));

      }
    } else {
      setState(() {
        run_diag_2=1;
        mobileDiagnosisReportetail = null;
        loading = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('${res.data['data']}'),
        backgroundColor: Colors.red.shade300,
      ));
    }
  }

  Future<void> getPackages(String id) async {
    UserPref prefs = UserPref();
    Future<String?> token = prefs.getTokenFromPref();
    String? accessToken = await token;
    EasyLoading.show(status: 'loading...');
    dynamic res = await _apiClient.getDeviceInsurancePackage(id, accessToken!);
    EasyLoading.dismiss();
    if (res.statusCode == 200) {
      if (res.data['code'] == 200) {
        // InsuranceHistoryModel histories =
        DeviceDiagnosticPackage _deviceDiagnosticPackage = DeviceDiagnosticPackage.fromJson(res.data['data']);
        Navigator.push(
          context,
          MaterialPageRoute(
              builder: (context) => SelectPackage(deviceDiagnosticPackage: _deviceDiagnosticPackage,insuranceId: id)),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('${res.data['message']}'),
          backgroundColor: Colors.red.shade300,
        ));
        // ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        //   content: Text('Error: ${res.data['data']['phone'][0]}'),
        //   backgroundColor: Colors.red.shade300,
        // ));

      }
    } else {
      setState(() {
        mobileDiagnosisReportetail = null;
        loading = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('${res.data['data']}'),
        backgroundColor: Colors.red.shade300,
      ));
    }
  }

  @override
  Widget build(BuildContext context) {

 return Scaffold(


   appBar: AppBar(
     // title: const Text('Home'),

     // title: Text("YOUR_APPBAR_TITLE"),
     // automaticallyImplyLeading: false,



     title: Image.asset('assets/instasure_icon.png',fit: BoxFit.contain, height: 32,),

     leading: new IconButton(
       icon: new Icon(Icons.arrow_back, color: const Color(0xff002E5B),),
       onPressed: () =>             Navigator.push( context, MaterialPageRoute( builder: (context) => const DiagnosisReportList()), ),
     ),


     automaticallyImplyLeading: true,
     backgroundColor: Colors.white,
     actions: <Widget>[
       IconButton(
         // AssetImage("assets/home/insurance.png"),
         icon: Icon(
           Icons.help_center,
           color: const Color(0xff002E5B),
         ),
         /*icon: Icon(
                Icons.settings,
                color: Colors.white,
              ),*/
         onPressed: () {
           setState(() {

           });
           /* Navigator.push(
                   context,
                   MaterialPageRoute(builder: (context) => const  MenuScreen()),
                 );*/

         },
       )
     ],
   ),
      body: loading
          ? Center(
              child: Text(""),
            )
          : Center(
              child: Padding(
              padding: const EdgeInsets.all(0),
              child: Column(
                children: [

                  Expanded(
                    child: ListView(
                      children: <Widget>[
                        const SizedBox(height: 20.0),
                        createHeader(),
                        const SizedBox(height: 20.0),

                  if (have_details == 200)
                    createCustomerDetails(),
                        if (have_details != 200)
                          createCustomerDetails_diag(),
                          const SizedBox(height: 80.0),
                      ],
                    ),
                  ),
                ],
              ),
            )),
      backgroundColor: const Color(0xFFEFF7FF),
    );
  }
  createHeader() {
    return Container(
      height: 38,
      child: const Center(
        child: Text(
          'Mobile Diagnosis Report Details',
          textAlign: TextAlign.center,
          style: TextStyle(
            fontFamily: 'Roboto Slab',
            fontSize: 16,
            color: Color(0xff002E5B),
          ),
        ),
      ),
      decoration: const BoxDecoration(color: Color(0xffF0F3F6), boxShadow: [
        BoxShadow(
            color: Color(0xffffffff),
            blurRadius: 6,
            spreadRadius: 0,
            offset: Offset(-3, -3)),
        BoxShadow(
            color: Color(0xffDDE4EF),
            blurRadius: 6,
            spreadRadius: 0,
            offset: Offset(3, 3)),
      ]),
    );
  }


  addFilterOption() {
    return Padding(
      padding: const EdgeInsets.only(right: 20),
      child: Align(
        alignment: Alignment.centerRight,
        child: Container(
          height: 35,
          width: 60,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(6),
            // border: Border.all(color: const Color(0xff00B3FF)),
            boxShadow: [
              BoxShadow(
                  color: const Color(0xff000000).withOpacity(0.16),
                  blurRadius: 6,
                  spreadRadius: 0,
                  offset: const Offset(0, 3)),
            ],
            color: const Color(0xffffffff),
          ),
          child: TextButton.icon(
              onPressed: null,
              icon: Image.asset(
                'assets/filter_icon.png',
                color: const Color(0xff000000),
              ),
              label: const Text(
                'All',
                style: TextStyle(color: Color(0xff000000), fontSize: 12),
              )),
        ),
      ),
    );
  }

  createCustomerDetails_diag() {

    return Padding(
        padding: const EdgeInsets.only(right: 14, top: 0, bottom: 0, left: 14),
        child: Container(
          // padding: const EdgeInsets.all(10.0),
          //width: (MediaQuery.of(context).size.width - 45) / 3,
            height: 100,
            alignment: Alignment.centerLeft,

            child: Padding(
              padding: const EdgeInsets.only(left: 20, right: 20, top: 20),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
if(run_diag_2==1)
  Center(
                      child: Container(
                        height: 35,
                        width: 150,
                        // padding: const EdgeInsets.fromLTRB(10, 15, 10, 5),
                        child: TextButton(
                          child: const Text(
                            'Run Diagnosis',
                            style: TextStyle(color: Colors.white),
                          ),
                          onPressed: () {
                            // getPackages("${mobileDiagnosisReportetail?.id}");

                            _diagnosisAlert(context);

                          },
                        ),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                          boxShadow: [
                            BoxShadow(
                                color:
                                const Color(0xff000000).withOpacity(0.16),
                                blurRadius: 3,
                                spreadRadius: 0,
                                offset: const Offset(0, 3)),
                          ],
                          color: const Color(0xff002E5B),
                        ),
                      ),
                    ),



                ],
              ),
            )));
  }



  createCustomerDetails() {
    //String? gg=mobileDiagnosisReportetail?.serialNumber;
    //print('this_is'+gg!);

  String Minutes ='';
  if(mobileDiagnosisReportetail?.validFor>0){
       Minutes = 'Minutes';
  } else {
       Minutes = '';
  }


    return Padding(
        padding: const EdgeInsets.only(right: 14, top: 0, bottom: 0, left: 14),
        child: Container(
            // padding: const EdgeInsets.all(10.0),
            //width: (MediaQuery.of(context).size.width - 45) / 3,
            height: 650,
            alignment: Alignment.centerLeft,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(13),
              boxShadow: [
                BoxShadow(
                    color: const Color(0xff000000).withOpacity(0.51),
                    blurRadius: 16,
                    spreadRadius: 0,
                    offset: const Offset(0, 0)),
              ],
              color: const Color(0xffF0F3F6),
            ),
            child: Padding(
              padding: const EdgeInsets.only(left: 20, right: 20),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  const SizedBox(
                    height: 10,
                  ),
                  SizedBox(
                    height: 35,
                    child: RowWidget3(
                      title: "Serial Number:",
                      value: '${mobileDiagnosisReportetail?.serialNumber}',
                      tfSize: 15,
                      vfSize: 13,
                      txtcolor: const Color(0xff000000),
                    ),
                  ),
                  const Divider(
                    height: 1,
                    color: Color(0xff707070),
                  ),
                  SizedBox(
                    height: 35,
                    child: RowWidget3(
                      title: "Price:",
                      value: "${mobileDiagnosisReportetail?.price}",
                      tfSize: 15,
                      vfSize: 13,
                      txtcolor: const Color(0xff000000),
                    ),
                  ),
                  const Divider(
                    height: 1,
                    color: Color(0xff707070),
                  ),
                  SizedBox(
                    height: 35,
                    child: RowWidget3(
                      title: "Motherboard Status: ",
                      value: mobileDiagnosisReportetail?.microphoneStatus.toString() == "1"
                          ? "Yes"
                          : "No",
                      tfSize: 15,
                      vfSize: 13,
                      txtcolor: const Color(0xff000000),
                    ),
                  ),
                  const Divider(
                    height: 1,
                    color: Color(0xff707070),
                  ),
                  SizedBox(
                    height: 35,
                    child: RowWidget3(
                      title: "Battery Health Status:",
                      value:
                          mobileDiagnosisReportetail?.batteryHealthStatus.toString() == "1"
                              ? "Yes"
                              : "No",
                      tfSize: 15,
                      vfSize: 13,
                      txtcolor: const Color(0xff000000),
                    ),
                  ),
                  const Divider(
                    height: 1,
                    color: Color(0xff707070),
                  ),
                  SizedBox(
                    height: 35,
                    child: RowWidget3(
                      title: "FrontCamera Status:",
                      value:
                          mobileDiagnosisReportetail?.frontCameraStatus.toString() == "1"
                              ? "Yes"
                              : "No",
                      tfSize: 15,
                      vfSize: 13,
                      txtcolor: const Color(0xff000000),
                    ),
                  ),
                  const Divider(
                    height: 1,
                    color: Color(0xff707070),
                  ),
                  SizedBox(
                    height: 35,
                    child: RowWidget3(
                      title: "BackCamera Status:",
                      value: mobileDiagnosisReportetail?.backCameraStatus.toString() == "1"
                          ? "Yes"
                          : "No",
                      tfSize: 15,
                      vfSize: 13,
                      txtcolor: const Color(0xff000000),
                    ),
                  ),
                  const Divider(
                    height: 1,
                    color: Color(0xff707070),
                  ),
                  SizedBox(
                    height: 35,
                    child: RowWidget3(
                      title: "Microphone Status:",
                      value: mobileDiagnosisReportetail?.microphoneStatus.toString() == "1"
                          ? "Yes"
                          : "No",
                      tfSize: 15,
                      vfSize: 13,
                      txtcolor: const Color(0xff000000),
                    ),
                  ),
                  /*
                  const Divider(
                    height: 1,
                    color: Color(0xff707070),
                  ),
                  SizedBox(
                    height: 50,
                    child: RowWidget2(
                      title: "Trade Licence:",
                      value: '${mobileDiagnosisReportetail?.serialNumber}',
                      tfSize: 15,
                      vfSize: 13,
                      ttxtcolor: const Color(0xff000000),
                    ),
                  ),
                  const Divider(
                    height: 1,
                    color: Color(0xff707070),
                  ),
                  SizedBox(
                      height: 50,
                      child: RowWidget2(
                        title: "NID:",
                        value: '${mobileDiagnosisReportetail?.serialNumber}',
                        tfSize: 15,
                        vfSize: 13,
                        ttxtcolor: const Color(0xff000000),
                      )),
                      */
                  const Divider(
                    height: 1,
                    color: Color(0xff707070),
                  ),
                  SizedBox(
                    height: 35,
                    child: RowWidget3(
                      title: "Ram Status:",
                      value: mobileDiagnosisReportetail?.ramStatus.toString() == "1"
                          ? "Yes"
                          : "No",
                      tfSize: 15,
                      vfSize: 13,
                      txtcolor: const Color(0xff000000),
                    ),
                  ),
                  const Divider(
                    height: 1,
                    color: Color(0xff707070),
                  ),
                  SizedBox(
                    height: 35,
                    child: RowWidget3(
                      title: "Rom Status:",
                      value: mobileDiagnosisReportetail?.romStatus.toString() == "1"
                          ? "Yes"
                          : "No",
                      tfSize: 15,
                      vfSize: 13,
                      txtcolor: const Color(0xff000000),
                    ),
                  ),
                  const Divider(
                    height: 1,
                    color: Color(0xff707070),
                  ),
                  SizedBox(
                    height: 35,
                    child: RowWidget3(
                      title: "Display Screen Status:",
                      value:
                          mobileDiagnosisReportetail?.displayScreenStatus.toString() == "1"
                              ? "Yes"
                              : "No",
                      tfSize: 15,
                      vfSize: 13,
                      txtcolor: const Color(0xff000000),
                    ),
                  ),
                  const Divider(
                    height: 1,
                    color: Color(0xff707070),
                  ),
                  SizedBox(
                    height: 35,
                    child: RowWidget3(
                      title: "Status",
                      value: "${mobileDiagnosisReportetail?.status}",
                      tfSize: 15,
                      vfSize: 13,
                      txtcolor: const Color(0xff000000),
                    ),
                  ),
/*                  const Divider(
                    height: 1,
                    color: Color(0xff707070),
                  ),
                  SizedBox(
                    height: 35,
                    child: RowWidget3(
                      title: "Is Active:",
                      value: mobileDiagnosisReportetail?.isActive == "1"
                          ? "Yes"
                          : "No",
                      tfSize: 15,
                      vfSize: 13,
                      txtcolor: const Color(0xff000000),
                    ),
                  ),*/
                  const Divider(
                    height: 1,
                    color: Color(0xff707070),
                  ),
                  SizedBox(
                    height: 35,
                    child: RowWidget3(
                      title: "Note:",
                      value: "${mobileDiagnosisReportetail?.note}",
                      tfSize: 15,
                      vfSize: 13,
                      txtcolor: const Color(0xff000000),
                    ),
                  ),
                  const Divider(
                    height: 1,
                    color: Color(0xff707070),
                  ),





                if(mobileDiagnosisReportetail?.validityMessage!='Start Diagnosis')
                  SizedBox(
                    height: 35,
                    child: RowWidget3(
                      title: "Validity for: ",
                      value: "${mobileDiagnosisReportetail?.validFor <=0 ? mobileDiagnosisReportetail?.validityMessage :mobileDiagnosisReportetail?.validFor.toString()} "+Minutes,
                      tfSize: 15,
                      vfSize: 13,
                      txtcolor: const Color(0xff000000),
                    ),
                  ),
                  const Divider(
                    height: 1,
                    color: Color(0xff707070),
                  ),
                  const SizedBox(
                    height: 20,
                  ),




//

                  if (_is_order_paid =="paid")
                  SizedBox(
                    height: 35,
                    child: RowWidget3(
                      title: "Expired Date:",
                      value: "${_order_expire_date}",
                      tfSize: 15,
                      vfSize: 13,
                      txtcolor: const Color(0xff000000),
                    ),
                  ),
                  if (_is_order_paid =="paid")
                  const Divider(
                    height: 1,
                    color: Color(0xff707070),
                  ),
                  if (_is_order_paid=="paid")
                  const SizedBox(
                    height: 20,
                  ),










                   if (mobileDiagnosisReportetail?.validityMessage =="Get Package" && _is_order_paid!='paid')
                    Center(
                      child: Container(
                        height: 35,
                        width: 150,
                        // padding: const EdgeInsets.fromLTRB(10, 15, 10, 5),
                        child: TextButton(
                          child: const Text(
                            'Get Package',
                            style: TextStyle(color: Colors.white),
                          ),
                          onPressed: () {
                            getPackages("${mobileDiagnosisReportetail?.id}");
                          },
                        ),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                          boxShadow: [
                            BoxShadow(
                                color:
                                    const Color(0xff000000).withOpacity(0.16),
                                blurRadius: 3,
                                spreadRadius: 0,
                                offset: const Offset(0, 3)),
                          ],
                          color: const Color(0xff002E5B),
                        ),
                      ),
                    ),






                  if (not_show_start==0 && mobileDiagnosisReportetail?.validityMessage !="Get Package"  && _is_order_paid!='paid' &&  mobileDiagnosisReportetail?.validityMessage.toString()!='Wait for approval')
                    Center(
                      child: Container(
                        height: 35,
                        width: 150,
                        // padding: const EdgeInsets.fromLTRB(10, 15, 10, 5),
                        child: TextButton(
                          child: const Text(
                            'Run Diagnosis',
                            style: TextStyle(color: Colors.white),
                          ),
                          onPressed: () {
                           // getPackages("${mobileDiagnosisReportetail?.id}");

                            _diagnosisAlert(context);

                          },
                        ),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                          boxShadow: [
                            BoxShadow(
                                color:
                                const Color(0xff000000).withOpacity(0.16),
                                blurRadius: 3,
                                spreadRadius: 0,
                                offset: const Offset(0, 3)),
                          ],
                          color: const Color(0xff002E5B),
                        ),
                      ),
                    ),




                  if (_is_order_paid =="paid" &&
                      _is_diagnosis_required =='0' )
                  Text(
                    'You are insured!',
                    textAlign: TextAlign.center,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.green,),
                  ),









                  /*if (mobileDiagnosisReportetail?.is_order_paid ==
                      "pending")
                    Text(
                      'Your Insurance Service Is Active',
                      textAlign: TextAlign.center,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.green,),
                    )*/

                ],
              ),
            )));
  }
  Map<String, dynamic> _readAndroidBuildData(AndroidDeviceInfo build) {
    return <String, dynamic>{
      'version.securityPatch': build.version.securityPatch,
      'version.sdkInt': build.version.sdkInt,
      'version.release': build.version.release,
      'version.previewSdkInt': build.version.previewSdkInt,
      'version.incremental': build.version.incremental,
      'version.codename': build.version.codename,
      'version.baseOS': build.version.baseOS,
      'board': build.board,
      'bootloader': build.bootloader,
      'brand': build.brand,
      'device': build.device,
      'display': build.display,
      'fingerprint': build.fingerprint,
      'hardware': build.hardware,
      'host': build.host,
      'id': build.id,
      'manufacturer': build.manufacturer,
      'model': build.model,
      'product': build.product,
      'supported32BitAbis': build.supported32BitAbis,
      'supported64BitAbis': build.supported64BitAbis,
      'supportedAbis': build.supportedAbis,
      'tags': build.tags,
      'type': build.type,
      'isPhysicalDevice': build.isPhysicalDevice,
      //'androidId': build.androidId,
      'systemFeatures': build.systemFeatures,
    };
  }

  Map<String, dynamic> _readIosDeviceInfo(IosDeviceInfo data) {
    return <String, dynamic>{
      'name': data.name,
      'systemName': data.systemName,
      'systemVersion': data.systemVersion,
      'model': data.model,
      'localizedModel': data.localizedModel,
      'identifierForVendor': data.identifierForVendor,
      'isPhysicalDevice': data.isPhysicalDevice,
      'utsname.sysname:': data.utsname.sysname,
      'utsname.nodename:': data.utsname.nodename,
      'utsname.release:': data.utsname.release,
      'utsname.version:': data.utsname.version,
      'utsname.machine:': data.utsname.machine,
    };
  }


  void _diagnosisAlert(BuildContext context) {
    showDialog(
        context: context,
        builder: (context) {
          return CupertinoAlertDialog(
            title: const Text('Device Diagnosis'),
            content: const Text('Are you sure you want to device diagnosis? If yes, then please attach microphone with your device.'),
            actions: <Widget>[
              TextButton(
                  onPressed: () {
                    Navigator.pop(context);
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const CheckDeviceFeature()),
                    );
                  },
                  child: Text('Yes')),
              TextButton(
                onPressed: () {
                  Navigator.pop(context); //close Dialog
                },
                child: Text('No'),
              )
            ],
          );
        });
  }

}
