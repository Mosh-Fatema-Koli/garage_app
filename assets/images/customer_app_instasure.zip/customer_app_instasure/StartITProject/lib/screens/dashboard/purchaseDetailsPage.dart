// ignore_for_file: unnecessary_new

import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:instasure/Utilities/helper.dart';
import 'package:instasure/Utilities/userPref.dart';
import 'package:instasure/domains/repo/apiClientDeviceInsurance.dart';
import 'package:instasure/domains/repo/apiTravelInsurance.dart';
import 'package:instasure/screens/travelInsurance/paymentWebView.dart';
import 'package:instasure/widgets/rowWidget.dart';
import 'package:instasure/widgets/topView4.dart';

import '../../domains/models/purchaseDeviceInsuranceModel.dart';

class PurchaseDetailsPage extends StatefulWidget {
  const PurchaseDetailsPage(
      {Key? key, required this.purchaseDeviceInsuranceModel})
      : super(key: key);
  final PurchaseDeviceInsuranceModel purchaseDeviceInsuranceModel;

  @override
  _PurchaseDetailsPageState createState() => _PurchaseDetailsPageState();
}

class _PurchaseDetailsPageState extends State<PurchaseDetailsPage> {
  final ApiClientDeviceInsurance _apiClientDeviceInsurance =
      ApiClientDeviceInsurance();
  bool _value = false;

  Future<void> payNow() async {
    if (!_value) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: const Text("Please tick this box if you want to proceed"),
        backgroundColor: Colors.red.shade300,
      ));
      return;
    }
    // Map<String, dynamic> data = {
    //   "order_id": widget.purchaseDeviceInsuranceModel.id ?? '',
    // };
    print("hvjfdvsjhdv");
    EasyLoading.instance.userInteractions = false;
    EasyLoading.show(status: 'Processing...');
    UserPref prefs = UserPref();
    Future<String?> token = prefs.getTokenFromPref();
    String? accessToken = await token;
    dynamic res = await _apiClientDeviceInsurance.payNowForDeviceInsurancePurchase(
        widget.purchaseDeviceInsuranceModel.id.toString(), accessToken!);
    print(widget.purchaseDeviceInsuranceModel.id.toString());
    print('url'+res.data['data'].toString());
    //ScaffoldMessenger.of(context).hideCurrentSnackBar();
    EasyLoading.dismiss();
    if (res.statusCode == 200) {
      Navigator.push(
          context,
          MaterialPageRoute(
              builder: (context) => PaymentWebview(
                    url: res.data['data'].toString(),
                    id: widget.purchaseDeviceInsuranceModel.id.toString(),
                  )));
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('${res.data['message']}'),
        backgroundColor: Colors.red.shade300,
      ));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
          child: Padding(
        padding: const EdgeInsets.all(0),
        child: Column(
          children: [
            Stack(
              children: [
                const TopView4(),
                Positioned(
                  bottom: 20.0,
                  left: 40.0,
                  child: SizedBox(
                      height: 30,
                      width: 30,
                      // color: const Color.fromRGBO(0, 46, 91, 1.0),
                      // padding: const EdgeInsets.fromLTRB(10, 15, 10, 5),
                      child: TextButton(
                        child: Image.asset('assets/back_button_icon.png'),
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                      )),
                )
              ],
            ),
            Expanded(
              child: ListView(
                children: <Widget>[
                  const SizedBox(height: 0.0),
                  createHeaderWidget(),
                  const SizedBox(height: 20.0),
                  createCustomerInfoWidget(),
                  createDeviceDetailsWidget(),
                  createPriceDetailsWidget(),
                  createInsuranceDetailsWidget(),
                  createTotalPriceInfoWidget(),
                  // createValifityInfoWidget(),
                  // const SizedBox(height: 20.0),
                  const SizedBox(
                    height: 20,
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Row(
                      children: <Widget>[
                        Checkbox(
                          value: _value,
                          onChanged: (value) {
                            setState(() {
                              _value = value!;
                            });
                          },
                          activeColor: Colors.green,
                        ),
                        const Expanded(
                          child: Text(
                              "I confirm that I have read and agreed to the terms and conditions."),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(
                    height: 30,
                  ),
                  createBottomButtonWidget(),
                  const SizedBox(height: 80.0),
                ],
              ),
            ),
          ],
        ),
      )),
      backgroundColor: const Color(0xFFEFF7FF),
    );
  }

  createHeaderWidget() {
    return Container(
      height: 56,
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            const Text(
              "Device Insurance Purchase Details ",
              textAlign: TextAlign.center,
              style: TextStyle(
                fontFamily: 'Roboto Slab',
                fontSize: 16,
                color: Color(0xff002E5B),
              ),
            ),
            const SizedBox(
              height: 3,
            ),
            // Text(
            //   getDateString(
            //       widget.purchaseDeviceInsuranceModel.createdAt ?? " ",
            //       'dd MMM yyyy'),
            //   textAlign: TextAlign.center,
            //   style: const TextStyle(
            //     fontFamily: 'Roboto Slab',
            //     fontSize: 12,
            //     color: Color(0xff002E5B),
            //   ),
            // ),
          ],
        ),
      ),
      decoration: const BoxDecoration(color: Color(0xffF0F3F6), boxShadow: [
        BoxShadow(
            color: Color(0xffffffff),
            blurRadius: 6,
            spreadRadius: 0,
            offset: Offset(-3, -3)),
        BoxShadow(
            color: Color(0xffDDE4EF),
            blurRadius: 6,
            spreadRadius: 0,
            offset: Offset(3, 3)),
      ]),
    );
  }

  createBottomButtonWidget() {
    return Padding(
      padding: const EdgeInsets.only(right: 35, top: 10, bottom: 10, left: 35),
      child: SizedBox(
        height: 50,
        child: Container(
          height: 40,
          //padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
          child: TextButton(
            child: const Text(
              'Pay Now',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.white),
            ),
            //

            onPressed: payNow,
          ),
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                    color: const Color(0xff000000).withOpacity(0.16),
                    blurRadius: 3,
                    spreadRadius: 0,
                    offset: const Offset(0, 3)),
              ],
              color: const Color(0xff002E5B)),
        ),
      ),
    );
  }

  createCustomerInfoWidget() {
    return Padding(
        padding:
            const EdgeInsets.only(right: 14, top: 10, bottom: 10, left: 14),
        child: Container(
            // padding: const EdgeInsets.all(10.0),
            //width: (MediaQuery.of(context).size.width - 45) / 3,
            height: 164,
            alignment: Alignment.centerLeft,
            // padding: const EdgeInsets.only(top: 20),
            child: Padding(
              padding: const EdgeInsets.only(
                left: 30,
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  const SizedBox(height: 10.0),
                  const Text(
                    "CUSTOMER INFO",
                    textAlign: TextAlign.left,
                    style: TextStyle(
                      fontFamily: 'Roboto Slab',
                      fontSize: 16,
                      color: Color(0xff002E5B),
                      decoration: TextDecoration.underline,
                    ),
                  ),
                  const SizedBox(height: 10.0),
                  RowWidget(
                      title: "Name: ",
                      value: widget.purchaseDeviceInsuranceModel.customerInfo
                              ?.customerName ??
                          " ",
                      fSize: 16),
                  const SizedBox(height: 10.0),
                  RowWidget(
                      title: "Phone: ",
                      value: widget.purchaseDeviceInsuranceModel.customerInfo
                              ?.customerPhone ??
                          " ",
                      fSize: 16),
                  const SizedBox(height: 10.0),
                  RowWidget(
                      title: "Email: ",
                      value: widget.purchaseDeviceInsuranceModel.customerInfo
                              ?.customerEmail ??
                          " ",
                      fSize: 16),
                  const SizedBox(height: 10.0),
                  RowWidget(
                      title: "Nid or Passport Number: ",
                      value: widget.purchaseDeviceInsuranceModel.customerInfo
                              ?.number ??
                          " ",
                      fSize: 16),
                ],
              ),
            ),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(40),
              boxShadow: const [
                BoxShadow(
                    color: Color(0xFFFFFFFF),
                    blurRadius: 6,
                    spreadRadius: 0,
                    offset: Offset(-3, -3)),
              ],
              color: const Color(0xFFF0F3F6),
            )));
  }

  createDeviceDetailsWidget() {
    return Padding(
        padding:
            const EdgeInsets.only(right: 14, top: 10, bottom: 10, left: 14),
        child: Container(
            // padding: const EdgeInsets.all(10.0),
            //width: (MediaQuery.of(context).size.width - 45) / 3,
            height: 164,
            alignment: Alignment.centerLeft,
            // padding: const EdgeInsets.only(top: 20),
            child: Padding(
              padding: const EdgeInsets.only(
                left: 30,
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  const SizedBox(height: 10.0),
                  const Text(
                    "DEVICE INFO",
                    textAlign: TextAlign.left,
                    style: TextStyle(
                      fontFamily: 'Roboto Slab',
                      fontSize: 16,
                      color: Color(0xff002E5B),
                      decoration: TextDecoration.underline,
                    ),
                  ),
                  const SizedBox(height: 10.0),
                  RowWidget(
                      title: "Device Name: ",
                      value: widget.purchaseDeviceInsuranceModel.deviceInfo
                              ?.deviceName ??
                          " ",
                      fSize: 16),
                  const SizedBox(height: 5.0),
                  RowWidget(
                      title: "Device Brand: ",
                      value: widget.purchaseDeviceInsuranceModel.deviceInfo
                              ?.brandName ??
                          " ",
                      fSize: 16),
                  const SizedBox(height: 5.0),
                  RowWidget(
                      title: "Device Model:  ",
                      value: widget.purchaseDeviceInsuranceModel.deviceInfo
                              ?.modelName ??
                          " ",
                      fSize: 16),
                  const SizedBox(height: 5.0),
                  RowWidget(
                      title: "Device Price:  ",
                      value:
                          "৳ ${widget.purchaseDeviceInsuranceModel.deviceInfo?.devicePrice}",
                      fSize: 16),
                ],
              ),
            ),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(40),
              boxShadow: const [
                BoxShadow(
                    color: Color(0xFFFFFFFF),
                    blurRadius: 6,
                    spreadRadius: 0,
                    offset: Offset(-3, -3)),
              ],
              color: const Color(0xFFF0F3F6),
            )));
  }

  createInsuranceDetailsWidget() {
    return Padding(
        padding:
            const EdgeInsets.only(right: 14, top: 10, bottom: 10, left: 14),
        child: Container(
            // padding: const EdgeInsets.all(10.0),
            //width: (MediaQuery.of(context).size.width - 45) / 3,
            height: 164,
            alignment: Alignment.centerLeft,
            // padding: const EdgeInsets.only(top: 20),
            child: Padding(
              padding: const EdgeInsets.only(
                left: 30,
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  const SizedBox(height: 10.0),
                  const Text(
                    "INSURANCE DETAILS",
                    textAlign: TextAlign.left,
                    style: TextStyle(
                      fontFamily: 'Roboto Slab',
                      fontSize: 16,
                      color: Color(0xff002E5B),
                      decoration: TextDecoration.underline,
                    ),
                  ),
                  const SizedBox(height: 10.0),
                  RowWidget(
                      title: "Policy No: ",
                      value: widget.purchaseDeviceInsuranceModel.deviceInfo
                              ?.deviceName ??
                          " ",
                      fSize: 16),
                  const SizedBox(height: 5.0),
                  // RowWidget(
                  //     title: "Status: ",
                  //     value: widget.purchaseDeviceInsuranceModel.deviceInfo
                  //             ?.brandName ??
                  //         " ",
                  //     fSize: 16),
                  // const SizedBox(height: 5.0),
                  RowWidget(
                      title: "Claimable Amount:  ",
                      value:
                          "৳ ${widget.purchaseDeviceInsuranceModel.claimableAmount}",
                      fSize: 16),
                  const SizedBox(height: 5.0),
                  RowWidget(
                      title: "Claimed Amount:  ",
                      value:
                          "৳ ${widget.purchaseDeviceInsuranceModel.claimedAmount}",
                      fSize: 16),
                ],
              ),
            ),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(40),
              boxShadow: const [
                BoxShadow(
                    color: Color(0xFFFFFFFF),
                    blurRadius: 6,
                    spreadRadius: 0,
                    offset: Offset(-3, -3)),
              ],
              color: const Color(0xFFF0F3F6),
            )));
  }

  createPriceDetailsWidget() {
    return Padding(
        padding:
            const EdgeInsets.only(right: 14, top: 10, bottom: 10, left: 14),
        child: Container(
            // padding: const EdgeInsets.all(10.0),
            //width: (MediaQuery.of(context).size.width - 45) / 3,
            alignment: Alignment.centerLeft,
            // padding: const EdgeInsets.only(top: 20),
            child: Padding(
              padding: const EdgeInsets.only(
                left: 30,
                right: 30,
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  const SizedBox(height: 10.0),
                  const Text(
                    "INSURANCE PRICE INFO",
                    textAlign: TextAlign.left,
                    style: TextStyle(
                      fontFamily: 'Roboto Slab',
                      fontSize: 16,
                      color: Color(0xff002E5B),
                      decoration: TextDecoration.underline,
                    ),
                  ),
                  const SizedBox(height: 10.0),
                  Center(
                    child: SizedBox(
                        width: 280,
                        child: Table(
                          columnWidths: const {
                            0: FlexColumnWidth(1),
                            1: FixedColumnWidth(60),
                            2: FlexColumnWidth(1),
                          },
                          border: TableBorder.all(
                            color: Colors.grey,
                            //style: BorderStyle.solid,
                            style: BorderStyle.solid,
                            width: 1.0,
                          ),
                          // Allows to add a border decoration around your table
                          children: widget
                              .purchaseDeviceInsuranceModel.insuranceTypeValue!
                              .map((insurancePriceInfo) {
                            return TableRow(children: [
                              Center(
                                  child: Padding(
                                padding:
                                    const EdgeInsets.only(top: 20, bottom: 20),
                                child: Text(
                                  widget.purchaseDeviceInsuranceModel
                                              .insuranceTypeValue!
                                              .indexOf(insurancePriceInfo) ==
                                          0
                                      ? 'Insurance Type'
                                      : '${insurancePriceInfo.partsType}',
                                  textAlign: TextAlign.left,
                                  style: const TextStyle(
                                    fontFamily: 'Roboto Slab',
                                    fontSize: 12,
                                    color: Color(0xff002E5B),
                                  ),
                                ),
                              )),
                              Center(
                                child: Padding(
                                  padding: const EdgeInsets.only(
                                      top: 20, bottom: 20),
                                  child: Text(
                                    widget.purchaseDeviceInsuranceModel
                                                .insuranceTypeValue!
                                                .indexOf(insurancePriceInfo) ==
                                            0
                                        ? 'Price'
                                        : '৳ ${insurancePriceInfo.price}',
                                    textAlign: TextAlign.left,
                                    style: const TextStyle(
                                      fontFamily: 'Roboto Slab',
                                      fontSize: 12,
                                      color: Color(0xff002E5B),
                                    ),
                                  ),
                                ),
                              ),
                              Center(
                                  child: Padding(
                                padding:
                                    const EdgeInsets.only(top: 20, bottom: 20),
                                child: Text(
                                  widget.purchaseDeviceInsuranceModel
                                              .insuranceTypeValue!
                                              .indexOf(insurancePriceInfo) ==
                                          0
                                      ? 'Method'
                                      : '${insurancePriceInfo.insType}',
                                  textAlign: TextAlign.left,
                                  style: const TextStyle(
                                    fontFamily: 'Roboto Slab',
                                    fontSize: 12,
                                    color: Color(0xff002E5B),
                                  ),
                                ),
                              )),
                            ]);
                          }).toList(),
                        )),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                ],
              ),
            ),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(40),
              boxShadow: const [
                BoxShadow(
                    color: Color(0xFFFFFFFF),
                    blurRadius: 6,
                    spreadRadius: 0,
                    offset: Offset(-3, -3)),
              ],
              color: const Color(0xFFF0F3F6),
            )));
  }

  createRemainingClaimWidget2() {
    return Padding(
        padding:
            const EdgeInsets.only(right: 14, top: 10, bottom: 10, left: 14),
        child: Container(
            // padding: const EdgeInsets.all(10.0),
            //width: (MediaQuery.of(context).size.width - 45) / 3,
            height: 164,
            alignment: Alignment.centerLeft,
            // padding: const EdgeInsets.only(top: 20),
            child: Padding(
              padding: const EdgeInsets.only(
                left: 30,
                right: 30,
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  const SizedBox(height: 10.0),
                  const Text(
                    "REMAINING CLAIM",
                    textAlign: TextAlign.left,
                    style: TextStyle(
                      fontFamily: 'Roboto Slab',
                      fontSize: 16,
                      color: Color(0xff002E5B),
                      decoration: TextDecoration.underline,
                    ),
                  ),
                  const SizedBox(height: 10.0),
                  Center(
                      child: SizedBox(
                    width: 280,
                    child: Table(
                        columnWidths: const {
                          0: FlexColumnWidth(1),
                          1: FlexColumnWidth(1),
                        },
                        border: TableBorder.all(
                          color: Colors.grey,
                          //style: BorderStyle.solid,
                          style: BorderStyle.solid,
                          width: 1.0,
                        ),
                        // Allows to add a border decoration around your table
                        children: [
                          const TableRow(children: [
                            Center(
                                child: Padding(
                              padding: EdgeInsets.only(top: 20, bottom: 20),
                              child: Text(
                                'Insurance Type',
                                textAlign: TextAlign.left,
                                style: TextStyle(
                                  fontFamily: 'Roboto Slab',
                                  fontSize: 12,
                                  color: Color(0xff002E5B),
                                ),
                              ),
                            )),
                            Center(
                              child: Padding(
                                padding: EdgeInsets.only(top: 20, bottom: 20),
                                child: Text(
                                  'Remaining Claim',
                                  textAlign: TextAlign.left,
                                  style: TextStyle(
                                    fontFamily: 'Roboto Slab',
                                    fontSize: 12,
                                    color: Color(0xff002E5B),
                                  ),
                                ),
                              ),
                            )
                          ]),
                          TableRow(children: [
                            const Center(
                                child: Padding(
                              padding: EdgeInsets.all(10),
                              child: Text(
                                '',
                                textAlign: TextAlign.left,
                                style: TextStyle(
                                  fontFamily: 'Roboto Slab',
                                  fontSize: 11,
                                  color: Color(0xff002E5B),
                                ),
                              ),
                            )),
                            Center(
                              child: Padding(
                                padding: const EdgeInsets.all(10),
                                child: Text(
                                  '৳ ',
                                  textAlign: TextAlign.left,
                                  style: const TextStyle(
                                    fontFamily: 'Roboto Slab',
                                    fontSize: 11,
                                    color: Color(0xff002E5B),
                                  ),
                                ),
                              ),
                            )
                          ]),
                        ]),
                  )),
                ],
              ),
            ),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(40),
              boxShadow: const [
                BoxShadow(
                    color: Color(0xFFFFFFFF),
                    blurRadius: 6,
                    spreadRadius: 0,
                    offset: Offset(-3, -3)),
              ],
              color: const Color(0xFFF0F3F6),
            )));
  }

  createTotalPriceInfoWidget() {
    return Padding(
        padding:
            const EdgeInsets.only(right: 14, top: 10, bottom: 10, left: 14),
        child: Container(
            // padding: const EdgeInsets.all(10.0),
            //width: (MediaQuery.of(context).size.width - 45) / 3,
            height: 164,
            alignment: Alignment.center,
            // padding: const EdgeInsets.only(top: 20),
            child: Padding(
              padding: const EdgeInsets.only(
                left: 30,
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  const SizedBox(height: 10.0),
                  const Text(
                    "TOTAL PRICE INFO",
                    textAlign: TextAlign.left,
                    style: TextStyle(
                      fontFamily: 'Roboto Slab',
                      fontSize: 16,
                      color: Color(0xff002E5B),
                      decoration: TextDecoration.underline,
                    ),
                  ),
                  const SizedBox(height: 10.0),
                  Text(
                    "Sub Total: ৳ ${widget.purchaseDeviceInsuranceModel.subTotal ?? '0'}",
                    textAlign: TextAlign.left,
                    style: const TextStyle(
                      fontFamily: 'Roboto Slab',
                      fontSize: 16,
                      color: Color(0xff002E5B),
                    ),
                  ),
                  const SizedBox(height: 10.0),
                  Text(
                    "VAT: ৳ ${widget.purchaseDeviceInsuranceModel.totalVat ?? '0'}",
                    textAlign: TextAlign.left,
                    style: const TextStyle(
                      fontFamily: 'Roboto Slab',
                      fontSize: 16,
                      color: Color(0xff002E5B),
                    ),
                  ),
                  const SizedBox(height: 10.0),
                  Text(
                    "Grand Total: ৳ ${widget.purchaseDeviceInsuranceModel.grandTotal ?? '0'}",
                    textAlign: TextAlign.left,
                    style: const TextStyle(
                      fontFamily: 'Roboto Slab',
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Color(0xff002E5B),
                    ),
                  ),
                ],
              ),
            ),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(40),
              boxShadow: const [
                BoxShadow(
                    color: Color(0xFFFFFFFF),
                    blurRadius: 6,
                    spreadRadius: 0,
                    offset: Offset(-3, -3)),
              ],
              color: const Color(0xFFF0F3F6),
            )));
  }

  createValifityInfoWidget() {
    return Padding(
        padding:
            const EdgeInsets.only(right: 70, top: 10, bottom: 10, left: 70),
        child: Container(
            // padding: const EdgeInsets.all(10.0),
            //width: (MediaQuery.of(context).size.width - 45) / 3,
            height: 164,
            alignment: Alignment.center,
            // padding: const EdgeInsets.only(top: 20),
            child: Padding(
              padding: const EdgeInsets.only(
                left: 30,
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  const SizedBox(height: 10.0),
                  const Text(
                    "VALIDITY INFO",
                    textAlign: TextAlign.left,
                    style: TextStyle(
                      fontFamily: 'Roboto Slab',
                      fontSize: 16,
                      color: Color(0xff002E5B),
                      decoration: TextDecoration.underline,
                    ),
                  ),
                  const SizedBox(height: 10.0),
                  Text(
                    "Total ${widget.purchaseDeviceInsuranceModel.grandTotal ?? 0} days",
                    textAlign: TextAlign.left,
                    style: const TextStyle(
                      fontFamily: 'Roboto Slab',
                      fontSize: 16,
                      color: Color(0xff002E5B),
                    ),
                  ),
                  const SizedBox(height: 10.0),
                  Text(
                    "Activation Date: ${widget.purchaseDeviceInsuranceModel.totalVat ?? '0'}",
                    textAlign: TextAlign.left,
                    style: const TextStyle(
                      fontFamily: 'Roboto Slab',
                      fontSize: 16,
                      color: Color(0xff002E5B),
                    ),
                  ),
                  const SizedBox(height: 10.0),
                  Text(
                    "Expire Date: ${widget.purchaseDeviceInsuranceModel.grandTotal ?? '0'}",
                    textAlign: TextAlign.left,
                    style: const TextStyle(
                      fontFamily: 'Roboto Slab',
                      fontSize: 16,
                      color: Color(0xff002E5B),
                    ),
                  ),
                  const SizedBox(height: 10.0),
                  Text(
                    "Remaining days: ${widget.purchaseDeviceInsuranceModel.grandTotal ?? '0'}",
                    textAlign: TextAlign.left,
                    style: const TextStyle(
                      fontFamily: 'Roboto Slab',
                      fontSize: 16,
                      color: Color(0xff002E5B),
                    ),
                  ),
                  const SizedBox(height: 10.0),
                  Text(
                    "Claimable Amount: ${widget.purchaseDeviceInsuranceModel.grandTotal ?? '0'}",
                    textAlign: TextAlign.left,
                    style: const TextStyle(
                      fontFamily: 'Roboto Slab',
                      fontSize: 16,
                      color: Color(0xff002E5B),
                    ),
                  ),
                ],
              ),
            ),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(40),
              boxShadow: const [
                BoxShadow(
                    color: Color(0xFFFFFFFF),
                    blurRadius: 6,
                    spreadRadius: 0,
                    offset: Offset(-3, -3)),
              ],
              color: const Color(0xFFF0F3F6),
            )));
  }
}
