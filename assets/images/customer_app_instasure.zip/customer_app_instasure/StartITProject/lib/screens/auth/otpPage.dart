import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:instasure/Utilities/validator.dart';
import 'package:instasure/domains/repo/apiAuthClient.dart';
import 'package:instasure/screens/auth/resetForgotPassword.dart';
import 'package:instasure/screens/mainPage.dart';

class OTPPage extends StatefulWidget {
  const OTPPage(
      {Key? key, required this.phoneNumber, required this.isFromForgotPassword})
      : super(key: key);

  final String phoneNumber;
  final bool isFromForgotPassword;

  @override
  _OTPPagePageState createState() => _OTPPagePageState();
}

class _OTPPagePageState extends State<OTPPage> {
//class LoginPage extends StatelessWidget {
  TextEditingController otpController = TextEditingController();
  final ApiAuthClient _apiClient = ApiAuthClient();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  Future<void> verifyOTP() async {



    if (_formKey.currentState!.validate()) {

      EasyLoading.instance.userInteractions = false;
      EasyLoading.show(status: 'Processing...');

      /*ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: const Text('Processing Data'),
        backgroundColor: Colors.green.shade300,
      ));*/

      Map<String, dynamic> otpData = {
        "code": otpController.text,
        "phone": widget.phoneNumber,
      };

      dynamic res = await _apiClient.verifyOTP(otpData);
      ScaffoldMessenger.of(context).hideCurrentSnackBar();

      if (res.data['code'] == 200 && res.data['success'] == true) {
        if (widget.isFromForgotPassword) { EasyLoading.dismiss();
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => ResetForgotPassword(
                        phone: widget.phoneNumber,
                      )));
        } else {
          EasyLoading.dismiss();

          Navigator.push(context,
              MaterialPageRoute(builder: (context) => const MainPage()));
        }
      } else {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('Error: ${res.data['data']}'),
          backgroundColor: Colors.red.shade300,
        ));

        EasyLoading.dismiss();

      }
      EasyLoading.dismiss();
    }else{
      EasyLoading.dismiss();
      EasyLoading.instance.userInteractions = false;
      EasyLoading.show(status: 'Please write valid Otp');

      await Future.delayed(Duration(seconds: 1));
      EasyLoading.dismiss();
    }

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: null,
        body: Form(
          key: _formKey,
          child: Container(
              decoration: const BoxDecoration(
                image: DecorationImage(
                  image: AssetImage("assets/splash.png"),
                  fit: BoxFit.cover,
                ),
              ),
              child: Padding(
                  padding: const EdgeInsets.only(left: 30, right: 30, top: 33),
                  child: ListView(
                    children: <Widget>[
                      Stack(
                        children: [
                          Container(
                              alignment: Alignment.center,
                              padding: const EdgeInsets.only(bottom: 32),
                              child: Image.asset(
                                "assets/otp.png",
                                height: 239,
                                width: 239,
                                fit: BoxFit.cover,
                              )
                              //
                              ),
                          Positioned(
                            top: 6.0,
                            left: 0.0,
                            child: SizedBox(
                                height: 30,
                                width: 30,
                                // color: const Color.fromRGBO(0, 46, 91, 1.0),
                                // padding: const EdgeInsets.fromLTRB(10, 15, 10, 5),
                                child: TextButton(
                                  child: Image.asset(
                                      'assets/back_button_icon.png'),
                                  onPressed: () {
                                    Navigator.of(context).pop();
                                  },
                                )),
                          )
                        ],
                      ),
                      Container(
                          alignment: Alignment.centerLeft,
                          padding: const EdgeInsets.all(10),
                          child: const Text(
                            'Enter OTP',
                            style: TextStyle(fontSize: 20),
                          )),
                      const SizedBox(
                        height: 20,
                      ),
                      Container(
                          height: 40,
                          padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
                          child: TextFormField(
                            textAlignVertical: TextAlignVertical.center,
                            controller: otpController,
                            validator: (value) =>
                                Validator.validateOtp(value ?? ""),
                            decoration: InputDecoration(
                                contentPadding: const EdgeInsets.only(
                                    left: 10, top: 0, right: 10, bottom: 0),
                                suffixIcon: const Icon(
                                  Icons.call,
                                  color: Color(0xFF000000),
                                ),
                                enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(20.0),
                                  borderSide: const BorderSide(
                                      color: Colors.transparent, width: 0.0),
                                ),
                                hintText: 'Enter OTP Here',
                                // labelText: 'Enter Your Full Name',
                                isDense: true,
                                isCollapsed: false),
                          ),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(20),
                            boxShadow: const [
                              BoxShadow(
                                  color: Color(0xFFFFFFFF),
                                  blurRadius: 6,
                                  spreadRadius: 0,
                                  offset: Offset(-3, -3)),
                              BoxShadow(
                                  color: Color(0xFFDDE4EF),
                                  blurRadius: 6,
                                  spreadRadius: 0,
                                  offset: Offset(3, 3)),
                            ],
                            color: const Color(0xffF0F3F6),
                          )),
                      const SizedBox(
                        height: 30,
                      ),
                      Container(
                          height: 40,
                          // color: const Color.fromRGBO(0, 46, 91, 1.0),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(20),
                            boxShadow: [
                              BoxShadow(
                                  color:
                                      const Color(0xff000000).withOpacity(0.16),
                                  blurRadius: 3,
                                  spreadRadius: 0,
                                  offset: const Offset(0, 3)),
                            ],
                            color: const Color(0xff002E5B),
                          ),
                          // padding: const EdgeInsets.fromLTRB(10, 15, 10, 5),
                          child: TextButton(
                            child: const Text(
                              'Submit',
                              style: TextStyle(color: Colors.white),
                            ),
                            onPressed: verifyOTP,
                            /* () {
                              print(otpController.text);
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => ResetPasswordPage()),
                              );
                            },*/
                          )),
                    ],
                  ))),
        ));
  }
}
