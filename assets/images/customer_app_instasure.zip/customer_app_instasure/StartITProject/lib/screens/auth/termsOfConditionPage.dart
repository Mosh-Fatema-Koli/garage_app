import 'package:flutter/material.dart';
import 'package:instasure/widgets/topView4.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'dart:async';

class TermsOfConditionPage extends StatefulWidget {
  const TermsOfConditionPage({Key? key}) : super(key: key);

  @override
  _TermsOfConditionPageState createState() => _TermsOfConditionPageState();
}

class _TermsOfConditionPageState extends State<TermsOfConditionPage> {
  final Completer<WebViewController> _controller =
      Completer<WebViewController>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: null,
      backgroundColor: const Color(0xFFEFF7FF),
      body: SizedBox(
        height: MediaQuery.of(context).size.height,
        child: Column(
          children: [
            SizedBox(
              height: 125,
              child: Stack(
                children: [
                  const TopView4(),
                  Positioned(
                    bottom: 20.0,
                    left: 40.0,
                    child: SizedBox(
                        height: 30,
                        width: 30,
                        // color: const Color.fromRGBO(0, 46, 91, 1.0),
                        // padding: const EdgeInsets.fromLTRB(10, 15, 10, 5),
                        child: TextButton(
                          child: Image.asset('assets/back_button_icon.png'),
                          onPressed: () {
                            Navigator.of(context).pop();
                          },
                        )),
                  )
                ],
              ),
            ),
            SizedBox(
              height: MediaQuery.of(context).size.height - 125,
              child: WebView(
                navigationDelegate: (NavigationRequest request) async {
                  setState(() {});
                  return NavigationDecision.navigate;
                },
                backgroundColor: Colors.white,
                zoomEnabled: true,
                initialUrl: "https://instasure.xyz/terms-and-condition",
                javascriptMode: JavascriptMode.unrestricted,
                onWebViewCreated: (WebViewController webViewController) {
                  _controller.complete(webViewController);
                },
                onPageFinished: (url) {
                  if (url.contains("success") || url.contains("fail")) {
                    Navigator.of(context).popUntil((route) => route.isFirst);
                  }
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
