import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:instasure/Utilities/userPref.dart';
import 'package:instasure/domains/models/auth/user.dart';
import 'package:instasure/domains/repo/apiAuthClient.dart';
import 'package:instasure/screens/auth/otpPage.dart';
import 'package:instasure/widgets/topView.dart';
import 'package:instasure/Utilities/validator.dart';

class SignUpPage extends StatefulWidget {
  const SignUpPage({Key? key}) : super(key: key);

  @override
  _SignUpPageState createState() => _SignUpPageState();
}

class _SignUpPageState extends State<SignUpPage> {
  @override
  void initState() {
    super.initState();
    UserPref prefs = UserPref();
    prefs.saveFirstLaunch(false);
  }

//class LoginPage extends StatelessWidget {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  TextEditingController nameController = TextEditingController();
  TextEditingController phoneController = TextEditingController();
  TextEditingController passwordController = TextEditingController();

  bool _showPassword = true;

  final ApiAuthClient _apiClient = ApiAuthClient();

  Future<void> registerUsers() async {

    EasyLoading.instance.userInteractions = false;
    EasyLoading.show(status: 'Processing...');



    if (Validator.validateName(nameController.text) != null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text("${Validator.validateName(nameController.text)}"),
        backgroundColor: Colors.red.shade300,
      ));
      //return;
    }

    else if (Validator.validatePhoneNumber(phoneController.text) != null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text("${Validator.validatePhoneNumber(phoneController.text)}"),
        backgroundColor: Colors.red.shade300,
      ));
     // return;
    }
    else if (Validator.validatePassword(passwordController.text) != null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text("${Validator.validatePassword(passwordController.text)}"),
        backgroundColor: Colors.red.shade300,
      ));
     // return;
    }

    // if (_formKey.currentState!.validate()) {
    //EasyLoading.instance.userInteractions = false;
    //EasyLoading.show(status: 'Processing...');
    if (Validator.validatePhoneNumber(phoneController.text) != null
        && Validator.validatePassword(passwordController.text) != null
         && Validator.validateName(nameController.text) != null) {
      await Future.delayed(Duration(seconds: 2));
      EasyLoading.dismiss();
      return;
    }


    Map<String, dynamic> userData = {
      "name": nameController.text,
      "phone": phoneController.text,
      "password": passwordController.text,
    };

    dynamic res = await _apiClient.registerUser(userData);
    EasyLoading.dismiss();

    // ScaffoldMessenger.of(context).hideCurrentSnackBar();
    if (res.statusCode == 200) {
      if (res.data['code'] == 200) {
        UserPref prefs = UserPref();
        prefs.saveTokenInPref(res.data['data']['token']);
        User _user = User.fromJson(res.data['data']['result']);
        prefs.saveUserInPref(_user);

        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => OTPPage(
                      phoneNumber: phoneController.text,
                      isFromForgotPassword: false,
                    )));
      } else {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('${res.data['message']}'),
          backgroundColor: Colors.red.shade300,
        ));
        // ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        //   content: Text('Error: ${res.data['data']['phone'][0]}'),
        //   backgroundColor: Colors.red.shade300,
        // ));
      }
    }
    // } else {}
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: null,
        body: Form(
          key: _formKey,
          child: Container(
              decoration: const BoxDecoration(
                image: DecorationImage(
                  image: AssetImage("assets/splash.png"),
                  fit: BoxFit.cover,
                ),
              ),
              child: Padding(
                  padding: const EdgeInsets.all(30),
                  child: ListView(
                    children: <Widget>[
                      Stack(
                        children: [
                          const TopView(),
                          Positioned(
                            top: 6.0,
                            left: 0.0,
                            child: SizedBox(
                                height: 30,
                                width: 30,
                                // color: const Color.fromRGBO(0, 46, 91, 1.0),
                                // padding: const EdgeInsets.fromLTRB(10, 15, 10, 5),
                                child: TextButton(
                                  child: Image.asset(
                                      'assets/back_button_icon.png'),
                                  onPressed: () {
                                    Navigator.of(context).pop();
                                  },
                                )),
                          )
                        ],
                      ),
                      const SizedBox(
                        height: 23,
                      ),
                      Container(
                          alignment: Alignment.centerLeft,
                          padding: const EdgeInsets.all(10),
                          child: const Text(
                            'Sign up',
                            style: TextStyle(fontSize: 20),
                          )),
                      const SizedBox(
                        height: 20,
                      ),
                      Align(
                        alignment: Alignment.center,
                        child: Container(
                            height: 40,
                            padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
                            child: TextFormField(
                              textAlignVertical: TextAlignVertical.center,
                              controller: nameController,
                              // validator: (value) =>
                              //     Validator.validateName(value ?? ""),
                              // key: _formKey,
                              decoration: InputDecoration(
                                  contentPadding: const EdgeInsets.only(
                                      left: 10, top: 0, right: 10, bottom: 0),
                                  suffixIcon: const Icon(
                                    Icons.person,
                                    color: Color(0xFF000000),
                                  ),
                                  enabledBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(20.0),
                                    borderSide: const BorderSide(
                                        color: Colors.transparent, width: 0.0),
                                  ),
                                  hintText: 'Enter Your Full Name',
                                  // labelText: 'Enter Your Full Name',
                                  isDense: true,
                                  isCollapsed: false),
                            ),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(20),
                              boxShadow: const [
                                BoxShadow(
                                    color: Color(0xFFFFFFFF),
                                    blurRadius: 6,
                                    spreadRadius: 0,
                                    offset: Offset(-3, -3)),
                                BoxShadow(
                                    color: Color(0xFFDDE4EF),
                                    blurRadius: 6,
                                    spreadRadius: 0,
                                    offset: Offset(3, 3)),
                              ],
                              color: const Color(0xffF0F3F6),
                            )),
                      ),
                      const SizedBox(
                        height: 25,
                      ),
                      Container(
                          height: 40,
                          padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
                          child: TextFormField(
                            controller: phoneController,
                            textAlignVertical: TextAlignVertical.center,
                            // validator: (value) =>
                            //     Validator.validatePhoneNumber(value ?? ""),
                            // key: _formKey,
                            decoration: InputDecoration(
                              contentPadding: const EdgeInsets.only(
                                  left: 10, top: 0, right: 10, bottom: 0),
                              suffixIcon: const Icon(
                                Icons.call,
                                color: Color(0xFF000000),
                              ),
                              enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(20.0),
                                borderSide: const BorderSide(
                                    color: Colors.transparent, width: 0.0),
                              ),
                              hintText: 'Enter Your Phone Number',

                              // labelText: 'Enter Your Phone Number',
                            ),
                          ),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(20),
                            boxShadow: const [
                              BoxShadow(
                                  color: Color(0xFFFFFFFF),
                                  blurRadius: 6,
                                  spreadRadius: 0,
                                  offset: Offset(-3, -3)),
                              BoxShadow(
                                  color: Color(0xFFDDE4EF),
                                  blurRadius: 6,
                                  spreadRadius: 0,
                                  offset: Offset(3, 3)),
                            ],
                            color: const Color(0xffF0F3F6),
                          )),
                      const SizedBox(
                        height: 25,
                      ),
                      Container(
                          height: 40,
                          padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
                          child: TextFormField(
                            obscureText: _showPassword,
                            controller: passwordController,
                            textAlignVertical: TextAlignVertical.center,
                            // validator: (value) =>
                            //     Validator.validatePassword(value ?? ""),
                            // key: _formKey,
                            decoration: InputDecoration(
                              contentPadding: const EdgeInsets.only(
                                  left: 10, top: 0, right: 10, bottom: 0),

                              suffixIcon: IconButton(
                                  color: const Color(0xFF000000),
                                  icon: Icon(_showPassword
                                      ? Icons.visibility
                                      : Icons.visibility_off),
                                  onPressed: () {
                                    print("testtgvhdsvchgd");
                                    setState(() {
                                      _showPassword = !_showPassword;
                                    });
                                  }),
                              enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(20.0),
                                borderSide: const BorderSide(
                                    color: Colors.transparent, width: 0.0),
                              ),
                              hintText: 'Enter Password',

                              // labelText: 'Enter Password',
                            ),
                          ),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(20),
                            boxShadow: const [
                              BoxShadow(
                                  color: Color(0xFFFFFFFF),
                                  blurRadius: 6,
                                  spreadRadius: 0,
                                  offset: Offset(-3, -3)),
                              BoxShadow(
                                  color: Color(0xFFDDE4EF),
                                  blurRadius: 6,
                                  spreadRadius: 0,
                                  offset: Offset(3, 3)),
                            ],
                            color: const Color(0xffF0F3F6),
                          )),
                      const SizedBox(
                        height: 30,
                      ),
                      Container(
                          height: 40,
                          // color: const Color.fromRGBO(0, 46, 91, 1.0),
                          decoration: const BoxDecoration(
                              borderRadius:
                                  BorderRadius.all(Radius.circular(20)),
                              color: Color.fromRGBO(0, 46, 91, 1.0)),
                          // padding: const EdgeInsets.fromLTRB(10, 15, 10, 5),
                          child: TextButton(
                            child: const Text(
                              'SIGN UP',
                              style: TextStyle(color: Colors.white),
                            ),
                            onPressed: registerUsers,
                            /*() async {
                              UserModel? user = await _authService.login(
                                  nameController.text,
                                  phoneController.text,
                                  passwordController.text);
                              if (user != null) {
                              } else {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(
                                    duration: Duration(seconds: 3),
                                    content:
                                        Text('email or password incorrect'),
                                  ),
                                );
                                return null;
                              }
                            },*/
                          )),
                      TextButton(
                        onPressed: () {
                          //forgot password screen
                        },
                        child: const Text(
                          'HELP',
                        ),
                      ),
                    ],
                  ))),
        ));
  }
}
