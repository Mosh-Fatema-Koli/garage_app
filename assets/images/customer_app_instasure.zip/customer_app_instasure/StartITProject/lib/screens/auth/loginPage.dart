import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:instasure/Utilities/userPref.dart';
import 'package:instasure/Utilities/validator.dart';
import 'package:instasure/domains/models/auth/user.dart';
import 'package:instasure/screens/auth/forgotPasswordPage.dart';
import 'package:instasure/screens/auth/signUpPage.dart';
import 'package:instasure/screens/mainPage.dart';
import 'package:instasure/screens/splashScreen.dart';
import 'package:instasure/widgets/topView.dart';
import 'package:instasure/domains/repo/apiAuthClient.dart';


import '../tabMenu/homePage.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({Key? key}) : super(key: key);

  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {

  var loading = true;

  @override
  void initState() {
    super.initState();
    UserPref prefs = UserPref();
    prefs.saveFirstLaunch(false);
  }

//class LoginPage extends StatelessWidget {
  TextEditingController phoneController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  bool _isObscure = true;


  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final ApiAuthClient _apiClient = ApiAuthClient();

  Future<void> loginUser() async {
print('loading...');
    EasyLoading.instance.userInteractions = false;
    EasyLoading.show(status: 'Processing...');

    if (Validator.validatePhoneNumber(phoneController.text) != null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text("${Validator.validatePhoneNumber(phoneController.text)}"),
        backgroundColor: Colors.red.shade300,
      ));
     // EasyLoading.dismiss();
     // return;
    }
    else if (Validator.validatePassword(passwordController.text) != null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text("${Validator.validatePassword(passwordController.text)}"),
        backgroundColor: Colors.red.shade300,
      ));
     //
      //return;
    }



if (Validator.validatePhoneNumber(phoneController.text) != null && Validator.validatePassword(passwordController.text) != null) {
  await Future.delayed(Duration(seconds: 3));
  EasyLoading.dismiss();
  return;
}
    // if (_formKey.currentState!.validate()) {
    // ScaffoldMessenger.of(context).showSnackBar(SnackBar(
    //   content: const Text('Processing Data'),
    //   backgroundColor: Colors.green.shade300,
    // ));
    //EasyLoading.instance.userInteractions = false;
    //EasyLoading.show(status: 'Processing...');

    Map<String, dynamic> logindata = {
      "phone": phoneController.text,
      "password": passwordController.text,
    };
    dynamic res = await _apiClient.login(logindata);
    //ScaffoldMessenger.of(context).hideCurrentSnackBar();
    EasyLoading.dismiss();

    if (res.statusCode == 200) {
      if (res.data['code'] == 200) {
        UserPref prefs = UserPref();
        prefs.saveTokenInPref(res.data['data']['token']);
        print('Mytoken: '+res.data['data']['token']);
        User _user = User.fromJson(res.data['data']['result']);
        prefs.saveUserInPref(_user);

        //Navigator.pop(context, MaterialPageRoute(builder: (context) => const HomePage()));

        Navigator.of(context).pushAndRemoveUntil(
            MaterialPageRoute(builder: (c) => const MainPage()),
            (route) => false);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('${res.data['message']}'),
          backgroundColor: Colors.red.shade300,
        ));
        // ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        //   content: Text('Error: ${res.data['data']['phone'][0]}'),
        //   backgroundColor: Colors.red.shade300,
        //
        //
        // ));

      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('${res.data['data']}'),
        backgroundColor: Colors.red.shade300,
      ));
    }
    // }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Form(
      key: _formKey,
      child: Container(
          decoration: const BoxDecoration(
            image: DecorationImage(
              image: AssetImage("assets/splash.png"),
              fit: BoxFit.cover,
            ),
          ),
          child: Padding(
              padding: const EdgeInsets.all(30),
              child: ListView(
                children: <Widget>[
                  const TopView(),
                  const SizedBox(
                    height: 74,
                  ),
                  Container(
                      alignment: Alignment.centerLeft,
                      padding: const EdgeInsets.all(10),
                      child: const Text(
                        'Login',
                        style: TextStyle(
                            fontSize: 24, color: Color.fromRGBO(0, 0, 0, 0.87)),
                      )),
                  const SizedBox(
                    height: 40,
                  ),
                  Container(
                      height: 40,
                      padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
                      child: TextFormField(
                        textAlignVertical: TextAlignVertical.center,
                        controller: phoneController,
                        keyboardType: TextInputType.number,
                        //validator: (value) =>
                        // Validator.validatePhoneNumber(value ?? ""),
                        decoration: InputDecoration(
                            contentPadding: const EdgeInsets.only(
                                left: 10, top: 0, right: 10, bottom: 0),
                            suffixIcon: const Icon(
                              Icons.call,
                              color: Color(0xFF000000),
                            ),

                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20.0),
                              borderSide: const BorderSide(
                                  color: Colors.transparent, width: 0.0),
                            ),
                            hintText: 'Enter Your Phone Number',

                            // labelText: 'Enter Your Full Name',
                            isDense: true,
                            isCollapsed: false),
                      ),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: const [
                          BoxShadow(
                              color: Color(0xFFFFFFFF),
                              blurRadius: 6,
                              spreadRadius: 0,
                              offset: Offset(-3, -3)),
                          BoxShadow(
                              color: Color(0xFFDDE4EF),
                              blurRadius: 6,
                              spreadRadius: 0,
                              offset: Offset(3, 3)),
                        ],
                        color: const Color(0xffF0F3F6),
                      )),
                  const SizedBox(
                    height: 22,
                  ),
                  Container(
                      height: 40,
                      padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
                      child: TextFormField(
                        obscureText: _isObscure,
                        controller: passwordController,
                        textAlignVertical: TextAlignVertical.center,
                        // validator: (value) =>
                        //     Validator.validatePassword(value ?? ""),
                        decoration: InputDecoration(
                          contentPadding: const EdgeInsets.only(
                              left: 10, top: 0, right: 10, bottom: 0),

                          suffixIcon: IconButton(
                              color: const Color(0xFF000000),
                              icon: Icon(_isObscure
                                  ? Icons.visibility
                                  : Icons.visibility_off),
                              onPressed: () {
                                print("testtgvhdsvchgd");
                                setState(() {
                                  _isObscure = !_isObscure;
                                });
                              }),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(20.0),
                            borderSide: const BorderSide(
                                color: Colors.transparent, width: 0.0),
                          ),
                          hintText: 'Enter Password',

                          // labelText: 'Enter Password',
                        ),
                      ),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: const [
                          BoxShadow(
                              color: Color(0xFFFFFFFF),
                              blurRadius: 6,
                              spreadRadius: 0,
                              offset: Offset(-3, -3)),
                          BoxShadow(
                              color: Color(0xFFDDE4EF),
                              blurRadius: 6,
                              spreadRadius: 0,
                              offset: Offset(3, 3)),
                        ],
                        color: const Color(0xffF0F3F6),
                      )),
                  const SizedBox(
                    height: 26,
                  ),
                  Container(
                    height: 40,
                    // padding: const EdgeInsets.fromLTRB(10, 15, 10, 5),
                    child: TextButton(
                      child: const Text(
                        'SIGN IN',
                        style: TextStyle(color: Colors.white),
                      ),
                      onPressed: loginUser,
                    ),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [
                        BoxShadow(
                            color: const Color(0xff000000).withOpacity(0.16),
                            blurRadius: 3,
                            spreadRadius: 0,
                            offset: const Offset(0, 3)),
                      ],
                      color: const Color(0xff002E5B),
                    ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  TextButton(
                    onPressed: () {
                      //forgot password screen
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const ForgotPasswordPage()),
                      );
                    },
                    child: const Text(
                      'Forgot Password?',
                    ),
                  ),
                  Row(
                    children: <Widget>[
                      const Text('New to Instasure?'),
                      TextButton(
                        child: const Text(
                          'Sign Up Now',
                          style: TextStyle(fontSize: 16),
                        ),
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const SignUpPage()),
                          );
                        },
                      )
                    ],
                    mainAxisAlignment: MainAxisAlignment.center,
                  ),
                ],
              ))),
    ));
  }
}
