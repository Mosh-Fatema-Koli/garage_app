import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:instasure/Utilities/userPref.dart';
import 'package:instasure/Utilities/validator.dart';
import 'package:instasure/domains/repo/apiAuthClient.dart';
import 'package:instasure/screens/auth/otpPage.dart';

class ForgotPasswordPage extends StatefulWidget {
  const ForgotPasswordPage({Key? key}) : super(key: key);

  @override
  _ForgotPasswordPageState createState() => _ForgotPasswordPageState();
}

class _ForgotPasswordPageState extends State<ForgotPasswordPage> {
//class LoginPage extends StatelessWidget {
  TextEditingController phoneController = TextEditingController();
  //final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  final ApiAuthClient _apiClient = ApiAuthClient();

  Future<void> checkPhoneNumber() async {

    print('loading...');
    EasyLoading.instance.userInteractions = false;
    EasyLoading.show(status: 'Processing...');

    if (Validator.validatePhoneNumber(phoneController.text) != null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text("${Validator.validatePhoneNumber(phoneController.text)}"),
        backgroundColor: Colors.red.shade300,
      ));
      //return;
    }
    if (Validator.validatePhoneNumber(phoneController.text) != null) {
      await Future.delayed(Duration(seconds: 2));
      EasyLoading.dismiss();
      return;
    }
    // if (_formKey.currentState!.validate()) {
   // EasyLoading.instance.userInteractions = false;
    //EasyLoading.show(status: 'Processing...');

    Map<String, dynamic> userData = {"phone": phoneController.text};

    dynamic res = await _apiClient.phoneNumberCheck(userData);
    EasyLoading.dismiss();

    // ScaffoldMessenger.of(context).hideCurrentSnackBar();
    if (res.statusCode == 200) {
      Navigator.push(
          context,
          MaterialPageRoute(
              builder: (context) => OTPPage(
                    phoneNumber: phoneController.text,
                    isFromForgotPassword: true,
                  )));
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('${res.data['message']}'),
        backgroundColor: Colors.red.shade300,
      ));
      // ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      //   content: Text('Error: ${res.data['data']['phone'][0]}'),
      //   backgroundColor: Colors.red.shade300,
      // ));
    }

    // } else {}
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: null,
        body: Container(
            decoration: const BoxDecoration(
              image: DecorationImage(
                image: AssetImage("assets/splash.png"),
                fit: BoxFit.cover,
              ),
            ),
            child: Padding(
                padding: const EdgeInsets.only(left: 30, right: 30, top: 24),
                child: ListView(
                  children: <Widget>[
                    Stack(
                      children: [
                        Container(
                            alignment: Alignment.center,
                            // padding: const EdgeInsets.only(bottom: 64),
                            child: Image.asset(
                              "assets/forgot_password.png",
                              height: 176,
                              width: 176,
                              fit: BoxFit.cover,
                            )
                            //
                            ),
                        Positioned(
                          top: 6.0,
                          left: 0.0,
                          child: SizedBox(
                              height: 30,
                              width: 30,
                              // color: const Color.fromRGBO(0, 46, 91, 1.0),
                              // padding: const EdgeInsets.fromLTRB(10, 15, 10, 5),
                              child: TextButton(
                                child:
                                    Image.asset('assets/back_button_icon.png'),
                                onPressed: () {
                                  Navigator.of(context).pop();
                                },
                              )),
                        )
                      ],
                    ),
                    Container(
                        alignment: Alignment.centerLeft,
                        padding: const EdgeInsets.all(10),
                        child: const Text(
                          'Forget Password',
                          style: TextStyle(fontSize: 20),
                        )),
                    const SizedBox(
                      height: 20,
                    ),
                    Container(
                        height: 40,
                        padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
                        child: TextFormField(
                          controller: phoneController,
                          textAlignVertical: TextAlignVertical.center,
                          // validator: (value) =>
                          //     Validator.validatePhoneNumber(value ?? ""),
                          // key: _formKey,
                          decoration: InputDecoration(
                            contentPadding: const EdgeInsets.only(
                                left: 10, top: 0, right: 10, bottom: 0),
                            suffixIcon: const Icon(
                              Icons.call,
                              color: Color(0xFF000000),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20.0),
                              borderSide: const BorderSide(
                                  color: Colors.transparent, width: 0.0),
                            ),
                            hintText: 'Enter Your Phone Number',

                            // labelText: 'Enter Your Phone Number',
                          ),
                        ),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                          boxShadow: const [
                            BoxShadow(
                                color: Color(0xFFFFFFFF),
                                blurRadius: 6,
                                spreadRadius: 0,
                                offset: Offset(-3, -3)),
                            BoxShadow(
                                color: Color(0xFFDDE4EF),
                                blurRadius: 6,
                                spreadRadius: 0,
                                offset: Offset(3, 3)),
                          ],
                          color: const Color(0xffF0F3F6),
                        )),
                    const SizedBox(
                      height: 30,
                    ),
                    Container(
                        height: 40,
                        // color: const Color.fromRGBO(0, 46, 91, 1.0),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                          boxShadow: [
                            BoxShadow(
                                color:
                                    const Color(0xff000000).withOpacity(0.16),
                                blurRadius: 3,
                                spreadRadius: 0,
                                offset: const Offset(0, 3)),
                          ],
                          color: const Color(0xff002E5B),
                        ),
                        // padding: const EdgeInsets.fromLTRB(10, 15, 10, 5),
                        child: TextButton(
                          child: const Text(
                            'VERIFY',
                            style: TextStyle(color: Colors.white),
                          ),
                          onPressed: checkPhoneNumber,
                        )),
                  ],
                ))));
  }
}
