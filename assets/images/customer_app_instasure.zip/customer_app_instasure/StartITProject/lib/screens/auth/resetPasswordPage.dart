import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:instasure/Utilities/userPref.dart';
import 'package:instasure/Utilities/validator.dart';
import 'package:instasure/domains/models/auth/user.dart';
import 'package:instasure/domains/repo/apiClientCustomerDasboard.dart';
import 'package:instasure/screens/mainPage.dart';
import 'dart:async';

class ResetPasswordPage extends StatefulWidget {
  ResetPasswordPage({Key? key}) : super(key: key);

  @override
  _ResetPasswordPageState createState() => _ResetPasswordPageState();
}

class _ResetPasswordPageState extends State<ResetPasswordPage> {
  final ApiClientCustomerDasboard _apiClient = ApiClientCustomerDasboard();
  TextEditingController oldPasswordController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController confirmPasswordController = TextEditingController();

  bool _isObscure = true;
  bool _isConfirmObscure = true;
  bool _isOldPasObscure = true;

  Future<void> resetPassword() async {
    if (Validator.validatePassword(oldPasswordController.text) != null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text("${Validator.validatePassword(passwordController.text)}"),
        backgroundColor: Colors.red.shade300,
      ));
      return;
    }

    if (Validator.validatePassword(passwordController.text) != null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text("${Validator.validatePassword(passwordController.text)}"),
        backgroundColor: Colors.red.shade300,
      ));
      return;
    }

    if (Validator.validatePassword(confirmPasswordController.text) != null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text("${Validator.validatePassword(passwordController.text)}"),
        backgroundColor: Colors.red.shade300,
      ));
      return;
    }

    if (passwordController.text != confirmPasswordController.text) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: const Text("Password & confirm password are not same"),
        backgroundColor: Colors.red.shade300,
      ));
      return;
    }
    // if (_formKey.currentState!.validate()) {
    // ScaffoldMessenger.of(context).showSnackBar(SnackBar(
    //   content: const Text('Processing Data'),
    //   backgroundColor: Colors.green.shade300,
    // ));
    EasyLoading.instance.userInteractions = false;
    EasyLoading.show(status: 'Processing...');
    Map<String, dynamic> data = {
      "old_password": oldPasswordController.text,
      "new_password": passwordController.text,
      "confirm_password": confirmPasswordController.text,
    };
    UserPref prefs = UserPref();
    Future<String?> token = prefs.getTokenFromPref();
    String? accessToken = await token;
    dynamic res = await _apiClient.customerPasswordUpdate(data, accessToken!);
    EasyLoading.dismiss();
    if (res.statusCode == 200) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('${res.data['response']}'),
        backgroundColor: Colors.green,
      ));
      Timer(const Duration(seconds: 5), () => Navigator.pop(context));
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('${res.data['response']}'),
        backgroundColor: Colors.red.shade300,
      ));
    }
    // }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: null,
        body: Container(
            decoration: const BoxDecoration(
              image: DecorationImage(
                image: AssetImage("assets/splash.png"),
                fit: BoxFit.cover,
              ),
            ),
            child: Padding(
                padding: const EdgeInsets.all(30),
                child: ListView(
                  children: <Widget>[
                    Stack(
                      children: [
                        Container(
                            alignment: Alignment.center,
                            padding: const EdgeInsets.only(bottom: 0),
                            child: Image.asset(
                              "assets/new_password.png",
                              height: 268,
                              width: 268,
                              fit: BoxFit.cover,
                            )
                            //
                            ),
                        Positioned(
                          top: 6.0,
                          left: 0.0,
                          child: SizedBox(
                              height: 30,
                              width: 30,
                              // color: const Color.fromRGBO(0, 46, 91, 1.0),
                              // padding: const EdgeInsets.fromLTRB(10, 15, 10, 5),
                              child: TextButton(
                                child:
                                    Image.asset('assets/back_button_icon.png'),
                                onPressed: () {
                                  Navigator.of(context).pop();
                                },
                              )),
                        )
                      ],
                    ),
                    Container(
                        alignment: Alignment.centerLeft,
                        padding: const EdgeInsets.all(10),
                        child: const Text(
                          'New Password',
                          style: TextStyle(fontSize: 20),
                        )),
                    const SizedBox(
                      height: 20,
                    ),
                    Container(
                        height: 40,
                        padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
                        child: TextFormField(
                          obscureText: _isOldPasObscure,
                          controller: oldPasswordController,
                          textAlignVertical: TextAlignVertical.center,
                          // validator: (value) =>
                          //     Validator.validatePassword(value ?? ""),
                          // key: _formKey,
                          decoration: InputDecoration(
                            contentPadding: const EdgeInsets.only(
                                left: 10, top: 0, right: 10, bottom: 0),

                            suffixIcon: IconButton(
                                color: const Color(0xFF000000),
                                icon: Icon(_isOldPasObscure
                                    ? Icons.visibility
                                    : Icons.visibility_off),
                                onPressed: () {
                                  print("testtgvhdsvchgd");
                                  setState(() {
                                    _isOldPasObscure = !_isOldPasObscure;
                                  });
                                }),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20.0),
                              borderSide: const BorderSide(
                                  color: Colors.transparent, width: 0.0),
                            ),
                            hintText: 'Enter Old Password',

                            // labelText: 'Enter Password',
                          ),
                        ),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                          boxShadow: const [
                            BoxShadow(
                                color: Color(0xFFFFFFFF),
                                blurRadius: 6,
                                spreadRadius: 0,
                                offset: Offset(-3, -3)),
                            BoxShadow(
                                color: Color(0xFFDDE4EF),
                                blurRadius: 6,
                                spreadRadius: 0,
                                offset: Offset(3, 3)),
                          ],
                          color: const Color(0xffF0F3F6),
                        )),
                    const SizedBox(
                      height: 25,
                    ),
                    Container(
                        height: 40,
                        padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
                        child: TextFormField(
                          obscureText: _isObscure,
                          controller: passwordController,
                          textAlignVertical: TextAlignVertical.center,
                          // validator: (value) =>
                          //     Validator.validatePassword(value ?? ""),
                          // key: _formKey,
                          decoration: InputDecoration(
                            contentPadding: const EdgeInsets.only(
                                left: 10, top: 0, right: 10, bottom: 0),

                            suffixIcon: IconButton(
                                color: const Color(0xFF000000),
                                icon: Icon(_isObscure
                                    ? Icons.visibility
                                    : Icons.visibility_off),
                                onPressed: () {
                                  print("testtgvhdsvchgd");
                                  setState(() {
                                    _isObscure = !_isObscure;
                                  });
                                }),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20.0),
                              borderSide: const BorderSide(
                                  color: Colors.transparent, width: 0.0),
                            ),
                            hintText: 'Enter New Password',

                            // labelText: 'Enter Password',
                          ),
                        ),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                          boxShadow: const [
                            BoxShadow(
                                color: Color(0xFFFFFFFF),
                                blurRadius: 6,
                                spreadRadius: 0,
                                offset: Offset(-3, -3)),
                            BoxShadow(
                                color: Color(0xFFDDE4EF),
                                blurRadius: 6,
                                spreadRadius: 0,
                                offset: Offset(3, 3)),
                          ],
                          color: const Color(0xffF0F3F6),
                        )),
                    const SizedBox(
                      height: 25,
                    ),
                    Container(
                        height: 40,
                        padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
                        child: TextFormField(
                          obscureText: _isConfirmObscure,
                          controller: confirmPasswordController,
                          textAlignVertical: TextAlignVertical.center,
                          // validator: (value) =>
                          //     Validator.validatePassword(value ?? ""),
                          // key: _formKey,
                          decoration: InputDecoration(
                            contentPadding: const EdgeInsets.only(
                                left: 10, top: 0, right: 10, bottom: 0),

                            suffixIcon: IconButton(
                                color: const Color(0xFF000000),
                                icon: Icon(_isConfirmObscure
                                    ? Icons.visibility
                                    : Icons.visibility_off),
                                onPressed: () {
                                  print("testtgvhdsvchgd");
                                  setState(() {
                                    _isConfirmObscure = !_isConfirmObscure;
                                  });
                                }),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20.0),
                              borderSide: const BorderSide(
                                  color: Colors.transparent, width: 0.0),
                            ),
                            hintText: 'Re-Enter New Password',

                            // labelText: 'Enter Password',
                          ),
                        ),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                          boxShadow: const [
                            BoxShadow(
                                color: Color(0xFFFFFFFF),
                                blurRadius: 6,
                                spreadRadius: 0,
                                offset: Offset(-3, -3)),
                            BoxShadow(
                                color: Color(0xFFDDE4EF),
                                blurRadius: 6,
                                spreadRadius: 0,
                                offset: Offset(3, 3)),
                          ],
                          color: const Color(0xffF0F3F6),
                        )),
                    const SizedBox(
                      height: 30,
                    ),
                    Container(
                        height: 40,
                        // color: const Color.fromRGBO(0, 46, 91, 1.0),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                          boxShadow: [
                            BoxShadow(
                                color:
                                    const Color(0xff000000).withOpacity(0.16),
                                blurRadius: 3,
                                spreadRadius: 0,
                                offset: const Offset(0, 3)),
                          ],
                          color: const Color(0xff002E5B),
                        ),
                        // padding: const EdgeInsets.fromLTRB(10, 15, 10, 5),
                        child: TextButton(
                          child: const Text(
                            'Submit',
                            style: TextStyle(color: Colors.white),
                          ),
                          onPressed: resetPassword,
                        )),
                  ],
                ))));
  }
}
