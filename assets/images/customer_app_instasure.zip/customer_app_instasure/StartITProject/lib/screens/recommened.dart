import 'package:flutter/material.dart';
import 'package:instasure/widgets/topView2.dart';
import 'package:instasure/widgets/topView3.dart';
import 'package:instasure/widgets/topView4.dart';

class Recommened extends StatefulWidget {
  const Recommened({Key? key, required this.title}) : super(key: key);
  final String title;

  @override
  _RecommenedState createState() => _RecommenedState();
}

class _RecommenedState extends State<Recommened> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: null,
        backgroundColor: const Color(0xFFEFF7FF),
        body: SingleChildScrollView(
            child: Column(
          children: <Widget>[
            Stack(
              children: [
                const TopView4(),
                Positioned(
                  bottom: 20.0,
                  left: 40.0,
                  child: SizedBox(
                      height: 30,
                      width: 30,
                      // color: const Color.fromRGBO(0, 46, 91, 1.0),
                      // padding: const EdgeInsets.fromLTRB(10, 15, 10, 5),
                      child: TextButton(
                        child: Image.asset('assets/back_button_icon.png'),
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                      )),
                )
              ],
            ),
            const SizedBox(
              height: 10,
            ),
            Container(
                height: 50,
                alignment: Alignment.center,
                child: Text(
                  widget.title,
                  style: const TextStyle(
                      fontSize: 16, color: Color.fromRGBO(0, 0, 0, 0.87)),
                ),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(0),
                  boxShadow: const [
                    BoxShadow(
                        color: Color(0xFFFFFFFF),
                        blurRadius: 6,
                        spreadRadius: 0,
                        offset: Offset(-3, -3)),
                    BoxShadow(
                        color: Color(0xFFDDE4EF),
                        blurRadius: 6,
                        spreadRadius: 0,
                        offset: Offset(3, 3)),
                  ],
                  color: const Color(0xffF0F3F6),
                )),
            Container(
                padding: const EdgeInsets.only(
                    left: 30.0, top: 100, right: 30, bottom: 5),
                alignment: Alignment.center,
                child: Image.asset(
                  "assets/icon_comming_soon.png",
                  fit: BoxFit.cover,
                )),
          ],
        )));
  }
}
