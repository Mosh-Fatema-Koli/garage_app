// ignore_for_file: unnecessary_new

import 'package:flutter/material.dart';
import 'package:instasure/widgets/imageWidget.dart';
import 'package:instasure/widgets/topView4.dart';

class AboutUs extends StatefulWidget {
  const AboutUs({Key? key}) : super(key: key);

  @override
  _AboutUsState createState() => _AboutUsState();
}

class _AboutUsState extends State<AboutUs> {
  TextEditingController nameController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController phoneController = TextEditingController();
  TextEditingController bussinameNameController = TextEditingController();
  TextEditingController yourMessageController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
          child: Padding(
        padding: const EdgeInsets.all(0),
        child: Column(
          children: [
            Stack(
              children: [
                const TopView4(),
                Positioned(
                  bottom: 20.0,
                  left: 40.0,
                  child: SizedBox(
                      height: 30,
                      width: 30,
                      // color: const Color.fromRGBO(0, 46, 91, 1.0),
                      // padding: const EdgeInsets.fromLTRB(10, 15, 10, 5),
                      child: TextButton(
                        child: Image.asset('assets/back_button_icon.png'),
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                      )),
                )
              ],
            ),
            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    const SizedBox(height: 10.0),
                    createAboutUsWidget(),
                    const SizedBox(height: 20.0),
                  ],
                ),
              ),
            )
          ],
        ),
      )),
      backgroundColor: const Color(0xFFEFF7FF),
    );
  }

  createAboutUsWidget() {
    return Column(
      children: [
        Container(
          height: 38,
          child: const Center(
            child: Text(
              'About Us',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontFamily: 'Roboto Slab',
                fontWeight: FontWeight.bold,
                fontSize: 16,
                color: Color(0xff002E5B),
              ),
            ),
          ),
          decoration: const BoxDecoration(color: Color(0xffF0F3F6), boxShadow: [
            BoxShadow(
                color: Color(0xffffffff),
                blurRadius: 6,
                spreadRadius: 0,
                offset: Offset(-3, -3)),
            BoxShadow(
                color: Color(0xffDDE4EF),
                blurRadius: 6,
                spreadRadius: 0,
                offset: Offset(3, 3)),
          ]),
        ),
        const ListTile(
          contentPadding: EdgeInsets.only(left: 25, top: 20, right: 25),
          title: Text(
            'WHAT IS INSTASURE?',
            textAlign: TextAlign.left,
            style: TextStyle(
              fontFamily: 'Roboto Slab',
              fontSize: 16,
              color: Color(0xff002E5B),
            ),
          ),
          subtitle: Text(
            '''\nInsurance sector is often characterized as traditional and conservativewith limited capacities for a profound transformation. However, Instasure 
believe digitally-enhanced services are no longer a nice-to-have and it’s a shift no
industry can ignore. The sector of insurance shouldn’t be an exception. 
With the purpose of reinventing insurance, we are trying to build first-ever
‘insurance-as-a-service’ platform in Bangladesh capable of meeting the rapidly
evolving needs of today’s Gen Z. Better cover for less cost and fast claim
processing using technology. If this wasn’t enough, Instasure is removing all 
excess on claims and allowing you to switch your cover off and back on with
the push of a button.''',
            textAlign: TextAlign.left,
            style: TextStyle(
              fontFamily: 'Roboto Slab',
              fontSize: 11,
              color: Color(0xff002E5B),
            ),
          ),
        ),
        const SizedBox(
          height: 20,
        ),
        ImageWidget(
          imagePath: 'assets/about_instasure_icon.png',
          onClicked: () async {},
          imageHeight: 152,
          imageWidth: 152,
          borderWidth: 15,
          borderRadious: 40,
        ),
        const SizedBox(
          height: 20,
        ),
        const ListTile(
          contentPadding: EdgeInsets.only(left: 25, top: 20, right: 25),
          title: Text(
            'WHY INSTASURE?',
            textAlign: TextAlign.left,
            style: TextStyle(
              fontFamily: 'Roboto Slab',
              fontSize: 16,
              color: Color(0xff002E5B),
            ),
          ),
          subtitle: Text(
            '''\nIt all has to do with machine learning technology/AI.

In order to trulyre Think insurance, Instasure has stripped away all the expenses 
and limitations we have come to accept from insurance companies. We wanted to
look at how we could offer more cost-effective premiums, while improving 
convenience and general cover.

By creating an online automated system, we were able to remove all brokers and 
other unnecessary middlemen. Our proprietary AI/ machine learning algorithm
analyze all possible scenario based on your handset & your personal profile and
thus Instasure is able to offer all the bells and whistles that really improve our 
customers lifestyle, while reducing the cost of premiums per device and altogether 
removing excess on claims. Why not see how Instasure can add value to your life?
''',
            textAlign: TextAlign.left,
            style: TextStyle(
              fontFamily: 'Roboto Slab',
              fontSize: 11,
              color: Color(0xff002E5B),
            ),
          ),
        ),
      ],
    );
  }
}
