import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:instasure/Utilities/userPref.dart';
import 'package:instasure/domains/repo/apiClientCustomerDasboard.dart';
import 'package:instasure/screens/dashboard/deviceInsurancePurchaseDetail.dart';
import 'package:instasure/screens/travelInsurance/travelInsuranceHistoryDetails.dart';
import 'package:instasure/widgets/topView4.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'dart:async';
import 'package:http/http.dart' as http;
import 'package:instasure/Utilities/ShowMessage.dart';

class PaymentWebview extends StatefulWidget {
  const PaymentWebview({Key? key, required this.url, required this.id})
      : super(key: key);
  final String url;
  final String id;

  @override
  _PaymentWebviewState createState() => _PaymentWebviewState();
  //            'https://sandbox.aamarpay.com//paynow.php?track=AAM1657013557198944',

}

class _PaymentWebviewState extends State<PaymentWebview> {
  final Completer<WebViewController> _controller =
      Completer<WebViewController>();
  final ApiClientCustomerDasboard _apiClient = ApiClientCustomerDasboard();

  @override
  void initState() {
    print("url3:${widget.url}");


    String string = widget.url;

    final containsD = string.contains('Invalid Email Address');
    print(containsD);
    if(containsD==true){
      //showAlertDialog(context, 'Invalid Email Address.');
     /* ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: const Text('Invalid Email Address'),
        backgroundColor: Colors.red.shade300,
      ));*/
      Navigator.of(context).pop();
    }
    print('I am call');
  }

  Future<void> aamarpaySuccess() async {

    print('start calling');

    EasyLoading.instance.userInteractions = false;
    EasyLoading.show(status: 'Processing...');

    UserPref prefs = UserPref();
    Future<String?> token = prefs.getTokenFromPref();
    String? accessToken = await token;

    var headers = {
      'Accept': 'application/json',
      'Authorization': 'Bearer $accessToken'
    };
    var request = http.MultipartRequest('POST',
        Uri.parse('https://instasure.xyz/api/aamarpay_success_response'));
    request.fields.addAll(
        {'opt_a': 'TravelInsOrder', 'opt_b': widget.id, 'is_api': 'true'});

    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();
    EasyLoading.dismiss();
    print(response.statusCode);
    print(response);
    print('okk');
    print(widget.id);

    if (response.statusCode == 200) {
      print(await response.stream.bytesToString());


      //showMessage('Thanks for your payment. We will issue your travel insurance document within 1 business day. A soft copy will be send by mail, hardcopy by courier in given address. You can also download a copy from app or web site after issue. For any query, Please call 096 06 25 25 25 or mail us.');
      //await Future.delayed(const Duration(seconds: 3), (){});


      Navigator.of(context).pushReplacement(MaterialPageRoute(
          builder: (BuildContext context) => TravelInsuranceHistoryDetails(
                id: widget.id, message:'Thanks for your payment. We will issue your travel insurance document within 1 business day. A soft copy will be send by mail, hardcopy by courier in given address. You can also download a copy from app or web site after issue. For any query, Please call 096 06 25 25 25 or mail us.'
              )));
    } else {
      //showMessage('Thanks for your payment. We will issue your travel insurance document within 1 business day. A soft copy will be send by mail, hardcopy by courier in given address. You can also download a copy from app or web site after issue. For any query, Please call 096 06 25 25 25 or mail us.');
     // await Future.delayed(const Duration(seconds: 3), (){});
      /*print(response.reasonPhrase);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Failed'),
        backgroundColor: Colors.red.shade300,
      ));*/
      Navigator.of(context).pushReplacement(MaterialPageRoute(
          builder: (BuildContext context) => TravelInsuranceHistoryDetails(
              id: widget.id,message:'Thanks for your payment. We will issue your travel insurance document within 1 business day. A soft copy will be send by mail, hardcopy by courier in given address. You can also download a copy from app or web site after issue. For any query, Please call 096 06 25 25 25 or mail us. Please wait... You are redirecting to payment history page'
          )));

    }
  }

  Future<void> aamarpayCancl() async {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: const Text('Processing Data'),
      backgroundColor: Colors.green.shade300,
    ));
    Map<String, dynamic> data = {
      "opt_a": 'TravelInsurance',
      "opt_b": widget.id,
      "is_api": 'true',
    };
    UserPref prefs = UserPref();
    Future<String?> token = prefs.getTokenFromPref();
    String? accessToken = await token;
    dynamic res = await _apiClient.aamarpayCancleResponse(data, accessToken!);
    ScaffoldMessenger.of(context).hideCurrentSnackBar();

    if (res.statusCode == 200) {
      Navigator.of(context).popUntil((route) => route.isFirst);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('${res.data['message']}'),
        backgroundColor: Colors.red.shade300,
      ));
    }
  }
  showMessage(String message) {
    Fluttertoast.showToast(
        msg: message,
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.CENTER,
        timeInSecForIosWeb: 1,
        backgroundColor: Colors.black,
        textColor: Colors.white,
        fontSize: 16.0);
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: null,
      backgroundColor: const Color(0xFFEFF7FF),
      body: SizedBox(
        height: MediaQuery.of(context).size.height,
        child: Column(
          children: [
            SizedBox(
              height: 125,
              child: Stack(
                children: [
                  const TopView4(),
                  Positioned(
                    bottom: 20.0,
                    left: 40.0,
                    child: SizedBox(
                        height: 30,
                        width: 30,
                        // color: const Color.fromRGBO(0, 46, 91, 1.0),
                        // padding: const EdgeInsets.fromLTRB(10, 15, 10, 5),
                        child: TextButton(
                          child: Image.asset('assets/back_button_icon.png'),
                          onPressed: () {
                            Navigator.of(context).pop();
                          },
                        )),
                  )
                ],
              ),
            ),
            SizedBox(
              height: MediaQuery.of(context).size.height - 200,
              child: WebView(
                navigationDelegate: (NavigationRequest request) async {

                  print('1111');
                  print(request.url);
                  print('22222');

                  print(request);
print('get_successnn'+widget.id);
                  if (request.url.contains("purchase/details") || request.url.contains("success")) {
                    print('success2x');
                    print(widget.id);
                    if (widget.id == "0") {
                      Navigator.of(context).popUntil((route) => route.isFirst);
                    } else {
                      aamarpaySuccess();
                    }
                    //Navigator.pop(context);

                    return NavigationDecision.prevent;
                  } else if (request.url.contains("fail")) {
                    print('fail2x');
                    // Navigator.pop(context);
                    if (widget.id == "0") {
                      Navigator.of(context).popUntil((route) => route.isFirst);
                    } else {
print('ccc');
                      aamarpayCancl();

                      Navigator.of(context).pushReplacement(MaterialPageRoute(
                          builder: (BuildContext context) =>
                              DeviceInsurancePurchaseDetail(
                                id: widget.id,
                                isCancel: true,
                              )));
                      // aamarpayCancl();
                    }

                    // setState(() {});
                    // Timer(const Duration(seconds: 3),
                    //     () => Navigator.pop(context));
                    return NavigationDecision.prevent;
                  } else {
                    setState(() {});
                    return NavigationDecision.navigate;
                  }
                },
                backgroundColor: Colors.white,
                zoomEnabled: true,
                initialUrl: widget.url,
                javascriptMode: JavascriptMode.unrestricted,
                onWebViewCreated: (WebViewController webViewController) {
                  _controller.complete(webViewController);
                },
                onPageFinished: (url) {
                  print('get_success21');
                  print(url);
                  print('get_success222');

                  if (url.contains("success")) {
                    print('success2');
                    print(widget.id);
                    if (widget.id == "0") {
                      print('get1');
                      Navigator.of(context).popUntil((route) => route.isFirst);
                    } else {
                      print('get2');
                      aamarpaySuccess();
                    }
                    //Navigator.of(context).popUntil((route) => route.isFirst);
                  }else if(url.contains("fail")){

                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                      content: const Text('Payment Failed'),
                      backgroundColor: Colors.red.shade300,
                    ));

                    aamarpayCancl();
                    print('ccc2');
                    print('fail2');
                    if (widget.id == "0") {



                      Navigator.of(context).popUntil((route) => route.isFirst);
                    } else {

                      Navigator.of(context).pop();
                     /* Navigator.of(context).pushReplacement(MaterialPageRoute(
                          builder: (BuildContext context) =>
                              DeviceInsurancePurchaseDetail(
                                id: widget.id,
                                isCancel: true,
                              )));
                      // aamarpayCancl();*/

                    }
                  }
                },
              ),
            ),
          ],
        ),
      ),
    );
  }



showAlertDialog(BuildContext context, String msg) {
  // set up the button
  Widget okButton = TextButton(
    child: const Text("OK"),
    onPressed: () {
      //Navigator.of(context).pop();
      Navigator.of(context, rootNavigator: true).pop();
    },
  );

  // set up the AlertDialog
  AlertDialog alert = AlertDialog(
    title: const Text("Instasure"),
    content: Text(msg),
    actions: [
      okButton,
    ],
  );

  // show the dialog
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return alert;
    },
  );
}

}