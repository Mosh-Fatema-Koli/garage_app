
import 'package:flutter/material.dart';
import 'package:instasure/screens/travelInsurance/getTravelInsurance.dart';
import 'package:instasure/screens/travelInsurance/travelInsuranceHistory.dart';
import 'package:instasure/widgets/topView4.dart';

class InsuranceSubMenu extends StatefulWidget {
  const InsuranceSubMenu({Key? key}) : super(key: key);

  @override
  State<InsuranceSubMenu> createState() => _InsuranceSubMenuState();
}

class _InsuranceSubMenuState extends State<InsuranceSubMenu> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: null,
        backgroundColor: const Color(0xFFEFF7FF),
        body: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(5),
              child: Column(
                children: <Widget>[
                  Stack(
                    children: [
                      const TopView4(),
                      Positioned(
                        bottom: 20.0,
                        left: 40.0,
                        child: SizedBox(
                            height: 30,
                            width: 30,
                            // color: const Color.fromRGBO(0, 46, 91, 1.0),
                            // padding: const EdgeInsets.fromLTRB(10, 15, 10, 5),
                            child: TextButton(
                              child: Image.asset('assets/back_button_icon.png'),
                              onPressed: () {
                                Navigator.of(context).pop();
                              },
                            )),
                      )
                    ],
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Container(
                      height: 50,
                      alignment: Alignment.center,
                      child: Text("Travel Insurance"
                        ,
                        style: const TextStyle(
                            fontSize: 16, color: Color.fromRGBO(0, 0, 0, 0.87)),
                      ),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(0),
                        boxShadow: const [
                          BoxShadow(
                              color: Color(0xFFFFFFFF),
                              blurRadius: 6,
                              spreadRadius: 0,
                              offset: Offset(-3, -3)),
                          BoxShadow(
                              color: Color(0xFFDDE4EF),
                              blurRadius: 6,
                              spreadRadius: 0,
                              offset: Offset(3, 3)),
                        ],
                        color: const Color(0xffF0F3F6),
                      )),
                  const SizedBox(
                    height: 30,
                  ),
                  Row(
                    children: [
                      Expanded(
                        flex: 1,

                        child: Padding(
                          padding: const EdgeInsets.all(5),
                          child: GestureDetector(

                            onTap: () {
                              print("Test");
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => const TravelsInsurance()),
                              );
                            },
                            child: Container(
                              //width: (MediaQuery.of(context).size.width - 45) / 3,
                                alignment: Alignment.center,
                                child: GestureDetector(
                                  onTap: () {
                                    print("Test");
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => const TravelsInsurance()),
                                    );
                                  },
                                  child: Padding(
                                    padding: const EdgeInsets.only(
                                        left: 6, right: 4, top: 6, bottom: 2),
                                    child: Column(
                                      children: [
                                        const SizedBox(
                                          height: 10,
                                        ),
                                        Image(
                                          image: AssetImage("assets/buy_now.png"),
                                          height: 60,
                                        ),

                                        const SizedBox(
                                          height: 10,
                                        ),
                                        Text("Buy Insurance",
                                          textAlign: TextAlign.center,
                                          style: const TextStyle(
                                            fontFamily: 'Roboto Slab',
                                            fontSize: 12,
                                            fontWeight: FontWeight.bold,
                                            color: Color(0xff000000),
                                          ),
                                        ),
                                        const SizedBox(
                                          height: 20,
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(40),
                                  border: Border.all(
                                      color: const Color(0xffF0F3F6), width: 6),
                                  boxShadow: const [
                                    BoxShadow(
                                        color: Color(0xFFFFFFFF),
                                        blurRadius: 6,
                                        spreadRadius: 0,
                                        offset: Offset(-3, -3)),
                                  ],
                                  color: const Color(0xFFffffff),
                                )),
                          ),
                        ),
                      ),
                      Expanded(
                        flex: 1,
                        child: Padding(
                          padding: const EdgeInsets.all(5),
                          child: GestureDetector(

                            onTap: () {
                              print("Test");
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => const TravelInsuranceHistory()),
                              );
                            },
                            child: Container(
                              //width: (MediaQuery.of(context).size.width - 45) / 3,
                                alignment: Alignment.center,
                                child: GestureDetector(
                                  onTap: () {
                                    print("Test");
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => const TravelInsuranceHistory()),
                                    );
                                  },
                                  child: Padding(
                                    padding: const EdgeInsets.only(
                                        left: 6, right: 4, top: 6, bottom: 2),
                                    child: Column(
                                      children: [
                                        const SizedBox(
                                          height: 10,
                                        ),
                                        Image(
                                          image: AssetImage("assets/report.png"),
                                          height: 60,
                                        ),

                                        const SizedBox(
                                          height: 10,
                                        ),
                                        Text("Purchase List",
                                          textAlign: TextAlign.center,
                                          style: const TextStyle(
                                            fontFamily: 'Roboto Slab',
                                            fontSize: 12,
                                            fontWeight: FontWeight.bold,
                                            color: Color(0xff000000),
                                          ),
                                        ),
                                        const SizedBox(
                                          height: 20,
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(40),
                                  border: Border.all(
                                      color: const Color(0xffF0F3F6), width: 6),
                                  boxShadow: const [
                                    BoxShadow(
                                        color: Color(0xFFFFFFFF),
                                        blurRadius: 6,
                                        spreadRadius: 0,
                                        offset: Offset(-3, -3)),
                                  ],
                                  color: const Color(0xFFffffff),
                                )),
                          ),
                        ),
                      ),

                    ],
                  ),


                ],
              ),
            )));
  }

}
