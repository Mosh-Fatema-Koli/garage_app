// ignore_for_file: unnecessary_new
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:instasure/Utilities/helper.dart';
import 'package:instasure/Utilities/userPref.dart';
import 'package:instasure/domains/models/travelInsurance/travelInsuranceHistoryDetailModel.dart';
import 'package:instasure/domains/repo/apiTravelInsurance.dart';
import 'package:instasure/screens/travelInsurance/invoice.dart';
import 'package:instasure/screens/travelInsurance/paymentWebView2.dart';
import 'package:instasure/screens/travelInsurance/travelInsuranceHistory.dart';
import 'package:instasure/widgets/rowWidget.dart';
import 'package:instasure/widgets/topView4.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../domains/models/dashboard/diagnosisReportList.dart';

class TravelInsuranceHistoryDetails extends StatefulWidget {
  const TravelInsuranceHistoryDetails({Key? key, required this.id , required this.message})
      : super(key: key);
  final String id;
  final String message;
  @override
  _InsuranceHistoryDetailsState createState() => _InsuranceHistoryDetailsState();
}

class _InsuranceHistoryDetailsState extends State<TravelInsuranceHistoryDetails> {


  final ApiTravelInsurance _apiClient = ApiTravelInsurance();
  late TravelInsuranceHistoryDetailModel? travelInsuranceHistoryDetailModel;
  var loading = true;
  String my_url = '';
  String my_url2 = '';


String this_order='0';
  @override
  void initState() {
    super.initState();
    () async {
      await Future.delayed(Duration.zero);
      getTravelInsuranceHistoryDetailData();
    }();
  }



  Future<void> _launchURL(String url) async {

    final uri = Uri.https(
        '',
        url);


   // final Uri uri = Uri(scheme: "https", host: url);
    if(!await launchUrl(
      uri,
      mode: LaunchMode.externalApplication,
    )) {
      throw "Can not launch url";
    }
  }



  Future<void> getTravelInsuranceHistoryDetailData() async {
    UserPref prefs = UserPref();
    Future<String?> token = prefs.getTokenFromPref();
    String? accessToken = await token;
    EasyLoading.instance.userInteractions = false;
    EasyLoading.show(status: 'Processing..');
    dynamic res = await _apiClient.getTravelInsuranceHisDetailtData(
        widget.id, accessToken!);

    EasyLoading.dismiss();
    //ScaffoldMessenger.of(context).hideCurrentSnackBar();
    print(res);
    print('pp');
    if (res.statusCode == 200) {
      if (res.data['code'] == 200) {
        this_order=res.data['data']['id'].toString();
        // InsuranceHistoryModel histories =
        TravelInsuranceHistoryDetailModel _travelInsuranceHistoryDetailModel =
            TravelInsuranceHistoryDetailModel.fromJson(res.data['data']);





        setState(() {
          travelInsuranceHistoryDetailModel =  _travelInsuranceHistoryDetailModel;


          print('1111');
          print(travelInsuranceHistoryDetailModel?.policy_certificate);
          print(travelInsuranceHistoryDetailModel?.policy_certificate_path);
          print('222');

          loading = false;
          if (travelInsuranceHistoryDetailModel?.policy_certificate_path !=
              null){
            my_url= travelInsuranceHistoryDetailModel?.policy_certificate_path ?? ' ';
            my_url=my_url.replaceAll('https://', '');
            print(my_url);
            print('fff');
          }
        });
      } else {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('${res.data['message']}'),
          backgroundColor: Colors.red.shade300,
        ));
        setState(() {
          loading = false;
        });
      }
    } else {
      setState(() {
        loading = false;
      });
    }
  }

  Future<void> payNow() async {
    EasyLoading.instance.userInteractions = false;
    EasyLoading.show(status: 'Processing...');
    Map<String, dynamic> data = {
      "order_id": travelInsuranceHistoryDetailModel?.id ?? '',
    };
    UserPref prefs = UserPref();
    Future<String?> token = prefs.getTokenFromPref();
    String? accessToken = await token;
    dynamic res = await _apiClient.travelInsuranceOrderPay(data, accessToken!);
    //ScaffoldMessenger.of(context).hideCurrentSnackBar();
    print(res);
    print('go');
    EasyLoading.dismiss();
    if (res.statusCode == 200) {
      Navigator.push(
          context,
          MaterialPageRoute(
              builder: (context) => PaymentWebview(
                    url: res.data.toString(),
                    id: this_order,
                  )));
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('${res.data['message']}'),
        backgroundColor: Colors.red.shade300,
      ));
      // ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      //   content: Text('Error: ${res.data['data']['phone'][0]}'),
      //   backgroundColor: Colors.red.shade300,
      // ));

    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(
        // title: const Text('Home'),

        // title: Text("YOUR_APPBAR_TITLE"),
        // automaticallyImplyLeading: false,



        title: Image.asset('assets/instasure_icon.png',fit: BoxFit.contain, height: 32,),

        leading: new IconButton(
          icon: new Icon(Icons.arrow_back, color: const Color(0xff002E5B),),
          onPressed: () =>
              Navigator.push( context, MaterialPageRoute( builder: (context) => const TravelInsuranceHistory()), ),
        ),


        automaticallyImplyLeading: true,
        backgroundColor: Colors.white,
        actions: <Widget>[
          IconButton(
            // AssetImage("assets/home/insurance.png"),
            icon: Icon(
              Icons.help_center,
              color: const Color(0xff002E5B),
            ),
            /*icon: Icon(
                Icons.settings,
                color: Colors.white,
              ),*/
            onPressed: () {
              setState(() {

              });
              /* Navigator.push(
                   context,
                   MaterialPageRoute(builder: (context) => const  MenuScreen()),
                 );*/

            },
          )
        ],
      ),
      body:   Center(
              child: Padding(
              padding: const EdgeInsets.all(0),
              child: Column(
                children: [
                  const SizedBox(height: 20.0),
                  Expanded(
                    child: ListView(
                      children: <Widget>[
                        const SizedBox(height: 0.0),
                         createHeader(),

                        const SizedBox(height: 45.0),
                       // if(widget.message!='')
                        message(),

                       // const SizedBox(height: 10.0),
                     /*   if (!loading) ...[
                          if (travelInsuranceHistoryDetailModel?.policyNumber !=
                              null)
                            if(widget.message!='')
                              Center(
                              //child: Text(
                             //   'Policy Number: ${travelInsuranceHistoryDetailModel?.policyNumber}'),
          /*child: Padding(
            padding: const EdgeInsets.all(0.0),

        child:Padding(
          padding: const EdgeInsets.only(top:10,bottom:10),
          child: Text(
            widget.message,
            style: TextStyle(
              fontSize: 16,
              color: Colors.green,
            ),
          ),
        )

          ),*/


      ),
                          const SizedBox(height: 10.0),
                        ],*/

                        const SizedBox(height: 5.0),

                      //  message(),
                       // message(),
                    /*
                        const SizedBox(height: 2.0),
                        createCustomerInfo(),
                        const SizedBox(height: 20.0),
                        createFlightDetails(),
                        const SizedBox(height: 20.0),
                        createPriceDetails(),
                        const SizedBox(height: 20.0), */
                        createBottomButton(),
                        const SizedBox(height: 40.0),


                      ],
                    ),
                  ),
                ],
              ),
            )),



      backgroundColor: const Color(0xFFEFF7FF),
    );
  }

  createHeader() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: <Widget>[


        Container(
          height: 38,
          child: const Center(
            child: Text(
              'Travel Insurance History Details',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontFamily: 'Roboto Slab',
                fontSize: 16,
                color: Color(0xff002E5B),
              ),
            ),
          ),
          decoration: const BoxDecoration(color: Color(0xffF0F3F6), boxShadow: [
            BoxShadow(
                color: Color(0xffffffff),
                blurRadius: 6,
                spreadRadius: 0,
                offset: Offset(-3, -3)),
            BoxShadow(
                color: Color(0xffDDE4EF),
                blurRadius: 6,
                spreadRadius: 0,
                offset: Offset(3, 3)),
          ]),
        ),

        SizedBox(height: 10),

       /* Padding(
          padding: const EdgeInsets.only(left: 10, right: 10),
          child: Text(
            loading
                ? ''
                : travelInsuranceHistoryDetailModel
                        ?.travelInsuranceCategoryTitle ??
                    '',
            textAlign: TextAlign.center,
            style: const TextStyle(
              fontFamily: 'Roboto Slab',
              fontSize: 16,
              color: Color(0xff002E5B),
            ),
          ),
        ),*/



    /*      Text(
          loading
              ? ''
              : getDateString(
                  travelInsuranceHistoryDetailModel?.createdAt ?? " ",
                  'dd MMM yyyy'),
          textAlign: TextAlign.center,
          style: const TextStyle(
            fontFamily: 'Roboto Slab',
            fontSize: 12,
            color: Color(0xff002E5B),
          ),
        ),
*/

    SizedBox( height: 10)
      ],
    );
  }

  createBottomButton() {
    return Padding(
      padding: const EdgeInsets.only(
        left: 14,
        right: 14,
      ),
      child: SizedBox(
        height: 30,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            if (!loading) ...[
              if (travelInsuranceHistoryDetailModel?.paymentStatus ==
                  'unpaid') ...[
                Container(
                  height: 30,
                  width: 150,

                  //padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
                  child: TextButton(
                    child: const Text(
                      'Cancel',
                      style: TextStyle(color: Colors.white),
                    ),
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                  ),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                          color: const Color(0xff000000).withOpacity(0.16),
                          blurRadius: 3,
                          spreadRadius: 0,
                          offset: const Offset(0, 3)),
                    ],
                    color: const Color(0xff002E5B),
                  ),
                ),
                Container(
                  height: 30,
                  width: 150,
                  //padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
                  child: TextButton(
                    child: const Text(
                      'Pay Now',
                      style: TextStyle(color: Colors.white),
                    ),
                    onPressed: payNow,
                  ),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                          color: const Color(0xff000000).withOpacity(0.16),
                          blurRadius: 3,
                          spreadRadius: 0,
                          offset: const Offset(0, 3)),
                    ],
                    color: const Color(0xff002E5B),
                  ),
                ),
              ] else if (travelInsuranceHistoryDetailModel?.paymentStatus ==
                  'paid') ...[
                    if(travelInsuranceHistoryDetailModel?.policy_certificate !=null)
                Container(
                  height: 30,
                  width: 110,

                  //padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
                  child: TextButton(
                    child: const Text(
                      'Download Policy' ,
                      style: TextStyle(color: Colors.white, fontSize: 10),
                    ),
                    onPressed: () {
                      _launchURL(my_url);
                    },
                  ),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                          color: const Color(0xff000000).withOpacity(0.16),
                          blurRadius: 3,
                          spreadRadius: 0,
                          offset: const Offset(0, 3)),
                    ],
                    color: const Color(0xff002E5B),
                  ),
                ),



               /* if(travelInsuranceHistoryDetailModel?.policy_certificate ==null)
                  Container(
                    height: 30,
                    width: 110,
                    decoration: BoxDecoration(
                    ),
                  ),*/


                if(travelInsuranceHistoryDetailModel?.policy_certificate ==null)
                Container(
                  height: 30,
                  width: 110,
                  //padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
                  decoration: BoxDecoration(
                  ),
                ),


                Container(
                  height: 30,
                  width: 110,
                  //padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
                  child: TextButton(
                    child: const Text(
                      'Download Invoice',
                      style: TextStyle(color: Colors.white, fontSize: 10),
                    ),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => Invoice(
                              id: '${travelInsuranceHistoryDetailModel?.id}'
                                  '',
                            )),
                      );
                    },
                  ),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                          color: const Color(0xff000000).withOpacity(0.16),
                          blurRadius: 3,
                          spreadRadius: 0,
                          offset: const Offset(0, 3)),
                    ],
                    color: const Color(0xff002E5B),
                  ),
                ),

                if(travelInsuranceHistoryDetailModel?.policy_certificate ==null)
             Container(
                  height: 30,
                  width: 110,
                  //padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),

                  decoration: BoxDecoration(
                  ),
                ),
                // if (DateTime.now()
                //         .difference(DateTime.parse(
                //             '${travelInsuranceHistoryDetailModel?.updatedAt}'))
                //         .inDays >
                //     30)
                if(travelInsuranceHistoryDetailModel?.policy_certificate !=null)
                Container(
                  height: 30,
                  width: 110,
                  //padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
                  child: TextButton(
                    child: const Text(
                      'Claim',
                      style: TextStyle(color: Colors.white, fontSize: 10),
                    ),
                    onPressed: () {
                      showPopUp(context);
                    },
                  ),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                          color: const Color(0xff000000).withOpacity(0.16),
                          blurRadius: 3,
                          spreadRadius: 0,
                          offset: const Offset(0, 3)),
                    ],
                    color: const Color(0xff002E5B),
                  ),
                ),
              ]
            ],
          ],
        ),
      ),
    );
  }

  createCustomerInfo() {
    return Padding(
        padding:
            const EdgeInsets.only(right: 14, top:30, bottom: 10, left: 14),
        child: Container(
            padding: const EdgeInsets.only(top: 20, bottom: 20, right: 2),
            //width: (MediaQuery.of(context).size.width - 45) / 3,
            alignment: Alignment.centerLeft,
            // padding: const EdgeInsets.only(top: 20),
            child: Padding(
              padding: const EdgeInsets.only(
                left: 30,
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  const SizedBox(height: 10.0),
                  const Text(
                    'DETAILS',
                    textAlign: TextAlign.left,
                    style: TextStyle(
                      fontFamily: 'Roboto Slab',
                      fontSize: 16,
                      color: Color(0xff002E5B),
                      decoration: TextDecoration.underline,
                    ),
                  ),


                  const SizedBox(height: 5.0),
                  RowWidget(
                      title: "Contact Person Name: ",
                      value: loading
                          ? ''
                          : travelInsuranceHistoryDetailModel?.fullName ?? '',
                      fSize: 16),
                  const SizedBox(height: 5.0),
                  RowWidget(
                      title: "Contact Person Phone: ",
                      value: loading
                          ? ''
                          : travelInsuranceHistoryDetailModel?.phone ?? '',
                      fSize: 16),
                  const SizedBox(height: 5.0),
                  RowWidget(
                      title: "Contact Person Email: ",
                      value: loading
                          ? ''
                          : travelInsuranceHistoryDetailModel?.email ?? '',
                      fSize: 16),
                  const SizedBox(height: 5.0),
                  RowWidget(
                      title: "Contact Person Age: ",
                      value: loading
                          ? ''
                          : travelInsuranceHistoryDetailModel?.age ?? '',
                      fSize: 16),
                ],
              ),
            ),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(40),
              boxShadow: const [
                BoxShadow(
                    color: Color(0xFFFFFFFF),
                    blurRadius: 6,
                    spreadRadius: 0,
                    offset: Offset(-3, -3)),
              ],
              color: const Color(0xFFF0F3F6),
            )));
  }



  message() {

    return Padding(
        padding:
        const EdgeInsets.only(right: 14, top: 10, bottom: 10, left: 14),
        child: Container(
            padding: const EdgeInsets.only(top: 20, bottom: 20, right: 2),
            //width: (MediaQuery.of(context).size.width - 45) / 3,
            alignment: Alignment.centerLeft,
            // padding: const EdgeInsets.only(top: 20),
            child: Padding(
              padding: const EdgeInsets.only(
                left: 30,
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  const SizedBox(height: 10.0),

                  Text(
                    'Thanks for your payment. We will issue your travel insurance document within 1 business day. A soft copy will be send by mail, hardcopy by courier in given address. '.toString(),
                    textAlign: TextAlign.left,
                    style: TextStyle(
                      fontFamily: 'Roboto Slab',
                      fontSize: 17,
                      color: Color(0xff002E5B),
                      decoration: TextDecoration.none,
                    ),
                  ),
                  const SizedBox(height: 20.0),

                  Text(
                    'You can also download a copy from app or web site after issue. For any query, Please call 096 06 25 25 25 or mail us.'.toString(),
                    textAlign: TextAlign.left,
                    style: TextStyle(
                      fontFamily: 'Roboto Slab',
                      fontSize: 17,
                      color: Color(0xff002E5B),
                      decoration: TextDecoration.none,
                    ),
                  ),
                  SizedBox( height: 10),

                ],
              ),
            ),
            ));
  }




  createFlightDetails() {
    return Padding(
        padding:
            const EdgeInsets.only(right: 14, top: 10, bottom: 10, left: 14),
        child: Container(
            // padding: const EdgeInsets.all(10.0),
            //width: (MediaQuery.of(context).size.width - 45) / 3,
            height: 164,
            alignment: Alignment.centerLeft,
            // padding: const EdgeInsets.only(top: 20),
            child: Padding(
              padding: const EdgeInsets.only(
                left: 30,
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  const SizedBox(height: 10.0),
                  const Text(
                    'FLIGHT DETAILS',
                    textAlign: TextAlign.left,
                    style: TextStyle(
                      fontFamily: 'Roboto Slab',
                      fontSize: 16,
                      color: Color(0xff002E5B),
                      decoration: TextDecoration.underline,
                    ),
                  ),
                  const SizedBox(height: 1.0),
                  RowWidget(
                      title: "Passport Number: ",
                      value: loading
                          ? ''
                          : travelInsuranceHistoryDetailModel?.passportNumber ??
                              '',
                      fSize: 16),
                  const SizedBox(height: 1.0),
                  RowWidget(
                      title: "Passport Expiry Date: ",
                      value: loading
                          ? ''
                          : getDateStringFRom(
                              travelInsuranceHistoryDetailModel
                                      ?.passportExpireTill ??
                                  "2000-01-01",
                              'yyyy-MM-dd',
                              'dd MMMM yyyy'),
                      fSize: 16),
                  const SizedBox(height: 1.0),
                  RowWidget(
                      title: "Flight Number:  ",
                      value: loading
                          ? ''
                          : travelInsuranceHistoryDetailModel?.flightNumber ??
                              '',
                      fSize: 16),
                  const SizedBox(height: 1.0),
                  RowWidget(
                      title: "Flight Date:  ",
                      value: loading
                          ? ''
                          : getDateStringFRom(
                              travelInsuranceHistoryDetailModel?.flightDate ??
                                  "2000-01-01",
                              'yyyy-MM-dd',
                              'dd MMMM yyyy'),
                      fSize: 16),
                  const SizedBox(height: 1.0),
                  RowWidget(
                      title: "Return Date:  ",
                      value: loading
                          ? ''
                          : getDateStringFRom(
                              travelInsuranceHistoryDetailModel?.returnDate ??
                                  "2000-01-01",
                              'yyyy-MM-dd',
                              'dd MMMM yyyy'),
                      fSize: 16),
                  const SizedBox(height: 1.0),
                  RowWidget(
                      title: "Total Stay:  ",
                      value: loading
                          ? ''
                          : "${travelInsuranceHistoryDetailModel?.totalDate} Days ",
                      fSize: 16),
                ],
              ),
            ),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(40),
              boxShadow: const [
                BoxShadow(
                    color: Color(0xFFFFFFFF),
                    blurRadius: 6,
                    spreadRadius: 0,
                    offset: Offset(-3, -3)),
              ],
              color: const Color(0xFFF0F3F6),
            )));
  }

  createPriceDetails() {
    return Padding(
        padding:
            const EdgeInsets.only(right: 14, top: 10, bottom: 10, left: 14),
        child: Container(
            // padding: const EdgeInsets.all(10.0),
            //width: (MediaQuery.of(context).size.width - 45) / 3,
            height: 164,
            alignment: Alignment.centerLeft,
            // padding: const EdgeInsets.only(top: 20),
            child: Padding(
              padding: const EdgeInsets.only(
                left: 30,
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  const SizedBox(height: 10.0),
                  const Text(
                    'PRICE EVALUATION',
                    textAlign: TextAlign.left,
                    style: TextStyle(
                      fontFamily: 'Roboto Slab',
                      fontSize: 16,
                      color: Color(0xff002E5B),
                      decoration: TextDecoration.underline,
                    ),
                  ),
                  const SizedBox(height: 1.0),
                  RowWidget(
                      title: "Insurance Price: ",
                      value: loading
                          ? ''
                          : travelInsuranceHistoryDetailModel?.insPrice.toString() ?? "",
                      fSize: 16),
                  const SizedBox(height: 1.0),
                  RowWidget(
                      title:
                          "Total Vat (${loading ? '' : travelInsuranceHistoryDetailModel?.vatPercentage ?? ""})%: ",
                      value: loading
                          ? ''
                          : travelInsuranceHistoryDetailModel?.totalVat.toString() ?? "",
                      fSize: 16),
                  const SizedBox(height: 1.0),
                  RowWidget(
                      title:
                          "Total Service Charge (${loading ? '' : travelInsuranceHistoryDetailModel?.serviceAmount ?? ""})%:  ",
                      value: loading
                          ? ''
                          : travelInsuranceHistoryDetailModel
                                  ?.serviceTotalAmount ??
                              "",
                      fSize: 16),
                  const SizedBox(height: 1.0),
                  RowWidget(
                      title: "Grand Total:  ",
                      value: loading
                          ? ''
                          : travelInsuranceHistoryDetailModel?.grandTotal ?? "",
                      fSize: 16),
                  const SizedBox(height: 1.0),
                  RowWidget(
                      title: "Payment Status:  ",
                      value: loading
                          ? ''
                          : travelInsuranceHistoryDetailModel?.paymentStatus ??
                              "",
                      fSize: 16),
                ],
              ),
            ),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(40),
              boxShadow: const [
                BoxShadow(
                    color: Color(0xFFFFFFFF),
                    blurRadius: 6,
                    spreadRadius: 0,
                    offset: Offset(-3, -3)),
              ],
              color: const Color(0xFFF0F3F6),
            )));
  }

  Future<Future> showPopUp(context) async {
    Size size = MediaQuery.of(context).size;
    return showDialog(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext context) {
          return StatefulBuilder(builder: (context, setState) {
            return AlertDialog(
              backgroundColor: Colors.white,
              shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.all(Radius.circular(20.0))),
              content: Padding(
                padding: const EdgeInsets.all(2.0),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    SizedBox(
                      height: 60,
                      width: 60,
                      child: Image.asset("assets/info_icon.png"),
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    const Center(
                      child: Text(
                        "Claims Important Information",
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.black, fontSize: 18),
                      ),
                    ),
                    const Padding(
                      padding: EdgeInsets.only(top: 15.0),
                      child: Text(
                        "WHAT TO DO IN THE CASE OF A MEDICAL EMERGENCY",
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.black, fontSize: 13),
                      ),
                    ),
                    const Padding(
                      padding: EdgeInsets.only(top: 15.0),
                      child: Text(
                        "In the event of Illness or Accident abroad which may lead to Hospital treatment or Curtailment of your trip",
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.black, fontSize: 12),
                      ),
                    ),
                    const Padding(
                      padding: EdgeInsets.only(top: 15.0),
                      child: Text(
                        'Please Contact',
                        textAlign: TextAlign.left,
                        style: TextStyle(
                          fontFamily: 'Roboto Slab',
                          fontSize: 11,
                          color: Color(0xff002E5B),
                          decoration: TextDecoration.underline,
                        ),
                      ),
                    ),
                    const Padding(
                      padding: EdgeInsets.only(top: 15.0),
                      child: Text(
                        'INTANA GLOBAL',
                        textAlign: TextAlign.left,
                        style: TextStyle(
                          fontFamily: 'Roboto Slab',
                          fontSize: 13,
                          color: Color(0xff002E5B),
                          decoration: TextDecoration.underline,
                        ),
                      ),
                    ),
                    const Padding(
                      padding: EdgeInsets.only(top: 15.0),
                      child: Text(
                        "Sussex House, Perrymount Road, Haywards Heath, West Sussex RH 16 1 DN Telephone: +44(0) 207 902 7405 Email: ops@intana-global.com",
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.black, fontSize: 12),
                      ),
                    ),
                    const Padding(
                      padding: EdgeInsets.only(top: 20.0),
                      child: Text(
                        "NB : (1) To avoid reverse charge calls, the claimant and/or  someone calling on his/her behalf over above telephone/fax be requested to give his/her telephone number so that the INTANA GLOBAL can immediately call back asking for other particulars. (2) INTANA GLOBAL is acting as Third Party Administrators/Assistance provider to render services in respect of claims to the Overseas Mediclaim Policy holders. In the event of a claim, please apply to INTANA GLOBAL for a Claim Form. When completed, please submit direct to INTANA GLOBAL together with the Insurance Certificate and relevant documentation.",
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.black, fontSize: 12),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: <Widget>[
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Container(
                              height: 30,
                              width: 75,
                              // padding: const EdgeInsets.fromLTRB(10, 15, 10, 5),
                              child: TextButton(
                                child: const Text(
                                  'Close',
                                  style: TextStyle(color: Colors.white),
                                ),
                                onPressed: () {
                                  Navigator.of(context).pop();
                                },
                              ),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(20),
                                boxShadow: [
                                  BoxShadow(
                                      color: const Color(0xff000000)
                                          .withOpacity(0.16),
                                      blurRadius: 3,
                                      spreadRadius: 0,
                                      offset: const Offset(0, 3)),
                                ],
                                color: const Color(0xff002E5B),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            );
          });
        });
  }
}
