import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:instasure/Utilities/userPref.dart';
import 'package:instasure/domains/models/travelInsurance/travelInsuranceOrderCreateResModel.dart';
import 'package:instasure/domains/repo/apiTravelInsurance.dart';
import 'package:instasure/screens/travelInsurance/paymentWebView2.dart';
import 'package:instasure/widgets/topView4.dart';

class Payment extends StatefulWidget {
  const Payment({Key? key, required this.travelInsuranceOrderCreateResModel})
      : super(key: key);
  final TravelInsuranceOrderCreateResModel travelInsuranceOrderCreateResModel;

  @override
  _PaymentState createState() => _PaymentState();
}

class _PaymentState extends State<Payment> {
  bool _value = true;
  final ApiTravelInsurance _apiClient = ApiTravelInsurance();

  Future<void> payNow() async {
    if (!_value) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: const Text("Please tick this box if you want to proceed"),
        backgroundColor: Colors.red.shade300,
      ));
      return;
    }
    EasyLoading.instance.userInteractions = false;
    EasyLoading.show(status: 'Processing...');
    Map<String, dynamic> data = {
      "order_id": widget.travelInsuranceOrderCreateResModel.id ?? '',
    };
    print(widget.travelInsuranceOrderCreateResModel.id);
    print('okkp');
    UserPref prefs = UserPref();
    Future<String?> token = prefs.getTokenFromPref();
    String? accessToken = await token;
    dynamic res = await _apiClient.travelInsuranceOrderPay(data, accessToken!);
    //ScaffoldMessenger.of(context).hideCurrentSnackBar();
    EasyLoading.dismiss();
    if (res.statusCode == 200) {
      Navigator.push(
          context,
          MaterialPageRoute(
              builder: (context) => PaymentWebview(
                    url: res.data.toString(),
                     id : widget.travelInsuranceOrderCreateResModel.id.toString()
                  )));
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('${res.data['message']}'),
        backgroundColor: Colors.red.shade300,
      ));
      // ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      //   content: Text('Error: ${res.data['data']['phone'][0]}'),
      //   backgroundColor: Colors.red.shade300,
      // ));

    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: null,
        backgroundColor: const Color(0xFFEFF7FF),
        body: SingleChildScrollView(
          child: Column(
            children: [
              Stack(
                children: [
                  Stack(
                    children: [
                      const TopView4(),
                      Positioned(
                        bottom: 20.0,
                        left: 40.0,
                        child: SizedBox(
                            height: 30,
                            width: 30,
                            // color: const Color.fromRGBO(0, 46, 91, 1.0),
                            // padding: const EdgeInsets.fromLTRB(10, 15, 10, 5),
                            child: TextButton(
                              child: Image.asset('assets/back_button_icon.png'),
                              onPressed: () {
                                Navigator.of(context).pop();
                              },
                            )),
                      )
                    ],
                  ),
                ],
              ),
              Padding(
                padding: const EdgeInsets.all(30.0),
                child: Column(
                  children: <Widget>[
                    const SizedBox(
                      height: 20,
                    ),
                    Container(
                        height: 40,
                        alignment: Alignment.center,
                        padding: const EdgeInsets.all(10),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: <Widget>[
                            Container(
                              alignment: Alignment.center,
                              child: const Text(
                                'Insurance Price',
                                style: TextStyle(
                                    fontSize: 16,
                                    color: Color.fromRGBO(0, 0, 0, 0.87)),
                              ),
                            ),
                            Container(
                              alignment: Alignment.center,
                              child: Text(
                                "${widget.travelInsuranceOrderCreateResModel.insPrice}",
                                style: const TextStyle(
                                    fontSize: 16,
                                    color: Color.fromRGBO(0, 0, 0, 0.87)),
                              ),
                            ),
                          ],
                        ),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                          boxShadow: const [
                            BoxShadow(
                                color: Color(0xFFFFFFFF),
                                blurRadius: 6,
                                spreadRadius: 0,
                                offset: Offset(-3, -3)),
                            BoxShadow(
                                color: Color(0xFFDDE4EF),
                                blurRadius: 6,
                                spreadRadius: 0,
                                offset: Offset(3, 3)),
                          ],
                          color: const Color(0xffF0F3F6),
                        )),
                    const SizedBox(
                      height: 20,
                    ),
                    Container(
                        height: 40,
                        alignment: Alignment.center,
                        padding: const EdgeInsets.all(10),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: <Widget>[
                            Container(
                              alignment: Alignment.center,
                              child: const Text(
                                'Total Vat',
                                style: TextStyle(
                                    fontSize: 16,
                                    color: Color.fromRGBO(0, 0, 0, 0.87)),
                              ),
                            ),
                            Container(
                              alignment: Alignment.center,
                              child: Text(
                                "${widget.travelInsuranceOrderCreateResModel.totalVat}(${widget.travelInsuranceOrderCreateResModel.vatPercentage}%)",
                                style: const TextStyle(
                                    fontSize: 16,
                                    color: Color.fromRGBO(0, 0, 0, 0.87)),
                              ),
                            ),
                          ],
                        ),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                          boxShadow: const [
                            BoxShadow(
                                color: Color(0xFFFFFFFF),
                                blurRadius: 6,
                                spreadRadius: 0,
                                offset: Offset(-3, -3)),
                            BoxShadow(
                                color: Color(0xFFDDE4EF),
                                blurRadius: 6,
                                spreadRadius: 0,
                                offset: Offset(3, 3)),
                          ],
                          color: const Color(0xffF0F3F6),
                        )),
                    const SizedBox(
                      height: 20,
                    ),
                    Container(
                        height: 40,
                        alignment: Alignment.center,
                        padding: const EdgeInsets.all(10),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: <Widget>[
                            Container(
                              alignment: Alignment.center,
                              child: const Text(
                                'Total Service Charge',
                                style: TextStyle(
                                    fontSize: 16,
                                    color: Color.fromRGBO(0, 0, 0, 0.87)),
                              ),
                            ),
                            Container(
                              alignment: Alignment.center,
                              child: Text(
                                "${widget.travelInsuranceOrderCreateResModel.serviceTotalAmount}(${widget.travelInsuranceOrderCreateResModel.serviceAmount}%)",
                                style: const TextStyle(
                                    fontSize: 16,
                                    color: Color.fromRGBO(0, 0, 0, 0.87)),
                              ),
                            ),
                          ],
                        ),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                          boxShadow: const [
                            BoxShadow(
                                color: Color(0xFFFFFFFF),
                                blurRadius: 6,
                                spreadRadius: 0,
                                offset: Offset(-3, -3)),
                            BoxShadow(
                                color: Color(0xFFDDE4EF),
                                blurRadius: 6,
                                spreadRadius: 0,
                                offset: Offset(3, 3)),
                          ],
                          color: const Color(0xffF0F3F6),
                        )),
                    const SizedBox(
                      height: 20,
                    ),
                    Container(
                        height: 40,
                        alignment: Alignment.center,
                        padding: const EdgeInsets.all(10),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: <Widget>[
                            Container(
                              alignment: Alignment.center,
                              child: const Text(
                                'Grand Total',
                                style: TextStyle(
                                    fontSize: 16,
                                    color: Color.fromRGBO(0, 0, 0, 0.87)),
                              ),
                            ),
                            Container(
                              alignment: Alignment.center,
                              child: Text(
                                "${widget.travelInsuranceOrderCreateResModel.grandTotal}",
                                style: const TextStyle(
                                    fontSize: 16,
                                    color: Color.fromRGBO(0, 0, 0, 0.87)),
                              ),
                            ),
                          ],
                        ),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                          boxShadow: const [
                            BoxShadow(
                                color: Color(0xFFFFFFFF),
                                blurRadius: 6,
                                spreadRadius: 0,
                                offset: Offset(-3, -3)),
                            BoxShadow(
                                color: Color(0xFFDDE4EF),
                                blurRadius: 6,
                                spreadRadius: 0,
                                offset: Offset(3, 3)),
                          ],
                          color: const Color(0xffF0F3F6),
                        )),
                    const SizedBox(
                      height: 20,
                    ),
                    Container(
                      height: 40,
                      alignment: Alignment.center,
                      child: Image.asset('assets/payment_gateway.png'),
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Row(
                        children: <Widget>[
                          Checkbox(
                            value: _value,
                            onChanged: (value) {
                              setState(() {
                                _value = value!;
                              });
                            },
                            activeColor: Colors.green,
                          ),
                          const Text("I accept payment and return policy."),
                        ],
                      ),
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                    Container(
                        height: 40,
                        width: 400,
                        // color: const Color.fromRGBO(0, 46, 91, 1.0),
                        decoration: const BoxDecoration(
                            borderRadius: BorderRadius.all(Radius.circular(20)),
                            color: Color.fromRGBO(0, 46, 91, 1.0)),
                        // padding: const EdgeInsets.fromLTRB(10, 15, 10, 5),
                        child: TextButton(
                            child: const Text(
                              'Pay Now',
                              style:
                                  TextStyle(color: Colors.white, fontSize: 16),
                            ),
                            onPressed: payNow)),
                  ],
                ),
              ),
            ],
          ),
        ));
  }
}
