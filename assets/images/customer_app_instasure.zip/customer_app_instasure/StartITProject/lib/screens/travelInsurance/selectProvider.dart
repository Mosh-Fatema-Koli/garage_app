import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:instasure/Utilities/userPref.dart';
import 'package:instasure/domains/models/travelInsurance/travelInsuranceOrderCreateResModel.dart';
import 'package:instasure/domains/models/travelInsurance/travelInsurancePlanModel.dart';
import 'package:instasure/domains/repo/apiTravelInsurance.dart';
import 'package:instasure/screens/travelInsurance/payment.dart';
import 'package:instasure/widgets/topView4.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';

class SelectProvider extends StatefulWidget {
  SelectProvider({Key? key, required this.insuranceReqData}) : super(key: key);

  Map<String, dynamic> insuranceReqData;

  @override
  _SelectProviderState createState() => _SelectProviderState();
}

class _SelectProviderState extends State<SelectProvider> {
  final ApiTravelInsurance _apiClient = ApiTravelInsurance();
  List<TravelInsurancePlanModel> travelInsurancePlans = [];
  var loading = true;
  late TravelInsurancePlanModel selectedTravelInsurancePlanModel;
  late TravelInsuranceOrderCreateResModel travelInsuranceOrderCreateResModel;
  int status_code=401;
String selected='';
  @override
  void initState() {
    print('bnm');
    super.initState();
    () async {
      await Future.delayed(Duration.zero);
      getTravelInsurancePlansdata();
    }();
  }

  Future<void> getTravelInsurancePlansdata() async {
    EasyLoading.instance.userInteractions = false;
    EasyLoading.show(status: 'Getting Insurance Plan Data...');

    Map<String, dynamic> logindata = {
      'dob': widget.insuranceReqData['dob'],
      'plan_category_id': widget.insuranceReqData['plan_category_id'],
      'flight_date': widget.insuranceReqData['flight_date'],
      'return_date': widget.insuranceReqData['return_date']
    };

    UserPref prefs = UserPref();

    Future<String?> token = prefs.getTokenFromPref();
    String? accessToken = await token;
    dynamic res =
        await _apiClient.getTravelInsurancePlanData(logindata, accessToken!);
   // ScaffoldMessenger.of(context).hideCurrentSnackBar();
    EasyLoading.dismiss();
    print(res.statusCode);
    print('???');
    status_code=res.statusCode;
    if (res.statusCode == 200) {
      if (res.data['code'] == 200) {
        if (res.data['data'] != null) {
          List jsonList = res.data['data'] as List;

          List<TravelInsurancePlanModel> plans = jsonList
              .map((jsonElement) =>
                  TravelInsurancePlanModel.fromJson(jsonElement))
              .toList();

          setState(() {
            travelInsurancePlans = plans;
            selectedTravelInsurancePlanModel = plans[0];
            loading = false;
          });
        } else {
          setState(() {
            loading = false;
          });
        }
        // Navigator.push(
        //  context, MaterialPageRoute(builder: (context) => const MainPage()));
      } else {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('${res.data['data']}'),
          backgroundColor: Colors.red.shade300,
        ));
        // ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        //   content: Text('Error: ${res.data['data']['phone'][0]}'),
        //   backgroundColor: Colors.red.shade300,
        // ));

      }
    } else {
      setState(() {
        loading = false;
      });
    }
  }

  Future<void> travleInsuranceCreateOrder() async {
    print('loading...');
    EasyLoading.instance.userInteractions = false;
    EasyLoading.show(status: 'Processing...');

    if (loading) {
      return;
    }
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: const Text('Creating Order'),
      backgroundColor: Colors.green.shade300,
    ));
    widget.insuranceReqData['plan_chart_id'] =
        "${selectedTravelInsurancePlanModel.id}";
    print("widget.insuranceReqData:${widget.insuranceReqData}");

    UserPref prefs = UserPref();
    Future<String?> token = prefs.getTokenFromPref();
    String? accessToken = await token;
    dynamic res = await _apiClient.travelInsuranceOrderCreate(
        widget.insuranceReqData, accessToken!);
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    EasyLoading.dismiss();
    print(res.statusCode);
    print('555');
    if (res.statusCode == 200) {
      if (res.data['code'] == 200) {
        travelInsuranceOrderCreateResModel =
            TravelInsuranceOrderCreateResModel.fromJson(res.data['data']);

        Navigator.push(
          context,
          MaterialPageRoute(
              builder: (context) => Payment(
                  travelInsuranceOrderCreateResModel:
                      travelInsuranceOrderCreateResModel)),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('${res.data['message']}'),
          backgroundColor: Colors.red.shade300,
        ));
        // ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        //   content: Text('Error: ${res.data['data']['phone'][0]}'),
        //   backgroundColor: Colors.red.shade300,
        // ));
      }
    } else {}
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: null,
        backgroundColor: const Color(0xFFEFF7FF),
        body: SingleChildScrollView(
            child: Column(
          children: [
            Stack(
              children: [
                Stack(
                  children: [
                    const TopView4(),
                    Positioned(
                      bottom: 20.0,
                      left: 40.0,
                      child: SizedBox(
                          height: 30,
                          width: 30,
                          // color: const Color.fromRGBO(0, 46, 91, 1.0),
                          // padding: const EdgeInsets.fromLTRB(10, 15, 10, 5),
                          child: TextButton(
                            child: Image.asset('assets/back_button_icon.png'),
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                          )),
                    )
                  ],
                ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.all(25.0),
              child: Column(
                children: <Widget>[
                  const SizedBox(
                    height: 10,
                  ),
                  Container(
                      height: 40,
                      alignment: Alignment.center,
                      padding: const EdgeInsets.all(10),
                      child: const Text(
                        'Select A Package',
                        style: TextStyle(
                            fontSize: 16, color: Color.fromRGBO(0, 0, 0, 0.87)),
                      ),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: const [
                          BoxShadow(
                              color: Color(0xFFFFFFFF),
                              blurRadius: 6,
                              spreadRadius: 0,
                              offset: Offset(-3, -3)),
                          BoxShadow(
                              color: Color(0xFFDDE4EF),
                              blurRadius: 6,
                              spreadRadius: 0,
                              offset: Offset(3, 3)),
                        ],
                        color: const Color(0xffF0F3F6),
                      )),
                  const SizedBox(
                    height: 10,
                  ),
                  SizedBox(
                    height: 450,
                    // color: Colors.red,
                    //width: (MediaQuery.of(context).size.width - 30) / 3,
                    child: !loading && travelInsurancePlans.isEmpty
                        ? const Center(
                            child: Text(
                                "Your criteria does not match with any package."))
                        : GridView.count(
                            crossAxisCount: 2,
                            crossAxisSpacing: 15,
                            mainAxisSpacing: 15,
                            childAspectRatio: 1.7,
                            children: List.generate(
                              loading ? 0 : travelInsurancePlans.length,
                              (index) {
                                TravelInsurancePlanModel
                                    travelInsurancePlanModel =
                                    travelInsurancePlans[index];
                                return GestureDetector(
                                  onTap: () {

                                    setState(() {
                                      selectedTravelInsurancePlanModel =
                                          travelInsurancePlanModel;
                                      print(travelInsurancePlanModel.policyProvider?.companyName);
                                      selected=travelInsurancePlanModel.policyProvider?.companyName;
                                    });
                                  },
                                  child: Container(
                                      alignment: Alignment.center,
                                      padding: const EdgeInsets.all(10),
                                      child: Text(
                                        "${travelInsurancePlanModel.policyProvider?.companyName}\nInsurance Price: ৳ ${travelInsurancePlanModel.insPrice}\nStay ${travelInsurancePlanModel.travelDays} days",
                                        style: const TextStyle(
                                            fontSize: 12,
                                            color:
                                                Color.fromRGBO(0, 0, 0, 0.87)),
                                      ),
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(40),
                                        border: Border.all(
                                          color:
                                              selectedTravelInsurancePlanModel ==
                                                      travelInsurancePlanModel
                                                  ? Colors.green
                                                  : Colors.transparent,
                                          width: 1,
                                        ),
                                        boxShadow: const [
                                          BoxShadow(
                                              color: Color(0xFFFFFFFF),
                                              blurRadius: 6,
                                              spreadRadius: 0,
                                              offset: Offset(-3, -3)),
                                          BoxShadow(
                                              color: Color(0xFFDDE4EF),
                                              blurRadius: 6,
                                              spreadRadius: 0,
                                              offset: Offset(3, 3)),
                                        ],
                                        color: const Color(0xffF0F3F6),
                                      )),
                                );

                                // );
                              },
                            ),
                          ),
                  ),
                  Text(
                    selected,
                    style: const TextStyle(
                        fontSize: 12,
                        color:
                        Color.fromRGBO(0, 0, 0, 0.87)),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  if(status_code!=401)
                  Container(
                      height: 40,
                      width: 400,
                      // color: const Color.fromRGBO(0, 46, 91, 1.0),
                      decoration: const BoxDecoration(
                          borderRadius: BorderRadius.all(Radius.circular(20)),
                          color: Color.fromRGBO(0, 46, 91, 1.0)),
                      // padding: const EdgeInsets.fromLTRB(10, 15, 10, 5),

                      child:
                      TextButton(
                        child: const Text(
                          'Submit',
                          style: TextStyle(color: Colors.white, fontSize: 16),
                        ),
                        onPressed: travleInsuranceCreateOrder,
                      )),
                  const SizedBox(
                    height: 100,
                  ),
                ],
              ),
            ),
          ],
        )));
  }
}
