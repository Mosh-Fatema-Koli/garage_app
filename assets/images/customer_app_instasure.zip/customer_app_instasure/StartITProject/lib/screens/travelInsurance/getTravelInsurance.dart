import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:instasure/Utilities/homeMenu.dart';
import 'package:instasure/Utilities/userPref.dart';
import 'package:instasure/domains/models/travelInsurance/planCategoryModel.dart';
import 'package:instasure/domains/repo/apiTravelInsurance.dart';
import 'package:instasure/screens/travelInsurance/selectProvider.dart';
import 'package:instasure/widgets/topView4.dart';
import 'package:intl/intl.dart';
import 'package:instasure/Utilities/validator.dart';
import '../../domains/models/auth/user.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';



class TravelsInsurance extends StatefulWidget {
  const TravelsInsurance({Key? key}) : super(key: key);

  @override
  _TravelsInsuranceState createState() => _TravelsInsuranceState();
}

class _TravelsInsuranceState extends State<TravelsInsurance> {
  DateTime? _selectedDate;
  TextEditingController fullNameController = TextEditingController();
  TextEditingController phoneController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController dateOfBirthController = TextEditingController();
  TextEditingController flightNumberController = TextEditingController();
  TextEditingController passportController = TextEditingController();
  TextEditingController dpassportExpireTillController = TextEditingController();
  TextEditingController planCountryTypeController = TextEditingController();
  TextEditingController planTitleController = TextEditingController();
  TextEditingController flightDtaeController = TextEditingController();
  TextEditingController returnDateController = TextEditingController();
  TextEditingController addressController = TextEditingController();
  @override
  void initState() {
    super.initState();
    getUserData();
  }

  var loading = true;
  final selectionOptions = ['Select', 'Non Schengen', 'Schengen'];
  String selectedType = 'Select';
  String selectedCategory = 'Select';
  String planCategoryId = '1';
  final _serviceCenters = serviceCenters;
  List<planCategoryModel> categoryList = [];

  final ApiTravelInsurance _apiClient = ApiTravelInsurance();

  Future<void> travleInsuranceCreateOrder() async {

    EasyLoading.instance.userInteractions = false;
   // EasyLoading.show(status: 'Processing...');


    int error=0;
    if (Validator.validateName(fullNameController.text) != null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: const Text('Enter your full name'),
        backgroundColor: Colors.red.shade300,
      ));
      //return;
      error=1;
    }

    else if (Validator.validatePhoneNumber(phoneController.text) != null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: const Text('Enter valid phone number'),
        backgroundColor: Colors.red.shade300,
      ));
      error=1;
      //return;
    }

    else if (Validator.validateEmail(emailController.text) != null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: const Text('Enter valid email'),
        backgroundColor: Colors.red.shade300,
      ));
      error=1;
     // return;
    }

    else if (Validator.validateText(dateOfBirthController.text) != null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: const Text('Select date of birth'),
        backgroundColor: Colors.red.shade300,
      ));
      error=1;
      //return;
    }

    else if (Validator.validateText(flightNumberController.text) != null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: const Text('Enter flight number'),
        backgroundColor: Colors.red.shade300,
      ));
      error=1;
     // return;
    }
    else if (Validator.validateText(addressController.text) != null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: const Text('Enter Shipping address'),
        backgroundColor: Colors.red.shade300,
      ));
      error=1;
      // return;
    }

    else if (Validator.validateText(passportController.text) != null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: const Text('Enter passport number'),
        backgroundColor: Colors.red.shade300,
      ));
      error=1;
      //return;
    }

    else if (selectedType == "Select") {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: const Text('Select plan title'),
        backgroundColor: Colors.red.shade300,
      ));
      error=1;
      //return;
    }

    else if (Validator.validateText(flightDtaeController.text) != null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: const Text('Select flight date'),
        backgroundColor: Colors.red.shade300,
      ));
      error=1;
     // return;
    }

    else if (Validator.validateText(returnDateController.text) != null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: const Text('Select return date'),
        backgroundColor: Colors.red.shade300,
      ));
      error=1;
     // return;
    }else{


    }

    DateTime dateTimeCreatedAt = DateTime.parse(flightDtaeController.text);
    DateTime dateTimeNow = DateTime.parse(returnDateController.text);
    final differenceInDays = dateTimeNow.difference(dateTimeCreatedAt).inDays;

    DateTime passportExpiryDat =
    DateTime.parse(dpassportExpireTillController.text);
    DateTime flightDate = DateTime.parse(flightDtaeController.text);

    if (passportExpiryDat.isBefore(flightDate)) {
     // showAlertDialog(context, 'Passport date should higher than flight date.');
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: const Text('Passport expired date should higher than flight date.'),
        backgroundColor: Colors.red.shade300,
      ));

      error=1;
    } else if (dateTimeNow.isBefore(dateTimeCreatedAt)) {
     /* showAlertDialog(
          context, 'Return date should be higher than flight date.');*/
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: const Text('Return date should be higher than flight date'),
        backgroundColor: Colors.red.shade300,
      ));

      error=1;
    }




    if (error==1) {
      await Future.delayed(Duration(seconds: 3));
      EasyLoading.dismiss();
      return;
    }




    if (passportExpiryDat.isBefore(flightDate)) {
      showAlertDialog(context, 'Passport date should higher than flight date.');
    } else if (dateTimeNow.isBefore(dateTimeCreatedAt)) {
      showAlertDialog(
          context, 'Return date should be higher than flight date.');
    } else {
      Map<String, dynamic> insuranceReqData = {
        "plan_category_id": planCategoryId,
        "full_name": fullNameController.text,
        "phone": phoneController.text,
        "email": emailController.text,
        "dob": dateOfBirthController.text,
        "age": '',
        "passport_number": passportController.text,
        "passport_expire_till": dpassportExpireTillController.text,
        "flight_number": flightNumberController.text,
        "flight_date": flightDtaeController.text,
        "return_date": returnDateController.text,
         "total_days": differenceInDays,
        "shipping_address": addressController.text,
      };
       Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) =>
                SelectProvider(insuranceReqData: insuranceReqData)),
      );
    }
  }

  Future<void> getPlanCategory(String countryType) async {
    /*ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: const Text('getting Plan categories'),
      backgroundColor: Colors.green.shade300,
    ));*/

    EasyLoading.instance.userInteractions = false;
    EasyLoading.show(status: 'Processing...');

    Map<String, dynamic> userData = {"country_type": countryType};
    UserPref prefs = UserPref();
    Future<String?> token = prefs.getTokenFromPref();
    String? accessToken = await token;
    dynamic res = await _apiClient.getPlanCategory(userData, accessToken!);
    //ScaffoldMessenger.of(context).hideCurrentSnackBar();
    EasyLoading.dismiss();
    if (res.statusCode == 200) {
      if (res.data['code'] == 200) {
        List jsonList = res.data['data'] as List;
        List<planCategoryModel> items = jsonList
            .map((jsonElement) => planCategoryModel.fromJson(jsonElement))
            .toList();

        setState(() {
          categoryList = items;
          selectedCategory =
              "${categoryList[0].planTitle}(${categoryList[0].countyDetails})";
          planCategoryId = categoryList[0].id.toString();
          loading = false;
        });
      } else {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('${res.data['message']}'),
          backgroundColor: Colors.red.shade300,
        ));
      }
    } else {}
  }

  void _presentDatePicker() {
    showDatePicker(
            context: context,
            initialDate: DateTime.now(),
            firstDate: DateTime(1900),
            lastDate: DateTime.now())
        .then((pickedDate) {
      // Check if no date is selected
      if (pickedDate == null) {
        return;
      }
      setState(() {
        _selectedDate = pickedDate;
        final DateFormat formatter = DateFormat('yyyy-MM-dd');
        final String formatted = formatter.format(_selectedDate!);
        dateOfBirthController.text = formatted.toString();
      });
    });
  }

  _flightandReturnDatePicker(String selectedName) {
    showDatePicker(
            context: context,
            initialDate: DateTime.now(),
            firstDate: DateTime.now(),
            lastDate: DateTime(2050))
        .then((pickedDate) {
      // Check if no date is selected
      if (pickedDate == null) {
        return;
      }
      setState(() {
        // using state so that the UI will be rerendered when date is picked
        _selectedDate = pickedDate;
        final DateFormat formatter = DateFormat('yyyy-MM-dd');
        final String formatted = formatter.format(_selectedDate!);
        if (selectedName == "flight") {
          flightDtaeController.text = formatted.toString();
        } else if (selectedName == "returnDate") {
          returnDateController.text = formatted.toString();
        } else {
          dpassportExpireTillController.text = formatted.toString();
        }
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: null,
        backgroundColor: const Color(0xFFEFF7FF),
        body: Padding(
            padding:
                const EdgeInsets.only(left: 0, top: 0, right: 0, bottom: 0),
            child: Column(
              children: [
                Stack(
                  children: [
                    const TopView4(),
                    Positioned(
                      bottom: 20.0,
                      left: 40.0,
                      child: SizedBox(
                          height: 30,
                          width: 30,
                          // color: const Color.fromRGBO(0, 46, 91, 1.0),
                          // padding: const EdgeInsets.fromLTRB(10, 15, 10, 5),
                          child: TextButton(
                            child: Image.asset('assets/back_button_icon.png'),
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                          )),
                    )
                  ],
                ),
                Expanded(
                  child: ListView(
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(30.0),
                        child: Column(
                          children: <Widget>[
                            const SizedBox(
                              height: 23,
                            ),
                            Container(
                              height: 60,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(20),
                                color: const Color(0xffF0F3F6),
                              ),
                              alignment: Alignment.center,
                              padding: const EdgeInsets.all(10),
                              child: const Text(
                                'International Travel Medical Insurance',
                                style: TextStyle(
                                    fontSize: 17, color: Colors.black),
                              ),
                            ),
                            const SizedBox(
                              height: 20,
                            ),
                            Container(
                              height: 40,
                              alignment: Alignment.centerLeft,
                              padding: const EdgeInsets.all(10),
                              child: const Text(
                                'Full Name',
                                style: TextStyle(
                                    fontSize: 17, color: Colors.black),
                              ),
                            ),
                            Container(
                              height: 40,
                              padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
                              child: TextField(
                                controller: fullNameController,
                                decoration: InputDecoration(
                                  contentPadding: const EdgeInsets.only(
                                      left: 10, top: 0, right: 0, bottom: 0),
                                  fillColor: const Color(0xFFF0F3F6),
                                  filled: true,
                                  enabledBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(20.0),
                                    borderSide: const BorderSide(
                                        color: Colors.transparent, width: 0.0),
                                  ),
                                ),
                              ),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(20),
                                boxShadow: const [
                                  BoxShadow(
                                      color: Color(0xFFFFFFFF),
                                      blurRadius: 6,
                                      spreadRadius: 0,
                                      offset: Offset(-3, -3)),
                                  BoxShadow(
                                      color: Color(0xFFDDE4EF),
                                      blurRadius: 6,
                                      spreadRadius: 0,
                                      offset: Offset(3, 3)),
                                ],
                                color: const Color(0xffF0F3F6),
                              ),
                            ),
                            Container(
                              height: 40,
                              alignment: Alignment.centerLeft,
                              padding: const EdgeInsets.all(10),
                              child: const Text(
                                'Phone',
                                style: TextStyle(
                                    fontSize: 17, color: Colors.black),
                              ),
                            ),
                            Container(
                              height: 40,
                              padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
                              child: TextField(
                                controller: phoneController,
                                decoration: InputDecoration(
                                  contentPadding: const EdgeInsets.only(
                                      left: 10, top: 0, right: 0, bottom: 0),
                                  fillColor: const Color(0xFFF0F3F6),
                                  filled: true,
                                  enabledBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(20.0),
                                    borderSide: const BorderSide(
                                        color: Colors.transparent, width: 0.0),
                                  ),
                                ),
                              ),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(20),
                                boxShadow: const [
                                  BoxShadow(
                                      color: Color(0xFFFFFFFF),
                                      blurRadius: 6,
                                      spreadRadius: 0,
                                      offset: Offset(-3, -3)),
                                  BoxShadow(
                                      color: Color(0xFFDDE4EF),
                                      blurRadius: 6,
                                      spreadRadius: 0,
                                      offset: Offset(3, 3)),
                                ],
                                color: const Color(0xffF0F3F6),
                              ),
                            ),
                            Container(
                              height: 40,
                              alignment: Alignment.centerLeft,
                              padding: const EdgeInsets.all(10),
                              child: const Text(
                                'Email',
                                style: TextStyle(
                                    fontSize: 17, color: Colors.black),
                              ),
                            ),
                            Container(
                              height: 40,
                              padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
                              child: TextField(
                                controller: emailController,
                                decoration: InputDecoration(
                                  contentPadding: const EdgeInsets.only(
                                      left: 10, top: 0, right: 0, bottom: 0),
                                  fillColor: const Color(0xFFF0F3F6),
                                  filled: true,
                                  enabledBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(20.0),
                                    borderSide: const BorderSide(
                                        color: Colors.transparent, width: 0.0),
                                  ),
                                ),
                              ),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(20),
                                boxShadow: const [
                                  BoxShadow(
                                      color: Color(0xFFFFFFFF),
                                      blurRadius: 6,
                                      spreadRadius: 0,
                                      offset: Offset(-3, -3)),
                                  BoxShadow(
                                      color: Color(0xFFDDE4EF),
                                      blurRadius: 6,
                                      spreadRadius: 0,
                                      offset: Offset(3, 3)),
                                ],
                                color: const Color(0xffF0F3F6),
                              ),
                            ),
                            Container(
                              height: 40,
                              alignment: Alignment.centerLeft,
                              padding: const EdgeInsets.all(10),
                              child: const Text(
                                'Date of Birth',
                                style: TextStyle(
                                    fontSize: 17, color: Colors.black),
                              ),
                            ),
                            GestureDetector(
                              onTap: _presentDatePicker,
                              child: Container(
                                height: 40,
                                padding:
                                    const EdgeInsets.fromLTRB(10, 0, 10, 0),
                                child: TextField(
                                  enabled: false,
                                  controller: dateOfBirthController,
                                  decoration: InputDecoration(
                                    contentPadding: const EdgeInsets.only(
                                        left: 10, top: 0, right: 0, bottom: 5),
                                    fillColor: const Color(0xFFF0F3F6),
                                    filled: true,
                                    enabledBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(20.0),
                                      borderSide: const BorderSide(
                                          color: Colors.transparent,
                                          width: 0.0),
                                    ),
                                  ),
                                ),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(20),
                                  boxShadow: const [
                                    BoxShadow(
                                        color: Color(0xFFFFFFFF),
                                        blurRadius: 6,
                                        spreadRadius: 0,
                                        offset: Offset(-3, -3)),
                                    BoxShadow(
                                        color: Color(0xFFDDE4EF),
                                        blurRadius: 6,
                                        spreadRadius: 0,
                                        offset: Offset(3, 3)),
                                  ],
                                  color: const Color(0xffF0F3F6),
                                ),
                              ),
                            ),
                            Container(
                              height: 40,
                              alignment: Alignment.centerLeft,
                              padding: const EdgeInsets.all(10),
                              child: const Text(
                                'Flight Number',
                                style: TextStyle(
                                    fontSize: 17, color: Colors.black),
                              ),
                            ),
                            Container(
                              height: 40,
                              padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
                              child: TextField(
                                controller: flightNumberController,
                                decoration: InputDecoration(
                                  contentPadding: const EdgeInsets.only(
                                      left: 10, top: 0, right: 0, bottom: 0),
                                  fillColor: const Color(0xFFF0F3F6),
                                  filled: true,
                                  enabledBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(20.0),
                                    borderSide: const BorderSide(
                                        color: Colors.transparent, width: 0.0),
                                  ),
                                ),
                              ),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(20),
                                boxShadow: const [
                                  BoxShadow(
                                      color: Color(0xFFFFFFFF),
                                      blurRadius: 6,
                                      spreadRadius: 0,
                                      offset: Offset(-3, -3)),
                                  BoxShadow(
                                      color: Color(0xFFDDE4EF),
                                      blurRadius: 6,
                                      spreadRadius: 0,
                                      offset: Offset(3, 3)),
                                ],
                                color: const Color(0xffF0F3F6),
                              ),
                            ),
                            Container(
                              height: 40,
                              alignment: Alignment.centerLeft,
                              padding: const EdgeInsets.all(10),
                              child: const Text(
                                'Passport Number',
                                style: TextStyle(
                                    fontSize: 17, color: Colors.black),
                              ),
                            ),
                            Container(
                              height: 40,
                              padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
                              child: TextField(
                                controller: passportController,
                                decoration: InputDecoration(
                                  contentPadding: const EdgeInsets.only(
                                      left: 10, top: 0, right: 0, bottom: 0),
                                  fillColor: const Color(0xFFF0F3F6),
                                  filled: true,
                                  enabledBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(20.0),
                                    borderSide: const BorderSide(
                                        color: Colors.transparent, width: 0.0),
                                  ),
                                ),
                              ),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(20),
                                boxShadow: const [
                                  BoxShadow(
                                      color: Color(0xFFFFFFFF),
                                      blurRadius: 6,
                                      spreadRadius: 0,
                                      offset: Offset(-3, -3)),
                                  BoxShadow(
                                      color: Color(0xFFDDE4EF),
                                      blurRadius: 6,
                                      spreadRadius: 0,
                                      offset: Offset(3, 3)),
                                ],
                                color: const Color(0xffF0F3F6),
                              ),
                            ),
                            Container(
                              height: 40,
                              alignment: Alignment.centerLeft,
                              padding: const EdgeInsets.all(10),
                              child: const Text(
                                'Passport Expire Till',
                                style: TextStyle(
                                    fontSize: 17, color: Colors.black),
                              ),
                            ),
                            GestureDetector(
                              onTap: () => _flightandReturnDatePicker('expire'),
                              child: Container(
                                height: 40,
                                padding:
                                    const EdgeInsets.fromLTRB(10, 0, 10, 0),
                                child: TextField(
                                  enabled: false,
                                  controller: dpassportExpireTillController,
                                  decoration: InputDecoration(
                                    contentPadding: const EdgeInsets.only(
                                        left: 10, top: 0, right: 0, bottom: 5),
                                    fillColor: const Color(0xFFF0F3F6),
                                    filled: true,
                                    enabledBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(20.0),
                                      borderSide: const BorderSide(
                                          color: Colors.transparent,
                                          width: 0.0),
                                    ),
                                  ),
                                ),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(20),
                                  boxShadow: const [
                                    BoxShadow(
                                        color: Color(0xFFFFFFFF),
                                        blurRadius: 6,
                                        spreadRadius: 0,
                                        offset: Offset(-3, -3)),
                                    BoxShadow(
                                        color: Color(0xFFDDE4EF),
                                        blurRadius: 6,
                                        spreadRadius: 0,
                                        offset: Offset(3, 3)),
                                  ],
                                  color: const Color(0xffF0F3F6),
                                ),
                              ),
                            ),
                            Container(
                              height: 40,
                              alignment: Alignment.centerLeft,
                              padding: const EdgeInsets.all(10),
                              child: const Text(
                                'Plan Country Type',
                                style: TextStyle(
                                    fontSize: 17, color: Colors.black),
                              ),
                            ),
                            Container(
                              height: 40,
                              alignment: Alignment.center,
                              padding: const EdgeInsets.all(10),
                              child: DropdownButton<String>(
                                isExpanded: true,
                                isDense: true,
                                value: selectedType,
                                icon: const Icon(Icons.arrow_downward),
                                iconSize: 14,
                                elevation: 10,
                                underline: Container(),
                                onChanged: (var newValue) {
                                  setState(() {
                                    selectedType = newValue!;
                                    getPlanCategory(selectedType);
                                  });
                                },
                                items: List.generate(
                                  selectionOptions.length,
                                  (index) => DropdownMenuItem(
                                    child: Text(selectionOptions[index]),
                                    value: selectionOptions[index],
                                  ),
                                ),
                              ),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(20),
                                boxShadow: const [
                                  BoxShadow(
                                      color: Color(0xFFFFFFFF),
                                      blurRadius: 6,
                                      spreadRadius: 0,
                                      offset: Offset(-3, -3)),
                                  BoxShadow(
                                      color: Color(0xFFDDE4EF),
                                      blurRadius: 6,
                                      spreadRadius: 0,
                                      offset: Offset(3, 3)),
                                ],
                                color: const Color(0xffF0F3F6),
                              ),
                            ),
                            Container(
                              height: 40,
                              alignment: Alignment.centerLeft,
                              padding: const EdgeInsets.all(10),
                              child: const Text(
                                'Plan Title',
                                style: TextStyle(
                                    fontSize: 17, color: Colors.black),
                              ),
                            ),
                            Container(
                                height: 40,
                                alignment: Alignment.center,
                                padding: const EdgeInsets.all(10),
                                child: DropdownButton<String>(
                                  isExpanded: true,
                                  isDense: true,
                                  value: selectedCategory,
                                  icon: const Icon(Icons.arrow_downward),
                                  iconSize: 14,
                                  elevation: 10,
                                  underline: Container(),
                                  onChanged: (var newValue) {
                                    setState(() {
                                      selectedCategory = newValue!;
                                      var filtered = categoryList
                                          .where((content) =>
                                              "${content.planTitle}(${content.countyDetails})" ==
                                              selectedCategory)
                                          .toList();
                                      planCategoryId =
                                          filtered[0].id.toString();
                                    });
                                  },
                                  items: List.generate(
                                    categoryList.length,
                                    (index) => DropdownMenuItem(
                                      child: Text(
                                          "${categoryList[index].planTitle}(${categoryList[index].countyDetails})"),
                                      value:
                                          "${categoryList[index].planTitle}(${categoryList[index].countyDetails})",
                                    ),
                                  ),
                                ),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(20),
                                  boxShadow: const [
                                    BoxShadow(
                                        color: Color(0xFFFFFFFF),
                                        blurRadius: 6,
                                        spreadRadius: 0,
                                        offset: Offset(-3, -3)),
                                    BoxShadow(
                                        color: Color(0xFFDDE4EF),
                                        blurRadius: 6,
                                        spreadRadius: 0,
                                        offset: Offset(3, 3)),
                                  ],
                                  color: const Color(0xffF0F3F6),
                                )),
                            Container(
                              height: 40,
                              alignment: Alignment.centerLeft,
                              padding: const EdgeInsets.all(10),
                              child: const Text(
                                'Flight Date',
                                style: TextStyle(
                                    fontSize: 17, color: Colors.black),
                              ),
                            ),
                            GestureDetector(
                              onTap: () => _flightandReturnDatePicker('flight'),
                              child: Container(
                                height: 40,
                                padding:
                                    const EdgeInsets.fromLTRB(10, 0, 10, 0),
                                child: TextField(
                                  enabled: false,
                                  controller: flightDtaeController,
                                  decoration: InputDecoration(
                                    contentPadding: const EdgeInsets.only(
                                        left: 10, top: 0, right: 0, bottom: 5),
                                    fillColor: const Color(0xFFF0F3F6),
                                    filled: true,
                                    enabledBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(20.0),
                                      borderSide: const BorderSide(
                                          color: Colors.transparent,
                                          width: 0.0),
                                    ),
                                  ),
                                ),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(20),
                                  boxShadow: const [
                                    BoxShadow(
                                        color: Color(0xFFFFFFFF),
                                        blurRadius: 6,
                                        spreadRadius: 0,
                                        offset: Offset(-3, -3)),
                                    BoxShadow(
                                        color: Color(0xFFDDE4EF),
                                        blurRadius: 6,
                                        spreadRadius: 0,
                                        offset: Offset(3, 3)),
                                  ],
                                  color: const Color(0xffF0F3F6),
                                ),
                              ),
                            ),
                            Container(
                              height: 40,
                              alignment: Alignment.centerLeft,
                              padding: const EdgeInsets.all(10),
                              child: const Text(
                                'Return Date',
                                style: TextStyle(
                                    fontSize: 17, color: Colors.black),
                              ),
                            ),
                            GestureDetector(
                              onTap: () =>
                                  _flightandReturnDatePicker('returnDate'),
                              child: Container(
                                height: 40,
                                padding:
                                    const EdgeInsets.fromLTRB(10, 0, 10, 0),
                                child: TextField(
                                  enabled: false,
                                  controller: returnDateController,
                                  decoration: InputDecoration(
                                    contentPadding: const EdgeInsets.only(
                                        left: 10, top: 0, right: 0, bottom: 5),
                                    fillColor: const Color(0xFFF0F3F6),
                                    filled: true,
                                    enabledBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(20.0),
                                      borderSide: const BorderSide(
                                          color: Colors.transparent,
                                          width: 0.0),
                                    ),
                                  ),
                                ),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(20),
                                  boxShadow: const [
                                    BoxShadow(
                                        color: Color(0xFFFFFFFF),
                                        blurRadius: 6,
                                        spreadRadius: 0,
                                        offset: Offset(-3, -3)),
                                    BoxShadow(
                                        color: Color(0xFFDDE4EF),
                                        blurRadius: 6,
                                        spreadRadius: 0,
                                        offset: Offset(3, 3)),
                                  ],
                                  color: const Color(0xffF0F3F6),
                                ),
                              ),
                            ),
                            Container(
                              height: 40,
                              alignment: Alignment.centerLeft,
                              padding: const EdgeInsets.all(10),
                              child: const Text(
                                'Shipping Address',
                                style: TextStyle(
                                    fontSize: 17, color: Colors.black),
                              ),
                            ),
                            Container(
                              height: 40,
                              padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
                              child: TextField(
                                controller: addressController,
                                decoration: InputDecoration(
                                  contentPadding: const EdgeInsets.only(
                                      left: 10, top: 0, right: 0, bottom: 0),
                                  fillColor: const Color(0xFFF0F3F6),
                                  filled: true,
                                  enabledBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(20.0),
                                    borderSide: const BorderSide(
                                        color: Colors.transparent, width: 0.0),
                                  ),
                                ),
                              ),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(20),
                                boxShadow: const [
                                  BoxShadow(
                                      color: Color(0xFFFFFFFF),
                                      blurRadius: 6,
                                      spreadRadius: 0,
                                      offset: Offset(-3, -3)),
                                  BoxShadow(
                                      color: Color(0xFFDDE4EF),
                                      blurRadius: 6,
                                      spreadRadius: 0,
                                      offset: Offset(3, 3)),
                                ],
                                color: const Color(0xffF0F3F6),
                              ),
                            ),
                            const SizedBox(
                              height: 30,
                            ),
                            Container(
                              height: 40,
                              width: 250,
                              // padding: const EdgeInsets.fromLTRB(10, 15, 10, 5),
                              child: TextButton(
                                child: const Text(
                                  'SUBMIT',
                                  style: TextStyle(color: Colors.white),
                                ),
                                onPressed: travleInsuranceCreateOrder,
                              ),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(20),
                                boxShadow: [
                                  BoxShadow(
                                      color: const Color(0xff000000)
                                          .withOpacity(0.16),
                                      blurRadius: 3,
                                      spreadRadius: 0,
                                      offset: const Offset(0, 3)),
                                ],
                                color: const Color(0xff002E5B),
                              ),
                            ),
                            const SizedBox(
                              height: 20,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            )));
  }

  Future<void> getUserData() async {
    UserPref prefs = UserPref();
    Future<User?> userData = prefs.getUserFromPref();
    User? userInfo = await userData;
    fullNameController.text = userInfo!.name.toString();
    phoneController.text = userInfo.phone.toString();
    emailController.text = userInfo.email.toString();
    if(userInfo.email.toString()=='null'){
      emailController.text ='';
    }
    dateOfBirthController.text = userInfo.dob.toString();
    if(userInfo.dob.toString()=='null'){
      dateOfBirthController.text ='';
    }
    dpassportExpireTillController.text = userInfo.passportExpireTill.toString();
    if(userInfo.passportExpireTill.toString()=='null'){
      dpassportExpireTillController.text ='';
    }
  }

  showAlertDialog(BuildContext context, String msg) {
    // set up the button
    Widget okButton = TextButton(
      child: const Text("OK"),
      onPressed: () {
        //Navigator.of(context).pop();
        Navigator.of(context, rootNavigator: true).pop();
      },
    );

    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: const Text("Instasure"),
      content: Text(msg),
      actions: [
        okButton,
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }
}
