// ignore_for_file: unnecessary_new

import 'package:flutter/material.dart';
import 'package:instasure/screens/travelInsurance/payment.dart';
import 'package:instasure/screens/travelInsurance/travelInsuranceHistory.dart';
import 'package:instasure/widgets/imageWidget.dart';
import 'package:instasure/widgets/topView4.dart';

import 'getTravelInsurance.dart';

class InternationalTravelInsurance extends StatefulWidget {
  const InternationalTravelInsurance({Key? key}) : super(key: key);

  @override
  _InternationalTravelInsuranceState createState() =>
      _InternationalTravelInsuranceState();
}

class _InternationalTravelInsuranceState
    extends State<InternationalTravelInsurance> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
          child: Padding(
        padding: const EdgeInsets.all(0),
        child: Column(
          children: [
            Stack(
              children: [
                const TopView4(),
                Positioned(
                  bottom: 20.0,
                  left: 40.0,
                  child: SizedBox(
                      height: 30,
                      width: 30,
                      // color: const Color.fromRGBO(0, 46, 91, 1.0),
                      // padding: const EdgeInsets.fromLTRB(10, 15, 10, 5),
                      child: TextButton(
                        child: Image.asset('assets/back_button_icon.png'),
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                      )),
                )
              ],
            ),
            Expanded(
              child: ListView(
                children: <Widget>[
                  const SizedBox(height: 0.0),
                  createHeaderWidget(),
                  const SizedBox(height: 20.0),
                  createDistributionWidget(),
                  const SizedBox(height: 20.0),
                ],
              ),
            ),
          ],
        ),
      )),
      backgroundColor: const Color(0xFFEFF7FF),
    );
  }

  createHeaderWidget() {
    return Container(
      height: 38,
      child: const Center(
        child: Text(
          'INTERNATIONAL TRAVEL INSURANCE',
          textAlign: TextAlign.center,
          style: TextStyle(
            fontFamily: 'Roboto Slab',
            fontSize: 16,
            color: Color(0xff002E5B),
          ),
        ),
      ),
      decoration: const BoxDecoration(color: Color(0xffF0F3F6), boxShadow: [
        BoxShadow(
            color: Color(0xffffffff),
            blurRadius: 6,
            spreadRadius: 0,
            offset: Offset(-3, -3)),
        BoxShadow(
            color: Color(0xffDDE4EF),
            blurRadius: 6,
            spreadRadius: 0,
            offset: Offset(3, 3)),
      ]),
    );
  }

  createDistributionWidget() {
    return Padding(
        padding: const EdgeInsets.only(left: 20, right: 20),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ImageWidget(
                  imagePath: 'assets/international_travel_insurance.png',
                  onClicked: () async {},
                  imageHeight: 152,
                  imageWidth: 152,
                  borderWidth: 15,
                  borderRadious: 40,
                ),
                const SizedBox(
                  width: 10,
                ),
                Expanded(
                    child: RichText(
                  text: const TextSpan(
                    style: TextStyle(color: Colors.black, fontSize: 16),
                    children: <TextSpan>[
                      TextSpan(
                          text:
                              'Online travel insurance is so simple you can get it while waiting to your gate.\n',
                          style: TextStyle(color: Colors.black)),
                      TextSpan(
                          text:
                              'Emergency medical expcenses, flight delay reimbursement, adventure sports covers, and much more. And the best part? Emergency medical expenses, flight delay reimbursement,adventure sports covers, and much much more. And the best part is - with COVID Medical Coverage!!!',
                          style: TextStyle(color: Colors.black, fontSize: 11)),
                    ],
                  ),
                ))
              ],
            ),
            const SizedBox(
              height: 30,
            ),
            Align(
              alignment: Alignment.centerRight,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Container(
                    height: 38,
                    width: 170,
                    child: TextButton(
                      child: const Text(
                        'Purchase History',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontFamily: 'Roboto Slab',
                          fontSize: 12,
                          color: Colors.white,
                        ),
                      ),
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => const TravelInsuranceHistory()),
                        );

                      },
                    ),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [
                        BoxShadow(
                            color: const Color(0xff000000).withOpacity(0.16),
                            blurRadius: 3,
                            spreadRadius: 0,
                            offset: const Offset(0, 3)),
                      ],
                      color: const Color(0xff002E5B),
                    ),
                  ),

                  const SizedBox(
                    width: 10
                    ,
                  ),
                  Container(
                    height: 38,
                    width: 170,
                    child: TextButton(
                      child: const Text(
                        'Buy Now',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontFamily: 'Roboto Slab',
                          fontSize: 12,
                          color: Colors.white,
                        ),
                      ),
                      onPressed: () {
                        Navigator.push(

                          context,
                          MaterialPageRoute(
                              builder: (context) => const TravelsInsurance()),
                        );
                      },
                    ),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [
                        BoxShadow(
                            color: const Color(0xff000000).withOpacity(0.16),
                            blurRadius: 3,
                            spreadRadius: 0,
                            offset: const Offset(0, 3)),
                      ],
                      color: const Color(0xff002E5B),
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(
              height: 30,
            ),
            ImageWidget(
              imagePath: 'assets/cliams_approved.png',
              onClicked: () async {},
              imageHeight: 237,
              imageWidth: 237,
              borderWidth: 20,
              borderRadious: 40,
            ),
            const SizedBox(height: 20.0),
            const Center(
                child: Text(
              'Advantages Of InstaSure \nInternational Travel Insurance',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontFamily: 'Roboto Slab',
                fontSize: 16,
                color: Color(0xff002E5B),
              ),
            )),
            const SizedBox(
              height: 10,
            ),
            const ListTile(
                dense: true,
                contentPadding: EdgeInsets.only(left: 0.0, right: 0.0),
                title: Text('1. COVID-19 Covered',
                    style: TextStyle(
                      fontFamily: 'Roboto Slab',
                      fontSize: 13,
                      color: Color(0xff002E5B),
                    )),
                subtitle: Text(
                  'When you re travelling abroad, we ll help you take care of the cost of treatment for COVID-19 if you test positive in the middle of your trip & require hospitalization',
                  style: TextStyle(
                    fontFamily: 'Roboto Slab',
                    fontSize: 11,
                    color: Color(0xff86888A),
                  ),
                )),
            const ListTile(
                dense: true,
                contentPadding: EdgeInsets.only(left: 0.0, right: 0.0),
                title: Text('2. Pay In Taka Get Cover In Dollars',
                    style: TextStyle(
                      fontFamily: 'Roboto Slab',
                      fontSize: 13,
                      color: Color(0xff002E5B),
                    )),
                subtitle: Text(
                  'When you opt for an international travel insurance policy, your premiums are in Bangladeshi Taka, but you re covered in USD. So, you can rest easy knowing you ll get the cover you need at an affordable cost.',
                  style: TextStyle(
                    fontFamily: 'Roboto Slab',
                    fontSize: 11,
                    color: Color(0xff86888A),
                  ),
                )),
            const ListTile(
                dense: true,
                contentPadding: EdgeInsets.only(left: 0.0, right: 0.0),
                title: Text('3. Affordable Policies',
                    style: TextStyle(
                      fontFamily: 'Roboto Slab',
                      fontSize: 13,
                      color: Color(0xff002E5B),
                    )),
                subtitle: Text(
                  'Our international travel insurance policies start at just BDTK 50 per day! That s a small price to pay for care-free travel!',
                  style: TextStyle(
                    fontFamily: 'Roboto Slab',
                    fontSize: 11,
                    color: Color(0xff86888A),
                  ),
                )),
            const ListTile(
                visualDensity: VisualDensity(horizontal: 0, vertical: -4),
                contentPadding: EdgeInsets.only(left: 0.0, right: 0.0),
                title: Text('4. Instant Policy Purchase',
                    style: TextStyle(
                      fontFamily: 'Roboto Slab',
                      fontSize: 13,
                      color: Color(0xff002E5B),
                    )),
                subtitle: Text(
                  'You can buy an InstaSure international travel insurance policy online with just a few easy clicks. We dont need extensive paperwork on a health check-up!',
                  style: TextStyle(
                    fontFamily: 'Roboto Slab',
                    fontSize: 11,
                    color: Color(0xff86888A),
                  ),
                )),
          ],
        ));
  }
}
