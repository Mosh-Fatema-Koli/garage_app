import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:instasure/Utilities/userPref.dart';
import 'package:instasure/domains/repo/apiClientCustomerDasboard.dart';
import 'package:instasure/screens/dashboard/deviceInsurancePurchaseDetail.dart';
import 'package:instasure/widgets/topView4.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'dart:async';
import 'package:http/http.dart' as http;

class PaymentWebview extends StatefulWidget {
  const PaymentWebview({Key? key, required this.url, required this.id})
      : super(key: key);
  final String url;
  final String id;

  @override
  _PaymentWebviewState createState() => _PaymentWebviewState();
  //            'https://sandbox.aamarpay.com//paynow.php?track=AAM1657013557198944',

}

class _PaymentWebviewState extends State<PaymentWebview> {
  final Completer<WebViewController> _controller =
      Completer<WebViewController>();
  final ApiClientCustomerDasboard _apiClient = ApiClientCustomerDasboard();

  @override
  void initState() {
    print("url2:${widget.url}");
  }

  Future<void> aamarpaySuccess() async {
    EasyLoading.instance.userInteractions = false;
    EasyLoading.show(status: 'Processing...');

    UserPref prefs = UserPref();
    Future<String?> token = prefs.getTokenFromPref();
    String? accessToken = await token;

    var headers = {
      'Accept': 'application/json',
      'Authorization': 'Bearer $accessToken'
    };
    var request = http.MultipartRequest('POST',
        Uri.parse('https://instasure.xyz/api/aamarpay_success_response'));
    request.fields.addAll(
        {'opt_a': 'DeviceInsurance', 'opt_b': widget.id, 'is_api': 'true'});

    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();
    EasyLoading.dismiss();
    if (response.statusCode == 200) {
      print(await response.stream.bytesToString());
      Navigator.of(context).pushReplacement(MaterialPageRoute(
          builder: (BuildContext context) => DeviceInsurancePurchaseDetail(
                id: widget.id,
                isCancel: false,
              )));
    } else {
      print(response.reasonPhrase);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Failed'),
        backgroundColor: Colors.red.shade300,
      ));
    }
  }

  Future<void> aamarpayCancl() async {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: const Text('Processing Data'),
      backgroundColor: Colors.green.shade300,
    ));
    Map<String, dynamic> data = {
      "opt_a": 'DeviceInsurance',
      "opt_b": widget.id,
      "is_api": 'true',
    };
    UserPref prefs = UserPref();
    Future<String?> token = prefs.getTokenFromPref();
    String? accessToken = await token;
    dynamic res = await _apiClient.aamarpayCancleResponse(data, accessToken!);
    ScaffoldMessenger.of(context).hideCurrentSnackBar();

    if (res.statusCode == 200) {
      Navigator.of(context).popUntil((route) => route.isFirst);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('${res.data['message']}'),
        backgroundColor: Colors.red.shade300,
      ));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: null,
      backgroundColor: const Color(0xFFEFF7FF),
      body: SizedBox(
        height: MediaQuery.of(context).size.height,
        child: Column(
          children: [
            SizedBox(
              height: 125,
              child: Stack(
                children: [
                  const TopView4(),
                  Positioned(
                    bottom: 20.0,
                    left: 40.0,
                    child: SizedBox(
                        height: 30,
                        width: 30,
                        // color: const Color.fromRGBO(0, 46, 91, 1.0),
                        // padding: const EdgeInsets.fromLTRB(10, 15, 10, 5),
                        child: TextButton(
                          child: Image.asset('assets/back_button_icon.png'),
                          onPressed: () {
                            Navigator.of(context).pop();
                          },
                        )),
                  )
                ],
              ),
            ),
            SizedBox(
              height: MediaQuery.of(context).size.height - 200,
              child: WebView(
                navigationDelegate: (NavigationRequest request) async {
                  print(request.url);

                  print(request);

                  if (request.url.contains("success")) {
                    if (widget.id == "0") {
                      Navigator.of(context).popUntil((route) => route.isFirst);
                    } else {
                      aamarpaySuccess();
                    }
                    //Navigator.pop(context);

                    return NavigationDecision.prevent;
                  } else if (request.url.contains("fail")) {
                    // Navigator.pop(context);
                    if (widget.id == "0") {
                      Navigator.of(context).popUntil((route) => route.isFirst);
                    } else {
                      Navigator.of(context).pushReplacement(MaterialPageRoute(
                          builder: (BuildContext context) =>
                              DeviceInsurancePurchaseDetail(
                                id: widget.id,
                                isCancel: true,
                              )));
                      // aamarpayCancl();
                    }

                    // setState(() {});
                    // Timer(const Duration(seconds: 3),
                    //     () => Navigator.pop(context));
                    return NavigationDecision.prevent;
                  } else {
                    setState(() {});
                    return NavigationDecision.navigate;
                  }
                },
                backgroundColor: Colors.white,
                zoomEnabled: true,
                initialUrl: widget.url,
                javascriptMode: JavascriptMode.unrestricted,
                onWebViewCreated: (WebViewController webViewController) {
                  _controller.complete(webViewController);
                },
                onPageFinished: (url) {
                  print('1452');
                  print(url);
                  if (url.contains("purchase/details")) {
                    if (widget.id == "0") {
                      Navigator.of(context).popUntil((route) => route.isFirst);
                    } else {
                      aamarpaySuccess();
                    }
                    //Navigator.of(context).popUntil((route) => route.isFirst);
                  }else if(url.contains("fail")){
                    if (widget.id == "0") {
                      Navigator.of(context).popUntil((route) => route.isFirst);
                    } else {
                      Navigator.of(context).pushReplacement(MaterialPageRoute(
                          builder: (BuildContext context) =>
                              DeviceInsurancePurchaseDetail(
                                id: widget.id,
                                isCancel: true,
                              )));
                      // aamarpayCancl();
                    }
                  }
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
