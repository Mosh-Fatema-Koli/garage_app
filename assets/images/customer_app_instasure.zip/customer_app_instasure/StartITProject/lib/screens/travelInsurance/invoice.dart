import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:instasure/Utilities/helper.dart';
import 'package:instasure/Utilities/userPref.dart';
import 'package:instasure/domains/models/travelInsurance/travelInsuranceInvoiceModel.dart';
import 'package:instasure/domains/repo/apiTravelInsurance.dart';
import 'package:instasure/screens/travelInsurance/payment.dart';
import 'package:instasure/widgets/topView4.dart';

class Invoice extends StatefulWidget {
  const Invoice({Key? key, required this.id}) : super(key: key);
  final String id;

  @override
  _InvoiceState createState() => _InvoiceState();
}

class _InvoiceState extends State<Invoice> {
  final ApiTravelInsurance _apiClient = ApiTravelInsurance();
  late TravelInsuranceInvoiceModel travelInsuranceInvoiceModel;
  var loading = true;
  List tableItemIndexs = <int>[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
  List bottomList = <int>[0, 1, 2, 3];

  @override
  void initState() {
    super.initState();
    () async {
      await Future.delayed(Duration.zero);
      getTravelInsuranceInvoiceData();
    }();
  }

  Future<void> getTravelInsuranceInvoiceData() async {
    UserPref prefs = UserPref();

    Future<String?> token = prefs.getTokenFromPref();
    String? accessToken = await token;
    print("widget.id:${widget.id}");
    EasyLoading.instance.userInteractions = false;
    EasyLoading.show(status: 'Processing...');
    dynamic res =
        await _apiClient.getTravelInsuranceInvoiceData(widget.id, accessToken!);
    //ScaffoldMessenger.of(context).hideCurrentSnackBar();
    EasyLoading.dismiss();
    if (res.statusCode == 200) {
      if (res.data['code'] == 200) {
        TravelInsuranceInvoiceModel _travelInsuranceInvoiceModel =
            TravelInsuranceInvoiceModel.fromJson(res.data['data']);

        setState(() {
          travelInsuranceInvoiceModel = _travelInsuranceInvoiceModel;
          loading = false;
        });
        // Navigator.push(
        //  context, MaterialPageRoute(builder: (context) => const MainPage()));
      } else {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('${res.data['message']}'),
          backgroundColor: Colors.red.shade300,
        ));
        setState(() {
          loading = false;
        });
      }
    } else {
      setState(() {
        loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: null,
        backgroundColor: const Color(0xFFEFF7FF),
        body: loading
            ? Center(
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: const [
                    CircularProgressIndicator(),
                    SizedBox(
                      width: 10,
                    ),
                    Text("Loading"),
                  ],
                ),
              )
            : Container(
                padding: const EdgeInsets.only(left: 8, right: 8),
                child: Column(
                  children: <Widget>[
                    Stack(
                      children: [
                        const TopView4(),
                        Positioned(
                          bottom: 20.0,
                          left: 40.0,
                          child: SizedBox(
                              height: 30,
                              width: 30,
                              // color: const Color.fromRGBO(0, 46, 91, 1.0),
                              // padding: const EdgeInsets.fromLTRB(10, 15, 10, 5),
                              child: TextButton(
                                child:
                                    Image.asset('assets/back_button_icon.png'),
                                onPressed: () {
                                  Navigator.of(context).pop();
                                },
                              )),
                        )
                      ],
                    ),
                    Expanded(
                      child: ListView(
                        children: <Widget>[
                          const SizedBox(
                            height: 10,
                          ),
                          buildInfoView(),
                          const SizedBox(
                            height: 30,
                          ),
                          Container(
                              height: 40,
                              width: 400,
                              // color: const Color.fromRGBO(0, 46, 91, 1.0),
                              decoration: const BoxDecoration(
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(20)),
                                  color: Color.fromRGBO(0, 46, 91, 1.0)),
                              // padding: const EdgeInsets.fromLTRB(10, 15, 10, 5),
                              child: TextButton(
                                child: const Text(
                                  'Go Back',
                                  style: TextStyle(
                                      color: Colors.white, fontSize: 16),
                                ),
                                onPressed: () {

                                  Navigator.of(context).pop();
                                },
                              )),
                          const SizedBox(
                            height: 30,
                          ),
                        ],
                      ),
                    )
                  ],
                )));
  }

  buildInfoView() {
    return Padding(
      padding: const EdgeInsets.only(left: 0.0, right: 0),
      child: Container(
        height: 800,
        width: MediaQuery.of(context).size.width - 20,
        color: const Color(0xFFFFFFFF),
        child: Column(
          children: [
            const SizedBox(
              height: 10,
            ),
            const Center(
                child: Text(
              "Invoice",
              style: TextStyle(
                fontFamily: 'RobotoSlab-Bold',
                fontSize: 18,
                color: Colors.black,
                decoration: TextDecoration.underline,
              ),
            )),
            const SizedBox(
              height: 10,
            ),
            Padding(
              padding: const EdgeInsets.only(left: 10.0, right: 10.0),
              child: Container(
                alignment: FractionalOffset.center,
                padding: const EdgeInsets.all(10),
                height: 150,
                color: const Color(0xFFbdbdbd),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    SizedBox(
                      width: (MediaQuery.of(context).size.width - 40 - 40) / 3,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            "Company Info\nInstasure",
                            style: TextStyle(
                              fontFamily: 'RobotoSlab-Bold',
                              fontSize: 10,
                              color: Color(0xFF000000),
                            ),
                          ),
                          Expanded(
                            child: RichText(
                              text: TextSpan(
                                style: const TextStyle(
                                    color: Colors.black, fontSize: 10),
                                children: <TextSpan>[
                                  const TextSpan(
                                      text: 'Address: ',
                                      style:
                                          TextStyle(color: Color(0xFF000000))),
                                  TextSpan(
                                      text: loading
                                          ? ''
                                          : '${travelInsuranceInvoiceModel.defaultAddress}',
                                      style: const TextStyle(
                                          color: Color(0xFF86888A),
                                          fontSize: 8)),
                                ],
                              ),
                            ),
                          ),
                          RichText(
                            text: const TextSpan(
                              style:
                                  TextStyle(color: Colors.black, fontSize: 10),
                              children: <TextSpan>[
                                TextSpan(
                                    text: 'Phone: ',
                                    style: TextStyle(color: Color(0xFF000000))),
                                TextSpan(
                                    text: '+0163878556757',
                                    style: TextStyle(
                                        color: Color(0xFF86888A), fontSize: 8)),
                              ],
                            ),
                          ),
                          RichText(
                            text: const TextSpan(
                              style:
                                  TextStyle(color: Colors.black, fontSize: 10),
                              children: <TextSpan>[
                                TextSpan(
                                    text: 'Cell-Phone: ',
                                    style: TextStyle(color: Color(0xFF000000))),
                                TextSpan(
                                    text: '+0163878556757',
                                    style: TextStyle(
                                        color: Color(0xFF86888A), fontSize: 8)),
                              ],
                            ),
                          ),
                          RichText(
                            text: const TextSpan(
                              style:
                                  TextStyle(color: Colors.black, fontSize: 10),
                              children: <TextSpan>[
                                TextSpan(
                                    text: 'Email: ',
                                    style: TextStyle(color: Color(0xFF000000))),
                                TextSpan(
                                    text: 'instasure@gmail.com',
                                    style: TextStyle(
                                        color: Color(0xFF86888A), fontSize: 8)),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      width: (MediaQuery.of(context).size.width - 40 - 40) / 3,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            "Contact Person Info",
                            style: TextStyle(
                              fontFamily: 'RobotoSlab-Bold',
                              fontSize: 10,
                              color: Color(0xFF000000),
                            ),
                          ),
                          RichText(
                            text: TextSpan(
                              style: const TextStyle(
                                  color: Colors.black, fontSize: 10),
                              children: <TextSpan>[
                                const TextSpan(
                                    text: 'Name: ',
                                    style: TextStyle(color: Color(0xFF000000))),
                                TextSpan(
                                    text: loading
                                        ? ''
                                        : '${travelInsuranceInvoiceModel.fullName}',
                                    style: const TextStyle(
                                        color: Color(0xFF86888A), fontSize: 8)),
                              ],
                            ),
                          ),
                          RichText(
                            text: TextSpan(
                              style: const TextStyle(
                                  color: Colors.black, fontSize: 10),
                              children: <TextSpan>[
                                const TextSpan(
                                    text: 'Phone: ',
                                    style: TextStyle(color: Color(0xFF000000))),
                                TextSpan(
                                    text: loading
                                        ? ''
                                        : '${travelInsuranceInvoiceModel.phone}',
                                    style: const TextStyle(
                                        color: Color(0xFF86888A), fontSize: 8)),
                              ],
                            ),
                          ),
                          RichText(
                            text: TextSpan(
                              style: const TextStyle(
                                  color: Colors.black, fontSize: 10),
                              children: <TextSpan>[
                                const TextSpan(
                                    text: 'Email: ',
                                    style: TextStyle(color: Color(0xFF000000))),
                                TextSpan(
                                    text: loading
                                        ? ''
                                        : '${travelInsuranceInvoiceModel.email}',
                                    style: const TextStyle(
                                        color: Color(0xFF86888A), fontSize: 8)),
                              ],
                            ),
                          ),
                          RichText(
                            text: TextSpan(
                              style: const TextStyle(
                                  color: Colors.black, fontSize: 10),
                              children: <TextSpan>[
                                const TextSpan(
                                    text: 'Age: ',
                                    style: TextStyle(color: Color(0xFF000000))),
                                TextSpan(
                                    text: loading
                                        ? ''
                                        : '${travelInsuranceInvoiceModel.age}',
                                    style: const TextStyle(
                                        color: Color(0xFF86888A), fontSize: 8)),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      width: (MediaQuery.of(context).size.width - 40 - 40) / 3,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          RichText(
                            text: TextSpan(
                              style: const TextStyle(
                                  color: Colors.black, fontSize: 10),
                              children: <TextSpan>[
                                const TextSpan(
                                    text: 'Invoice: ',
                                    style: TextStyle(color: Color(0xFF000000))),
                                TextSpan(
                                    text: loading
                                        ? ''
                                        : '${travelInsuranceInvoiceModel.invoiceCode}',
                                    style: const TextStyle(
                                        color: Color(0xFF000000),
                                        fontSize: 10)),
                              ],
                            ),
                          ),
                          const SizedBox(
                            height: 30,
                          ),
                          RichText(
                            text: TextSpan(
                              style: const TextStyle(
                                  color: Colors.black, fontSize: 10),
                              children: <TextSpan>[
                                const TextSpan(
                                    text: 'Date: ',
                                    style: TextStyle(color: Color(0xFF000000))),
                                TextSpan(
                                    text: loading
                                        ? ''
                                        : getDateString(
                                            travelInsuranceInvoiceModel
                                                    .createdAt ??
                                                '',
                                            'dd-MM-yyyy'),
                                    style: const TextStyle(
                                        color: Color(0xFF86888A), fontSize: 8)),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(
              height: 10,
            ),
            buildTabeView(),
            const SizedBox(
              height: 10,
            ),
            buildBottomTabeView(),
          ],
        ),
      ),
    );
  }

  buildTabeView() {
    return Padding(
        padding: const EdgeInsets.only(left: 10.0, right: 10.0),
        child: SizedBox(
            width: MediaQuery.of(context).size.width,
            child: Table(
              columnWidths: const {
                0: FlexColumnWidth(1),
                1: FlexColumnWidth(1),
              },
              border: const TableBorder(
                top: BorderSide(color: Color(0xff707070), width: 0.5),
                // bottom: BorderSide(color: Color(0xff707070), width: 0.5),
                horizontalInside:
                    BorderSide(color: Color(0xff707070), width: 0.5),
              ),

              // Allows to add a border decoration around your table
              children: tableItemIndexs.map((index) {
                var value = '';
                var key = '';

                if (index == 0) {
                  key = 'Travel Plan Name';
                  value = loading
                      ? ''
                      : '${travelInsuranceInvoiceModel.travelInsuranceCategoryTitle}';
                } else if (index == 1) {
                  key = 'Passport Number';

                  value = loading
                      ? ''
                      : '${travelInsuranceInvoiceModel.passportNumber}';
                } else if (index == 2) {
                  key = 'Passport Expiray Date';

                  value = loading
                      ? ''
                      : getDateStringFRom(
                          travelInsuranceInvoiceModel.passportExpireTill ??
                              "2000-01-01",
                          'yyyy-MM-dd',
                          'dd-MM-yyyy');
                } else if (index == 3) {
                  key = 'Flight Number';

                  value = loading
                      ? ''
                      : travelInsuranceInvoiceModel.flightNumber ?? '';
                } else if (index == 4) {
                  key = 'Flight Date';

                  value = loading
                      ? ''
                      : getDateStringFRom(
                          travelInsuranceInvoiceModel.flightDate ??
                              "2000-01-01",
                          'yyyy-MM-dd',
                          'dd-MM-yyyy');
                } else if (index == 5) {
                  key = 'Return Date';

                  value = loading
                      ? ''
                      : getDateStringFRom(
                          travelInsuranceInvoiceModel.returnDate ??
                              "2000-01-01",
                          'yyyy-MM-dd',
                          'dd-MM-yyyy');
                } else if (index == 6) {
                  key = 'Total Stay';

                  value = loading
                      ? ''
                      : travelInsuranceInvoiceModel.totalDate ?? '';
                } else if (index == 7) {
                  key = 'Insurance Price';

                  value =
                      loading ? '' : travelInsuranceInvoiceModel.insPrice.toString() ?? '';
                } else if (index == 8) {
                  key = loading
                      ? ''
                      : 'Total Vat(${travelInsuranceInvoiceModel.vatPercentage})%';
                  value =
                      loading ? '' : travelInsuranceInvoiceModel.totalVat.toString() ?? '';
                } else if (index == 9) {
                  key = loading
                      ? ''
                      : 'Total Service Charge(${travelInsuranceInvoiceModel.serviceAmount})%';

                  value = loading
                      ? ''
                      : travelInsuranceInvoiceModel.serviceTotalAmount.toString() ?? '';
                } else if (index == 10) {
                  key = 'In Total Insurance Amount';

                  value = loading
                      ? ''
                      : travelInsuranceInvoiceModel.grandTotal.toString() ?? '';
                }

                return TableRow(children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 10, bottom: 10),
                    child: Text(
                      key,
                      textAlign: TextAlign.left,
                      style: const TextStyle(
                        fontFamily: 'Roboto Slab',
                        fontSize: 12,
                        color: Color(0xff000000),
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 10, bottom: 10),
                    child: Text(
                      value,
                      textAlign: TextAlign.left,
                      style: const TextStyle(
                        fontFamily: 'Roboto Slab',
                        fontSize: 12,
                        color: Color(0xffbdbdbd),
                      ),
                    ),
                  ),
                ]);
              }).toList(),
            )));
  }

  buildBottomTabeView() {
    return Padding(
      padding: const EdgeInsets.only(left: 10.0, right: 10.0),
      child: Align(
        alignment: Alignment.centerRight,
        child: SizedBox(
            width: MediaQuery.of(context).size.width / 2,
            child: Table(
              columnWidths: const {
                0: FlexColumnWidth(1),
                1: FlexColumnWidth(1),
              },
              border: const TableBorder(
                top: BorderSide(color: Color(0xff707070), width: 0.5),
                // bottom: BorderSide(color: Color(0xff707070), width: 0.5),
                horizontalInside:
                    BorderSide(color: Color(0xff707070), width: 0.5),
              ),

              // Allows to add a border decoration around your table
              children: bottomList.map((index) {
                var value = '';
                var key = '';

                if (index == 0) {
                  key = 'Sub Total:';
                  value =
                      loading ? '' : travelInsuranceInvoiceModel.insPrice.toString() ?? '';
                } else if (index == 1) {
                  key = loading
                      ? ''
                      : 'Vat(${travelInsuranceInvoiceModel.vatPercentage})%:';
                  value =
                      loading ? '' : travelInsuranceInvoiceModel.totalVat.toString() ?? '';
                } else if (index == 2) {
                  key = loading
                      ? ''
                      : 'Service Charge(${travelInsuranceInvoiceModel.serviceAmount})%:';

                  value = loading
                      ? ''
                      : travelInsuranceInvoiceModel.serviceTotalAmount.toString() ?? '';
                } else if (index == 3) {
                  key = 'Total:';

                  value = loading
                      ? ''
                      : travelInsuranceInvoiceModel.grandTotal.toString() ?? '';
                }
                return TableRow(children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 10, bottom: 10),
                    child: Text(
                      key,
                      textAlign: TextAlign.left,
                      style: const TextStyle(
                        fontFamily: 'Roboto Slab',
                        fontSize: 12,
                        color: Color(0xff000000),
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 10, bottom: 10),
                    child: Text(
                      value,
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        fontFamily: 'Roboto Slab',
                        fontSize: 12,
                        color: Color(0xffbdbdbd),
                      ),
                    ),
                  ),
                ]);
              }).toList(),
            )),
      ),
    );
  }
}
