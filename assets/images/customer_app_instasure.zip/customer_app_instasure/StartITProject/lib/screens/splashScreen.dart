// ignore: file_names
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:instasure/Utilities/userPref.dart';

import 'package:instasure/screens/auth/loginPage.dart';
import 'package:instasure/screens/deviceInsurance/claimRequests.dart';

import 'package:instasure/screens/mainPage.dart';
import 'package:instasure/screens/onboarding.dart';
import 'package:instasure/screens/travelInsurance/invoice.dart';
import 'package:instasure/screens/travelInsurance/selectProvider.dart';
import 'package:instasure/widgets/topView.dart';

import 'claimProcess/claimPage.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  var accessToken = false;
  var isFirstTimeLaunch = false;

  @override
  void initState() {
    super.initState();
    goToInitialPage();

    // Navigator.of(context).push(
    // MaterialPageRoute(builder: (_) {
    //   return const LoginPage();
    // },
    //   settings: const RouteSettings(name: 'LoginPage',),
    // ));

    Timer(
        const Duration(seconds: 3),
        () => Navigator.of(context).pushReplacement(MaterialPageRoute(
            //builder: (BuildContext context) => const ClaimPage())));

            builder: (BuildContext context) => isFirstTimeLaunch
                ? Onboarding()
                : accessToken
                    ? const LoginPage()
                    : const LoginPage())));
  }

  goToInitialPage() async {
    UserPref prefs = UserPref();
    Future<bool> isFirstLaunch = prefs.isFirstLaunch();
    bool _isFirstLaunch = await isFirstLaunch;
    Future<String?> token = prefs.getTokenFromPref();
    String? _token = await token;
    print (_token);
    setState(() {
      accessToken = _token == null ? false : true;
      isFirstTimeLaunch = _isFirstLaunch;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Container(
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage("assets/splash.png"),
            fit: BoxFit.cover,
          ),
        ),
        child: const Center(
          child: TopView(),
        ),
      ),
    );
  }
}
