import 'package:flutter/material.dart';
import 'package:instasure/widgets/topView2.dart';
import 'package:instasure/widgets/topView4.dart';
import '../widgets/topView.dart';

class ParrentProgramSubmissionSuccess extends StatefulWidget {
  const ParrentProgramSubmissionSuccess({Key? key}) : super(key: key);

  @override
  _ParrentProgramSubmissionSuccessState createState() =>
      _ParrentProgramSubmissionSuccessState();
}

class _ParrentProgramSubmissionSuccessState
    extends State<ParrentProgramSubmissionSuccess> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: null,
      backgroundColor: const Color(0xFFEFF7FF),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Stack(
            children: [
              const TopView4(),
              Positioned(
                bottom: 20.0,
                left: 40.0,
                child: SizedBox(
                    height: 30,
                    width: 30,
                    // color: const Color.fromRGBO(0, 46, 91, 1.0),
                    // padding: const EdgeInsets.fromLTRB(10, 15, 10, 5),
                    child: TextButton(
                      child: Image.asset('assets/back_button_icon.png'),
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                    )),
              )
            ],
          ),
          Center(
            child: Container(
                alignment: Alignment.center,
                padding: const EdgeInsets.only(left: 25, top: 200, right: 25),
                child: Image.asset(
                  "assets/submission_success_icon.png",
                  fit: BoxFit.cover,
                )
                //
                ),
          ),
          Container(
              alignment: Alignment.center,
              margin: const EdgeInsets.all(15),
              // padding: const EdgeInsets.all(15),
              child: const Text(
                'We will contact you soon',
                style: TextStyle(fontSize: 17),
              ))
        ],
      ),
    );
  }
}
