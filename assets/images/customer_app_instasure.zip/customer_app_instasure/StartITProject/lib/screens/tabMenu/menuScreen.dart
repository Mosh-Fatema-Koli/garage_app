import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:instasure/Utilities/menuList.dart';
import 'package:instasure/Utilities/userPref.dart';
import 'package:instasure/domains/repo/apiAuthClient.dart';
import 'package:instasure/screens/aboutUs.dart';
import 'package:instasure/screens/auth/loginPage.dart';
import 'package:instasure/screens/auth/resetPasswordPage.dart';
import 'package:instasure/screens/dashboard/contactus.dart';
import 'package:instasure/screens/dashboard/dashboard.dart';
import 'package:instasure/screens/dashboard/diagnosisReportDetail.dart';
import 'package:instasure/screens/dashboard/profileScreen.dart';
import 'package:instasure/screens/deviceInsurance/claimRequests.dart';
import 'package:instasure/screens/deviceInsurance/deviceInsuranceClaimHistory.dart';
import 'package:instasure/screens/tourInsurance/tour_history.dart';
import 'package:instasure/screens/travelInsurance/getTravelInsurance.dart';
import 'package:instasure/screens/travelInsurance/travelInsuranceHistory.dart';
import 'package:instasure/screens/deviceInsurance/deviceInsuranceHistory.dart';
import 'package:instasure/screens/trip_Insurance/trip_history.dart';
import 'package:instasure/screens/vehicle_Insurance/buy_vehicle_insurance.dart';

import 'package:shared_preferences/shared_preferences.dart';

import '../../domains/models/dashboard/diagnosisReportList.dart';
import '../../domains/models/menuItesmListModel.dart';
import '../diagonostic/checkDeviceFeature.dart';

class MenuScreen extends StatefulWidget {
  const MenuScreen({Key? key}) : super(key: key);

  @override
  _MenuScreenState createState() => _MenuScreenState();
}

class _MenuScreenState extends State<MenuScreen> {
  SharedPreferences? preferences;
  final ApiAuthClient _apiClient = ApiAuthClient();
  bool _isShown = true;

  List<Menu> data = [];
  @override
  void initState() {
    super.initState();

    initializePreference().whenComplete((){
      setState(() {
//        this.preferences?.setInt("counter", 7);
//        this.preferences?.setString("serial_number", "zxcxzv");
      });
    });


    dataList.forEach((element) {
      data.add(Menu.fromJson(element));
    });
    //Navigator.of(context).popUntil((route) => route.isFirst);
  }


  Future<void> initializePreference() async{
    this.preferences = await SharedPreferences.getInstance();
   // this.preferences?.setString("name", "Peter");
  }


  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context).copyWith(dividerColor: Colors.transparent);
   /* return Scaffold(
      body: SafeArea(
        top: false,
        child: Column(
          // mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const TopView4(),
            buildMenuList(),
          ],
        ),
      ),
      backgroundColor: const Color(0xFFEFF7FF),
    );*/

    return WillPopScope(

      onWillPop: () async {
        final shouldPop = await showDialog<bool>(
          context: context,
          builder: (context) {
            return AlertDialog(
              title: const Text('Do you want to close the app?'),
              actionsAlignment: MainAxisAlignment.spaceBetween,
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.pop(context, true);
                  },
                  child: const Text('Yes'),
                ),
                TextButton(
                  onPressed: () {
                    Navigator.pop(context, false);
                  },
                  child: const Text('No'),
                ),
              ],
            );
          },
        );
        return shouldPop!;
      },




      child: Scaffold(

        body: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 20.0),

          child: Column(

            children: <Widget>[
              Divider(),
//Dashboard
              Column(
                children: <Widget>[
                  InkWell(
                      child: Padding(
                        padding: EdgeInsets.all(15), //apply padding to all four sides
                        child: Align(
                          alignment: Alignment.centerLeft,

                          child: Container(

                            child:  Text( "Dashboard",
                              style: TextStyle( fontSize: 18.0, fontWeight: FontWeight.bold ),
                            ),
                          ),
                        ),
                      ),
                      onTap: () => {
                      Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const DashBoard()),
                      )
                      }
                  ),
                ],
              ),
              Divider(),
//Device
              Theme( //new
                data:theme, //new
                child:ExpansionTile(
                  title:
                  Text( "Device Insurance",
                    style: TextStyle( fontSize: 18.0, fontWeight: FontWeight.bold ),
                  ),

                  children: <Widget>[

                    SizedBox(height:3.0),
//A1 Device Diagnosis
                    Material(
                      elevation: 6,
                      shadowColor:Colors.black.withAlpha(70),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),

                      child: ListTile(
                        onTap: () => {



                        //this.preferences.getBool(Constant().IS_TESTING)
if(this.preferences?.getString("serial_number")==''){
  print(1)
}
else if(this.preferences?.getString("serial_number")==null){
  _diagnosisAlert(context)

}else if(this.preferences?.getString("serial_number")!=null){
  Navigator.push(
    context,
    MaterialPageRoute(
        builder: (context) => DiagnosisReportDetail(
          id: "${this.preferences?.getString("serial_number")}",
        )),
  )
}else if(this.preferences?.getString("serial_number")!=''){
  print(4)
}else{
  print(5)
  }
                          /*  if(this.preferences?.getString("serial_number") == 0){
                                 /*   Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => DiagnosisReportDetail(
                                          id: "${this.preferences?.getString("serial_number")}",
                                        )),
                                  )*/
                             // print(this.preferences?.getString("serial_number"));
                              print('kk')
                            }

                            else{
                              print("ok")
                              //_diagnosisAlert(context)
                            }*/

                        },
                        tileColor: Theme.of(context).cardColor,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),

                        title:RichText(
                          text: TextSpan(
                            children: [
                              WidgetSpan(
                                child: Icon(Icons.subdirectory_arrow_right_outlined  , size: 22),
                              ),
                              TextSpan(
                                text: 'Buy Insurance',style: TextStyle(
                                color: Colors.black87,
                              ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),

                    SizedBox(height:10.0),
//A2 Diagnosis Report List
                    Material(
                      elevation: 6,
                      shadowColor:Colors.black.withAlpha(70),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),

                      child: ListTile(
                        onTap: () => {
                          Navigator.push( context, MaterialPageRoute( builder: (context) => const DiagnosisReportList()), )
                        },
                        tileColor: Theme.of(context).cardColor,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),

                        title:RichText(
                          text: TextSpan(
                            children: [
                              WidgetSpan(
                                child: Icon(Icons.subdirectory_arrow_right_outlined  , size: 22),
                              ),
                              TextSpan(
                                text: 'Diagnosis Report List',style: TextStyle(
                                color: Colors.black87,
                              ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height:10.0),

//A3 Device Insurance History
                    Material(
                      elevation: 6,
                      shadowColor:Colors.black.withAlpha(70),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),

                      child: ListTile(
                        onTap: () => {

                          Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const DeviceInsuranceHistory()),
                          )
                        },
                        tileColor: Theme.of(context).cardColor,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),

                        title:RichText(
                          text: TextSpan(
                            children: [
                              WidgetSpan(
                                child: Icon(Icons.subdirectory_arrow_right_outlined  , size: 22),
                              ),
                              TextSpan(
                                text: 'Purchase History',style: TextStyle(
                                color: Colors.black87,
                              ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height:10.0),
//A4 Device Insurance Claim Requests
                    Material(
                      elevation: 6,
                      shadowColor:Colors.black.withAlpha(70),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),

                      child: ListTile(
                        onTap: () => {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const ClaimRequests()),
                          )                      },
                        tileColor: Theme.of(context).cardColor,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),

                        title:RichText(
                          text: TextSpan(
                            children: [
                              WidgetSpan(
                                child: Icon(Icons.subdirectory_arrow_right_outlined  , size: 22),
                              ),
                              TextSpan(
                                text: 'Support Tickets',style: TextStyle(
                                color: Colors.black87,
                              ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height:10.0),
//A5 Device Insurance Claim History
                    Material(
                      elevation: 6,
                      shadowColor:Colors.black.withAlpha(70),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),

                      child: ListTile(
                        onTap: () => {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) =>
                                const DeviceInsuranceClaimHistory()),
                          )
                        },
                        tileColor: Theme.of(context).cardColor,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),

                        title:RichText(
                          text: TextSpan(
                            children: [
                              WidgetSpan(
                                child: Icon(Icons.subdirectory_arrow_right_outlined  , size: 22),
                              ),
                              TextSpan(
                                text: 'Claim History',style: TextStyle(
                                color: Colors.black87,
                              ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height:10.0),
                  ],
                ),
              ),

//Travel
              Divider(),
              Theme( //new
                data:theme, //new
                child: ExpansionTile(

                  title:
                  Text( "Travel Insurance",
                    style: TextStyle( fontSize: 18.0, fontWeight: FontWeight.bold ),
                  ),

                  children: <Widget>[

                    SizedBox(height:3.0),
//A1 Get Travel Insurance
                    Material(
                      elevation: 6,
                      shadowColor:Colors.black.withAlpha(70),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),

                      child: ListTile(
                        onTap: () => {

                          Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const TravelsInsurance()),
                          )

                        },
                        tileColor: Theme.of(context).cardColor,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),

                        title:RichText(
                          text: TextSpan(
                            children: [
                              WidgetSpan(
                                child: Icon(Icons.subdirectory_arrow_right_outlined  , size: 22),
                              ),
                              TextSpan(
                                text: 'Get Travel Insurance',style: TextStyle(
                                color: Colors.black87,
                              ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),

                    SizedBox(height:10.0),
//A2 Travel Insurance History
                    Material(
                      elevation: 6,
                      shadowColor:Colors.black.withAlpha(70),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),

                      child: ListTile(
                        onTap: () => {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const TravelInsuranceHistory()),
                          )
                        },
                        tileColor: Theme.of(context).cardColor,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),

                        title:RichText(
                          text: TextSpan(
                            children: [
                              WidgetSpan(
                                child: Icon(Icons.subdirectory_arrow_right_outlined  , size: 22),
                              ),
                              TextSpan(
                                text: 'Travel Insurance History',style: TextStyle(
                                color: Colors.black87,
                              ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),

                    SizedBox(height:10.0),

                  ],
                ),
              ),

 //Tour
              Divider(),
              Theme( //new
                data:theme, //new
                child: ExpansionTile(

                  title:
                  Text( "Tour Insurance",
                    style: TextStyle( fontSize: 18.0, fontWeight: FontWeight.bold ),
                  ),

                  children: <Widget>[

                    SizedBox(height:3.0),

//A2 Tour Insurance History
                    Material(
                      elevation: 6,
                      shadowColor:Colors.black.withAlpha(70),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),

                      child: ListTile(
                        onTap: () => {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const TourStatus()),
                          )


                        },
                        tileColor: Theme.of(context).cardColor,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),

                        title:RichText(
                          text: TextSpan(
                            children: [
                              WidgetSpan(
                                child: Icon(Icons.subdirectory_arrow_right_outlined  , size: 22),
                              ),
                              TextSpan(
                                text: 'Tour Insurance History',style: TextStyle(
                                color: Colors.black87,
                              ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),

                    SizedBox(height:10.0),

                  ],
                ),
              ),
//Trip
              Divider(),
              Theme( //new
                data:theme, //new
                child: ExpansionTile(

                  title:
                  Text( "Trip Insurance",
                    style: TextStyle( fontSize: 18.0, fontWeight: FontWeight.bold ),
                  ),

                  children: <Widget>[

                    SizedBox(height:3.0),

//A2 Tour Insurance History
                    Material(
                      elevation: 6,
                      shadowColor:Colors.black.withAlpha(70),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),

                      child: ListTile(
                        onTap: () => {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const TripHistory()),
                          )


                        },
                        tileColor: Theme.of(context).cardColor,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),

                        title:RichText(
                          text: TextSpan(
                            children: [
                              WidgetSpan(
                                child: Icon(Icons.subdirectory_arrow_right_outlined  , size: 22),
                              ),
                              TextSpan(
                                text: 'Trip Insurance History',style: TextStyle(
                                color: Colors.black87,
                              ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),

                    SizedBox(height:10.0),

                  ],
                ),
              ),
 //Student
              Divider(),
              Theme( //new
                data:theme, //new
                child: ExpansionTile(

                  title:
                  Text( "Student Insurance",
                    style: TextStyle( fontSize: 18.0, fontWeight: FontWeight.bold ),
                  ),

                  children: <Widget>[

                    SizedBox(height:3.0),

//A2student Insurance History
                    Material(
                      elevation: 6,
                      shadowColor:Colors.black.withAlpha(70),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),

                      child: ListTile(
                        onTap: () => {

                        },
                        tileColor: Theme.of(context).cardColor,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),

                        title:RichText(
                          text: TextSpan(
                            children: [
                              WidgetSpan(
                                child: Icon(Icons.subdirectory_arrow_right_outlined  , size: 22),
                              ),
                              TextSpan(
                                text: 'Student Insurance History',style: TextStyle(
                                color: Colors.black87,
                              ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),

                    SizedBox(height:10.0),

                  ],
                ),
              ),

 //Vehicle
              Divider(),
              Theme( //new
                data:theme, //new
                child: ExpansionTile(

                  title:
                  Text( "Vehicle Insurance",
                    style: TextStyle( fontSize: 18.0, fontWeight: FontWeight.bold ),
                  ),

                  children: <Widget>[


                    SizedBox(height:3.0),
// Buy Vehicle Insurance
                    Material(
                      elevation: 6,
                      shadowColor:Colors.black.withAlpha(70),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),

                      child: ListTile(
                        onTap: () => {

                          Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const BuyVehicleInsurance()),
                          )

                        },
                        tileColor: Theme.of(context).cardColor,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),

                        title:RichText(
                          text: TextSpan(
                            children: [
                              WidgetSpan(
                                child: Icon(Icons.subdirectory_arrow_right_outlined  , size: 22),
                              ),
                              TextSpan(
                                text: 'Buy Vehicle Insurance',style: TextStyle(
                                color: Colors.black87,
                              ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),

                    SizedBox(height:10.0),

//vehicle Insurance History
                    Material(
                      elevation: 6,
                      shadowColor:Colors.black.withAlpha(70),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),

                      child: ListTile(
                        onTap: () => {

                        },
                        tileColor: Theme.of(context).cardColor,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),

                        title:RichText(
                          text: TextSpan(
                            children: [
                              WidgetSpan(
                                child: Icon(Icons.subdirectory_arrow_right_outlined  , size: 22),
                              ),
                              TextSpan(
                                text: 'Vehicle Insurance History',style: TextStyle(
                                color: Colors.black87,
                              ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),

                    SizedBox(height:10.0),

                  ],
                ),
              ),

//Setting
              Divider(),
              Theme( //new
                data:theme, //new
                child: ExpansionTile(
                  title:
                  Text( "Settings",
                    style: TextStyle( fontSize: 18.0, fontWeight: FontWeight.bold ),
                  ),

                  children: <Widget>[

                    SizedBox(height:3.0),
//A1 Edit Profile
                    Material(
                      elevation: 6,
                      shadowColor:Colors.black.withAlpha(70),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),

                      child: ListTile(
                        onTap: () => {

                          Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const ProfileScreen()),
                          )

                        },
                        tileColor: Theme.of(context).cardColor,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),

                        title:RichText(
                          text: TextSpan(
                            children: [
                              WidgetSpan(
                                child: Icon(Icons.subdirectory_arrow_right_outlined  , size: 22),
                              ),
                              TextSpan(
                                text: 'Edit Profile',style: TextStyle(
                                color: Colors.black87,
                              ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),

                    SizedBox(height:10.0),
//A2 Change Password
                    Material(
                      elevation: 6,
                      shadowColor:Colors.black.withAlpha(70),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),

                      child: ListTile(
                        onTap: () => {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) =>   ResetPasswordPage()),
                          )
                        },
                        tileColor: Theme.of(context).cardColor,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),

                        title:RichText(
                          text: TextSpan(
                            children: [
                              WidgetSpan(
                                child: Icon(Icons.subdirectory_arrow_right_outlined  , size: 22),
                              ),
                              TextSpan(
                                text: 'Change Password',style: TextStyle(
                                color: Colors.black87,
                              ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height:10.0),
                  ],
                ),
              ),

              Divider(),
              Column(
                children: <Widget>[
                  InkWell(

                      child: Padding(
                        padding: EdgeInsets.all(15), //apply padding to all four sides
                        child: Align(
                          alignment: Alignment.centerLeft,

                          child: Container(

                            child:  Text( "Contact Us",
                              style: TextStyle( fontSize: 18.0, fontWeight: FontWeight.bold ),

                            ),
                          ),

                          /*,   */

                        ),
                      ),
                      onTap: () => {

                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => const ContactUs()),
                        )

                      }
                  ),
                ],
              ),
              Divider(),
              Column(
                children: <Widget>[
                  InkWell(
                      child: Padding(
                        padding: EdgeInsets.all(15), //apply padding to all four sides
                        child: Align(
                          alignment: Alignment.centerLeft,

                          child: Container(

                            child:  Text( "Account Delete",
                              style: TextStyle( fontSize: 18.0, fontWeight: FontWeight.bold ),

                            ),
                          ),

                          /*,   */

                        ),
                      ),
                      onTap: () => {
                      }
                  ),
                ],
              ),
              Divider(),
//sign out
              Column(
                children: <Widget>[
                    InkWell(
                      child: Padding(
                    padding: EdgeInsets.all(15), //apply padding to all four sides
                      child: Align(
                        alignment: Alignment.centerLeft,

                        child: Container(

                          child:  Text( "Sign Out",
                            style: TextStyle( fontSize: 18.0, fontWeight: FontWeight.bold ),

                          ),
                        ),

                        /*,   */

                      ),
                  ),
                        onTap: () => {
                        logout()
                        }
                  ),
                ],
              ),
              Divider(),
             // buildMenuList(),
            ],
          ),
        ),



        /* body: SafeArea(
    top: false,
    child: Column(



    ),
  ),*/
        backgroundColor: const Color(0xFFEFF7FF),
      ),

    );
  }




  Widget buildMenuList() {
    return Expanded(
      child: ListView.builder(
        primary: false,
        scrollDirection: Axis.vertical,
        shrinkWrap: true,
        itemCount: menuList.length,
        itemBuilder: (BuildContext context, int index) {
          return GestureDetector(
            onTap: () {
              if (index == menu_list.dashboard.index) {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const DashBoard()),
                );
              } else if (index == menu_list.profile.index) {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => const ProfileScreen()),
                );
              } else if (index == menu_list.diagnosisReportList.index) {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => const DiagnosisReportList()),
                );
              } else if (index == menu_list.getTravelInsurance.index) {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => const TravelsInsurance()),
                );
              } else if (index == menu_list.travelInsuranceHistory.index) {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => const TravelInsuranceHistory()),
                );
              } else if (index == menu_list.deviceDiagnosis.index) {
                _diagnosisAlert(context);
              }else if (index == menu_list.deviceInsuranceHistory.index) {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => const DeviceInsuranceHistory()),
                );
              } else if (index == menu_list.deviceInsuranceClaimRequest.index) {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => const ClaimRequests()),
                );
              } else if (index == menu_list.deviceInsuranceClaimHistory.index) {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) =>
                          const DeviceInsuranceClaimHistory()),
                );
              }
              /*else if (index == menu_list.collectAndServiceCenter.index) {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => const ServiceCenter()),
                  );
                } else if (index == menu_list.deliveryProcess.index) {
                  // Navigator.push(
                  //   context,
                  //   MaterialPageRoute(
                  //       builder: (context) =>
                  //           const DeviceInsuranceClaimHistory()),
                  // );
                } */

              // else if (index == menu_list.claim.index) {
              //   Navigator.push(
              //     context,
              //     MaterialPageRoute(builder: (context) => const HowToClaim()),
              //   );
              // }
              // else if (index == menu_list.blog.index) {
              //   // Navigator.push(
              //   //   context,
              //   //   MaterialPageRoute(
              //   //       builder: (context) =>
              //   //           const DeviceInsuranceClaimHistory()),
              //   // );
              // }
            else if (index == menu_list.chanePassword.index) {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => ResetPasswordPage()),
                );
              } else if (index == menu_list.signOut.index) {
                // Navigator.push(
                //   context,
                //   MaterialPageRoute(
                //       builder: (context) => const ScreoolAbleTest()),
                // );
                logout();
              }
            },
            child: Padding(
              padding: const EdgeInsets.only(top: 10.0),
              child: Container(
                  height: 48,
                  child: Padding(
                    padding: const EdgeInsets.only(left: 20, right: 20),
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        menuList[index],
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                            fontFamily: 'Roboto Slab',
                            fontSize: 14.0,
                            color: Color(0xFF002E5B)),
                      ),
                    ),
                  ),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(0),
                    boxShadow: const [
                      BoxShadow(
                          color: Color(0xFFFFFFFF),
                          blurRadius: 6,
                          spreadRadius: 0,
                          offset: Offset(-3, -3)),
                      BoxShadow(
                          color: Color(0xFFDDE4EF),
                          blurRadius: 6,
                          spreadRadius: 0,
                          offset: Offset(3, 3)),
                    ],
                    color: const Color(0xffF0F3F6),
                  )),
            ),
          );
        },
      ),
    );
  }

  Future<void> logout() async {
    EasyLoading.instance.userInteractions = false;
    EasyLoading.show(status: 'Processing...');
    UserPref prefs = UserPref();
    Future<String?> token = prefs.getTokenFromPref();

    String? accessToken = await token;
    print("accessToken:$accessToken");

    dynamic res = await _apiClient.logout(accessToken!);
    EasyLoading.dismiss();
    if (res.statusCode == 200) {
      if (res.data['code'] == 200) {
        prefs.removeTokenFromPref();
        prefs.removeUserFromPref();
        // Navigator.of(context).pushAndRemoveUntil(
        //     MaterialPageRoute(builder: (c) => const LoginPage()),
        //     (route) => true);

        Navigator.of(context, rootNavigator: true).pushReplacement(
            MaterialPageRoute(builder: (context) => const LoginPage()));

        // Navigator.popUntil(context, ModalRoute.withName('/login'));
      } else {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('${res.data['message']}'),
          backgroundColor: Colors.red.shade300,
        ));
      }
    } else {}
  }


  void _diagnosisAlert(BuildContext context) {
    showDialog(
        context: context,
        builder: (context) {
          return CupertinoAlertDialog(
            title: const Text('Device Diagnosis'),
            content: const Text('Are you sure you want to device diagnosis? If yes, then please attach microphone with your device.'),
            actions: <Widget>[
              TextButton(
                  onPressed: () {
                    Navigator.pop(context);
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const CheckDeviceFeature()),
                    );
                  },
                  child: Text('Yes')),
              TextButton(
                onPressed: () {
                  Navigator.pop(context); //close Dialog
                },
                child: Text('No'),
              )
            ],
          );
        });
  }


}
