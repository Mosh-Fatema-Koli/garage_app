// ignore_for_file: unnecessary_new

import 'package:flutter/material.dart';
import 'package:instasure/screens/deviceInsurance/deviceInsuranceHistory.dart';
import 'package:instasure/screens/studentsInsurance/claim_history.dart';
import 'package:instasure/screens/tourInsurance/tour_history.dart';
import 'package:instasure/screens/travelInsurance/travelInsuranceHistory.dart';
import 'package:instasure/screens/trip_Insurance/trip_history.dart';


import '../../Utilities/homeMenu.dart';

class HowToClaim extends StatefulWidget {
  const HowToClaim({Key? key}) : super(key: key);

  @override
  _HowToClaimState createState() => _HowToClaimState();
}

class _HowToClaimState extends State<HowToClaim> {
//class LoginPage extends StatelessWidget {
  @override
  void initState() {
    super.initState();
    //Navigator.of(context).popUntil((route) => route.isFirst);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
          child: Padding(
        padding: const EdgeInsets.all(0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            //const TopView4(),
            Expanded(
              child: ListView(
                children: <Widget>[
                  const SizedBox(height: 20.0),
                  createHeaderWidget(),
             //     const SizedBox(height: 20.0),
                  Align(
                    alignment: Alignment.center,
                      child: Padding(
                        padding: EdgeInsets.all(20),
                        child: Text("To make a claim request, Please select insurance product from below.\n or \ncall: +8809606252525 \nor \nmail us hello@instasure.xyz",textAlign:TextAlign.center ,style: TextStyle(
                          fontFamily: 'Roboto Slab',
                          fontSize: 14,
                          color: Color(0xff020e4f),
                        ),),
                      )),
                  const SizedBox(height: 20.0),
                  buildGridView(),
                  const SizedBox(height: 20.0),
                  /*Center(
                    child: Container(
                      height: 30,
                      width: MediaQuery.of(context).size.width - 70,
                      child: TextButton(
                        child: const Text(
                          'Sign In',
                          style: TextStyle(color: Colors.white),
                        ),
                        onPressed: () {},
                      ),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(15),
                        boxShadow: [
                          BoxShadow(
                              color: const Color(0xff000000).withOpacity(0.15),
                              blurRadius: 3,
                              spreadRadius: 0,
                              offset: const Offset(0, 3)),
                        ],
                        color: const Color(0xff002E5B),
                      ),
                    ),
                  ),*/
                ],
              ),
            ),
          ],
        ),
      )),
      backgroundColor: const Color(0xFFEFF7FF),
    );
  }

  createHeaderWidget() {
    return Container(
      height: 38,
      child: const Center(
        child: Text(
          'CLAIM',
          textAlign: TextAlign.center,
          style: TextStyle(
            fontFamily: 'Roboto Slab',
            fontSize: 16,
            color: Color(0xff002E5B),
          ),
        ),
      ),
      decoration: const BoxDecoration(color: Color(0xffF0F3F6), boxShadow: [
        BoxShadow(
            color: Color(0xffffffff),
            blurRadius: 6,
            spreadRadius: 0,
            offset: Offset(-3, -3)),
        BoxShadow(
            color: Color(0xffDDE4EF),
            blurRadius: 6,
            spreadRadius: 0,
            offset: Offset(3, 3)),
      ]),
    );
  }


  buildGridView() {
    return Padding(
      padding: const EdgeInsets.only(right: 20, top: 0, bottom: 10, left: 20),
      child: Container(
       height:500,
        // color: Colors.red,

        //width: (MediaQuery.of(context).size.width - 30) / 3,
        child: GridView.count(
          physics: const NeverScrollableScrollPhysics(),
          crossAxisCount: 3,
          crossAxisSpacing: 20,
          mainAxisSpacing: 20,
        childAspectRatio: 1.1,

          children: List.generate(
            homeMenus.length,
                (index) {
              var cat = homeMenus[index];
              //return Padding(
              // padding: const EdgeInsets.only(right: 50, left: 0),
              //child: Container(
              return GestureDetector(
                onTap: () {
                  if (index == 0) {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const DeviceInsuranceHistory()),
                    );
                  } else if (index == 1) {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) =>
                          const TravelInsuranceHistory()),
                    );
                  } else if (index == 2) {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const TourStatus()),
                    );
                  } else if (index == 3) {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => TripHistory()),
                    );
                  } else if (index == 4) {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => ClaimHistory()),
                    );
                  } else if (index == 5) {
                    // Navigator.push(
                    //   context,
                    //   MaterialPageRoute(
                    //       builder: (context) => const Recommened(
                    //         title: 'Car Insurance',
                    //       )),
                    // );
                  } else if (index == 6) {
                    // Navigator.push(
                    //   context,
                    //   MaterialPageRoute(
                    //       builder: (context) => const Recommened(
                    //         title: 'Bike Insurance',
                    //       )),
                    // );
                  } else if (index == 7) {
                    // Navigator.push(
                    //   context,
                    //   MaterialPageRoute(
                    //       builder: (context) => const Recommened(
                    //         title: 'Home Insurance',
                    //       )),
                    // );
                  } else if (index == 8) {
                    //   Navigator.push(
                    //     context,
                    //     MaterialPageRoute(
                    //         builder: (context) => const Recommened(
                    //           title: 'Upcomming Products',
                    //         )),
                    //   );
                  } else if (index == 9) {
                    //   Navigator.push(
                    //     context,
                    //     MaterialPageRoute(
                    //         builder: (context) => const Recommened(
                    //           title: 'Upcomming Products',
                    //         )),
                    //   );
                  }
                },
                child: Container(
                  //width: (MediaQuery.of(context).size.width - 45) / 3,
                  alignment: Alignment.center,
                  // padding: const EdgeInsets.all(5),
                  // color: Colors.red,
                  //height: MediaQuery.of(context).size.height,

                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      if (index != 10)
                        Image(
                          image: AssetImage(cat["img"]),
                          height: 35,
                        ),
                      const SizedBox(height: 2.0),
                      Text(
                        cat["name"],
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          fontFamily: 'Roboto Slab',
                          fontSize: 13,
                          color: Color(0xff000000),
                        ),
                      ),
                    ],
                  ),

                  decoration: BoxDecoration(
                      color: Color(0xffF0F3F6),
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0xffffffff),
                          blurRadius: 6,
                          spreadRadius: 0,
                        ),
                        BoxShadow(
                            color: Color(0xffDDE4EF),
                            blurRadius: 6,
                            spreadRadius: 0,
                            offset: Offset(3, 3)),
                      ]),
                ),
              );

              // );
            },
          ),
        ),
        // decoration: const BoxDecoration(
        //   image: DecorationImage(
        //     image: AssetImage("assets/home/gridView_bg.png"),
        //     fit: BoxFit.cover,
        //   ),
        // ),
      ),
    );
  }



}
