// ignore_for_file: unnecessary_new

import 'package:banner_carousel/banner_carousel.dart';
import 'package:flutter/material.dart';
import 'package:instasure/Utilities/slideItem.dart';
import 'package:instasure/screens/aboutUs.dart';
import 'package:instasure/screens/parrentProgram.dart';
import 'package:instasure/screens/studentsInsurance/studentsInsurance.dart';
import 'package:instasure/screens/tourInsurance/tourInsurance.dart';
import 'package:instasure/screens/travelInsurance/internationalTravelInsurance.dart';
import 'package:instasure/screens/mobileInsurance.dart';
import 'package:instasure/screens/recommened.dart';
import 'package:instasure/screens/trip_Insurance/trip.dart';
import 'package:instasure/screens/vehicle_Insurance/vehicle_insurance.dart';



import '../../Utilities/homeMenu.dart';
import '../auth/termsOfConditionPage.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
//class LoginPage extends StatelessWidget {
  TextEditingController phoneController = TextEditingController();
  ScrollController _controller = ScrollController();
  double initialPosition = 0.0;
  double endPosition = 0.0;
  double distance = 0.0;
int show_appbar=0;

  static List<BannerModel> listBanners = [
    BannerModel(imagePath:  "assets/banner.png", id: "1"),
    BannerModel(imagePath:  "assets/1.png", id: "2"),
    BannerModel(imagePath:  "assets/2.png", id: "3"),
    BannerModel(imagePath:  "assets/3.png", id: "4"),
     ];

  @override
  void initState() {
    super.initState();
    _controller = ScrollController();
    _controller.addListener(_scrollListener);
    //Navigator.of(context).popUntil((route) => route.isFirst);
  }
  _scrollListener() {
    if (_controller.offset >= _controller.position.maxScrollExtent &&
        !_controller.position.outOfRange) {
      setState(() {
        show_appbar=0;
        print(1);
      });
    }
    if (_controller.offset <= _controller.position.minScrollExtent &&
        !_controller.position.outOfRange) {
      setState(() { show_appbar=0;
        print(2);
      });
    }
  }
  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        final shouldPop = await showDialog<bool>(
          context: context,
          builder: (context) {
            return AlertDialog(
              title: const Text('Do you want to close the app?'),
              actionsAlignment: MainAxisAlignment.spaceBetween,
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.pop(context, true);
                  },
                  child: const Text('Yes'),
                ),
                TextButton(
                  onPressed: () {
                    Navigator.pop(context, false);
                  },
                  child: const Text('No'),
                ),
              ],
            );
          },
        );
        return shouldPop!;
      },


      child: Scaffold(
        appBar: show_appbar==1 ?   AppBar(
          // title: const Text('Home'),
          title: Image.asset('assets/instasure_icon.png',fit: BoxFit.contain,
            height: 32,),

          backgroundColor: Colors.white,
          actions: <Widget>[
            IconButton(
              // AssetImage("assets/home/insurance.png"),
              icon: Icon(
                Icons.notifications_active,
                color: const Color(0xff002E5B),
              ),
              /*icon: Icon(
                Icons.settings,
                color: Colors.white,
              ),*/
              onPressed: () {
                // do something
              },
            )
          ],
        ): null,



        body: Center(
            child: ListView(
              controller: _controller,
              children: <Widget>[

                BannerCarousel.fullScreen(
                  banners: listBanners,
            customizedIndicators: IndicatorModel.animation(width: 20, height: 5, spaceBetween: 2, widthAnimation: 50),
                  height: 200,
                  activeColor: Colors.amberAccent,
                  disableColor: Colors.white,
                  animation: true,
                  indicatorBottom: false,
                ),
                const SizedBox(height: 10.0),
                buildSlideList(),
                const SizedBox(height: 0.0),
                Padding(
                  padding: const EdgeInsets.only(
                      right: 20, top: 0, bottom: 5, left: 20),
                  child: Container(
                    height: 540,
                    decoration: const BoxDecoration(
                        image: DecorationImage(
                          image: AssetImage("assets/home/gridView_bg.png"),
                          fit: BoxFit.cover,
                        ),
                        borderRadius:
                            BorderRadius.all(Radius.circular(35))),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const SizedBox(height: 20),
                        const Text("PRODUCTS"),

                        buildGridView(),
                      ],
                    ),
                  ),
                ),
              ],
            )),
      ),






    );
  }

  buildSlideList() {
    return SizedBox(
      height: (MediaQuery.of(context).size.width - 30) / 3,
      width: (MediaQuery.of(context).size.width - 30) / 3,
      child: ListView.builder(
        primary: false,
        scrollDirection: Axis.horizontal,
        shrinkWrap: true,
        itemCount: homeSlideMenus.length,
        itemBuilder: (BuildContext context, int index) {
          String img = images[index];

          return Padding(
            padding: const EdgeInsets.only(right: 3, left: 3),
            child: GestureDetector(
              onTap: () {
                if (index == 0) {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const AboutUs()),
                  );
                } else if (index == 1) {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => const ParrentProgram()),
                  );
                } else if (index == 2) {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => const TermsOfConditionPage()),
                  );
                }
              },
              child: Container(
                width: (MediaQuery.of(context).size.width - 30) / 3,
                alignment: Alignment.center,
                padding: const EdgeInsets.all(9),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    const SizedBox(height: 10.0),

                    Center(
                      child: Image(
                        image: AssetImage(img),
                        height: 37,
                      ),
                    ),
                    // Icon(
                    //   icons[index],
                    //   color: Colors.red,
                    //   size: 70,
                    // ),
                    const SizedBox(height: 10.0),
                    Expanded(
                      child: Text(
                        homeSlideMenus[index],
                        style: const TextStyle(
                          fontSize: 12.0,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                  ],
                ),
                decoration: const BoxDecoration(
                  image: DecorationImage(
                    image: AssetImage("assets/trending_bg.png"),
                    fit: BoxFit.fitWidth,
                  ),
                  // shape: BoxShape.circle,
                  // color: Colors.red,
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  buildGridView() {
    return Padding(
      padding: const EdgeInsets.only(right: 20, top: 20, bottom: 0, left: 20),
      child: SizedBox(
      height: 450,
        // color: Colors.red,

        //width: (MediaQuery.of(context).size.width - 30) / 3,
        child: GridView.count(
          physics: const NeverScrollableScrollPhysics(),
          crossAxisCount: 3,
          scrollDirection: Axis.vertical,
          crossAxisSpacing: 10,
          mainAxisSpacing: 10,
          children: List.generate(
            homeMenus.length,
            (index) {
              var cat = homeMenus[index];
              //return Padding(
              // padding: const EdgeInsets.only(right: 50, left: 0),
              //child: Container(
              return GestureDetector(
                onTap: () {
                  if (index == 0) {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const MobileInsurance()),
                    );
                  } else if (index == 1) {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) =>
                              const InternationalTravelInsurance()),
                    );
                  }else if (index == 2) {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => TourInsurance()),
                    );
                  } else if (index == 3) {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const TripInsurance()),
                    );
                  }
                  else if (index == 4) {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => StudentInsutance()));
                  }
                  else if (index == 5) {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => VehicleInsurance()),
                    );
                  }
                  else if (index == 6) {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const Recommened(
                                title: 'Health Insurance',
                              )),
                    );
                  } else if (index == 7) {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const Recommened(
                                title: 'Life Insurance',
                              )),
                    );
                  } else if (index == 8) {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const Recommened(
                                title: 'Agriculture Insurance',
                              )),
                    );
                  } else if (index == 10) {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const Recommened(
                                title: 'Home Insurance',
                              )),
                    );
                  }
                  else if (index == 10) {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const Recommened(
                            title: 'Upcomming Products',
                          )),
                    );
                  }
                },
                child: Container(
                  //width: (MediaQuery.of(context).size.width - 45) / 3,
                  alignment: Alignment.center,
                  // padding: const EdgeInsets.all(5),
                  // color: Colors.red,

                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      if (index != 10)
                        Image(
                          image: AssetImage(cat["img"]),
                          height: 35,
                        ),
                      const SizedBox(height: 2.0),
                      Text(
                        cat["name"],
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          fontFamily: 'Roboto Slab',
                          fontSize: 13,
                          color: Color(0xff000000),
                        ),
                      ),
                    ],
                  ),

                  decoration: BoxDecoration(
                      color: Color(0xffF0F3F6),
                      borderRadius: BorderRadius.circular(100),
                      boxShadow: [
                        BoxShadow(
                            color: Color(0xffffffff),
                            blurRadius: 6,
                            spreadRadius: 0,
                            offset: Offset(-3, -3)),
                        BoxShadow(
                            color: Color(0xffDDE4EF),
                            blurRadius: 6,
                            spreadRadius: 0,
                            offset: Offset(3, 3)),
                      ]),
                ),
              );

              // );
            },
          ),
        ),
        // decoration: const BoxDecoration(
        //   image: DecorationImage(
        //     image: AssetImage("assets/home/gridView_bg.png"),
        //     fit: BoxFit.cover,
        //   ),
        // ),
      ),
    );
  }
}


