// ignore_for_file: unnecessary_new

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:instasure/screens/dashboard/diagnosisReportDetail.dart';
import 'package:instasure/screens/deviceInsurance/sub_menu.dart';
import 'package:instasure/screens/diagonostic/checkDeviceFeature.dart';
import 'package:instasure/screens/mobileInsurance.dart';
import 'package:instasure/screens/recommened.dart';
import 'package:instasure/screens/studentsInsurance/student_insurance_history.dart';
import 'package:instasure/screens/tourInsurance/tour_history.dart';
import 'package:instasure/screens/travelInsurance/internationalTravelInsurance.dart';
import 'package:instasure/screens/travelInsurance/submenu.dart';
import 'package:instasure/Utilities/homeMenu.dart';
import 'package:instasure/screens/trip_Insurance/trip_history.dart';
import 'package:instasure/widgets/topView2.dart';
import 'package:instasure/widgets/topView4.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../travelInsurance/getTravelInsurance.dart';


class MyInsurance extends StatefulWidget {
  const MyInsurance({Key? key}) : super(key: key);

  @override
  _MyInsuranceState createState() => _MyInsuranceState();
}

class _MyInsuranceState extends State<MyInsurance> {
//class LoginPage extends StatelessWidget {
  SharedPreferences? preferences;
  @override
  void initState() {
    super.initState();

    initializePreference().whenComplete((){
      setState(() {
//        this.preferences?.setInt("counter", 7);
//        this.preferences?.setString("serial_number", "zxcxzv");
      });
    });


    //Navigator.of(context).popUntil((route) => route.isFirst);
  }
  Future<void> initializePreference() async{
    this.preferences = await SharedPreferences.getInstance();
    // this.preferences?.setString("name", "Peter");
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body:SingleChildScrollView(
        child: Center(
                child: Padding(
              padding: const EdgeInsets.only(right: 0, top: 40, bottom: 0, left: 0),
              child: Column(

                children: [
                  createHeaderWidget(),

                  const SizedBox(height: 60.0),
                 Container(
                   height: 500,
                   child:  buildGridView(),
                 )

                ],
              ),
            )),
      ),


      backgroundColor: const Color(0xFFEFF7FF),
    );
  }
  createHeaderWidget() {
    return Container(
      height: 38,
      child: const Center(
        child: Text(
          'Choose Your Insurance',
          textAlign: TextAlign.center,
          style: TextStyle(
            fontFamily: 'Roboto Slab',
            fontSize: 16,
            color: Color(0xff002E5B),
          ),
        ),
      ),
      decoration: const BoxDecoration(color: Color(0xffF0F3F6), boxShadow: [
        BoxShadow(
            color: Color(0xffffffff),
            blurRadius: 6,
            spreadRadius: 0,
            offset: Offset(-3, -3)),
        BoxShadow(
            color: Color(0xffDDE4EF),
            blurRadius: 6,
            spreadRadius: 0,
            offset: Offset(3, 3)),
      ]),
    );
  }

  buildGridView() {
    return Padding(
      padding: const EdgeInsets.only(right: 20, top: 0, bottom: 0, left: 20),
      child: SizedBox(
        height:MediaQuery.of(context).size.height,
        // color: Colors.red,

        //width: (MediaQuery.of(context).size.width - 30) / 3,
        child: GridView.count(
          physics: const NeverScrollableScrollPhysics(),
          crossAxisCount: 3,
          crossAxisSpacing: 20,
          mainAxisSpacing: 20,
          children: List.generate(
            homeMenus.length,
                (index) {
              var cat = homeMenus[index];
              //return Padding(
              // padding: const EdgeInsets.only(right: 50, left: 0),
              //child: Container(
              return GestureDetector(
                onTap: () {
                  if (index == 0) {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const DeviceSubMenu()),
                    );
                  } else if (index == 1) {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) =>
                          const InsuranceSubMenu()),
                    );
                  } else if (index == 2) {
                     Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const TourStatus()),
                    );
                  } else if (index == 3) {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => TripHistory()),
                    );
                  } else if (index == 4) {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => StudentInsuranceHistory()),
                    );
                  } else if (index == 5) {
                    // Navigator.push(
                    //   context,
                    //   MaterialPageRoute(
                    //       builder: (context) => const Recommened(
                    //         title: 'Car Insurance',
                    //       )),
                    // );
                  } else if (index == 6) {
                    // Navigator.push(
                    //   context,
                    //   MaterialPageRoute(
                    //       builder: (context) => const Recommened(
                    //         title: 'Bike Insurance',
                    //       )),
                    // );
                  } else if (index == 7) {
                    // Navigator.push(
                    //   context,
                    //   MaterialPageRoute(
                    //       builder: (context) => const Recommened(
                    //         title: 'Home Insurance',
                    //       )),
                    // );
                   } else if (index == 8) {
                  //   Navigator.push(
                  //     context,
                  //     MaterialPageRoute(
                  //         builder: (context) => const Recommened(
                  //           title: 'Upcomming Products',
                  //         )),
                  //   );
                  }
                },
                child: Container(
                  //width: (MediaQuery.of(context).size.width - 45) / 3,
                  alignment: Alignment.center,
                  // padding: const EdgeInsets.all(5),
                  // color: Colors.red,

                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      if (index != 10)
                        Image(
                          image: AssetImage(cat["img"]),
                          height: 35,
                        ),
                      const SizedBox(height: 2.0),
                      Text(
                        cat["name"],
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          fontFamily: 'Roboto Slab',
                          fontSize: 13,
                          color: Color(0xff000000),
                        ),
                      ),
                    ],
                  ),

                  decoration: BoxDecoration(
                      color: Color(0xffF0F3F6),
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [
                        BoxShadow(
                            color: Color(0xffffffff),
                            blurRadius: 6,
                            spreadRadius: 0,
                            ),
                        BoxShadow(
                            color: Color(0xffDDE4EF),
                            blurRadius: 6,
                            spreadRadius: 0,
                            offset: Offset(3, 3)),
                      ]),
                ),
              );

              // );
            },
          ),
        ),
        // decoration: const BoxDecoration(
        //   image: DecorationImage(
        //     image: AssetImage("assets/home/gridView_bg.png"),
        //     fit: BoxFit.cover,
        //   ),
        // ),
      ),
    );
  }

  void _diagnosisAlert(BuildContext context) {
    showDialog(
        context: context,
        builder: (context) {
          return CupertinoAlertDialog(
            title: const Text('Device Diagnosis'),
            content: const Text('Are you sure you want to device diagnosis? If yes, then please attach microphone with your device.'),
            actions: <Widget>[
              TextButton(
                  onPressed: () {
                    Navigator.pop(context);
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const CheckDeviceFeature()),
                    );
                  },
                  child: Text('Yes')),
              TextButton(
                onPressed: () {
                  Navigator.pop(context); //close Dialog
                },
                child: Text('No'),
              )
            ],
          );
        });
  }

}
