import 'package:flutter/material.dart';
import 'package:instasure/widgets/topView2.dart';
import 'package:instasure/widgets/topView4.dart';

class HotDeals extends StatefulWidget {
  const HotDeals({Key? key}) : super(key: key);

  @override
  _HotDealsState createState() => _HotDealsState();
}

class _HotDealsState extends State<HotDeals> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: null,
        backgroundColor: const Color(0xffF0F3F6),
        body: SingleChildScrollView(
            child: Column(
          children: <Widget>[
            Stack(
              children: [
                Stack(
                  children: [
                    const TopView4(),
                    Positioned(
                      bottom: 20.0,
                      left: 40.0,
                      child: SizedBox(
                          height: 30,
                          width: 30,
                          child: TextButton(
                            child: Image.asset('assets/back_button_icon.png'),
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                          )),
                    )
                  ],
                ),
              ],
            ),
            const SizedBox(
              height: 10,
            ),
            Container(
                height: 50,
                alignment: Alignment.center,
                child: const Text(
                  'Hot Deals',
                  style: TextStyle(
                      fontSize: 16, color: Color.fromRGBO(0, 0, 0, 0.87)),
                ),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(0),
                  boxShadow: const [
                    BoxShadow(
                        color: Color(0xFFFFFFFF),
                        blurRadius: 6,
                        spreadRadius: 0,
                        offset: Offset(-3, -3)),
                    BoxShadow(
                        color: Color(0xFFDDE4EF),
                        blurRadius: 6,
                        spreadRadius: 0,
                        offset: Offset(3, 3)),
                  ],
                  color: const Color(0xffF0F3F6),
                )),
            Container(
                padding: const EdgeInsets.only(
                    left: 30.0, top: 80, right: 30, bottom: 5),
                alignment: Alignment.center,
                child: Image.asset(
                  "assets/hot_deals.png",
                  fit: BoxFit.cover,
                )),
            Container(
                alignment: Alignment.center,
                padding: const EdgeInsets.all(5),
                child: const Text(
                  'NO HOT DEALS',
                  style: TextStyle(fontSize: 17),
                ))
          ],
        )));
  }
}
