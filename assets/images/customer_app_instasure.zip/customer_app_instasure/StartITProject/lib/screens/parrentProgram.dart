// ignore_for_file: unnecessary_new

import 'package:flutter/material.dart';
import 'package:instasure/widgets/imageWidget.dart';
import 'package:instasure/widgets/topView4.dart';

class ParrentProgram extends StatefulWidget {
  const ParrentProgram({Key? key}) : super(key: key);

  @override
  _ParrentProgramState createState() => _ParrentProgramState();
}

class _ParrentProgramState extends State<ParrentProgram> {
  TextEditingController nameController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController phoneController = TextEditingController();
  TextEditingController bussinameNameController = TextEditingController();
  TextEditingController yourMessageController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
          child: Padding(
        padding: const EdgeInsets.all(0),
        child: Column(
          children: [
            Stack(
              children: [
                const TopView4(),
                Positioned(
                  bottom: 20.0,
                  left: 40.0,
                  child: SizedBox(
                      height: 30,
                      width: 30,
                      // color: const Color.fromRGBO(0, 46, 91, 1.0),
                      // padding: const EdgeInsets.fromLTRB(10, 15, 10, 5),
                      child: TextButton(
                        child: Image.asset('assets/back_button_icon.png'),
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                      )),
                )
              ],
            ),
            Expanded(
              child: ListView(
                children: <Widget>[
                  const SizedBox(height: 0.0),
                  createHeaderWidget(),
                  const SizedBox(height: 20.0),
                  createDistributionWidget(),
                  const SizedBox(height: 20.0),
                  createAffiliatenWidget(),
                  const SizedBox(height: 20.0),
                  const Center(
                   /*   child: Text(
                    'So what are you waiting for?',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontFamily: 'Roboto Slab',
                      fontSize: 16,
                      color: Color(0xff002E5B),
                    ),
                  )*/

                  ),
                  const SizedBox(height: 20.0),
                 // createTextFields(),
                  const SizedBox(height: 20.0),
                ],
              ),
            ),
          ],
        ),
      )),
      backgroundColor: const Color(0xFFEFF7FF),
    );
  }

  createHeaderWidget() {
    return Container(
      height: 38,
      child: const Center(
        child: Text(
          'Parent Program',
          textAlign: TextAlign.center,
          style: TextStyle(
            fontFamily: 'Roboto Slab',
            fontSize: 16,
            color: Color(0xff002E5B),
          ),
        ),
      ),
      decoration: const BoxDecoration(color: Color(0xffF0F3F6), boxShadow: [
        BoxShadow(
            color: Color(0xffffffff),
            blurRadius: 6,
            spreadRadius: 0,
            offset: Offset(-3, -3)),
        BoxShadow(
            color: Color(0xffDDE4EF),
            blurRadius: 6,
            spreadRadius: 0,
            offset: Offset(3, 3)),
      ]),
    );
  }

  createDistributionWidget() {
    return Padding(
        padding: const EdgeInsets.only(left: 20, right: 20),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ImageWidget(
              imagePath: 'assets/parent_program.png',
              onClicked: () async {},
              imageHeight: 152,
              imageWidth: 152,
              borderWidth: 15,
              borderRadious: 40,
            ),
            const SizedBox(
              width: 10,
            ),
            Expanded(
                child: RichText(
              text: const TextSpan(
                style: TextStyle(color: Colors.black, fontSize: 16),
                children: <TextSpan>[
                  TextSpan(
                      text: 'Ready for a new take on insurance distribution?\n',
                      style: TextStyle(
                          color: Colors.black, fontWeight: FontWeight.bold)),
                  TextSpan(
                      text:
                          'Are you an insurance provider that wants to get your products in the hands of more customers,in the fast-growing digital world? Are you a company that would like to offer insurance products to your customers, but don’t know how to start? Are you a customer seeking multiple insurance solutions to suit your lifestyle needs, without having to apply to them all individually? Meet Instasure. Institute is a technology platform that streamlines insurance distribution and enables businesses to offer a range of insurance products through a single channel. Want early access to Instasure? Please Contact Us.',
                      style: TextStyle(color: Colors.black, fontSize: 12)),
                ],
              ),
            ))
          ],
        ));
  }

  createAffiliatenWidget() {
    return Padding(
        padding: const EdgeInsets.only(left: 20, right: 20),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
                child: RichText(
              text: const TextSpan(
                style: TextStyle(color: Colors.black, fontSize: 16),
                children: <TextSpan>[
                  TextSpan(
                      text: 'Affiliate and Partner Program:\n',
                      style: TextStyle(
                          color: Colors.black, fontWeight: FontWeight.bold)),
                  TextSpan(
                      text:
                          'Do we partner with awesome businesses in our community? You bet we do. Whether you re in the mobile phone business, mobile phone repair shop, connecting with a customer base or providing a benefit to your employees, we are here to make that happen. Our process is as easy as breaking your phone and we have multiple ways to work with your customers and/or employees.',
                      style: TextStyle(color: Colors.black, fontSize: 12)),
                ],
              ),
            )),
            const SizedBox(
              width: 10,
            ),
            ImageWidget(
              imagePath: 'assets/affiliate_icon.png',
              onClicked: () async {},
              imageHeight: 152,
              imageWidth: 152,
              borderWidth: 15,
              borderRadious: 40,
            ),
          ],
        ));
  }

  createTextFields() {
    return Padding(
      padding: const EdgeInsets.only(left: 35, right: 35),
      child: Column(
        children: [
          Container(
            height: 40,
            alignment: Alignment.centerLeft,
            padding: const EdgeInsets.all(10),
            child: const Text(
              'Name',
              style: TextStyle(fontSize: 17, color: Colors.black),
            ),
          ),
          Container(
            height: 40,
            padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
            child: TextField(
              controller: nameController,
              decoration: InputDecoration(
                fillColor: const Color(0xFFF0F3F6),
                filled: true,
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(20.0),
                  borderSide:
                      const BorderSide(color: Colors.transparent, width: 0.0),
                ),
              ),
            ),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              boxShadow: const [
                BoxShadow(
                    color: Color(0xFFFFFFFF),
                    blurRadius: 6,
                    spreadRadius: 0,
                    offset: Offset(-3, -3)),
                BoxShadow(
                    color: Color(0xFFDDE4EF),
                    blurRadius: 6,
                    spreadRadius: 0,
                    offset: Offset(3, 3)),
              ],
              color: const Color(0xffF0F3F6),
            ),
          ),
          Container(
            height: 40,
            alignment: Alignment.centerLeft,
            padding: const EdgeInsets.all(10),
            child: const Text(
              'Phone',
              style: TextStyle(fontSize: 17, color: Colors.black),
            ),
          ),
          Container(
            height: 40,
            padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
            child: TextField(
              controller: phoneController,
              decoration: InputDecoration(
                fillColor: const Color(0xFFF0F3F6),
                filled: true,
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(20.0),
                  borderSide:
                      const BorderSide(color: Colors.transparent, width: 0.0),
                ),
              ),
            ),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              boxShadow: const [
                BoxShadow(
                    color: Color(0xFFFFFFFF),
                    blurRadius: 6,
                    spreadRadius: 0,
                    offset: Offset(-3, -3)),
                BoxShadow(
                    color: Color(0xFFDDE4EF),
                    blurRadius: 6,
                    spreadRadius: 0,
                    offset: Offset(3, 3)),
              ],
              color: const Color(0xffF0F3F6),
            ),
          ),
          Container(
            height: 40,
            alignment: Alignment.centerLeft,
            padding: const EdgeInsets.all(10),
            child: const Text(
              'Email',
              style: TextStyle(fontSize: 17, color: Colors.black),
            ),
          ),
          Container(
            height: 40,
            padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
            child: TextField(
              controller: emailController,
              decoration: InputDecoration(
                fillColor: const Color(0xFFF0F3F6),
                filled: true,
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(20.0),
                  borderSide:
                      const BorderSide(color: Colors.transparent, width: 0.0),
                ),
              ),
            ),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              boxShadow: const [
                BoxShadow(
                    color: Color(0xFFFFFFFF),
                    blurRadius: 6,
                    spreadRadius: 0,
                    offset: Offset(-3, -3)),
                BoxShadow(
                    color: Color(0xFFDDE4EF),
                    blurRadius: 6,
                    spreadRadius: 0,
                    offset: Offset(3, 3)),
              ],
              color: const Color(0xffF0F3F6),
            ),
          ),
          Container(
            height: 40,
            alignment: Alignment.centerLeft,
            padding: const EdgeInsets.all(10),
            child: const Text(
              'Business Name',
              style: TextStyle(fontSize: 17, color: Colors.black),
            ),
          ),
          Container(
            height: 40,
            padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
            child: TextField(
              controller: bussinameNameController,
              decoration: InputDecoration(
                fillColor: const Color(0xFFF0F3F6),
                filled: true,
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(20.0),
                  borderSide:
                      const BorderSide(color: Colors.transparent, width: 0.0),
                ),
              ),
            ),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              boxShadow: const [
                BoxShadow(
                    color: Color(0xFFFFFFFF),
                    blurRadius: 6,
                    spreadRadius: 0,
                    offset: Offset(-3, -3)),
                BoxShadow(
                    color: Color(0xFFDDE4EF),
                    blurRadius: 6,
                    spreadRadius: 0,
                    offset: Offset(3, 3)),
              ],
              color: const Color(0xffF0F3F6),
            ),
          ),
          Container(
            height: 40,
            alignment: Alignment.centerLeft,
            padding: const EdgeInsets.all(10),
            child: const Text(
              'Your Message',
              style: TextStyle(fontSize: 17, color: Colors.black),
            ),
          ),
          Container(
            height: 98,
            padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
            child: TextField(
              controller: yourMessageController,
              keyboardType: TextInputType.multiline,
              maxLines: null,
              decoration: InputDecoration(
                fillColor: const Color(0xFFF0F3F6),
                filled: true,
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(50.0),
                  borderSide:
                      const BorderSide(color: Colors.transparent, width: 0.0),
                ),
              ),
            ),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(50),
              boxShadow: const [
                BoxShadow(
                    color: Color(0xFFFFFFFF),
                    blurRadius: 6,
                    spreadRadius: 0,
                    offset: Offset(-3, -3)),
                BoxShadow(
                    color: Color(0xFFDDE4EF),
                    blurRadius: 6,
                    spreadRadius: 0,
                    offset: Offset(3, 3)),
              ],
              color: const Color(0xffF0F3F6),
            ),
          ),
          const SizedBox(
            height: 20,
          ),
          Container(
            height: 30,
            width: MediaQuery.of(context).size.width - 70,
            child: TextButton(
              child: const Text(
                'Submit',
                style: TextStyle(color: Colors.white),
              ),
              onPressed: () {},
            ),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(15),
              boxShadow: [
                BoxShadow(
                    color: const Color(0xff000000).withOpacity(0.15),
                    blurRadius: 3,
                    spreadRadius: 0,
                    offset: const Offset(0, 3)),
              ],
              color: const Color(0xff002E5B),
            ),
          ),
        ],
      ),
    );
  }
}
