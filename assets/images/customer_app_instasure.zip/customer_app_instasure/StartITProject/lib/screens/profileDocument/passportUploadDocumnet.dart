import 'dart:io';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:instasure/screens/dashboard/profileScreen.dart';
import '../../Utilities/constant.dart';
import '../../Utilities/userPref.dart';
import '../../domains/repo/apis.dart';
import '../../widgets/topView.dart';
import 'package:image_picker/image_picker.dart';
import 'package:http/http.dart' as http;
import 'package:fluttertoast/fluttertoast.dart';

class PassportUploadDocumnet extends StatefulWidget {
  const PassportUploadDocumnet(
      {Key? key,
      required this.passportfrontImageUri,})
      : super(key: key);

  final passportfrontImageUri;


  @override
  _PassportUploadDocumnetState createState() => _PassportUploadDocumnetState();
}

class _PassportUploadDocumnetState extends State<PassportUploadDocumnet> {
  late var frontImageUri = null;
  bool isFrom_front = false;


  Future<void> updatePassport() async {
    EasyLoading.instance.userInteractions = false;
    //showMessage('Passport did not updated');
    UserPref prefs = UserPref();
    Future<String?> token = prefs.getTokenFromPref();
    String? accessToken = await token;
    var headers = {
      'Accept': 'application/json',
      'Authorization': 'Bearer $accessToken'
    };
    String uri = Constants.BASE_URL + ApisEndPoints.customerProfileUpdate;
    var request = http.MultipartRequest('POST', Uri.parse(uri));
    request.files
        .add(await http.MultipartFile.fromPath('passport[0]', frontImageUri));
    //request.files.add(await http.MultipartFile.fromPath('passport[1]', backImageUri));
    request.headers.addAll(headers);
    http.StreamedResponse response = await request.send();
    //ScaffoldMessenger.of(context).hideCurrentSnackBar();
    EasyLoading.dismiss();
    if (response.statusCode == 200) {
      showMessage('Passport successfully updated');
      Navigator.pop(context,
          MaterialPageRoute(builder: (context) => const ProfileScreen()));
    } else {
      print(response.reasonPhrase);
    }
  }

  Future<void> _showChoiceDialog(BuildContext context, bool isFront) {
    return showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: const Text(
              "Choose option",
              style: TextStyle(color: Colors.blue),
            ),
            content: SingleChildScrollView(
              child: ListBody(
                children: [
                  const Divider(
                    height: 1,
                    color: Colors.blue,
                  ),
                  ListTile(
                    onTap: () {
                      openGallery(isFront);
                      Navigator.of(context).pop();
                    },
                    title: const Text("Gallery"),
                    leading: const Icon(
                      Icons.account_box,
                      color: Colors.blue,
                    ),
                  ),
                  const Divider(
                    height: 1,
                    color: Colors.blue,
                  ),
                  ListTile(
                    onTap: () {
                      openCamrea(isFront);
                      Navigator.of(context).pop();
                    },
                    title: const Text("Camera"),
                    leading: const Icon(
                      Icons.camera,
                      color: Colors.blue,
                    ),
                  ),
                ],
              ),
            ),
          );
        });
  }

  @override


  void initState(){
    super.initState();
    updatePassport();

  }

  Widget build(BuildContext context) {
    return Scaffold(
        appBar: null,
        body: SingleChildScrollView(
            child: Column(
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.only(left: 20, right: 20, top: 30),
              child: Stack(
                children: [
                  Stack(
                    children: [
                      const TopView(),
                      Positioned(
                        top: 6.0,
                        left: 0.0,
                        child: SizedBox(
                            height: 30,
                            width: 30,
                            // color: const Color.fromRGBO(0, 46, 91, 1.0),
                            child: TextButton(
                              child: Image.asset('assets/back_button_icon.png'),
                              onPressed: () {
                                Navigator.of(context).pop();
                              },
                            )),
                      )
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(
              height: 10,
            ),
            const SizedBox(
              height: 10,
            ),
            Padding(
              padding: const EdgeInsets.only(left: 20.0, right: 20),
              child: Container(
                  height: 40,
                  child: Padding(
                    padding: const EdgeInsets.all(0.0),
                    child: GestureDetector(
                        onTap: () {},
                        child: Row(
                          textDirection: TextDirection.ltr,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            const SizedBox(
                              width: 10,
                            ),
                            Image.asset('assets/profile/passport_icon.png'),
                            const SizedBox(
                              width: 10,
                            ),
                            const Align(
                              alignment: Alignment.centerLeft,
                              child: Text(
                                'Passport',
                                textAlign: TextAlign.left,
                                style: TextStyle(
                                    fontFamily: 'Roboto Slab',
                                    fontSize: 14.0,
                                    color: Color(0xFF002E5B)),
                              ),
                            ),
                            const Spacer(),
                            Image.asset('assets/profile/visiblity_icon.png'),
                          ],
                        )),
                  ),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(16),
                    boxShadow: const [
                      BoxShadow(
                          color: Color(0xFFFFFFFF),
                          blurRadius: 6,
                          spreadRadius: 0,
                          offset: Offset(-3, -3)),
                      BoxShadow(
                          color: Color(0xFFDDE4EF),
                          blurRadius: 6,
                          spreadRadius: 0,
                          offset: Offset(3, 3)),
                    ],
                    color: const Color(0xffF0F3F6),
                  )),
            ),
            const SizedBox(
              height: 30,
            ),
            GestureDetector(
              onTap: () => _showChoiceDialog(context, true),
              child: Container(
                  height: 150,
                  width: 250,
                  child: Padding(
                      padding: const EdgeInsets.all(5),
                      child: isFrom_front
                          ? Image.file(File(frontImageUri))
                          : widget.passportfrontImageUri != null
                              /*? Image.network(widget.passportfrontImageUri)*/
                              ? Image.network(
                                  widget.passportfrontImageUri[0],
                                  fit: BoxFit.fill,
                                  loadingBuilder: (BuildContext context,
                                      Widget child,
                                      ImageChunkEvent? loadingProgress) {
                                    if (loadingProgress == null) return child;
                                    return Center(
                                      child: CircularProgressIndicator(
                                        value: loadingProgress
                                                    .expectedTotalBytes !=
                                                null
                                            ? loadingProgress
                                                    .cumulativeBytesLoaded /
                                                loadingProgress
                                                    .expectedTotalBytes!
                                            : null,
                                      ),
                                    );
                                  },
                                )
                              : Image.asset('assets/profile/nid_icon.png')),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(75),
                    boxShadow: const [
                      BoxShadow(
                          color: Color(0xFFFFFFFF),
                          blurRadius: 6,
                          spreadRadius: 0,
                          offset: Offset(-3, -3)),
                    ],
                    color: const Color(0xffF0F3F6),
                  )),
            ),
            const SizedBox(
              height: 10,
            ),
            Container(
              alignment: Alignment.center,
              child: const Text(
                'Passport front',
                style: TextStyle(
                    fontSize: 16, color: Color.fromRGBO(0, 0, 0, 0.87)),
              ),
            ),

            const SizedBox(
              height: 20,
            ),
            Container(
              height: 30,
              width: MediaQuery.of(context).size.width - 70,
              //padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
              child: TextButton(
                child: const Text(
                  'Update Profile',
                  style: TextStyle(color: Colors.white),
                ),
                onPressed: () {
                  updatePassport();
                },
              ),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                      color: const Color(0xff000000).withOpacity(0.16),
                      blurRadius: 3,
                      spreadRadius: 0,
                      offset: const Offset(0, 3)),
                ],
                color: const Color(0xff002E5B),
              ),
            ),
          ],
        )));
  }

  Future<void> openCamrea(bool isFront) async {
    final ImagePicker _picker = ImagePicker();
    final XFile? image = await _picker.pickImage(source: ImageSource.camera);
    setState(() {

        isFrom_front = true;
        frontImageUri = image!.path.toString();

    });
  }

  Future<void> openGallery(bool isFront) async {
    final ImagePicker _picker = ImagePicker();
    final XFile? image = await _picker.pickImage(source: ImageSource.gallery);
    setState(() {

        isFrom_front = true;
        frontImageUri = image!.path;

    });
  }

  showMessage(String message) {
    Fluttertoast.showToast(
        msg: message,
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.CENTER,
        timeInSecForIosWeb: 1,
        backgroundColor: Colors.blue,
        textColor: Colors.white,
        fontSize: 16.0);
  }
}
