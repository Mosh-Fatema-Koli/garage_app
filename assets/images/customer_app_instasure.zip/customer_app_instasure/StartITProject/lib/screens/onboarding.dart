import 'package:flutter/material.dart';
import 'package:instasure/screens/auth/loginPage.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import '../widgets/topView.dart';

class Onboarding extends StatelessWidget {
  Onboarding({Key? key}) : super(key: key);
  final PageController controller = PageController();

  void dispose() {
    controller.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        padding: const EdgeInsets.only(bottom: 0, top: 0),
        child: PageView(
          scrollDirection: Axis.horizontal,
          controller: controller,
          children: [
            Container(
              color: Colors.white,
              child:SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(10.0, 0, 10.0, 0),

                child: Column(
                  children: [
                    const SizedBox(
                      height: 60,
                    ),
                    Stack(
                        clipBehavior: Clip.none,
                        alignment: Alignment.bottomCenter,
                        children: [
                          // Image.asset('assets/restaurant1.jpeg'),
                        Container(
                        alignment: Alignment.center,
                        //  padding: const EdgeInsets.only(bottom: 84),
                        child: const SizedBox(
                          height: 120,
                        ),
                      //
                    ),

                          // const Image(
                          //   height: 100.0,
                          //   width: 200,
                          //   fit: BoxFit.cover,
                          //   image: NetworkImage(
                          //       'https://images.unsplash.com/photo-1485160497022-3e09382fb310?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTN8fG1vdW50YWluc3xlbnwwfHwwfHw%3D&w=1000&q=80'),
                          // ),
                          Positioned(
                              top: 6.0,
                              right: 10.0,
                              child: Stack(
                                  clipBehavior: Clip.none,
                                  alignment: Alignment.bottomCenter,
                                  children: [
                                    Card(
                                      shape: RoundedRectangleBorder(
                                          borderRadius:
                                          BorderRadius.circular(12.0)),
                                      child: Padding(
                                        padding: const EdgeInsets.only(
                                            left: 10,
                                            right: 10,
                                            top: 5,
                                            bottom: 5),
                                        child: Row(
                                          children: const <Widget>[
                                            Text(
                                              "SKIP >>",
                                              style: TextStyle(
                                                fontSize: 16.0,
                                              ),
                                            ),
                                            // Icon(
                                            //   Icons.skip_next,
                                            //   color: Colors.red,
                                            //   size: 15.0,
                                            // ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    SizedBox(
                                      height: 30,
                                      width: 60,
                                      child: TextButton(
                                        // style: ButtonStyle(
                                        //   backgroundColor:
                                        //       MaterialStateProperty.all(Colors.green),
                                        // ),
                                        child: const Center(
                                          child: Text(
                                            "",
                                            style: TextStyle(
                                              color: Colors.red,
                                            ),
                                          ),
                                        ),
                                        onPressed: () {
                                          Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                                builder: (context) =>
                                                    LoginPage()),
                                          );
                                        },
                                      ),
                                    ),
                                  ])),
                        ]),
                    const SizedBox(
                      height: 120,
                    ),
                    Image.asset(
                      "assets/instasure_icon.png",
                      height: 120,

                      fit: BoxFit.cover,
                    ),
                    Image.asset(
                      "assets/touching.png",
                      height: 67,
                      width: MediaQuery.of(context).size.width - 250,
                      fit: BoxFit.fitWidth,
                    ),

                    const SizedBox(
                      height: 10,
                    ),
                    /*const Text(
                      'INSTASURE',
                      style: TextStyle(
                          color: Colors.grey,
                          fontFamily: 'Roboto Slab',
                          fontSize: 30),
                    ),*/
                    const SizedBox(
                      height: 20,
                    ),
                    const Padding(
                      padding: EdgeInsets.fromLTRB(40.0, 0, 40.0, 0),
                      child: Text(
                        '',
                        style: TextStyle(
                            color: Colors.grey,
                            fontFamily: 'Roboto Slab',
                            fontSize: 18),
                      ),
                    ),
                  ],
                ),

                /*
                child: Column(
                  children: [
                    const SizedBox(
                      height: 60,
                    ),
                    Stack(
                        clipBehavior: Clip.none,
                        alignment: Alignment.bottomCenter,
                        children: [
                         Container(
                        alignment: Alignment.center,
                        //  padding: const EdgeInsets.only(bottom: 84),
                       /* child: Image.asset(
                          "assets/instasure_icon.png",
                          height: 127,
                          width: MediaQuery.of(context).size.width - 80,
                          fit: BoxFit.fitWidth,
                        )*/
                      //
                    ),
                          Positioned(
                              top: 6.0,
                              right: 10.0,

                              child: Stack(
                                  clipBehavior: Clip.none,
                                  alignment: Alignment.bottomCenter,
                                  children: [
                                    Card(
                                      shape: RoundedRectangleBorder(
                                          borderRadius:
                                          BorderRadius.circular(12.0)),
                                      child: Padding(
                                        padding: const EdgeInsets.only(
                                            left: 10,
                                            right: 10,
                                            top: 5,
                                            bottom: 5),
                                        child: Row(
                                          children: const <Widget>[
                                            Text(
                                              "SKIP >>",
                                              style: TextStyle(
                                                fontSize: 16.0,
                                              ),
                                            ),
                                            // Icon(
                                            //   Icons.skip_next,
                                            //   color: Colors.red,
                                            //   size: 15.0,
                                            // ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    SizedBox(
                                      height: 30,
                                      width: 60,
                                      child: TextButton(
                                        // style: ButtonStyle(
                                        //   backgroundColor:
                                        //       MaterialStateProperty.all(Colors.green),
                                        // ),
                                        child: const Center(
                                          child: Text(
                                            "",
                                            style: TextStyle(
                                              color: Colors.red,
                                            ),
                                          ),
                                        ),
                                        onPressed: () {
                                          Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                                builder: (context) =>
                                                    LoginPage()),
                                          );
                                        },
                                      ),
                                    ),
                                  ])


                              /*child: Stack(
                                  clipBehavior: Clip.none,
                                  alignment: Alignment.bottomCenter,
                                  children: [
                                    Card(
                                      shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(12.0)),
                                      child: Padding(
                                        padding: const EdgeInsets.only(
                                            left: 10,
                                            right: 10,
                                            top: 5,
                                            bottom: 5),
                                        child: Row(
                                          children: const <Widget>[
                                            Text(
                                              "SKIP >>",
                                              style: TextStyle(
                                                fontSize: 16.0,
                                              ),
                                            ),
                                            // Icon(
                                            //   Icons.skip_next,
                                            //   color: Colors.red,
                                            //   size: 15.0,
                                            // ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    SizedBox(
                                      height: 30,
                                      width: 60,
                                      child: TextButton(
                                        // style: ButtonStyle(
                                        //   backgroundColor:
                                        //       MaterialStateProperty.all(Colors.green),
                                        // ),
                                        child: const Center(
                                          child: Text(
                                            "",
                                            style: TextStyle(
                                              color: Colors.red,
                                            ),
                                          ),
                                        ),
                                        onPressed: () {
                                          Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                                builder: (context) =>
                                                    LoginPage()),
                                          );
                                        },
                                      ),
                                    ),
                                  ])*/

                          ),
                        ]),
                    /*

                    const SizedBox(
                      height: 60,
                    ),
                    Image.asset(
                      "assets/onboarding.png",
                      height: 240,
                      width: 240,
                      fit: BoxFit.cover,
                    ),
                    const SizedBox(
                      height: 50,
                    ),
                    */

                     Center(
                      child: Column(
                          children: [

                            const SizedBox(
                              height: 240,
                            ),

                            Image.asset(
                              "assets/instasure_icon.png",
                              height: 127,
                              width: MediaQuery.of(context).size.width - 80,
                              fit: BoxFit.fitWidth,
                            ),
                            Image.asset(
                              "assets/touching.png",
                              height: 67,
                              width: MediaQuery.of(context).size.width - 250,
                              fit: BoxFit.fitWidth,
                            ),
                          /*  Text(
                              "Touching Lives",
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                fontSize: 18.0,
                              ),
                            ),*/
                          ]
                      ),
                    ),


                    /*const Text(
                      'INSTASURE',
                      style: TextStyle(
                          color: Colors.grey,
                          fontFamily: 'Roboto Slab',
                          fontSize: 30),
                    ),*/
                   /*
                    const SizedBox(
                      height: 20,
                    ),
                    const Padding(
                      padding: EdgeInsets.fromLTRB(40.0, 0, 40.0, 0),
                      child: Text(
                        'Let\'s Re Think Insurance, Together.',
                        style: TextStyle(
                            color: Colors.grey,
                            fontFamily: 'Roboto Slab',
                            fontSize: 18),
                      ),
                    ),
                    */
                  ],
                ),
                */

              ),
            )
            ),
            Container(
              color: Colors.white,
              child:SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(10.0, 0, 10.0, 0),
                child: Column(
                  children: [
                    const SizedBox(
                      height: 60,
                    ),
                    Stack(
                        clipBehavior: Clip.none,
                        alignment: Alignment.bottomCenter,
                        children: [
                          // Image.asset('assets/restaurant1.jpeg'),
                          const TopView(),

                          // const Image(
                          //   height: 100.0,
                          //   width: 200,
                          //   fit: BoxFit.cover,
                          //   image: NetworkImage(
                          //       'https://images.unsplash.com/photo-1485160497022-3e09382fb310?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTN8fG1vdW50YWluc3xlbnwwfHwwfHw%3D&w=1000&q=80'),
                          // ),
                          Positioned(
                              top: 6.0,
                              right: 10.0,
                              child: Stack(
                                  clipBehavior: Clip.none,
                                  alignment: Alignment.bottomCenter,
                                  children: [
                                    Card(
                                      shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(12.0)),
                                      child: Padding(
                                        padding: const EdgeInsets.only(
                                            left: 10,
                                            right: 10,
                                            top: 5,
                                            bottom: 5),
                                        child: Row(
                                          children: const <Widget>[
                                            Text(
                                              "SKIP >>",
                                              style: TextStyle(
                                                fontSize: 16.0,
                                              ),
                                            ),
                                            // Icon(
                                            //   Icons.skip_next,
                                            //   color: Colors.red,
                                            //   size: 15.0,
                                            // ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    SizedBox(
                                      height: 30,
                                      width: 60,
                                      child: TextButton(
                                        // style: ButtonStyle(
                                        //   backgroundColor:
                                        //       MaterialStateProperty.all(Colors.green),
                                        // ),
                                        child: const Center(
                                          child: Text(
                                            "",
                                            style: TextStyle(
                                              color: Colors.red,
                                            ),
                                          ),
                                        ),
                                        onPressed: () {
                                          Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                                builder: (context) =>
                                                    LoginPage()),
                                          );
                                        },
                                      ),
                                    ),
                                  ])),
                        ]),
                    const SizedBox(
                      height: 120,
                    ),
                    Image.asset(
                      "assets/mob1.png",
                      height: 180,

                      fit: BoxFit.cover,
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    /*const Text(
                      'INSTASURE',
                      style: TextStyle(
                          color: Colors.grey,
                          fontFamily: 'Roboto Slab',
                          fontSize: 30),
                    ),*/
                    const SizedBox(
                      height: 20,
                    ),
                    const Padding(
                      padding: EdgeInsets.fromLTRB(40.0, 0, 40.0, 0),
                      child: Text(
                        'A phone call may solve your problem. But if your phone itself is the cause of the problem, then what is the solution?',
                        style: TextStyle(
                            color: Colors.grey,
                            fontFamily: 'Roboto Slab',
                            fontSize: 18),
                      ),
                    ),
                  ],
                ),
              ),
              )
            ),
            Container(
              color: Colors.white,
              child:SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(10.0, 0, 10.0, 0),
                child: Column(
                  children: [
                    const SizedBox(
                      height: 60,
                    ),
                    Stack(
                        clipBehavior: Clip.none,
                        alignment: Alignment.bottomCenter,
                        children: [
                          const TopView(),
                          Positioned(
                              top: 6.0,
                              right: 10.0,
                              child: Stack(
                                  clipBehavior: Clip.none,
                                  alignment: Alignment.bottomCenter,
                                  children: [
                                    Card(
                                      shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(12.0)),
                                      child: Padding(
                                        padding: const EdgeInsets.only(
                                            left: 10,
                                            right: 10,
                                            top: 5,
                                            bottom: 5),
                                        child: Row(
                                          children: const <Widget>[
                                            Text(
                                              "SKIP >>",
                                              style: TextStyle(
                                                fontSize: 16.0,
                                              ),
                                            ),
                                            // Icon(
                                            //   Icons.skip_next,
                                            //   color: Colors.red,
                                            //   size: 15.0,
                                            // ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    SizedBox(
                                      height: 30,
                                      width: 60,
                                      child: TextButton(
                                        // style: ButtonStyle(
                                        //   backgroundColor:
                                        //       MaterialStateProperty.all(Colors.green),
                                        // ),
                                        child: const Center(
                                          child: Text(
                                            "",
                                            style: TextStyle(
                                              color: Colors.red,
                                            ),
                                          ),
                                        ),
                                        onPressed: () {
                                          Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                                builder: (context) =>
                                                    const LoginPage()),
                                          );
                                        },
                                      ),
                                    ),
                                  ])),
                        ]),
                    const SizedBox(
                      height: 120,
                    ),
                    Image.asset(
                      "assets/tra.jpg",
                      height: 150,

                      fit: BoxFit.cover,
                    ),
                    const SizedBox(
                      height: 30,
                    ),
                   /* const Text(
                      'INSTASURE',
                      style: TextStyle(
                          color: Colors.grey,
                          fontFamily: 'Roboto Slab',
                          fontSize: 30),
                    ),*/
                    const SizedBox(
                      height: 5,
                    ),
                    const Padding(
                      padding: EdgeInsets.fromLTRB(40.0, 0, 40.0, 0),
                      child: Align(
                        child: Text(
                          'International travel insurance is so easy, you can get it while waiting in the airport lounge and the best part? With covid medical cover alien items center, 3 slider image position and content position should be same, required perfect alignment.',
                          style: TextStyle(
                              color: Colors.grey,
                              fontFamily: 'Roboto Slab',
                              fontSize: 18),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              )
            ),
          ],
        ),
      ),
      bottomSheet: Container(
        color: Colors.transparent,
        // padding: EdgeInsets.symmetric(horizontal: ),
        height: 80,
        child: Center(
          child: SmoothPageIndicator(
              controller: controller, // PageController
              count: 3,
              effect: const WormEffect(), // your preferred effect
              onDotClicked: (index) {}),
        ),
      ),
    );
  }
}
