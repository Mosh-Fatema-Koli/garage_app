import 'package:flutter/material.dart';

class PaymentSuccessFull extends StatefulWidget {
  const PaymentSuccessFull({Key? key}) : super(key: key);

  @override
  _PaymentSuccessFullState createState() => _PaymentSuccessFullState();
}

class _PaymentSuccessFullState extends State<PaymentSuccessFull> {
  final PreferredSizeWidget appBar = AppBar(
    leading: const Icon(Icons.arrow_back_outlined),
    elevation: 0,
    backgroundColor: const Color(0xFFEFF7FF),
    foregroundColor: Colors.black,
    centerTitle: true,
    title: Image.asset(
      'assets/logo-instasure_small.png',
      fit: BoxFit.fitWidth,
    ),
  );

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: appBar,
      body: SingleChildScrollView(
        child: Column(
          children: <Widget>[
            Stack(
              children: <Widget>[
                Align(
                  alignment: Alignment.center,
                  child: Container(
                    margin: const EdgeInsets.only(top: 50),
                    width: 130,
                    height: 130,
                    child: Image.asset('assets/payment.png'),
                  ),
                ),
                Positioned(
                  right: 35,
                  child: IconButton(
                    onPressed: () {},
                    icon: const Icon(
                      Icons.highlight_off,
                      color: Colors.red,
                    ),
                  ),
                )
              ],
            ),
            Container(
              margin: const EdgeInsets.only(top: 10),
              width: 300,
              child: const Text(
                'Your Payment has been Successfully Completed',
                style: TextStyle(
                  fontSize: 16,
                  color: Color(0xFF597794),
                  fontWeight: FontWeight.bold,
                ),
                textAlign: TextAlign.center,
              ),
            ),
            Container(
              margin: const EdgeInsets.only(top: 5),
              width: 300,
              child: const Text(
                'Need any help!',
                style: TextStyle(
                  fontSize: 16,
                  color: Color(0xFF597794),
                  fontWeight: FontWeight.bold,
                ),
                textAlign: TextAlign.center,
              ),
            ),
            const SizedBox(
              width: 300,
              child: Text(
                'Contact us',
                style: TextStyle(
                  fontSize: 16,
                  color: Color(0xFF597794),
                  fontWeight: FontWeight.bold,
                ),
                textAlign: TextAlign.center,
              ),
            ),
            Container(
              margin: const EdgeInsets.only(top: 5),
              width: MediaQuery.of(context).size.width / 2,
              child: ElevatedButton(
                style: ButtonStyle(
                  backgroundColor: MaterialStateProperty.all(Colors.red),
                  shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                    RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                  ),
                ),
                onPressed: () {},
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: const <Widget>[
                    Icon(Icons.headphones),
                    Text('+880960-6252525'),
                  ],
                ),
              ),
            ),
            Container(
              margin: const EdgeInsets.only(
                top: 10,
                bottom: 5,
                left: 10,
                right: 10,
              ),
              height: 300,
              width: double.infinity,
              decoration: BoxDecoration(
                color: const Color(0xFFF0F3F6),
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.1),
                    spreadRadius: 1,
                    blurRadius: 2,
                    offset: const Offset(3, 3),
                  ),
                  const BoxShadow(
                    color: Colors.white,
                    blurRadius: 2,
                    spreadRadius: 1,
                    offset: Offset(-3, -3),
                  ),
                ],
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: <Widget>[
                  const Text(
                    'Insurance Details',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      decoration: TextDecoration.underline,
                      fontSize: 18,
                      color: Color(0xFF597794),
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const Text(
                    'Policy No. 1020283199774',
                    style: TextStyle(
                      fontSize: 15,
                      color: Color(0xFF597794),
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.only(left: 30),
                    width: double.infinity,
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: <Widget>[
                          Row(
                            children: const <Widget>[
                              Text(
                                'Contact Person Name: ',
                                style: TextStyle(
                                  color: Color(0xFF597794),
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              Text(
                                'Shofique Shahriar',
                                style: TextStyle(
                                  color: Color(0xFFAEB1B3),
                                  fontWeight: FontWeight.bold,
                                ),
                              )
                            ],
                          ),
                          Row(
                            children: const <Widget>[
                              Text(
                                'Contact Person Phone: ',
                                style: TextStyle(
                                  color: Color(0xFF597794),
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              Text(
                                '01723144515',
                                style: TextStyle(
                                  color: Color(0xFFAEB1B3),
                                  fontWeight: FontWeight.bold,
                                ),
                              )
                            ],
                          ),
                          Row(
                            children: const <Widget>[
                              Text(
                                'Contact Person Email: ',
                                style: TextStyle(
                                  color: Color(0xFF597794),
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              Text(
                                'test@gmail.com',
                                style: TextStyle(
                                  color: Color(0xFFAEB1B3),
                                  fontWeight: FontWeight.bold,
                                ),
                              )
                            ],
                          ),
                          Row(
                            children: const <Widget>[
                              Text(
                                'Passport Number: ',
                                style: TextStyle(
                                  color: Color(0xFF597794),
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              Text(
                                'BN1234567',
                                style: TextStyle(
                                  color: Color(0xFFAEB1B3),
                                  fontWeight: FontWeight.bold,
                                ),
                              )
                            ],
                          ),
                          Row(
                            children: const <Widget>[
                              Text(
                                'Flight Date: ',
                                style: TextStyle(
                                  color: Color(0xFF597794),
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              Text(
                                '11 May 2022',
                                style: TextStyle(
                                  color: Color(0xFFAEB1B3),
                                  fontWeight: FontWeight.bold,
                                ),
                              )
                            ],
                          ),
                          Row(
                            children: const <Widget>[
                              Text(
                                'Return Date: ',
                                style: TextStyle(
                                  color: Color(0xFF597794),
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              Text(
                                '26 May 2022',
                                style: TextStyle(
                                  color: Color(0xFFAEB1B3),
                                  fontWeight: FontWeight.bold,
                                ),
                              )
                            ],
                          ),
                          Row(
                            children: const <Widget>[
                              Text(
                                'Total Stay: ',
                                style: TextStyle(
                                  color: Color(0xFF597794),
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              Text(
                                '15 Days',
                                style: TextStyle(
                                  color: Color(0xFFAEB1B3),
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                          Row(
                            children: const <Widget>[
                              Text(
                                'Insurance Price: ',
                                style: TextStyle(
                                  color: Color(0xFF597794),
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              Text(
                                '1162 Tk',
                                style: TextStyle(
                                  color: Color(0xFFAEB1B3),
                                  fontWeight: FontWeight.bold,
                                ),
                              )
                            ],
                          ),
                          Row(
                            children: const <Widget>[
                              Text(
                                'Total Vat (15)%: ',
                                style: TextStyle(
                                  color: Color(0xFF597794),
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              Text(
                                '174.3 Tk',
                                style: TextStyle(
                                  color: Color(0xFFAEB1B3),
                                  fontWeight: FontWeight.bold,
                                ),
                              )
                            ],
                          ),
                          Row(
                            children: const <Widget>[
                              Text(
                                'Total Service Charge (10)%: ',
                                style: TextStyle(
                                  color: Color(0xFF597794),
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              Text(
                                '116.2 Tk',
                                style: TextStyle(
                                  color: Color(0xFFAEB1B3),
                                  fontWeight: FontWeight.bold,
                                ),
                              )
                            ],
                          ),
                          Row(
                            children: const <Widget>[
                              Text(
                                'Grand Total: ',
                                style: TextStyle(
                                  color: Color(0xFF597794),
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              Text(
                                '1452.5 Tk',
                                style: TextStyle(
                                  color: Color(0xFFAEB1B3),
                                  fontWeight: FontWeight.bold,
                                ),
                              )
                            ],
                          ),
                          Row(
                            children: const <Widget>[
                              Text(
                                'Payment Status: ',
                                style: TextStyle(
                                  color: Color(0xFF597794),
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              Text(
                                'Paid',
                                style: TextStyle(
                                  color: Color(0xFFAEB1B3),
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                        ]),
                  ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
