// ignore_for_file: unnecessary_new

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:instasure/domains/models/menuItesmListModel.dart';
import 'package:instasure/domains/repo/apiAuthClient.dart';
import 'package:instasure/screens/dashboard/diagnosisReportDetail.dart';
import 'package:instasure/screens/deviceInsurance/deviceInsuranceHistory.dart';
import 'package:instasure/screens/diagonostic/checkDeviceFeature.dart';
import 'package:instasure/widgets/imageWidget.dart';
import 'package:instasure/widgets/topView2.dart';
import 'package:instasure/Utilities/slideItem.dart';
import 'package:instasure/widgets/topView4.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../Utilities/homeMenu.dart';

class MobileInsurance extends StatefulWidget {
  const MobileInsurance({Key? key}) : super(key: key);

  @override
  _MobileInsuranceState createState() => _MobileInsuranceState();
}

class _MobileInsuranceState extends State<MobileInsurance> {

  SharedPreferences? preferences;
  final ApiAuthClient _apiClient = ApiAuthClient();
  bool _isShown = true;

  List<Menu> data = [];
  @override
  void initState() {
    super.initState();

    initializePreference().whenComplete((){
      setState(() {
//        this.preferences?.setInt("counter", 7);
//        this.preferences?.setString("serial_number", "zxcxzv");
      });
    });


    dataList.forEach((element) {
      data.add(Menu.fromJson(element));
    });
    //Navigator.of(context).popUntil((route) => route.isFirst);
  }


  Future<void> initializePreference() async{
    this.preferences = await SharedPreferences.getInstance();
    // this.preferences?.setString("name", "Peter");
  }

  void _diagnosisAlert(BuildContext context) {
    showDialog(
        context: context,
        builder: (context) {
          return CupertinoAlertDialog(
            title: const Text('Device Diagnosis'),
            content: const Text('Are you sure you want to device diagnosis? If yes, then please attach microphone with your device.'),
            actions: <Widget>[
              TextButton(
                  onPressed: () {
                    Navigator.pop(context);
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const CheckDeviceFeature()),
                    );
                  },
                  child: Text('Yes')),
              TextButton(
                onPressed: () {
                  Navigator.pop(context); //close Dialog
                },
                child: Text('No'),
              )
            ],
          );
        });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
          child: Padding(
        padding: const EdgeInsets.all(0),
        child: Column(
          children: [
            Stack(
              children: [
                const TopView4(),
                Positioned(
                  bottom: 20.0,
                  left: 40.0,
                  child: SizedBox(
                      height: 30,
                      width: 30,
                      // color: const Color.fromRGBO(0, 46, 91, 1.0),
                      // padding: const EdgeInsets.fromLTRB(10, 15, 10, 5),
                      child: TextButton(
                        child: Image.asset('assets/back_button_icon.png'),
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                      )),
                )
              ],
            ),
            Expanded(
              child: ListView(
                children: <Widget>[
                  const SizedBox(height: 0.0),
                  createHeaderWidget(),
                  const SizedBox(height: 20.0),
                  createCoverageWidget(),
                  const SizedBox(height: 20.0),
                  buildProtectionSlideList(),
                  const SizedBox(
                    height: 20,
                  ),
                  const Center(
                      child: Text(
                    'Our Claim Conditions',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontFamily: 'Roboto Slab',
                      fontSize: 16,
                      color: Color(0xff002E5B),
                    ),
                  )),
                  const SizedBox(
                    height: 20,
                  ),
                  buildClaimConditionSlideList(),
                  const SizedBox(
                    height: 20,
                  ),
                  buildMiddleWidget(),
                  const SizedBox(
                    height: 30,
                  ),
                  const Center(
                      child: Text(
                    'Buying is as easy as 1-2-3',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontFamily: 'Roboto Slab',
                      fontSize: 16,
                      color: Color(0xff002E5B),
                    ),
                  )),
                  const SizedBox(
                    height: 30,
                  ),
                  buildBuyingStepSlideList(),
                  const SizedBox(
                    height: 30,
                  ),
                  buildBottomWidget(),
                  const SizedBox(
                    height: 50,
                  ),
                ],
              ),
            ),
          ],
        ),
      )),
      backgroundColor: const Color(0xFFEFF7FF),
    );
  }

  createHeaderWidget() {
    return Container(
      height: 38,
      child: const Center(
        child: Text(
          'Insurance Coverage for your Phones',
          textAlign: TextAlign.center,
          style: TextStyle(
            fontFamily: 'Roboto Slab',
            fontSize: 16,
            color: Color(0xff002E5B),
          ),
        ),
      ),
      decoration: const BoxDecoration(color: Color(0xffF0F3F6), boxShadow: [
        BoxShadow(
            color: Color(0xffffffff),
            blurRadius: 6,
            spreadRadius: 0,
            offset: Offset(-3, -3)),
        BoxShadow(
            color: Color(0xffDDE4EF),
            blurRadius: 6,
            spreadRadius: 0,
            offset: Offset(3, 3)),
      ]),
    );
  }

  createCoverageWidget() {
    return Padding(
        padding: const EdgeInsets.only(left: 20, right: 20),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ImageWidget(
                  imagePath: 'assets/insurance_coverage.png',
                  onClicked: () async {},
                  imageHeight: 152,
                  imageWidth: 152,
                  borderWidth: 15,
                  borderRadious: 40,
                ),
                const SizedBox(
                  width: 10,
                ),
                Expanded(
                    child: RichText(
                  text: const TextSpan(
                    style: TextStyle(color: Colors.black, fontSize: 16),
                    children: <TextSpan>[
                      TextSpan(
                          text:
                              'You re Gonna Drop Your Phone either on Floor or in Water',
                          style: TextStyle(color: Colors.black)),
                      TextSpan(
                          text:
                              'When you do, instasure covers the cost to fix your phone. No hidden fees. No Hassles. Traditional Device Protection Programs are expensive, full of hidden fees, complicated, and overly time consuming. So, we decided to turn the old model on its head and created a Device Protection Program that is low cost, simple to understand, and provides Bangladeshi s the coverage they really need. We cover whatever breaks or damage including theft.',
                          style: TextStyle(color: Colors.black, fontSize: 11)),
                    ],
                  ),
                ))
              ],
            ),
            const SizedBox(
              height: 30,
            ),
             Align(
              alignment: Alignment.centerRight,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Container(
                    height: 38,
                    width: 170,
                    child: TextButton(
                      child: const Text(
                        'Purchase History',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontFamily: 'Roboto Slab',
                          fontSize: 12,
                          color: Colors.white,
                        ),
                      ),
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => const DeviceInsuranceHistory()),
                        );
                      },
                    ),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [
                        BoxShadow(
                            color: const Color(0xff000000).withOpacity(0.16),
                            blurRadius: 3,
                            spreadRadius: 0,
                            offset: const Offset(0, 3)),
                      ],
                      color: const Color(0xff002E5B),
                    ),
                  ),

                  const SizedBox(
                    width: 10
                    ,
                  ),
                  Container(
                    height: 38,
                    width: 170,
                    child: TextButton(
                      child: const Text(
                        'Buy Now',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontFamily: 'Roboto Slab',
                          fontSize: 12,
                          color: Colors.white,
                        ),
                      ),
                      onPressed: () {

                        //this.preferences.getBool(Constant().IS_TESTING)
                        if(this.preferences?.getString("serial_number")==''){
                          print(1);
                        }
                        else if(this.preferences?.getString("serial_number")==null){
                          _diagnosisAlert(context);

                        }else if(this.preferences?.getString("serial_number")!=null){
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => DiagnosisReportDetail(
                                  id: "${this.preferences?.getString("serial_number")}",
                                )),
                          );
                        }else if(this.preferences?.getString("serial_number")!=''){
                          print(4);
                        }else{
                          print(5);
                        }
                      },
                    ),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [
                        BoxShadow(
                            color: const Color(0xff000000).withOpacity(0.16),
                            blurRadius: 3,
                            spreadRadius: 0,
                            offset: const Offset(0, 3)),
                      ],
                      color: const Color(0xff002E5B),
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(
              height: 30,
            ),

            const Center(
                child: Text(
              'Our Protection Plans',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontFamily: 'Roboto Slab',
                fontSize: 16,
                color: Color(0xff002E5B),
              ),
            )),
          ],
        ));
  }

  buildProtectionSlideList() {
    return Padding(
      padding: const EdgeInsets.only(right: 5, left: 15),
      child: SizedBox(
        height: (MediaQuery.of(context).size.width - 50) / 3,
        width: (MediaQuery.of(context).size.width - 50) / 3,
        child: ListView.builder(
          primary: false,
          scrollDirection: Axis.horizontal,
          shrinkWrap: true,
          itemCount: protectionPlans.length,
          itemBuilder: (BuildContext context, int index) {
            var protectionPlan = protectionPlans[index];

            return Padding(
              padding: const EdgeInsets.only(right: 10, left: 0),
              child: Container(
                width: (MediaQuery.of(context).size.width - 50) / 3,
                alignment: Alignment.center,
                padding: const EdgeInsets.all(5),
                child: GestureDetector(
                  onTap: () {},
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Image(
                        image: AssetImage(protectionPlan['img']),
                        height: 60,
                        // fit: BoxFit.cover,
                      ),
                      const SizedBox(
                        height: 5,
                      ),
                      Text(protectionPlan['title'],
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            fontFamily: 'Roboto Slab',
                            fontSize: 8,
                            color: Color(0xff002E5B),
                          )),
                      Text(
                        protectionPlan['subTitle'],
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          fontFamily: 'Roboto Slab',
                          fontSize: 6,
                          color: Color(0xff86888A),
                        ),
                      ),
                      const SizedBox(height: 0.0),
                    ],
                  ),
                ),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(40),
                  boxShadow: [
                    BoxShadow(
                        color: const Color(0xff000000).withOpacity(0.16),
                        blurRadius: 6,
                        spreadRadius: 0,
                        offset: const Offset(-3, -3)),
                  ],
                  color: const Color(0xffF0F3F6),
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  buildClaimConditionSlideList() {
    return Padding(
      padding: const EdgeInsets.only(right: 5, left: 15),
      child: SizedBox(
        height: (MediaQuery.of(context).size.width - 50) / 3,
        width: (MediaQuery.of(context).size.width - 50) / 3,
        child: ListView.builder(
          primary: false,
          scrollDirection: Axis.horizontal,
          shrinkWrap: true,
          itemCount: claimConditions.length,
          itemBuilder: (BuildContext context, int index) {
            var claimCondition = claimConditions[index];

            return Padding(
              padding: const EdgeInsets.only(
                right: 10,
              ),
              child: Container(
                width: (MediaQuery.of(context).size.width - 50) / 3,
                alignment: Alignment.center,
                padding: const EdgeInsets.all(5),
                child: GestureDetector(
                  onTap: () {},
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Image(
                        image: AssetImage(claimCondition['img']),
                        height: 60,
                        // fit: BoxFit.cover,
                      ),
                      const SizedBox(
                        height: 5,
                      ),
                      Text(claimCondition['title'],
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            fontFamily: 'Roboto Slab',
                            fontSize: 8,
                            color: Color(0xff002E5B),
                          )),
                      Text(
                        claimCondition['subTitle'],
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          fontFamily: 'Roboto Slab',
                          fontSize: 6,
                          color: Color(0xff86888A),
                        ),
                      ),
                      const SizedBox(height: 0.0),
                    ],
                  ),
                ),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(40),
                  boxShadow: [
                    BoxShadow(
                        color: const Color(0xff000000).withOpacity(0.16),
                        blurRadius: 6,
                        spreadRadius: 0,
                        offset: const Offset(-3, -3)),
                  ],
                  color: const Color(0xffF0F3F6),
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  buildMiddleWidget() {
    return Padding(
        padding: const EdgeInsets.only(left: 20, right: 20),
        child: Column(
          children: [
            const Center(
                child: Text(
              'What s great about Mobile \nPhone Insurance by InstaSure?',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontFamily: 'Roboto Slab',
                fontSize: 16,
                color: Color(0xff002E5B),
              ),
            )),
            const SizedBox(
              height: 30,
            ),
            ImageWidget(
              imagePath: 'assets/hand_mobile.png',
              onClicked: () async {},
              imageHeight: 152,
              imageWidth: 152,
              borderWidth: 13,
              borderRadious: 40,
            ),
            const SizedBox(height: 20.0),
            const Center(
                child: Text(
              'Advantages Of InstaSure \nInternational Travel Insurance',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontFamily: 'Roboto Slab',
                fontSize: 16,
                color: Color(0xff002E5B),
              ),
            )),
            const SizedBox(
              height: 10,
            ),
            RichText(
              text: const TextSpan(
                style: TextStyle(color: Colors.black, fontSize: 13),
                children: <TextSpan>[
                  TextSpan(
                      text: 'New & Used phones -',
                      style: TextStyle(color: Color(0xFF002E5B))),
                  TextSpan(
                      text:
                          'Now mobile insurance for brand new phones as well as old/used ones (max 13 months).',
                      style: TextStyle(color: Color(0xFF86888A), fontSize: 11)),
                ],
              ),
            ),
            const SizedBox(
              height: 5,
            ),
            RichText(
              text: const TextSpan(
                style: TextStyle(color: Colors.black, fontSize: 13),
                children: <TextSpan>[
                  TextSpan(
                      text: 'Screen/Physical and Liquid Damage/Theft covered -',
                      style: TextStyle(color: Color(0xFF002E5B))),
                  TextSpan(
                      text:
                          'Screen damages are the most common of all heartbreaks! All screen damages due to accidental or liquid damage are covered! Also any other physical or liquid damage to phone set and theft is also covered under different protection plan.',
                      style: TextStyle(color: Color(0xFF86888A), fontSize: 11)),
                ],
              ),
            ),
            const SizedBox(
              height: 5,
            ),
            RichText(
              text: const TextSpan(
                style: TextStyle(color: Colors.black, fontSize: 13),
                children: <TextSpan>[
                  TextSpan(
                      text: 'Low prices -',
                      style: TextStyle(color: Color(0xFF002E5B))),
                  TextSpan(
                      text:
                          'Buy this mobile insurance cover at almost the cost of a Screen Guard !',
                      style: TextStyle(color: Color(0xFF86888A), fontSize: 11)),
                ],
              ),
            ),
            const SizedBox(
              height: 5,
            ),
            RichText(
              text: const TextSpan(
                style: TextStyle(color: Colors.black, fontSize: 13),
                children: <TextSpan>[
                  TextSpan(
                      text: 'Country wide cover - ',
                      style: TextStyle(color: Color(0xFF002E5B))),
                  TextSpan(
                      text:
                          'Travel around the country worry-free. Our mobile insurance policy is valid everywhere.',
                      style: TextStyle(color: Color(0xFF86888A), fontSize: 11)),
                ],
              ),
            ),
            const SizedBox(
              height: 5,
            ),
            RichText(
              text: const TextSpan(
                style: TextStyle(color: Colors.black, fontSize: 13),
                children: <TextSpan>[
                  TextSpan(
                      text: 'IMEI and NID linked cover -',
                      style: TextStyle(color: Color(0xFF002E5B))),
                  TextSpan(
                      text:
                          'Whether you use the phone or your family or friend does, this mobile insurance policy will be valid for all. It is linked to the IMEI of the phone & NID of a family member.',
                      style: TextStyle(color: Color(0xFF86888A), fontSize: 11)),
                ],
              ),
            ),
            const SizedBox(
              height: 5,
            ),
            RichText(
              text: const TextSpan(
                style: TextStyle(color: Colors.black, fontSize: 13),
                children: <TextSpan>[
                  TextSpan(
                      text: 'Protection up to Sum Insured -',
                      style: TextStyle(color: Color(0xFF002E5B))),
                  TextSpan(
                      text:
                          'At the time of buying, we will show you an amount, called Sum Insured. Post claim approval, you can get your repair costs reimbursed up to your respective sum insured.',
                      style: TextStyle(color: Color(0xFF86888A), fontSize: 11)),
                ],
              ),
            ),
          ],
        ));
  }

  buildBuyingStepSlideList() {
    return SizedBox(
      height: 180,
      width: (MediaQuery.of(context).size.width - 30) / 3,
      child: ListView.builder(
        primary: false,
        scrollDirection: Axis.horizontal,
        shrinkWrap: true,
        itemCount: buyingSteps.length,
        itemBuilder: (BuildContext context, int index) {
          var buyingStep = buyingSteps[index];

          return Padding(
            padding: const EdgeInsets.only(right: 5, left: 5),
            child: Container(
              width: (MediaQuery.of(context).size.width - 30) / 3,
              alignment: Alignment.center,
              padding: const EdgeInsets.all(0),
              child: GestureDetector(
                onTap: () {},
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    ImageWidget(
                      imagePath: buyingStep['img'],
                      onClicked: () async {},
                      imageHeight: 118,
                      imageWidth: 118,
                      borderWidth: 13,
                      borderRadious: 40,
                    ),
                    const SizedBox(
                      height: 5,
                    ),
                    Text(buyingStep['title'],
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          fontFamily: 'Roboto Slab',
                          fontSize: 16,
                          color: Color(0xff002E5B),
                        )),
                    const SizedBox(
                      height: 10,
                    ),
                    Text(
                      buyingStep['subTitle'],
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        fontFamily: 'Roboto Slab',
                        fontSize: 10,
                        color: Color(0xff86888A),
                      ),
                    ),
                    const SizedBox(height: 0.0),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  buildBottomWidget() {
    return Padding(
        padding: const EdgeInsets.only(left: 20, right: 20),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              // flex: 2,
              child: Column(
                children: [
                  const Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      'And, how to Claim for your \nMobile Insurance?',
                      textAlign: TextAlign.left,
                      style: TextStyle(
                        fontFamily: 'Roboto Slab',
                        fontSize: 16,
                        color: Color(0xff002E5B),
                      ),
                    ),
                  ),
                  const SizedBox(height: 5.0),
                  RichText(
                    text: const TextSpan(
                      style: TextStyle(color: Colors.black, fontSize: 13),
                      children: <TextSpan>[
                        TextSpan(
                            text: 'Step 1 -',
                            style: TextStyle(color: Color(0xFF002E5B))),
                        TextSpan(
                            text:
                                '- Tell us about your heartbreak: Call us at 096 06 252525 within 24 hours of the accident or fill up the claim form on our web site www.instasure.xyz',
                            style: TextStyle(
                                color: Color(0xFF86888A), fontSize: 11)),
                      ],
                    ),
                  ),
                  const SizedBox(height: 5.0),
                  RichText(
                    text: const TextSpan(
                      style: TextStyle(color: Colors.black, fontSize: 13),
                      children: <TextSpan>[
                        TextSpan(
                            text: 'Step 2 -',
                            style: TextStyle(color: Color(0xFF002E5B))),
                        TextSpan(
                            text:
                                'Go to Nearest Service center: You can also raise claim by visiting nearest authorized service center.',
                            style: TextStyle(
                                color: Color(0xFF86888A), fontSize: 11)),
                      ],
                    ),
                  ),
                  const SizedBox(height: 5.0),
                  RichText(
                    text: const TextSpan(
                      style: TextStyle(color: Colors.black, fontSize: 13),
                      children: <TextSpan>[
                        TextSpan(
                            text: 'Step 3 - ',
                            style: TextStyle(color: Color(0xFF002E5B))),
                        TextSpan(
                            text:
                                'For Theft: Go to our web site, fill up the claim form and attach scan copy of FIR and sim replacement copy. Once approved, send original FIR and SIM replacement copy to our address. You will get payment according to depreciated value within 20 working days.',
                            style: TextStyle(
                                color: Color(0xFF86888A), fontSize: 11)),
                      ],
                    ),
                  ),
                  const SizedBox(height: 5.0),
                  RichText(
                    text: const TextSpan(
                      style: TextStyle(color: Colors.black, fontSize: 13),
                      children: <TextSpan>[
                        TextSpan(
                            text: 'Step 4 - ',
                            style: TextStyle(color: Color(0xFF002E5B))),
                        TextSpan(
                            text:
                                'Travel around the country worry-free. Our mobile insurance policy is valid everywhere.',
                            style: TextStyle(
                                color: Color(0xFF86888A), fontSize: 11)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(
              width: 10,
            ),
            ImageWidget(
              imagePath: 'assets/cliams_approved.png',
              onClicked: () async {},
              imageHeight: 152,
              imageWidth: 152,
              borderWidth: 13,
              borderRadious: 40,
            ),
          ],
        ));
  }
}
