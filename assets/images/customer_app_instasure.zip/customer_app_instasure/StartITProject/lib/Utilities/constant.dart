class Constants {
 static const BASE_URL = 'https://instasure.xyz/api/';
 //static const BASE_URL = 'https://dns.staritltd.shop/api/';

  static String USER_KEY = "USER";
  static String TOKEN_KEY = "TOKEN";
  static String FirstLaunch = "FIRSTLAUNCH";
}
