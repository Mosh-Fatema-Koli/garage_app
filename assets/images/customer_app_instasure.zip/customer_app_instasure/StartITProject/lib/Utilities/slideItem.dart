import 'package:flutter/material.dart';

List homeSlideMenus = [
  'About Us',
  'Partner \n  Program',
  'Terms & Conditions',
];

List icons = [
  Icons.directions_bike,
  Icons.directions_boat,
  Icons.directions_bus,
];

List images = [
  "assets/about_us.png",
  "assets/partner_program.png",
  "assets/terms_and_conditions.png"
];

List protectionPlans = [
  {
    "title": "SCREEN PROTECTION",
    "subTitle": "12 months Validity - 1 or 2 Times",
    "img": "assets/screen_protection.png"
  },
  {
    "title": "DAMAGE",
    "subTitle": "12 months validity - multiple times",
    "img": "assets/theft.png"
  },
  {
    "title": "THEFT",
    "subTitle": "12 months validity - Depreciated Value",
    "img": "assets/damage.png"
  },
];

List claimConditions = [
  {
    "title": "APPROVAL",
    "subTitle": "Typical Claim approval time is \nmax 24 hours",
    "img": "assets/insurance_claim_approved.png"
  },
  {
    "title": "DEDUCTIBLES",
    "subTitle": "500 tk or 10% of the claim value\n(whichever is lower)",
    "img": "assets/deductibles.png"
  },
  {
    "title": "SERVICE CENTER",
    "subTitle":
        "Only authorized service center is \nallowed to provide service",
    "img": "assets/service-center.png"
  },
];
