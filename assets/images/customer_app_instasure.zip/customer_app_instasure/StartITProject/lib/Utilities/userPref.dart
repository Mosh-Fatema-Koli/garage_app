import 'package:injectable/injectable.dart';
import 'constant.dart';
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:instasure/domains/models/auth/user.dart';

@singleton
class UserPref {
  UserPref();

  void saveFirstLaunch(bool firstLaunch) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(Constants.FirstLaunch, firstLaunch);
  }

  Future<bool> isFirstLaunch() async {
    final prefs = await SharedPreferences.getInstance();

    if (prefs.containsKey(Constants.FirstLaunch)) {
      return prefs.getBool(Constants.FirstLaunch)!;
    } else {
      return true;
    }
  }

  Future<String?>? get token {
    Future<String?> _token = getTokenFromPref();
    return _token;
  }

  void saveTokenInPref(String token) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(Constants.TOKEN_KEY, token);
  }

  Future<String?> getTokenFromPref() async {
    final prefs = await SharedPreferences.getInstance();

    if (prefs.containsKey(Constants.TOKEN_KEY)) {
      return prefs.getString(Constants.TOKEN_KEY);
    } else {
      return null;
    }
  }

  void removeTokenFromPref() async {
    final prefs = await SharedPreferences.getInstance();

    prefs.remove(Constants.TOKEN_KEY);
  }

  Future<User?> getUserFromPref() async {
    final prefs = await SharedPreferences.getInstance();

    //Convert user object into String to save it to pref.
    if (prefs.containsKey(Constants.USER_KEY)) {
      return User.fromJson(json.decode(prefs.getString(Constants.USER_KEY)!));
    }
    return null;
  }

  // final body = json.decode(response.body);
  void saveUserInPref(User _user) async {
    final prefs = await SharedPreferences.getInstance();
    //Convert user object into String to save it to pref.
    prefs.setString(Constants.USER_KEY, json.encode(_user.toJson()));
  }

  void removeUserFromPref() async {
    final prefs = await SharedPreferences.getInstance();

    prefs.remove(Constants.USER_KEY);
  }
}
