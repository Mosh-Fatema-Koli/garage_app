import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

void navigateTo({
  required BuildContext context,
  required Widget screen,
}) {
  Navigator.of(context).push(
    MaterialPageRoute(builder: (context) => screen),
  );
}

void navigateAndFinish({
  required BuildContext context,
  required Widget screen,
}) {
  Navigator.of(context).pushReplacement(
    MaterialPageRoute(builder: (context) => screen),
  );
}

void showSnackBar({
  required BuildContext context,
  required String content,
}) {
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(content: Text(content)),
  );
}

String getDateString(String date, String format) {
  // date = '2021-01-26T03:17:00.000000Z';
  DateTime parseDate = DateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").parse(date);
  var inputDate = DateTime.parse(parseDate.toString());
  var outputFormat = DateFormat(format);
  var outputDate = outputFormat.format(inputDate);
  return outputDate;
}

String getDateStringFRom(
    String date, String inputFormat, String _outputFormat) {
  // date = '2021-01-26T03:17:00.000000Z';
  DateTime parseDate = DateFormat(inputFormat).parse(date);
  var inputDate = DateTime.parse(parseDate.toString());
  var outputFormat = DateFormat(_outputFormat);
  var outputDate = outputFormat.format(inputDate);
  return outputDate;
}

Color getColorFromStatus(String status) {
  if (status == "unpaid") {
    return const Color(0xFFE92929);
  } else if (status == "paid") {
    return const Color(0xFF31D601);
  } else if (status == "pending") {
    return const Color(0xFFF8E00B);
  } else if (status == "disbursed") {
    return const Color(0xffE92929);
  }
  return const Color(0xffE92929);
}
