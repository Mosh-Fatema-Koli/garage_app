import 'package:flutter/material.dart';
import 'package:instasure/Utilities/menuList.dart';

class ProfileAttribute {
  String name;
  String image;
  bool isEnable;
  profileAttributesTypes type;

  ProfileAttribute(
      {required this.name,
      required this.image,
      required this.isEnable,
      required this.type});
  static List<ProfileAttribute> getProfileAttributes() {
    return <ProfileAttribute>[
     ProfileAttribute(
          name: "User Type:",
          image: "assets/profile/usertype_icon.png",
          isEnable: false,
          type: profileAttributesTypes.none),
      ProfileAttribute(
          name: "Name",
          image: "assets/profile/user_icon.png",
          isEnable: false,
          type: profileAttributesTypes.none),
      ProfileAttribute(
          name: "Phone",
          image: "assets/profile/phone_icon.png",
          isEnable: false,
          type: profileAttributesTypes.none),
      ProfileAttribute(
          name: "Email",
          image: "assets/profile/email_icon.png",
          isEnable: true,
          type: profileAttributesTypes.none),
      ProfileAttribute(
          name: "Passport Number",
          image: "assets/profile/passport_icon.png",
          isEnable: true,
          type: profileAttributesTypes.none),
      ProfileAttribute(
          name: "Date Of Birth",
          image: "assets/profile/calendar_icon.png",
          isEnable: false,
          type: profileAttributesTypes.dateOfBirth),
      ProfileAttribute(
          name: "Address",
          image: "assets/profile/address_icon.png",
          isEnable: true,
          type: profileAttributesTypes.none),
      ProfileAttribute(
          name: "Passport",
          image: "assets/profile/passport_icon.png",
          isEnable: false,
          type: profileAttributesTypes.passport),
      ProfileAttribute(
          name: "NID",
          image: "assets/profile/nid_icon.png",
          isEnable: false,
          type: profileAttributesTypes.nid),
      ProfileAttribute(
          name: "Driving Licence",
          image: "assets/profile/car_icon.png",
          isEnable: false,
          type: profileAttributesTypes.drivingLincence),
      ProfileAttribute(
          name: "Profile Update",
          image: "assets/profile/car_icon.png",
          isEnable: false,
          type: profileAttributesTypes.none),
    ];
  }
}
