import 'package:flutter/material.dart';

List homeMenus = [
  {
    "name": "Mobile\nInsurance",
    "img": "assets/mobile_insurance.png"
  },
  {
    "name": "Travel\nInsurance",
    "img": "assets/interNational_yravel_insurance.png"
  },
  {
    "name": "Tour\nInsurance",
    "img": "assets/tour.png"
  },
  {
    "name": "Trip\nInsurance",
    "img": "assets/trip.png"
  },

  {
    "name": "Student\nInsurance",
    "img": "assets/student.png"
  },

  {"name": "Motor \nInsurance", "img": "assets/car_insurance.png"},

  {"name": "Health \nInsurance", "img": "assets/health_insurance.png"},
  {"name": "Life \nInsurance", "img": "assets/life_insurance.png"},
  {"name": "Agriculture \nInsurance", "img": "assets/agriculture_insurance.png"},

  {"name": "Home \nInsurance", "img": "assets/home_insurance.png"},
  {"name": "Upcomming \nProducts", "img": "assets/bg_insurance.png"},
];

List dashBoardMenus = [
  {"name": "Total \nMedical Insurance", "img": "assets/dashboard_menu.png"},
  {"name": "Total \nDevice Insurance", "img": "assets/dashboard_menu.png"},
  {"name": "Total \nDevice Claim", "img": "assets/dashboard_menu.png"},
  {"name": "Total \nDevice Claim\nRequst", "img": "assets/dashboard_menu.png"},
];

List claimedSteps = [
  {
    "name": "Initiate\nRequest",
    "step": "Step - 1",
    "img": "assets/request.jpeg"
  },
  {
    "name": "Submit\nDocuments",
    "step": "Step - 2",
    "img": "assets/document.jpeg"
  },
  {
    "name": "Repair\nReimbursement",
    "step": "Step - 3",
    "img": "assets/repair.jpeg"
  },
  {
    "name": "Enjoy\nBenefits",
    "step": "Step - 4",
    "img": "assets/benefits.jpeg"
  },
];

List serviceCenters = [
  {
    "type": "Service Center",
    "name": "Vivo Service Center",
    "centerIcon": "assets/centername_icon.png",
    "location": "12/15, Dhanmondi-32, Dhaka-1209",
    "locIcon": "assets/location_icon.png",
    "phone": "01911505050",
    "phoneIcon": "assets/email_icon.png",
    "email": "service@vivo.com",
    "emailIcon": "assets/phone_icon.png"
  },
  {
    "type": "Service Center",
    "name": "Vivo Service Center",
    "centerIcon": "assets/centername_icon.png",
    "location": "12/15, Dhanmondi-32, Dhaka-1209",
    "locIcon": "assets/location_icon.png",
    "phone": "01911505050",
    "phoneIcon": "assets/email_icon.png",
    "email": "service@vivo.com",
    "emailIcon": "assets/phone_icon.png"
  },
  {
    "type": "Collection Center",
    "name": "Vivo Service Center",
    "centerIcon": "assets/centername_icon.png",
    "location": "12/15, Dhanmondi-32, Dhaka-1209",
    "locIcon": "assets/location_icon.png",
    "phone": "01911505050",
    "phoneIcon": "assets/email_icon.png",
    "email": "service@vivo.com",
    "emailIcon": "assets/phone_icon.png"
  },
];

List myInsuranceList = [
  'TRAVEL INSURANCE',
  'DEVICE INSURANCE',
];

List insuranceHistories = [
  {
    "date": "10 May 2022",
    "plan": "NON-SCHENGEN PLAN A\n(WORLDWIDE EXCLUDING USA AND CANADA)",
    "payment_status": "Un Paid",
  },
  {
    "date": "10 May 2022",
    "plan": "NON-SCHENGEN PLAN A\n(WORLDWIDE EXCLUDING USA AND CANADA)",
    "payment_status": "Un Paid",
  },
  {
    "date": "10 May 2022",
    "plan": "NON-SCHENGEN PLAN A\n(WORLDWIDE EXCLUDING USA AND CANADA)",
    "payment_status": "Expired",
  },
  {
    "date": "10 May 2022",
    "plan": "NON-SCHENGEN PLAN A\n(WORLDWIDE EXCLUDING USA AND CANADA)",
    "payment_status": "Paid",
  },
  {
    "date": "10 May 2022",
    "plan": "NON-SCHENGEN PLAN A\n(WORLDWIDE EXCLUDING USA AND CANADA)",
    "payment_status": "Un Paid",
  },
  {
    "date": "10 May 2022",
    "plan": "NON-SCHENGEN PLAN A\n(WORLDWIDE EXCLUDING USA AND CANADA)",
    "payment_status": "Un Paid",
  },
];

var customerInfo = {
  "type": "DETAILS",
  "name": "Vivo Service Center",
  "phone": "01911505050",
  "email": "service@vivo.com",
  "age": "31 Years",
};

var flightDetailInfo = {
  "type": "FLIGHT DETAILS",
  "passportNumber": "BN1234567",
  "passportExpirayDate": "01 January 2023",
  "flightNumber": "074",
  "flightDate": "01 January 2023",
  "flightReturnDate": "16 January 2023",
  "totalStay": "15 days",
};

var priceEvaluation = {
  "type": "PRICE EVALUATION",
  "insurancePrice": "1000tk",
  "totalVat(15%)": "150tk",
  "totalServiceCharge(10%)": "100tk",
  "grandTotal": "1250tk",
  "paymentStatus": "Unpaid",
};

var deviceInfo = {
  "type": "DEVICE INFO",
  "name": "Xiaomi Note 9 Pro",
  "brand": "Xiaomi",
  "model": "Xiaomi Redmi 10A",
  "price": "10000tk",
};

List buyingSteps = [
  {
    "title": "STEP 1",
    "subTitle": "A quick 'Screen Test' \nof your phone",
    "img": "assets/screen_test.png"
  },
  {
    "title": "STEP 2",
    "subTitle": "An External Check",
    "img": "assets/external_check.png"
  },
  {
    "title": "STEP 3",
    "subTitle": "Complete Payment",
    "img": "assets/complete_payment.png"
  },
];
