List menuList = [
  'Dashboard',
  'Profile Manage',
  'Diagnosis Report List',
  'Get Travel Insurance',
  'Travel Insurance History',
  'Device Diagnosis',
  'Device Insurance History',
  'Device Insurance Claim Requests',
  'Device Insurance Claim History',
  //'Collection & Service Center',
  //'Delivery Process',
  //'Claim',
  //'Blog',
  'Change Password',
  'Sign Out'
];

enum menu_list {
  dashboard,
  profile,
  diagnosisReportList,
  getTravelInsurance,
  travelInsuranceHistory,
  deviceDiagnosis,
  deviceInsuranceHistory,
  deviceInsuranceClaimRequest,
  deviceInsuranceClaimHistory,
  // collectAndServiceCenter,
  // deliveryProcess,
  //claim,
  // blog,
  chanePassword,
  signOut,
}

enum profileAttributesTypes {
  none,
  passport,
  nid,
  drivingLincence,
  dateOfBirth,
}
