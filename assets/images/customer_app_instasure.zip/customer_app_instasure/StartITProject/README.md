# instasure

Website address with all kind of access 

	http://dns.starit-ltd.xyz/
	
	
	Parent dealer phone 		: 01222222222
	Childe dealer phone 		: 01333333333
	Customer phone 				: 01555555555

	Common pass  for all		: 123456
	
App Design : https://xd.adobe.com/view/445125c6-ef3f-4709-8506-da5b5785eaaa-1102/

API :  baseURL:	https://dns.staritltdtest.website/api 
	[ postman collection in documents directory ]
 
